package image

import (
	"encoding/json"
	"errors"
	"fmt"
	"github.com/sirupsen/logrus"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"net/http"
)

type branchAdParams struct {
	CategoryID    int      `json:"category_id"`
	CategoryTitle string   `json:"category_title"`
	CategoryDisk  string   `json:"category_disk"`
	CenterPlanID  int      `json:"center_plan_id"`
	BranchPlanID  int      `json:"branch_plan_id"`
	CenterImages  []string `json:"center_images"`
	BranchImages  []string `json:"branch_images"`
}

// Overview 门店更新广告
func Overview() {
	fmt.Println("over view")
	url := fmt.Sprintf("%s/api/support/branch/ad?branch_id=%s", config.Setting.Centre.Domain, config.Setting.Centre.Salt)

	response, err := util.HTTPGet(url)
	if err != nil {
		logger.Entry().WithError(err).WithField("url", url).Error("[门店广告任务] 获取门店广告图信息错误")
		return
	}

	var params struct {
		Code int              `json:"code"`
		Data []branchAdParams `json:"data"`
	}

	if err := json.Unmarshal(response, &params); nil != err {
		logger.Entry().WithError(err).WithField("response", string(response)).Error("[门店广告任务] 解析返回信息错误")
		return
	}

	dealBranchAd(params.Data)
}

type branchAdResponse struct {
	Params        branchAdParams `json:"params"`
	CenterSuccess bool           `json:"center_success"`
	BranchSuccess bool           `json:"branch_success"`
}

func dealBranchAd(items []branchAdParams) {
	var response []branchAdResponse
	for _, item := range items {
		logger.Entry().WithField("params", item).Info("[门店广告任务] 开始处理门店广告图信息")

		//if err := util.Mkdir(item.CategoryDisk); nil != err {
		//	logger.Entry().WithError(err).Error("[门店广告任务] 初始文件夹失败")
		//	continue
		//}
		//item.CategoryDisk = `/home/hyc/GolandProjects/song-system/storage/ad`
		tempDir := fmt.Sprintf("%s-temp", item.CategoryDisk)
		if err := dealTempDir(tempDir); nil != err {
			logger.Entry().WithError(err).Error("[门店广告任务] 初始临时文件夹失败")
			continue
		}

		data := branchAdResponse{
			Params:        item,
			CenterSuccess: false,
			BranchSuccess: false,
		}
		// todo 失败调用 util.DelDir 删除临时文件夹
		if err := downloadImages(item.CenterImages, tempDir); nil != err {
			logger.Entry().WithError(err).Error("[门店广告任务] 处理总部失败")
			continue
		}
		data.CenterSuccess = true

		if err := downloadImages(item.BranchImages, tempDir); nil != err {
			logger.Entry().WithError(err).Error("[门店广告任务] 处理门店失败")
			continue

		}
		data.BranchSuccess = true

		// move
		if err := dealImageDir(tempDir, item.CategoryDisk); nil != err {
			logger.Entry().WithError(err).Error("[门店广告任务] 处理图片文件失败")
			continue
		}

		response = append(response, data)
	}

	url := fmt.Sprintf("%s/api/support/branch/ad", config.Setting.Centre.Domain)
	params := util.Params{}
	params.Set("branch_id", config.Setting.Centre.Salt)
	params.Set("params", response)

	res, err := util.HTTPPost(url, params, http.StatusNoContent)
	logger.Entry().WithField("response", string(res)).Info("[门店广告任务] 回传响应返回")
	if err != nil {
		return
	}

	fmt.Println(string(res))

}

func downloadImages(images []string, disk string) error {
	oss := util.NewAliyunOss(config.Setting.Aliyun.Oss)

	for _, image := range images {
		ossFile := fmt.Sprintf("%s/%s", config.Setting.Aliyun.Oss.Ad, image)
		localFile := fmt.Sprintf("%s/%s", disk, image)
		logger.Entry().WithField("oss file", ossFile).WithField("local file", localFile).Info("下载文件")

		crc64, err := oss.GetToFile(localFile, ossFile)
		if err != nil {
			return fmt.Errorf("下载文件错误,file:%s,err:%s", image, err.Error())
		}

		localCrc64, e := util.FileCRC64String(localFile)
		if e != nil {
			return fmt.Errorf("校验本地md5错误,file:%s, err:%s", image, e.Error())
		}

		logger.Entry().WithFields(logrus.Fields{
			"local":       localFile,
			"oss":         ossFile,
			"oss_crc64":   crc64,
			"local_crc64": localCrc64,
		}).Info("校验文件crc64")

		if localCrc64 != crc64 {
			return errors.New("校验hash crc64错误")
		}
	}
	return nil
}

func dealTempDir(dir string) error {
	if err := util.DelDir(dir); nil != err {
		return err
	}

	return util.Mkdir(dir)
}

func dealImageDir(tempDir string, imageDir string) error {
	// 判断文件夹存在
	exists, err := util.FileExists(imageDir)
	if err != nil {
		return err
	}

	// 不存在
	if !exists {
		return util.MvFile(tempDir, imageDir)
	}

	if _, err := util.DiffDir(imageDir, tempDir); nil == err {
		logger.Entry().WithField("image dir", imageDir).WithField("temp dir", tempDir).Info("[门店广告任务] 内容相同 跳过")
		return nil
	}

	//存在 备份
	backDir := fmt.Sprintf("%s-back", imageDir)
	if err := util.DelDir(backDir); nil != err {
		return err
	}
	// 备份
	if err := util.MvFile(imageDir, backDir); nil != err {
		return err
	}

	return util.MvFile(tempDir, imageDir)
}
