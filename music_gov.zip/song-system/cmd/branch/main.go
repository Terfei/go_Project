package main

import (
	"context"
	"flag"
	"fmt"
	"github.com/robfig/cron/v3"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/cmd/branch/image"
	"gitlab.omytech.com.cn/vod/song-system/internal/branch/router"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"net/http"
	"os"
	"os/signal"
	"time"
)

var (
	conf   string
	module string
)

func init() {
	usage()
	flag.StringVar(&conf, "c", "", "指定配置文件位置")
	flag.StringVar(&module, "m", "server", "指定服务模块")
	flag.Parse()

	if "" == conf {
		if err := defaultConfig(); nil != err {
			usage()
			panic("请指定配置文件位置")
		}
	}

	logger.SetOption(logger.Channel(fmt.Sprintf("song-system-branch-%s", module)))

	// 导入配置
	config.Load(conf)
}

func main() {
	switch module {
	case "server":
		serverModule()
	case "cron":
		cronModule()
	default:
		panic("不能识别的服务")
	}
}

func serverModule() {
	router.Init()
	srv := &http.Server{Addr: fmt.Sprintf(":%d", config.Setting.App.Port), Handler: router.Router}
	logger.Entry().Info("启动服务")
	go func() {
		if err := srv.ListenAndServe(); nil != err && http.ErrServerClosed != err {
			panic("启动服务失败")
		}
	}()

	// 接收终端信号来关闭服务
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt)
	<-quit
	logger.Entry().Info("关闭服务")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); nil != err {
		logger.Entry().Fatal("关闭服务异常，强制关闭")
	}

	logger.Entry().Info("关闭服务完成")
}

func cronModule() {
	//job.BranchDownload()
	//download.BranchDownload()
	image.Overview()
	c := cron.New()
	//c.AddFunc("*/5 * * * *", download.BranchDownload)
	c.AddFunc("*/30 * * * *", image.Overview)
	//c.Start()
	//defer c.Stop()
	//select {}
}

func defaultConfig() error {
	path, err := os.Getwd()
	if err != nil {
		return err
	}

	file := fmt.Sprintf("%s/configs/branch.toml", path)
	exists, err := util.FileExists(file)
	if err != nil {
		return err
	}
	if !exists {
		return fmt.Errorf("默认配置不存在,%s", file)
	}

	conf = file
	return nil
}

// usage 返回使用方法
func usage() {
	fmt.Fprintf(os.Stderr, `
Usage: go run cmd/branch/main.go -m {服务：server | cron} -c {配置文件，默认configs/branch.conf}
`)
}
