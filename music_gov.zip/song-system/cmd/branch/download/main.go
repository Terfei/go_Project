package download

import (
	"context"
	"errors"
	"fmt"
	"github.com/sirupsen/logrus"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"math"
	"net/http"
	"time"
)

var rdk = `branch_download`
var rdkLock = `branch_download_lock`

// BranchDownloadParams 门店下载参数
type BranchDownloadParams struct {
	Version string
	OssFile string
	File    string
	DBFile  string
}

// BranchDownload 门店下载
func BranchDownload() {
	ctx := context.Background()
	logger.Entry().Info("门店下载 [start]")
	if err := model.RedisConnection(config.Setting.Database.Redis); nil != err {
		logger.Entry().WithError(err).Error("门店下载 redis连接错误")
		return
	}

	if model.Rds.Exists(ctx, rdkLock).Val() == 1 {
		logger.Entry().Info("门店下载 存在处理中任务　跳过")
		return
	}

	if model.Rds.Exists(ctx, rdk).Val() != 1 {
		logger.Entry().Info("门店下载 redis信息为空　跳过")
		return
	}

	items := model.Rds.HKeys(ctx, rdk).Val()
	logger.Entry().WithField("branches", items).Info("需要处理的版本信息")

	if len(items) == 0 {
		logger.Entry().Info("门店下载 redis empty 跳过")
		return
	}

	// 判断是否在处理中
	for _, item := range items {
		val := model.Rds.HGet(ctx, rdk, item).Val()
		if val == "deal" {
			continue
		}
		// 暂时锁定
		model.Rds.Set(ctx, rdkLock, time.Now().Format("2006-01-02 15:04:05"), time.Hour)

		// 不能多个进程处理同一sqlite,此处同步处理即可
		dealBranchDownload(BranchDownloadParams{
			Version: item,
			OssFile: val,
		})

		model.Rds.HDel(ctx, rdk, item)
	}
	model.Rds.Del(ctx, rdkLock)
}

func dealBranchDownload(params BranchDownloadParams) {
	if err := util.Mkdir(config.Setting.Storage.Path); nil != err {
		logger.Entry().WithError(err).Error("初始存储文件夹失败")
		return
	}
	params.File = fmt.Sprintf("%s/%s.7z", config.Setting.Storage.Path, params.Version)
	params.DBFile = fmt.Sprintf("%s/local.db", config.Setting.Storage.Path)

	// 下载
	if err := fileDownload(params.File, params.OssFile); nil != err {
		logger.Entry().WithError(err).WithField("params", params).Error("下载aliyun 7z文件失败")
		return
	}

	// 解压
	archive := util.Archive{
		FileName: params.File,
		FilePath: config.Setting.Storage.Path,
	}
	if err := archive.UnCompression(); nil != err {
		logger.Entry().WithError(err).Error("解压失败")
		return
	}

	if err := dealVersionDetail(params); nil != err {
		logger.Entry().WithError(err).Error("处理批次文件错误")
		return
	}

	//mv file
	if err := util.MvFile(params.DBFile, fmt.Sprintf("%s/%s.db", config.Setting.Storage.Path, params.Version)); nil != err {
		logger.Entry().WithError(err).Error("移动文件失败")
	}

	logger.Entry().WithField("params", params).Info("处理成功")
}

func dealVersionDetail(params BranchDownloadParams) error {
	model.LocalDBConnection(config.DBConfig{
		Dialect: "sqlite3",
		Server:  params.DBFile,
		Log:     true,
	})
	var items []localdb.BranchVersionDetail
	if err := model.LocalDB.Table(localdb.TableBranchVersionDetail).Find(&items).Error; err != nil {
		return fmt.Errorf("查询数据库失败，err:%s", err.Error())
	}

	disk, err := getDisk()
	if err != nil {
		logger.Entry().WithError(err).Error("获取磁盘映射失败")
		return err
	}

	for _, item := range items {
		downloadDisk, err := getDownloadDisk(item, disk)
		if err != nil {
			logger.Entry().WithError(err).Error("获取存储文件夹信息错误")
			continue
		}
		//暂时不开多进程处理，sqlite写入会出现锁情况 todo
		downloadVersionDetail(item, downloadDisk)

		time.Sleep(time.Microsecond * 100)
	}

	checkDownload()
	return nil
}

func downloadVersionDetail(item localdb.BranchVersionDetail, disk DiskParams) {
	logger.Entry().WithFields(logrus.Fields{
		"item": item,
		"disk": disk,
	}).Info("下载文件")

	local := fmt.Sprintf("%s/%s", disk.Local, item.Filename)
	if err := fileDownload(local, item.OssFilename); nil != err {
		logger.Entry().WithError(err).Error("下载文件失败")
		return
	}

	share := fmt.Sprintf("%s/%s", disk.Share, item.Filename)
	if err := util.CpFile(local, share); nil != err {
		logger.Entry().WithError(err).Error("移动文件到共享盘失败")
		return
	}

	update := map[string]interface{}{
		"is_download": 1,
		"disk_file":   local,
	}

	if err := model.LocalDB.Table(localdb.TableBranchVersionDetail).Where("id = ?", item.ID).Update(update).Error; nil != err {
		logger.Entry().WithError(err).WithField("id", item.ID).Error("修改下载记录失败")
		return
	}
}

func fileDownload(local, file string) error {
	logger.Entry().WithFields(logrus.Fields{
		"local": local,
		"file":  file,
	}).Info("开始下载文件")

	oss := util.NewAliyunOss(config.Setting.Aliyun.Oss)

	crc64, err := oss.GetToFile(local, file)
	if err != nil {
		return fmt.Errorf("下载文件错误,err:%s", err.Error())
	}

	localCrc64, e := util.FileCRC64String(local)
	if e != nil {
		return fmt.Errorf("校验本地md5错误, err:%s", e.Error())
	}

	logger.Entry().WithFields(logrus.Fields{
		"local":       local,
		"oss":         file,
		"oss_crc64":   crc64,
		"local_crc64": localCrc64,
	}).Info("校验文件crc64")

	if localCrc64 != crc64 {
		return errors.New("校验hash crc64错误")
	}

	return nil
}

func checkDownload() {
	var count int
	var total int
	model.LocalDB.Table(localdb.TableBranchVersionDetail).Count(&total)
	model.LocalDB.Table(localdb.TableBranchVersionDetail).Where("is_download = 1").Count(&count)
	logger.Entry().WithFields(logrus.Fields{
		"总数量": total,
		"已处理": count,
	}).Info("检查文件下载数量")

	// todo 数量处理完成 删除表 移动sqlite
	size := 500
	page := math.Ceil(float64(total) / float64(size))
	logger.Entry().WithField("page", page).Info("开始回传下载结果")
	for i := 1; i <= int(page); i++ {
		offset := (i - 1) * size
		var items []localdb.BranchVersionDetail
		if err := model.LocalDB.Table(localdb.TableBranchVersionDetail).Offset(offset).Limit(size).Find(&items).Error; err != nil {
			logger.Entry().WithError(err).WithField("page", i).Error("查询数据错误")
			return
		}

		url := fmt.Sprintf("%s/api/support/sync/callback", config.Setting.Centre.Domain)
		params := util.Params{}
		params.Set("branch_id", config.Setting.Centre.Salt)
		params.Set("items", items)

		res, err := util.HTTPPost(url, params, http.StatusNoContent)
		logger.Entry().WithField("response", string(res)).Info("回传响应返回")
		if err != nil {
			return
		}
	}
}
