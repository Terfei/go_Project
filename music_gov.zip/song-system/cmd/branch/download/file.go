package download

import (
	"fmt"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// DiskParams ...
type DiskParams struct {
	Local string
	Share string
}

func getDownloadDisk(detail localdb.BranchVersionDetail, disks util.Params) (DiskParams, error) {
	disk, err := getMaterialDisk(disks, detail.RelationType)
	if err != nil {
		return DiskParams{}, err
	}

	if detail.Dir != "" {
		localPath := fmt.Sprintf("%s/%s", disk.Local, detail.Dir)
		if err := util.Mkdir(localPath); nil != err {
			logger.Entry().WithError(err).WithField("path", localPath).Errorf("创建文件夹失败")
			return DiskParams{}, err
		}
		sharePath := fmt.Sprintf("%s/%s", disk.Share, detail.Dir)
		if err := util.Mkdir(sharePath); nil != err {
			logger.Entry().WithError(err).WithField("path", localPath).Errorf("创建文件夹失败")
			return DiskParams{}, err
		}
		return DiskParams{
			Local: localPath,
			Share: sharePath,
		}, nil
	}

	return DiskParams{
		Local: disk.Local,
		Share: disk.Share,
	}, nil
}

func getMaterialDisk(disks util.Params, category string) (DiskParams, error) {
	if !disks.Exists(category) {
		return DiskParams{}, fmt.Errorf("磁盘映射关系不存在, %s", category)
	}

	disk := disks.Get(category).(map[string]interface{})

	local := disk["local"].(string)
	if err := util.Mkdir(local); nil != err {
		logger.Entry().WithError(err).WithField("path", local).Errorf("创建文件夹失败")
		return DiskParams{}, err
	}
	share := disk["share"].(string)
	if err := util.Mkdir(share); nil != err {
		logger.Entry().WithError(err).WithField("path", share).Errorf("创建文件夹失败")
		return DiskParams{}, err
	}

	return DiskParams{
		Local: local,
		Share: share,
	}, nil
}
