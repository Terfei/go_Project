package download

import (
	"encoding/json"
	"fmt"
	"github.com/sirupsen/logrus"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// getDisk 获取磁盘映射
func getDisk() (util.Params, error) {
	url := fmt.Sprintf("%s/api/support/disk", config.Setting.Centre.Domain)
	response, err := util.HTTPGet(url)
	if err != nil {
		logger.Entry().WithError(err).WithField("url", url).Info("请求获取磁盘映射")
		return util.Params{}, fmt.Errorf("请求获取磁盘映射失败, err:%s", err)
	}

	var body struct {
		Code int         `json:"code"`
		Data util.Params `json:"data"`
	}
	logger.Entry().WithFields(logrus.Fields{
		"url":      url,
		"response": string(response),
	}).Info("请求获取磁盘映射")

	if err = json.Unmarshal(response, &body); nil != err {
		return body.Data, fmt.Errorf("获取磁盘映射,解析失败, err:%s", err.Error())
	}

	return body.Data, nil
}
