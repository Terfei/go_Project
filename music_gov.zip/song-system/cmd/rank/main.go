package main

import (
	"flag"
	"fmt"
	"math"
	"net/http"
	"os"
	"time"

	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

var conf string

func init() {
	flag.StringVar(&conf, "c", "", "指定配置文件位置")
	flag.Parse()
	if conf == "" {
		Usage()
		panic("指定配置文件位置")
	}

	// 载入配置文件
	config.Load(conf)

	model.SQLServerConnection(config.Setting.Database.SQLServer)

}

type stat struct {
	SongNo string `json:"SongNo" gorm:"column:SongNo"`
	Total  int    `json:"Total" gorm:"column:Total"`
	Songer string `json:"Songer" gorm:"column:Songer"`
}

func main() {
	var items []stat
	model.SQLServerDB.Table("PH_Charts").Select("SongNo, Count(1) as Total,Songer").Group("SongNo,Songer").Find(&items)

	min := 0
	max := 0
	size := 300
	page := math.Ceil(float64(len(items)) / float64(size))
	url := fmt.Sprintf("%s/api/support/import/branch/accompany", config.Setting.Centre.Domain)
	params := util.Params{}
	params.Set("branch_id", config.Setting.Centre.Salt)

	for i := 0; i < int(page); i++ {
		min = i * size
		max = (i + 1) * size
		if max > len(items) {
			max = len(items)
		}

		params.Set("stats", items[min:max])
		fmt.Println(util.HTTPPost(url, params, http.StatusNoContent))

		time.Sleep(time.Second)
	}
}

// Usage 返回使用方法
func Usage() {
	fmt.Fprintf(os.Stderr, `
Usage: go run cmd/rank/main.go -c {config}
`)
}
