package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"time"
)

// ImportAccompanyAudioQlty 伴奏音质
func ImportAccompanyAudioQlty() {
	fmt.Println(time.Now(), "AccompanyAudioQlty [start]")
	items, err := model.LocalDB.Table(localdb.TableAccompanyAudioQlty).Rows()
	if err != nil {
		panic(err)
	}

	for items.Next() {
		var item localdb.AccompanyAudioQlty
		if err := model.LocalDB.ScanRows(items, &item); nil != err {
			panic(err)
		}
		handleAccompanyAudioQlty(item)
	}

	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableAccompanyAudioqlty).Select("max(id) as max").Find(&res)
	sql := fmt.Sprintf("alter sequence song.accompany_audioqlty_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)

	fmt.Println(time.Now(), "AccompanyAudioQlty [end]")
}

func handleAccompanyAudioQlty(item localdb.AccompanyAudioQlty) {
	a := dealAccompanyAudioQlty(item)

	if err := model.SongDB.Create(&a).Error; nil != err {
		panic(err)
	}

	time.Sleep(time.Microsecond * 100)
}

func dealAccompanyAudioQlty(item localdb.AccompanyAudioQlty) song.AccompanyAudioqlty {
	var data song.AccompanyAudioqlty
	data.ID = item.AudioqltyID
	data.Code = item.AudioqltyCode
	data.Image = item.AudioqltyImage
	data.Seq = item.Seq
	data.IsShow = item.IsShow
	return data
}
