package table

import (
	"fmt"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	bridgeBranch "gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"time"
)

// MakeDefaultVersion 生成默认批次
func MakeDefaultVersion() {
	fmt.Println(time.Now(), "Version [start]")
	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		code := meta.VersionCode("20200101001")
		version := meta.VersionOverview{
			VersionCode: code,
			Remark:      "初始默认批次",
			IsDefault:   1,
		}
		if err := tx.Create(&version).Error; nil != err {
			return err
		}

		for _, item := range bridgeBranch.AllBranchMap() {
			data := branch.Version{
				VersionBase: branch.VersionBase{
					BranchID:    item.BranchID,
					VersionID:   version.ID,
					VersionCode: version.VersionCode,
				},
				Remarks:     "初始默认批次",
				CanDownload: 1,
			}

			if err := tx.Create(&data).Error; nil != err {
				return err
			}
		}

		// 处理每种类型批次信息
		for _, category := range branch.AllVersionCategoryType() {
			update := map[string]interface{}{
				"overview_id": version.ID,
				"updated_at":  time.Now(),
			}
			if err := tx.Table(category.String()).Where("overview_id = 0").Update(update).Error; nil != err {
				return err
			}
		}

		return nil
	})

	if err != nil {
		fmt.Println(err)
	}
	fmt.Println(time.Now(), "Version [end]")
}
