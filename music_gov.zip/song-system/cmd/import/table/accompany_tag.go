package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"time"
)

// ImportAccompanyTag 伴奏标签
func ImportAccompanyTag() {
	fmt.Println(time.Now(), "伴奏标签 AccompanyTag [start]")

	items, err := model.LocalDB.Table(localdb.TableAccompanyTag).Rows()
	if err != nil {
		panic(err)
	}

	for items.Next() {
		var item localdb.AccompanyTag
		if err := model.LocalDB.ScanRows(items, &item); nil != err {
			panic(err)
		}
		dealAccompanyTag(item)
	}
	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableAccompanyTag).Select("max(id) as max").Find(&res)
	sql := fmt.Sprintf("alter sequence song.accompany_tag_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)

	fmt.Println(time.Now(), "伴奏标签 AccompanyTag [end]")
}

func dealAccompanyTag(item localdb.AccompanyTag) {
	data := handleAccompanyTag(item)

	if err := model.SongDB.Create(&data).Error; nil != err {
		panic(err)
	}
}

func handleAccompanyTag(item localdb.AccompanyTag) song.AccompanyTag {
	var data song.AccompanyTag
	data.ID = item.TagID
	data.Name = item.TagName
	data.Seq = item.Seq
	data.IsShow = item.IsShow
	return data
}
