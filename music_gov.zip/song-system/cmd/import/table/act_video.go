package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"time"
)

// ImportActVideo 导入跳舞视频
func ImportActVideo() {
	fmt.Println(time.Now(), "ActVideo [start]")
	items, err := model.LocalDB.Table(localdb.TableActVideo).Rows()
	if err != nil {
		panic(err)
	}

	for items.Next() {
		var item localdb.ActVideo
		if err := model.LocalDB.ScanRows(items, &item); nil != err {
			panic(err)
		}
		saveActVideo(item)
	}
	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableActVideo).Select("max(id) as max").Find(&res)
	sql := fmt.Sprintf("alter sequence song.act_video_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)
	fmt.Println(time.Now(), "ActVideo [end]")
}

func saveActVideo(item localdb.ActVideo) {
	video := dealActVideo(item)

	if err := model.SongDB.Create(&video).Error; nil != err {
		fmt.Println(err)
	}
}

func dealActVideo(item localdb.ActVideo) song.ActVideo {
	return song.ActVideo{
		AccompanyID:        item.AccompanyID,
		Songno:             item.Songno,
		AccompanyName:      item.AccompanyName,
		AccompanyNameSpell: item.AccompanyNameSpell,
		AccompanyFilename:  item.AccompanyFilename,
		Audio:              item.Audio,
		HostIP:             item.HostIP,
		Image:              item.Image,
		CategoryID:         item.CategoryID,
		ActVideoType:       item.Type,
		CharCount:          item.CharCount,
		Rank:               item.Rank,
		LampID:             item.LampID,
		EffectID:           item.EffectID,
		ReverberationID:    item.ReverberationID,
	}
}
