package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"time"
)

// ImportAccompanyLanguage 伴奏语种
func ImportAccompanyLanguage() {
	fmt.Println(time.Now(), "AccompanyLanguage [start]")

	items, err := model.LocalDB.Table(localdb.TableAccompanyLanguage).Rows()
	if err != nil {
		panic(err)
	}

	for items.Next() {
		var item localdb.AccompanyLanguage
		if err := model.LocalDB.ScanRows(items, &item); nil != err {
			panic(err)
		}
		dealAccompanyLanguage(item)
	}
	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableAccompanyLanguage).Select("max(id) as max").Find(&res)

	sql := fmt.Sprintf("alter sequence song.accompany_language_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)

	fmt.Println(time.Now(), "AccompanyLanguage [end]")
}

func dealAccompanyLanguage(item localdb.AccompanyLanguage) {
	data := handleAccompanyLanguage(item)

	if err := model.SongDB.Create(&data).Error; nil != err {
		panic(err)
	}
}

func handleAccompanyLanguage(item localdb.AccompanyLanguage) song.AccompanyLanguage {
	var data song.AccompanyLanguage
	data.ID = item.LanguageID
	data.Name = item.LanguageName
	data.NameKey = item.LanguageNameKey
	data.Image = item.LanguageImage
	data.Seq = item.Seq
	data.IsShow = item.IsShow
	return data
}
