package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	bridgeBranch "gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"time"
)

// ImportAuthorize 门店授权
func ImportAuthorize() {
	fmt.Println(time.Now(), "Authorize [start]")
	items, err := model.BridgeDB.Table(bridgeBranch.TableMetaBranch).Rows()
	if err != nil {
		panic(err)
	}

	var count int
	for items.Next() {
		var item bridgeBranch.MetaBranch
		if err := model.BridgeDB.ScanRows(items, &item); nil != err {
			panic(err)
		}
		count = count + 1
		handleAuthorize(item)
	}

	fmt.Println(time.Now(), "Authorize [end]")
}

func handleAuthorize(item bridgeBranch.MetaBranch) {
	a := dealAuthorize(item)

	if err := model.SongDB.Create(&a).Error; nil != err {
		panic(err)
	}

	time.Sleep(time.Microsecond * 100)
}

func dealAuthorize(item bridgeBranch.MetaBranch) branch.Authorize {
	var data branch.Authorize
	data.BranchID = item.BranchID
	data.BranchCode = item.Code
	data.Category = branch.AuthorizeCategorySong

	return data
}
