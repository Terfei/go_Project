package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// ImportAccompany 导入伴奏
func ImportAccompany() {
	items, err := model.LocalDB.Table(localdb.TableAccompany).Rows()
	if err != nil {
		panic(err)
	}

	work := util.NewWork(20)
	for items.Next() {
		var accompany localdb.Accompany
		if err := model.LocalDB.ScanRows(items, &accompany); nil != err {
			panic(err)
		}

		work.Add(accompany)
		go handleAccompany(accompany, work)
	}

	work.Wait()

	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableAccompany).Select("max(id) as max").Find(&res)
	sql := fmt.Sprintf("alter sequence song.accompany_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)
}

func handleAccompany(a localdb.Accompany, w *util.Work) {
	defer w.Done()
	fmt.Println(time.Now(), "accompany songno: ", a.Songno)
	accompany := dealAccompany(a)

	if err := model.SongDB.Create(&accompany).Error; nil != err {
		panic(err)
	}
	// 延迟
	time.Sleep(time.Microsecond * 100)
	fmt.Println(time.Now(), "accompany songno: ", a.Songno, "done")
}

// dealAccompany 处理数据
func dealAccompany(accompany localdb.Accompany) song.Accompany {
	var s song.Accompany
	s.ID = accompany.AccompanyID
	s.Name = accompany.AccompanyName
	s.NameSpell = accompany.AccompanyNameSpell
	s.CharCount = accompany.CharCount
	singers := song.AccompanySingers{}
	if accompany.SingerID > 0 {
		s := getSinger(accompany.SingerID)
		if nil != s {
			singers.SingerOne = *s
		}
	}
	if accompany.SingerIDTwo > 0 {
		s := getSinger(accompany.SingerIDTwo)
		if nil != s {
			singers.SingerTwo = *s
		}
	}
	if accompany.SingerIDThree > 0 {
		s := getSinger(accompany.SingerIDThree)
		if nil != s {
			singers.SingerThree = *s
		}
	}
	if accompany.SingerIDFour > 0 {
		s := getSinger(accompany.SingerIDFour)
		if nil != s {
			singers.SingerFour = *s
		}
	}
	s.Singers = singers
	s.SingerNameAll = accompany.SingerNameAll
	s.Audio = accompany.Audio
	s.Songno = accompany.Songno
	s.Filename = accompany.AccompanyFilename
	s.ReleaseTime = accompany.ReleaseTime
	s.Ext = accompany.Codec
	s.MidFilepath = accompany.MidFilepath
	s.LanguageID = accompany.LanguageID
	s.Channel = accompany.Channel
	s.VersionID = accompany.VersionID
	s.CategoryID = accompany.CategoryID
	s.EffectID = accompany.EffectID
	s.LampID = accompany.LampID
	s.ReverberationGroup = accompany.ReverberationGroup
	s.ServerPath = accompany.HostIP
	s.Rank = accompany.Rank
	s.VideoqltyID = accompany.VideoqltyID
	s.AudioqltyID = accompany.AudioqltyID
	s.TagID = accompany.TagID
	emoIds, err := accompany.EmoTagID.ToPqInt64Arr()
	if err != nil {
		panic(err)
	}

	s.EmoTagIds = emoIds

	return s
}

func getSinger(id int) *song.AccompanySinger {
	singer, err := localdb.SingerByID(id)
	if err != nil {
		return nil
	}

	return &song.AccompanySinger{
		ID:   singer.SingerID,
		Name: singer.SingerName,
	}
}
