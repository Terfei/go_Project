package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"time"
)

// ImportSingerArea 导入歌手区域
func ImportSingerArea() {
	fmt.Println(time.Now(), "歌手区域 SingerArea [start]")
	items, err := model.LocalDB.Table(localdb.TableSingerArea).Rows()
	if err != nil {
		panic(err)
	}

	for items.Next() {
		var item localdb.SingerArea
		if err := model.LocalDB.ScanRows(items, &item); nil != err {
			panic(err)
		}
		dealSingerArea(item)
	}
	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableSingerArea).Select("max(id) as max").Find(&res)
	sql := fmt.Sprintf("alter sequence song.singer_area_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)

	fmt.Println(time.Now(), "歌手区域 SingerArea [end]")
}

func dealSingerArea(item localdb.SingerArea) {
	area := handleSingerArea(item)

	if err := model.SongDB.Create(&area).Error; nil != err {
		panic(err)
	}
}

func handleSingerArea(item localdb.SingerArea) song.SingerArea {
	var area song.SingerArea
	area.Name = item.AreaName
	area.ID = item.AreaID
	area.Seq = item.Seq
	area.Image = item.AreaImage

	return area
}
