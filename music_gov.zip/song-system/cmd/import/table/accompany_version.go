package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"time"
)

// ImportAccompanyVersion 伴奏版本
func ImportAccompanyVersion() {
	fmt.Println(time.Now(), "AccompanyVersion [start]")
	items, err := model.LocalDB.Table(localdb.TableAccompanyVersion).Rows()
	if err != nil {
		panic(err)
	}

	for items.Next() {
		var item localdb.AccompanyVersion
		if err := model.LocalDB.ScanRows(items, &item); nil != err {
			panic(err)
		}
		handleAccompanyVersion(item)
	}
	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableAccompanyVersion).Select("max(id) as max").Find(&res)
	sql := fmt.Sprintf("alter sequence song.accompany_version_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)

	fmt.Println(time.Now(), "AccompanyVersion [end]")
}

func handleAccompanyVersion(item localdb.AccompanyVersion) {
	a := dealAccompanyVersion(item)

	if err := model.SongDB.Create(&a).Error; nil != err {
		panic(err)
	}

	time.Sleep(time.Microsecond * 100)
}

func dealAccompanyVersion(item localdb.AccompanyVersion) song.AccompanyVersion {
	var data song.AccompanyVersion
	data.ID = item.VersionID
	data.Seq = item.Seq
	data.Name = item.VersionName
	return data
}
