package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/sqlserver"
	"time"
)

// ImportAcc 导入公播
func ImportAcc() {
	fmt.Println(time.Now(), "AutoPlayAccCK [start]")
	cks, errCk := model.SQLServerDB.Table(sqlserver.TableAutoPlayAccCK).Rows()
	if errCk != nil {
		panic(errCk)
	}
	for cks.Next() {
		var chunk sqlserver.AutoPlayAccCK
		if err := model.SQLServerDB.ScanRows(cks, &chunk); nil != err {
			panic(err)
		}

		acc := handleAccCK(chunk)
		saveAcc(acc)
	}
	fmt.Println(time.Now(), "AutoPlayAccCK [end]")

	fmt.Println(time.Now(), "AutoPlayAccKP [start]")
	kps, errKp := model.SQLServerDB.Table(sqlserver.TableAutoPlayAccKP).Rows()
	if errKp != nil {
		panic(errKp)
	}
	for kps.Next() {
		var kp sqlserver.AutoPlayAccKP
		if err := model.SQLServerDB.ScanRows(kps, &kp); nil != err {
			panic(err)
		}

		acc := handleAccKP(kp)
		saveAcc(acc)
	}
	fmt.Println(time.Now(), "AutoPlayAccKP [end]")

	fmt.Println(time.Now(), "AutoPlayAccGala [start]")
	galas, errGala := model.SQLServerDB.Table(sqlserver.TableAutoPlayAccGala).Rows()
	if errGala != nil {
		panic(errGala)
	}
	for galas.Next() {
		var gala sqlserver.AutoPlayAccGala
		if err := model.SQLServerDB.ScanRows(galas, &gala); nil != err {
			panic(err)
		}

		acc := handleAccGala(gala)
		saveAcc(acc)
	}
	fmt.Println(time.Now(), "AutoPlayAccGala [end]")

	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableAcc).Select("max(id) as max").Find(&res)
	sql := fmt.Sprintf("alter sequence song.acc_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)
}

func saveAcc(acc song.Acc) {
	if err := model.SongDB.Create(&acc).Error; nil != err {
		panic(err)
	}
}

func handleAccCK(item sqlserver.AutoPlayAccCK) song.Acc {
	return song.Acc{
		AccID:           item.AutoplayAccID,
		AccName:         item.AutoplayAccName,
		HostIP:          item.HostIP,
		Filename:        item.AutoplayAccFilename,
		Filename2:       item.AutoplayAccFilename2,
		ListID:          item.ListID,
		ListName:        item.ListName,
		Seq:             item.Seq,
		Codec:           item.Codec,
		Channel:         item.Channel,
		LampID:          item.LampID,
		ReverberationID: item.ReverberationID,
		EffectID:        item.EffectID,
		Volume:          item.Volume,
		Audio:           item.Audio,
		StartTime:       item.StartTime,
		EndTime:         item.EndTime,
		StrLevel:        item.StrLevel,
		Mode:            item.Mode,
		AccType:         song.AccTypeCK,
	}
}

func handleAccKP(item sqlserver.AutoPlayAccKP) song.Acc {
	return song.Acc{
		AccID:           item.AutoplayAccID,
		AccName:         item.AutoplayAccName,
		HostIP:          item.HostIP,
		Filename:        item.AutoplayAccFilename,
		Filename2:       item.AutoplayAccFilename2,
		ListID:          item.ListID,
		ListName:        item.ListName,
		Seq:             item.Seq,
		Codec:           item.Codec,
		Channel:         item.Channel,
		LampID:          item.LampID,
		ReverberationID: item.ReverberationID,
		EffectID:        item.EffectID,
		Volume:          item.Volume,
		Audio:           item.Audio,
		StartTime:       item.StartTime,
		EndTime:         item.EndTime,
		StrLevel:        item.StrLevel,
		Mode:            item.Mode,
		AccType:         song.AccTypeKP,
	}
}

func handleAccGala(item sqlserver.AutoPlayAccGala) song.Acc {
	return song.Acc{
		AccID:           item.AutoplayAccID,
		AccName:         item.AutoplayAccName,
		HostIP:          item.HostIP,
		Filename:        item.AutoplayAccFilename,
		Filename2:       item.AutoplayAccFilename2,
		ListID:          item.ListID,
		ListName:        item.ListName,
		Seq:             item.Seq,
		Codec:           item.Codec,
		Channel:         item.Channel,
		LampID:          item.LampID,
		ReverberationID: item.ReverberationID,
		EffectID:        item.EffectID,
		Volume:          item.Volume,
		Audio:           item.Audio,
		StartTime:       item.StartTime,
		EndTime:         item.EndTime,
		StrLevel:        item.StrLevel,
		Mode:            item.Mode,
		AccType:         song.AccTypeGala,
	}
}
