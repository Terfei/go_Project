package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/sqlserver"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

var t util.NullTime

// ImportSinger 导入歌手
func ImportSinger() {
	singers, err := model.LocalDB.Table(localdb.TableSinger).Rows()

	if err != nil {
		panic(err)
	}

	work := util.NewWork(20)
	for singers.Next() {
		var singer localdb.Singer

		if err := model.LocalDB.ScanRows(singers, &singer); nil != err {
			panic(err)
		}

		work.Add(singer)
		go handleSinger(singer, work)
	}

	work.Wait()

	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableNameSinger).Select("max(id) as max").Find(&res)
	sql := fmt.Sprintf("alter sequence song.singer_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)
}

func handleSinger(s localdb.Singer, w *util.Work) {
	defer w.Done()

	singer := dealSinger(s)

	fmt.Println(time.Now(), "singer id: ", singer.ID)

	if err := model.SongDB.Create(&singer).Error; nil != err {
		panic(err)
	}

	// 延迟
	time.Sleep(time.Microsecond * 100)
	fmt.Println(time.Now(), "singer id: ", singer.ID, "done")

}

func dealSinger(s localdb.Singer) song.Singer {
	var singer song.Singer
	singer.ID = s.SingerID
	singer.Name = s.SingerName
	singer.Nickname = s.SingerNickname
	singer.NameSpell = s.SingerNameSpell
	singer.CharCount = s.CharCount
	singer.Gender = song.Gander(s.SingerGender)
	singer.AreaID = s.AreaID
	singer.Image = s.SingerImage
	singer.Rank = s.Rank
	singer.Weight = s.Weight
	singer.CreatedAt = t
	singer.UpdatedAt = t
	row := model.SQLServerDB.Table(sqlserver.TablePubGSinger).Where("SONGERNAME = ?", s.SingerName).Select("SingerNo,LANGUAGE_TYPE,BH").Row()

	if err := row.Scan(&singer.Code, &singer.LanguageType, &singer.Bh); nil != err {
		fmt.Println(err)
	}

	return singer
}
