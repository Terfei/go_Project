package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"time"
)

// ImportAccompanyCategory 伴奏分类
func ImportAccompanyCategory() {
	fmt.Println(time.Now(), "AccompanyCategory [begin]")

	items, err := model.LocalDB.Table(localdb.TableAccompanyCategory).Rows()
	if err != nil {
		panic(err)
	}

	var count int
	for items.Next() {
		var item localdb.AccompanyCategory
		if err := model.LocalDB.ScanRows(items, &item); nil != err {
			panic(err)
		}
		count = count + 1
		handAccompanyCategory(item)
	}

	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableAccompanyCategory).Select("max(id) as max").Find(&res)

	sql := fmt.Sprintf("alter sequence song.accompany_category_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)

	fmt.Println(time.Now(), "AccompanyCategory [end]")
}

func handAccompanyCategory(item localdb.AccompanyCategory) {
	a := dealAccompanyCategory(item)

	if err := model.SongDB.Create(&a).Error; nil != err {
		panic(err)
	}

	time.Sleep(time.Microsecond * 100)
}

func dealAccompanyCategory(item localdb.AccompanyCategory) song.AccompanyCategory {
	var data song.AccompanyCategory
	data.ID = item.CategoryID
	data.Name = item.CategoryName
	data.NameKey = item.CategoryNameKey
	data.Image = item.CategoryImage
	data.Seq = item.Seq
	data.IsShow = item.IsShow
	data.Type = item.Type
	return data
}
