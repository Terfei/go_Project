package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"time"
)

// ImportPartyDance 导入派对舞曲
func ImportPartyDance() {
	fmt.Println(time.Now(), "PartyDance [start]")

	items, err := model.LocalDB.Table(localdb.TablePartyDance).Rows()
	if err != nil {
		panic(err)
	}

	for items.Next() {
		var item localdb.PartyDance
		if err := model.LocalDB.ScanRows(items, &item); nil != err {
			panic(err)
		}
		party := dealPartyDance(item)
		savePartyDance(party)
	}
	var res struct {
		Max int
	}
	model.SongDB.Table(song.TablePartyDance).Select("max(id) as max").Find(&res)
	sql := fmt.Sprintf("alter sequence song.party_dance_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)

	fmt.Println(time.Now(), "PartyDance [end]")
}

func savePartyDance(party song.PartyDance) {
	if err := model.SongDB.Create(&party).Error; nil != err {
		panic(err)
	}
}

func dealPartyDance(item localdb.PartyDance) song.PartyDance {
	return song.PartyDance{
		ID:                     item.AccompanyID,
		Songno:                 item.Songno,
		AccompanyID:            item.AccompanyID,
		AccompanyName:          item.AccompanyName,
		AccompanyNameSpell:     item.AccompanyNameSpell,
		AccompanyFilename:      item.AccompanyFilename,
		AccompanyTitleFilename: item.AccompanyTitleFilename,
		Audio:                  item.Audio,
		HostIP:                 item.HostIP,
		Image:                  item.Image,
		CategoryID:             item.CategoryID,
		CategoryName:           item.CategoryName,
		CharCount:              item.CharCount,
		Rank:                   item.Rank,
		LampID:                 item.LampID,
		EffectID:               item.EffectID,
		ReverberationID:        item.ReverberationID,
		Codec:                  item.Codec,
		Volume:                 item.Volume,
		StrLevel:               item.StrLevel,
		UpdateTime:             item.UpdateTime,
	}
}
