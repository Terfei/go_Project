package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"time"
)

// ImportAccompanyVideoQlty 伴奏视频质量
func ImportAccompanyVideoQlty() {
	fmt.Println(time.Now(), "AccompanyVideoQlty [start]")
	items, err := model.LocalDB.Table(localdb.TableAccompanyVideoQlty).Rows()
	if err != nil {
		panic(err)
	}

	for items.Next() {
		var item localdb.AccompanyVideoQlty
		if err := model.LocalDB.ScanRows(items, &item); nil != err {
			panic(err)
		}
		handleAccompanyVideoQlty(item)
	}
	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableAccompanyVideoqlty).Select("max(id) as max").Find(&res)
	sql := fmt.Sprintf("alter sequence song.accompany_videoqlty_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)

	fmt.Println(time.Now(), "AccompanyVideoQlty [end]")
}

func handleAccompanyVideoQlty(item localdb.AccompanyVideoQlty) {
	a := dealAccompanyVideoQlty(item)

	if err := model.SongDB.Create(&a).Error; nil != err {
		panic(err)
	}

	time.Sleep(time.Microsecond * 100)
}

func dealAccompanyVideoQlty(item localdb.AccompanyVideoQlty) song.AccompanyVideoqlty {
	var data song.AccompanyVideoqlty
	data.ID = item.VideoqltyID
	data.Code = item.VideoqltyCode
	data.Image = item.VideoqltyImage
	data.Seq = item.Seq
	data.IsShow = item.IsShow
	return data
}
