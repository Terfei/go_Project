package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"time"
)

// ImportEmoTag 情绪标签
func ImportEmoTag() {
	fmt.Println(time.Now(), "EmoTag [start]")
	items, err := model.LocalDB.Table(localdb.TableEmoTag).Rows()
	if err != nil {
		panic(err)
	}

	for items.Next() {
		var item localdb.EmoTag
		if err := model.LocalDB.ScanRows(items, &item); nil != err {
			panic(err)
		}
		dealEmoTag(item)
	}
	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableEmoTag).Select("max(id) as max").Find(&res)
	sql := fmt.Sprintf("alter sequence song.emo_tag_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)

	fmt.Println(time.Now(), "EmoTag [end]")
}

func dealEmoTag(item localdb.EmoTag) {
	data := handleEmoTag(item)

	if err := model.SongDB.Create(&data).Error; nil != err {
		panic(err)
	}
}

func handleEmoTag(item localdb.EmoTag) song.EmoTag {
	var data song.EmoTag
	data.ID = item.EmoTagID
	data.Name = item.EmoTagName
	data.NameKey = item.EmoTagName
	data.Image = item.EmoTagImage
	data.Seq = item.Seq
	data.IsShow = item.IsShow
	return data
}
