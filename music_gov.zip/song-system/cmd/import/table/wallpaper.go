package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// ImportWallpaper 导入动态壁纸
func ImportWallpaper() {
	fmt.Println(time.Now(), "动态壁纸 wallpaper [start]")
	items, err := model.LocalDB.Table(localdb.TableWallpaper).Rows()
	if err != nil {
		panic(err)
	}

	for items.Next() {
		var item localdb.Wallpaper
		if err := model.LocalDB.ScanRows(items, &item); nil != err {
			panic(err)
		}
		dealWallpaper(item)
	}
	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableWallpaper).Select("max(id) as max").Find(&res)
	sql := fmt.Sprintf("alter sequence song.wallpaper_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)

	fmt.Println(time.Now(), "动态壁纸 wallpaper [end]")
}

func dealWallpaper(item localdb.Wallpaper) {
	wallpaper := handleWallpaper(item)

	if err := model.SongDB.Create(&wallpaper).Error; nil != err {
		panic(err)
	}
}

func handleWallpaper(item localdb.Wallpaper) song.Wallpaper {
	wallpaper := song.Wallpaper{
		WallpaperNo:       item.WallpaperNo,
		WallpaperName:     item.WallpaperName,
		WallpaperFilename: item.WallpaperFilename,
		Codec:             item.Codec,
		Width:             item.Width,
		Height:            item.Height,
		HostIP:            item.HostIP,
		Location:          item.Location,
		PipX:              item.PipX,
		PipY:              item.PipY,
		PngX:              item.PngX,
		PngY:              item.PngY,
		Pip2X:             item.Pip2X,
		Pip2Y:             item.Pip2Y,
		Png2X:             item.Png2X,
		Png2Y:             item.Png2Y,
		PipWidth:          item.PipWidth,
		PipHeight:         item.PipHeight,
		PngHostIP:         item.PngHostIP,
		PngCount:          item.PngCount,
		EmoTagIds:         nil,
		CreatedAt:         util.NullTime{},
		UpdatedAt:         util.NullTime{},
	}

	emoIds, err := item.EmoTagID.ToPqInt64Arr()
	if err != nil {
		panic(err)
	}

	wallpaper.EmoTagIds = emoIds

	return wallpaper
}
