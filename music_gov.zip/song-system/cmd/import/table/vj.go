package table

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"time"
)

// ImportVj 导入vj
func ImportVj() {
	fmt.Println(time.Now(), "vj [start]")
	items, err := model.LocalDB.Table(localdb.TableVJ).Rows()
	if err != nil {
		panic(err)
	}

	for items.Next() {
		var item localdb.VJ
		if err := model.LocalDB.ScanRows(items, &item); nil != err {
			panic(err)
		}
		vj := dealVj(item)
		saveVj(vj)
	}
	var res struct {
		Max int
	}
	model.SongDB.Table(song.TableVj).Select("max(id) as max").Find(&res)
	sql := fmt.Sprintf("alter sequence song.vj_id_seq restart with %d", res.Max)
	model.SongDB.Exec(sql)

	fmt.Println(time.Now(), "vj [end]")
}

func saveVj(vj song.Vj) {
	if err := model.SongDB.Create(&vj).Error; nil != err {
		panic(err)
	}
}

func dealVj(item localdb.VJ) song.Vj {
	return song.Vj{
		ID:         item.VjID,
		Name:       item.VjName,
		Filename:   item.VjFilename,
		HostIP:     item.HostIP,
		Codec:      item.Codec,
		CategoryID: item.CategoryID,
	}
}
