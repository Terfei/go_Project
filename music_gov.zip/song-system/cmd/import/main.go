package main

import (
	"flag"
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/cmd/import/table"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"os"
)

var conf string

func init() {
	flag.StringVar(&conf, "c", "", "指定配置文件位置")
	flag.Parse()
	if conf == "" {
		Usage()
		panic("指定配置文件位置")
	}

	// 载入配置文件
	config.Load(conf)

	model.LocalDBConnection(config.Setting.Database.Sqlite)
	model.SongSystemConnection(config.Setting.Database.Song)
	model.SQLServerConnection(config.Setting.Database.SQLServer)
	model.BridgeConnection(config.Setting.Database.Bridge)
}

func main() {
	// 伴奏
	table.ImportAccompany()
	// 歌手
	table.ImportSinger()
	//　伴奏音质
	table.ImportAccompanyAudioQlty()
	// 伴奏分类
	table.ImportAccompanyCategory()
	// 伴奏语种
	table.ImportAccompanyLanguage()
	// 伴奏标签
	table.ImportAccompanyTag()
	// 伴奏视频质量
	table.ImportAccompanyVersion()
	// 伴奏版本
	table.ImportAccompanyVideoQlty()
	// 情绪标签
	table.ImportEmoTag()
	// 门店授权
	table.ImportAuthorize()
	// 歌手区域
	table.ImportSingerArea()
	//动态壁纸
	table.ImportWallpaper()
	// 公播
	table.ImportAcc()
	// 派对舞曲
	table.ImportPartyDance()
	// vj视频
	table.ImportVj()
	// 跳舞视频
	table.ImportActVideo()
	// 生成默认批次
	table.MakeDefaultVersion()
}

// Usage 返回使用方法
func Usage() {
	fmt.Fprintf(os.Stderr, `
Usage: go run cmd/import/main.go -c {config}
`)
}
