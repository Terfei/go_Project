package main

import (
	"flag"
	"fmt"
	"os"

	"github.com/golang-migrate/migrate/v4"
	_ "github.com/golang-migrate/migrate/v4/database/postgres"
	_ "github.com/golang-migrate/migrate/v4/source/file"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
)

const (
	// MIGRATEUP 迁移
	MIGRATEUP string = "up"
	// MIGRATEDOWN 回滚
	MIGRATEDOWN string = "down"
)

var conf string
var path string
var action string

func init() {
	flag.StringVar(&conf, "c", "", "指定配置文件位置")
	flag.StringVar(&path, "p", "", "指定迁移文件位置")
	flag.StringVar(&action, "a", "", "指定迁移动作")
	flag.Parse()
	if conf == "" {
		panic("请指定配置文件位置")
	}
	if path == "" {
		panic("请指定迁移文件位置")
	}

	if action != MIGRATEDOWN && action != MIGRATEUP {
		Usage()
		panic("请指定正确的执行操作")
	}

	// 载入配置文件
	config.Load(conf)
}

func main() {
	c := config.Setting.Database.Song
	filePath := fmt.Sprintf("file://%s", path)
	dbSource := fmt.Sprintf("postgres://%s:%s@%s:%d/%s?sslmode=disable",
		c.User, c.Password, c.Server, c.Port, c.Database)
	mig, err := migrate.New(filePath, dbSource)
	if err != nil {
		panic("数据库迁移功能初始化失败")
	}

	switch action {
	case MIGRATEUP:
		// 迁移
		if err := mig.Up(); err != nil {
			fmt.Println(err.Error())
			panic("执行迁移失败")
		}
	case MIGRATEDOWN:
		// 回滚
		if err = mig.Down(); err != nil {
			fmt.Println(err.Error())
			panic("执行回滚失败")
		}
	}
	os.Exit(0)
}

// Usage 返回使用方法
func Usage() {
	fmt.Fprintf(os.Stderr, `
Usage: go run cmd/migrate/main.go -c {config} -p {filepath} -a {action}
Options:
	action:		up, down, force
Example:
	go run cmd/migrate/main.go -c configs/setting.toml -p ./database/migrations -a up
	go run cmd/migrate/main.go -c configs/setting.toml -p ./database/migrations -a down
`)
}
