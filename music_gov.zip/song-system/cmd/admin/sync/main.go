package sync

import (
	"context"
	"fmt"
	"github.com/sirupsen/logrus"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"net/http"
	"os"
	"time"
)

// BranchSyncParams 门店同步参数
type BranchSyncParams struct {
	StartDate   string
	SyncVersion string
	BranchID    string
	Folder      string
	LocalDBFile string
	History     *branch.SyncHistory
}

// BranchSyncRedisKey redis key
var BranchSyncRedisKey = `branch_sync`

// DealBranchSync 处理门店同步信息
func DealBranchSync() {
	logger.Entry().Info("开始处理门店同步任务,start")
	ctx := context.Background()

	if err := model.RedisConnection(config.Setting.Database.Redis); nil != err {
		logger.Entry().WithError(err).Error("门店同步任务,redis连接错误")
		return
	}

	if model.Rds.Exists(ctx, BranchSyncRedisKey).Val() != 1 {
		logger.Entry().Info("门店同步任务,redis信息为空,跳过")
		return
	}

	items := model.Rds.HKeys(ctx, BranchSyncRedisKey).Val()
	logger.Entry().WithField("branches", items).Info("门店同步任务, 需要处理的门店信息")

	if len(items) == 0 {
		logger.Entry().Info("门店同步任务,[redis empty],跳过")
		return
	}

	// 判断是否在处理中
	var ids []string
	for _, id := range items {
		val := model.Rds.HGet(ctx, BranchSyncRedisKey, id).Val()
		if val == "deal" {
			logger.Entry().WithField("branch_id", id).Info("门店同步任务,该门店处理中,跳过")
			continue
		}

		model.Rds.HSet(ctx, BranchSyncRedisKey, id, "deal")
		ids = append(ids, id)
	}

	if len(ids) > 0 {
		//处理门店同步任务
		workDealSync(ids)

		model.Rds.Del(ctx, BranchSyncRedisKey)
	}
}
func workDealSync(branchIDs []string) {
	d, err := time.ParseDuration("-240h")
	if err != nil {
		logger.Entry().WithError(err).Error("门店同步服务，初始时间错误")
		return
	}

	startDate := time.Now().Add(d).Format("2006-01-02")
	syncVersion := time.Now().Format("20060102150405")

	work := util.NewWork(len(branchIDs))
	for idx, item := range branchIDs {
		work.Add(idx + 1)

		params := BranchSyncParams{
			StartDate:   startDate,
			SyncVersion: syncVersion,
			BranchID:    item,
		}

		go deal(params, work)
	}

	work.Wait()
}

// deal 处理
func deal(params BranchSyncParams, work *util.Work) {
	defer work.Done()
	params.Folder = fmt.Sprintf("%s/%s", config.Setting.Storage.Path, params.BranchID)
	params.LocalDBFile = fmt.Sprintf("%s/%s/local.db", config.Setting.Storage.Path, params.BranchID)

	history, err := createSyncHistory(params)
	if err != nil {
		logger.Entry().WithError(err).Error("创建同步历史错误")
		return
	}
	params.History = history

	logFields := logrus.Fields{
		"branch_id":    params.BranchID,
		"sync_version": params.SyncVersion,
		"folder":       params.Folder,
		"db":           params.LocalDBFile,
	}

	if err := dealBranchLocalDB(params); nil != err {
		logger.Entry().WithFields(logFields).WithError(err).Error("初始门店db文件失败")
		updateSyncHistoryFail(params.History, "初始门店db文件失败")
		return
	}

	//开始处理数据
	if err := dealBranchExport(params); nil != err {
		logger.Entry().WithFields(logFields).WithError(err).Error("处理门店数据失败")
		updateSyncHistoryFail(params.History, err.Error())
		return
	}

	//压缩上传
	if err := archivePutOss(params); nil != err {
		logger.Entry().WithFields(logFields).WithError(err).Error("压缩上传失败")
		updateSyncHistoryFail(params.History, err.Error())
		return
	}

	if err := notifyBranch(params); nil != err {
		logger.Entry().WithFields(logFields).WithError(err).Error("通知门店失败")
		updateSyncHistoryFail(params.History, err.Error())
		return
	}

	updateSyncHistorySuccess(params.History)

	logger.Entry().WithFields(logFields).Info("处理完成")
}

func archivePutOss(params BranchSyncParams) error {
	compressFile := fmt.Sprintf("%s/%s.7z", params.Folder, params.SyncVersion)
	archive := util.NewArchive(compressFile, params.LocalDBFile)
	if err := archive.CompressionFile(); nil != err {
		logger.Entry().WithError(err).Error("压缩文件失败")
		return fmt.Errorf("压缩文件失败, err:%s", err.Error())
	}

	//上传aliyun
	f, err := os.Open(compressFile)
	if nil != err {
		return fmt.Errorf("上传读取文件失败, err:%s", err.Error())
	}

	ossConfig := config.Setting.Aliyun.Oss
	ossFile := fmt.Sprintf("%s/%s/%s.7z", ossConfig.Db, params.BranchID, params.SyncVersion)
	if err := util.NewAliyunOss(ossConfig).Upload(f, ossFile); nil != err {
		return fmt.Errorf("上传阿里云失败, err:%s", err.Error())
	}

	return nil
}

func notifyBranch(params BranchSyncParams) error {
	var server branch.Server
	if err := model.SongDB.Where("branch_id = ?", params.BranchID).First(&server).Error; nil != err {
		return fmt.Errorf("[查询门店服务, err:%s]", err.Error())
	}

	url := fmt.Sprintf("%s/api/sync", server.Domain)

	request := util.Params{}
	request.Set("version", params.SyncVersion)
	request.Set("branch_id", params.BranchID)
	request.Set("file", fmt.Sprintf("%s/%s/%s.7z", config.Setting.Aliyun.Oss.Db, params.BranchID, params.SyncVersion))

	rst, err := util.HTTPPost(url, request, http.StatusNoContent)
	if err != nil {
		return fmt.Errorf("[]通知门店, err:%s", err.Error())
	}

	logger.Entry().WithFields(logrus.Fields{
		"url":     url,
		"request": request,
		"result":  string(rst),
	}).Info("请求门店接口")

	return nil
}

// dealBranchLocalDB 初始门店db
func dealBranchLocalDB(params BranchSyncParams) error {
	logger.Entry().WithField("params", params).Info("门店同步服务，处理门店文件信息")
	if exists, err := util.FileExists(params.LocalDBFile); exists || err != nil {
		return err
	}

	if err := util.Mkdir(params.Folder); nil != err {
		return err
	}

	return util.CpFile(config.Setting.Storage.DB, params.LocalDBFile)
}
