package sync

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
)

func createSyncHistory(params BranchSyncParams) (*branch.SyncHistory, error) {
	var history branch.SyncHistory
	if err := model.SongDB.Table(branch.TableSyncHistory).Where("branch_id = ?", params.BranchID).Where("sync_code = ?", params.SyncVersion).First(&history); nil == err {
		return &history, nil
	}

	data := branch.SyncHistory{
		BranchID: params.BranchID,
		SyncCode: params.SyncVersion,
		Status:   "init",
	}

	if err := model.SongDB.Create(&data).Error; nil != err {
		return nil, err
	}

	return &data, nil
}

func updateSyncHistoryFail(history *branch.SyncHistory, remark string) {
	params := map[string]interface{}{
		"status": "fail",
		"remark": remark,
	}

	updateSyncHistory(history, params)
}

func updateSyncHistorySuccess(history *branch.SyncHistory) {
	params := map[string]interface{}{
		"status": "success",
	}

	updateSyncHistory(history, params)
}

func updateSyncHistory(history *branch.SyncHistory, params map[string]interface{}) {
	model.SongDB.Model(&branch.SyncHistory{}).Where("id = ?", history.ID).Update(params)
}
