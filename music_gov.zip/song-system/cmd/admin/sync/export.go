package sync

import (
	"fmt"
	"github.com/jinzhu/gorm"
	dbGorm "gitlab.omytech.com.cn/gopkg/db/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/cmd/admin/sync/export"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/report"
	"time"
)

func dealBranchExport(params BranchSyncParams) error {
	//初始数据库链接
	db := dbGorm.Build(dbGorm.Config{
		Dialect: dbGorm.ConfigDialectSqliteV3,
		Server:  params.LocalDBFile,
	}).LogMode(true)

	if err := migrate(db); nil != err {
		logger.Entry().WithError(err).Error("初始门店数据库迁移失败")
		return err
	}

	if err := exportBaseTables(db, params); nil != err {
		return err
	}

	versions := getVersions(params)

	if err := exportMaterialTable(db, params, versions); nil != err {
		return err
	}

	return nil
}

func exportMaterialTable(db *gorm.DB, params BranchSyncParams, versions []branch.Version) error {
	for _, version := range versions {
		if err := export.Accompany(db, params.StartDate, version); nil != err {
			return fmt.Errorf("accompany version:%s, err:%s", version.VersionCode, err.Error())
		}

		if err := export.Singer(db, params.StartDate, version); nil != err {
			return fmt.Errorf("singer version:%s, err:%s", version.VersionCode, err.Error())
		}

		if err := export.Acc(db, params.StartDate, version); nil != err {
			return fmt.Errorf("acc version:%s, err:%s", version.VersionCode, err.Error())
		}

		if err := export.Vj(db, params.StartDate, version); nil != err {
			return fmt.Errorf("vj version:%s, err:%s", version.VersionCode, err.Error())
		}

		if err := export.PartyDance(db, params.StartDate, version); nil != err {
			return fmt.Errorf("party dance version:%s, err:%s", version.VersionCode, err.Error())
		}

		if err := export.Wallpaper(db, params.StartDate, version); nil != err {
			return fmt.Errorf("wallpaper version:%s, err:%s", version.VersionCode, err.Error())
		}

		if err := export.ActVideo(db, params.StartDate, version); nil != err {
			return fmt.Errorf("act video version:%s, err:%s", version.VersionCode, err.Error())
		}
	}

	if err := refreshAccompanyRank(db, params); nil != err {
		return fmt.Errorf("刷新歌曲排行信息错误, err:%s", err.Error())
	}

	if err := refreshSingerRank(db); nil != err {
		return fmt.Errorf("刷新歌手排行信息错误, err:%s", err.Error())
	}

	return nil
}

func refreshSingerRank(db *gorm.DB) error {
	singerTop := getSingerTop()
	singerRank := getSingerRank()

	topCount := len(singerTop)
	rankCount := len(singerRank)
	var singers []localdb.Singer
	db.Table(localdb.TableSinger).Find(&singers)

	for idx, singer := range singers {
		update := make(map[string]interface{})

		// 存在置顶
		if top, exists := singerTop[singer.SingerID]; exists {
			update["rank"] = top

			if err := updateSingerRank(db, singer, update); nil != err {
				logger.Entry().WithError(err).Error("重新刷新歌手排名置顶, 更新错误")
				return fmt.Errorf("重新刷新歌手排名置顶,更新, err:%s", err.Error())
			}

			continue
		}

		if rank, exists := singerRank[singer.SingerID]; exists {
			update["rank"] = topCount + rank
		} else {
			update["rank"] = topCount + rankCount + idx + 1
		}

		if err := updateSingerRank(db, singer, update); nil != err {
			logger.Entry().WithError(err).Error("重新刷新歌手排名, 更新错误")
			return fmt.Errorf("重新刷新歌手排名,更新, err:%s", err.Error())
		}

		time.Sleep(time.Microsecond * 10)
	}

	return nil
}

func updateSingerRank(db *gorm.DB, singer localdb.Singer, update map[string]interface{}) error {
	logger.Entry().WithField("params", map[string]interface{}{
		"singer_id":   singer.SingerID,
		"singer_name": singer.SingerName,
		"rank":        update,
	}).Info("刷新歌手排名信息")

	return db.Table(localdb.TableSinger).Where("singer_id = ?", singer.SingerID).Update(update).Error
}

// 刷新排名
// 存在置顶，直接使用置顶顺序
// 不存在置顶，使用点击数排名
// 不存在置顶 没有点击数
func refreshAccompanyRank(db *gorm.DB, params BranchSyncParams) error {
	accompanyTop := getAccompanyTop()
	accompanyCountryRank := getAccompanyCountryRank()
	accompanyLocalRank := getAccompanyLocalRank(params)

	topCount := len(accompanyTop)
	countryRankCount := len(accompanyCountryRank)
	localRankCount := len(accompanyLocalRank)

	var accompanys []localdb.Accompany
	db.Table(localdb.TableAccompany).Find(&accompanys)

	for idx, accompany := range accompanys {
		update := make(map[string]interface{})
		// 存在置顶
		if top, exists := accompanyTop[accompany.AccompanyID]; exists {
			update["rank"] = top
			update["local_rank"] = top

			if err := updateAccompanyRank(db, accompany, update); nil != err {
				logger.Entry().WithError(err).Error("重新刷新歌曲排名置顶, 更新错误")
				return fmt.Errorf("重新刷新歌曲排名置顶,更新, err:%s", err.Error())
			}

			continue
		}

		// 全国点击数
		if rank, exists := accompanyCountryRank[accompany.AccompanyID]; exists {
			update["rank"] = rank + topCount
		} else {
			update["rank"] = topCount + countryRankCount + idx + 1
		}

		if rank, exists := accompanyLocalRank[accompany.AccompanyID]; exists {
			update["local_rank"] = rank + topCount
		} else {
			update["local_rank"] = topCount + localRankCount + idx + 1
		}

		if err := updateAccompanyRank(db, accompany, update); nil != err {
			logger.Entry().WithError(err).Error("重新刷新歌曲排名排名, 更新错误")
			return fmt.Errorf("重新刷新歌曲排名,更新, err:%s", err.Error())
		}

		time.Sleep(time.Microsecond * 10)
	}

	return nil
}

func updateAccompanyRank(db *gorm.DB, accompany localdb.Accompany, update map[string]interface{}) error {
	logger.Entry().WithField("params", map[string]interface{}{
		"accompany_id":   accompany.AccompanyID,
		"accompany_name": accompany.AccompanyName,
		"rank":           update,
	}).Info("刷新歌曲排名信息")

	return db.Table(localdb.TableAccompany).Where("accompany_id = ?", accompany.AccompanyID).Update(update).Error
}

func migrate(db *gorm.DB) error {
	if err := db.Exec(`DROP table if exists Sync_Version_Detail`).Error; nil != err {
		return err
	}

	sql := `CREATE TABLE Sync_Version_Detail(
	id integer PRIMARY KEY AUTOINCREMENT,
    version_id int not null,
	version_code CHAR(11) not null,
	version_category_id int not null,
	relation_type varchar(32) not null,
	relation_id int not null,
	dir varchar(32),
	filename varchar(64),
	oss_filename varchar(64),
	disk_file varchar(64),
	is_download smallint default 0
);`
	return db.Exec(sql).Error
}

func exportBaseTables(db *gorm.DB, params BranchSyncParams) error {
	if err := export.AccompanyAudioqlty(db, params.StartDate); nil != err {
		return err
	}

	if err := export.AccompanyCategory(db, params.StartDate); nil != err {
		return err
	}

	if err := export.AccompanyLanguage(db, params.StartDate); nil != err {
		return err
	}

	if err := export.AccompanyTag(db, params.StartDate); nil != err {
		return err
	}

	if err := export.AccompanyVersion(db, params.StartDate); nil != err {
		return err
	}

	if err := export.AccompanyVideoqlty(db, params.StartDate); nil != err {
		return err
	}

	if err := export.EmoTag(db, params.StartDate); nil != err {
		return err
	}

	if err := export.SingerArea(db, params.StartDate); nil != err {
		return err
	}

	return nil
}

func getVersions(params BranchSyncParams) []branch.Version {
	var versions []branch.Version
	model.SongDB.Table(branch.TableVersion).
		Where("branch_id = ?", params.BranchID).
		Order("updated_at").
		Unscoped().
		Find(&versions)

	return versions
}

func getAccompanyTop() map[int]int {
	type top struct {
		AccompanyID int `json:"accompany_id"`
		Weight      int `json:"weight"`
	}

	var tops []top
	model.SongDB.Table(report.TableAccompanyTopping).Select("accompany_id, weight").Order("weight").Scan(&tops)

	response := make(map[int]int)
	for idx, t := range tops {
		response[t.AccompanyID] = idx + 1
	}

	logger.Entry().WithField("accompany top", response).Info("歌曲置顶结果")

	return response
}

func getAccompanyLocalRank(params BranchSyncParams) map[int]int {
	type rank struct {
		AccompanyID int    `json:"accompany_id"`
		SumTimes    int    `json:"sum_times"`
		Songno      string `json:"songno"`
	}
	var ranks []rank
	model.SongDB.Table(report.TableReportAccompanyClicks).
		Where("branch_id = ?", params.BranchID).
		Where("accompany_id > 0").
		Select("accompany_id,songno,sum(times) as sum_times").
		Group("accompany_id,songno").
		Order("sum_times desc, songno asc").
		Scan(&ranks)

	response := make(map[int]int)
	for idx, r := range ranks {
		response[r.AccompanyID] = idx + 1
	}

	return response
}

func getAccompanyCountryRank() map[int]int {
	type rank struct {
		AccompanyID int    `json:"accompany_id"`
		SumTimes    int    `json:"sum_times"`
		Songno      string `json:"songno"`
	}
	var ranks []rank
	model.SongDB.Table(report.TableReportAccompanyClicks).
		Where("accompany_id > 0").
		Select("accompany_id,songno,sum(times) as sum_times").
		Group("accompany_id,songno").
		Order("sum_times desc, songno asc").
		Scan(&ranks)

	response := make(map[int]int)
	for idx, r := range ranks {
		response[r.AccompanyID] = idx + 1
	}

	return response
}

func getSingerTop() map[int]int {
	type top struct {
		SingerID int `json:"singer_id"`
		Weight   int `json:"weight"`
	}

	var tops []top
	model.SongDB.Table(report.TableAccompanyTopping).Select("singer_id, weight").Order("weight").Scan(&tops)

	response := make(map[int]int)
	for idx, t := range tops {
		response[t.SingerID] = idx + 1
	}

	logger.Entry().WithField("singer top", response).Info("歌手置顶结果")

	return response
}

func getSingerRank() map[int]int {
	type rank struct {
		SingerID int `json:"singer_id"`
		SumTimes int `json:"sum_times"`
	}
	var ranks []rank
	model.SongDB.Table(report.TableReportAccompanyClicks).
		Where("singer_id > 0").
		Select("singer_id,sum(times) as sum_times").
		Group("singer_id").
		Order("sum_times desc").
		Scan(&ranks)

	response := make(map[int]int)
	for idx, r := range ranks {
		response[r.SingerID] = idx + 1
	}

	return response
}
