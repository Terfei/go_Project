package export

import (
	"errors"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// SingerArea singer_area
func SingerArea(localDB *gorm.DB, start string) error {
	logger.Entry().Info("同步　singer_area")
	db := model.SongDB
	items, err := db.Model(&song.SingerArea{}).Unscoped().Where("updated_at > ?", start).Rows()
	if items == nil {
		logger.Entry().Info("singer_area empty")
		return nil
	}
	defer items.Close()

	if err != nil {
		logger.Entry().WithError(err).Error("singer_area error")
		return errors.New("singer_area error")
	}

	for items.Next() {
		var item song.SingerArea

		if err := db.ScanRows(items, &item); nil != err {
			logger.Entry().WithError(err).Error("singer_area scan error")
			return errors.New("singer_area scan error")
		}

		if err := dealSingerArea(localDB, item); nil != err {
			logger.Entry().WithError(err).WithField("id", item.ID).Error("singer_area 保存信息错误")
			return errors.New("singer_area 保存信息错误")
		}
	}

	return nil
}

func dealSingerArea(localDB *gorm.DB, item song.SingerArea) error {
	if item.DeletedAt != nil {
		return localDB.Where("area_id = ?", item.ID).Delete(&localdb.SingerArea{}).Error
	}

	var count int
	localDB.Table(localdb.TableSingerArea).Where("area_id = ?", item.ID).Count(&count)

	a := makeSingerArea(item)
	if count > 0 {
		update := util.StructToMap(a)
		return localDB.Model(&localdb.SingerArea{}).Where("area_id = ?", item.ID).Update(update).Error
	}

	return localDB.Create(&a).Error
}

func makeSingerArea(item song.SingerArea) localdb.SingerArea {
	return localdb.SingerArea{
		AreaID:    item.ID,
		AreaName:  item.Name,
		AreaImage: item.Image,
		Seq:       item.Seq,
	}
}
