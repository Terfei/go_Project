package export

import (
	"database/sql"
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// Acc 公播
func Acc(localDB *gorm.DB, start string, version branch.Version) error {
	logger.Entry().WithField("version", version.VersionCode).Info("同步 acc")
	db := model.SongDB
	var items *sql.Rows
	var err error
	if version.DeletedAt == nil && version.CanDownload == 1 {
		items, err = db.Table(song.TableAcc).Where("updated_at > ?", start).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	} else {
		items, err = db.Table(song.TableAcc).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	}

	if items == nil || err != nil {
		logger.Entry().Info("acc empty or error")
		return nil
	}
	defer items.Close()

	var category branch.VersionCategory
	if version.DeletedAt == nil {
		category = songVersionCategory(version, branch.VersionCategoryTypeAcc)
	}

	for items.Next() {
		var acc song.Acc
		if err := db.ScanRows(items, &acc); nil != err {
			logger.Entry().WithError(err).Error("acc scan err")
			return errors.New("acc scan err")
		}

		if version.DeletedAt == nil && version.CanDownload == 1 {
			if err := dealAcc(localDB, category, acc); nil != err {
				logger.Entry().WithError(err).WithField("acc_id", acc.ID).Error("acc save error")
				return fmt.Errorf("acc_id:%d, 保存信息错误, err:%s", acc.ID, err.Error())
			}
		} else {
			logger.Entry().WithField("id", acc.AccID).Info("批次删除 acc")
			if err := localDB.Where("autoplay_acc_id = ?", acc.AccID).Delete(&localdb.AutoPlayAcc{}).Error; nil != err {
				logger.Entry().WithError(err).WithField("acc_id", acc.ID).Error("批次删除 acc save error")
				return fmt.Errorf("acc_id:%d, 批次删除, 保存信息错误, err:%s", acc.ID, err.Error())
			}
		}

		time.Sleep(time.Microsecond * 100)
	}

	return resetBranchCategory(category)
}

func dealAcc(localDB *gorm.DB, category branch.VersionCategory, item song.Acc) error {
	acc := makeAcc(item)

	return localDB.Transaction(func(tx *gorm.DB) error {
		resetBranchDetail(category.BranchID, item.ID, branch.VersionCategoryTypeAcc)
		if item.DeletedAt != nil {
			logger.Entry().WithField("id", acc.AutoplayAccID).Info("删除 acc")

			return tx.Where("autoplay_acc_id = ?", acc.AutoplayAccID).Delete(&localdb.AutoPlayAcc{}).Error
		}
		if err := dealAccFile(tx, category, item); nil != err {
			logger.Entry().WithError(err).WithField("acc id", item.ID).Error("处理文件失败")
			return err
		}
		var count int
		tx.Table(localdb.TableAutoPlayAcc).Where("autoplay_acc_id = ?", acc.AutoplayAccID).Count(&count)
		if count > 0 {
			update := util.StructToMap(acc)
			return tx.Table(localdb.TableAutoPlayAcc).Where("autoplay_acc_id = ?", acc.AutoplayAccID).Update(update).Error
		}

		return tx.Create(&acc).Error
	})
}

func dealAccFile(db *gorm.DB, category branch.VersionCategory, item song.Acc) error {
	var files []detailFile

	files = append(files, detailFile{
		File:    fmt.Sprintf("%s.%s", item.Filename, item.Codec),
		OssFile: fmt.Sprintf("%s/%s.%s", config.Setting.Aliyun.Oss.Song, item.Filename, item.Codec),
	})

	if item.Filename2 != "" {
		files = append(files, detailFile{
			File:    fmt.Sprintf("%s.%s", item.Filename2, item.Codec),
			OssFile: fmt.Sprintf("%s/%s.%s", config.Setting.Aliyun.Oss.Song, item.Filename2, item.Codec),
		})
	}

	for _, file := range files {
		if err := saveVersionDetail(db, category, file, item.ID, branch.VersionCategoryTypeAcc); nil != err {
			return fmt.Errorf("处理公播文件详情, err:%s", err.Error())
		}
	}
	return nil
}

func makeAcc(item song.Acc) localdb.AutoPlayAcc {
	return localdb.AutoPlayAcc{
		AutoplayAccID:        item.AccID,
		AutoplayAccName:      item.AccName,
		HostIP:               item.HostIP,
		AutoplayAccFilename:  item.Filename,
		AutoplayAccFilename2: item.Filename2,
		ListID:               item.AccType.Int(), //acc type
		ListName:             item.ListName,
		Seq:                  item.Seq,
		Codec:                item.Codec,
		Channel:              item.Channel,
		LampID:               item.LampID,
		ReverberationID:      item.ReverberationID,
		EffectID:             item.EffectID,
		Volume:               item.Volume,
		Audio:                item.Audio,
		StartTime:            item.StartTime,
		EndTime:              item.EndTime,
		Mode:                 item.Mode,
		StrLevel:             item.StrLevel,
	}
}
