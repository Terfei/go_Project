package export

import (
	"database/sql"
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// Singer 歌手
func Singer(localDB *gorm.DB, start string, version branch.Version) error {
	logger.Entry().WithField("version", version.VersionCode).Info("同步 singer")
	db := model.SongDB

	var items *sql.Rows
	var err error
	if version.DeletedAt == nil && version.CanDownload == 1 {
		items, err = db.Table(song.TableNameSinger).Where("updated_at > ?", start).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	} else {
		items, err = db.Table(song.TableNameSinger).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	}

	if items == nil || nil != err {
		logger.Entry().Info("singer empty or error")
		return nil
	}
	defer items.Close()

	var category branch.VersionCategory
	if version.DeletedAt == nil {
		category = songVersionCategory(version, branch.VersionCategoryTypeSinger)
	}

	for items.Next() {
		var singer song.Singer

		if err := db.ScanRows(items, &singer); nil != err {
			logger.Entry().WithError(err).Error("singer scan err")
			return errors.New("singer scan err")
		}

		if version.DeletedAt == nil && version.CanDownload == 1 {
			if err := dealSinger(localDB, category, singer); nil != err {
				logger.Entry().WithError(err).WithField("singer_id", singer.ID).Error("singer 保存错误")
				return fmt.Errorf("singer_id:%d, 保存信息错误，err:%s", singer.ID, err.Error())
			}
		} else {
			logger.Entry().WithField("id", singer.ID).Info("批次删除 singer")
			if err := localDB.Where("singer_id = ?", singer.ID).Delete(&localdb.Singer{}).Error; nil != err {
				logger.Entry().WithError(err).WithField("singer_id", singer.ID).Error("批次删除 singer 保存信息错误")
				return fmt.Errorf("singer_id:%d, 批次删除,保存信息错误，err:%s", singer.ID, err.Error())
			}
		}

		time.Sleep(time.Microsecond * 100)
	}

	return resetBranchCategory(category)
}

func dealSinger(localDB *gorm.DB, category branch.VersionCategory, item song.Singer) error {
	singer := makeSinger(item)

	return localDB.Transaction(func(tx *gorm.DB) error {
		resetBranchDetail(category.BranchID, item.ID, branch.VersionCategoryTypeSinger)
		if item.DeletedAt != nil {
			logger.Entry().WithField("id", singer.SingerID).Info("删除 singer")

			return tx.Where("singer_id = ?", singer.SingerID).Delete(&localdb.Singer{}).Error
		}

		if err := dealSingerFile(tx, category, item); nil != err {
			logger.Entry().WithError(err).WithField("id", item.ID).Error("处理文件失败")
			return err
		}

		var count int
		tx.Table(localdb.TableSinger).Where("singer_id = ?", singer.SingerID).Count(&count)
		if count > 0 {
			update := util.StructToMap(singer)
			return tx.Table(localdb.TableSinger).Where("singer_id = ?", singer.SingerID).Update(update).Error
		}

		return tx.Create(&singer).Error
	})
}

func dealSingerFile(db *gorm.DB, category branch.VersionCategory, item song.Singer) error {
	var files []detailFile

	files = append(files, detailFile{
		File:    fmt.Sprintf("%s.jpg", item.Name),
		OssFile: fmt.Sprintf("%s/%s.jpg", config.Setting.Aliyun.Oss.Image, item.Name),
	})

	for _, file := range files {
		if err := saveVersionDetail(db, category, file, item.ID, branch.VersionCategoryTypeSinger); nil != err {
			return fmt.Errorf("保存文件详情, err:%s", err.Error())
		}
	}
	return nil
}

func makeSinger(item song.Singer) localdb.Singer {
	return localdb.Singer{
		SingerID:        item.ID,
		SingerName:      item.Name,
		SingerNickname:  item.Nickname,
		SingerNameSpell: item.NameSpell,
		CharCount:       item.CharCount,
		SingerGender:    item.Gender.Int(),
		AreaID:          item.AreaID,
		SingerImage:     fmt.Sprintf("%s.jpg", item.Name),
		Weight:          item.Weight,
	}
}
