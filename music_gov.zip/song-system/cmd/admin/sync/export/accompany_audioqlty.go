package export

import (
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// AccompanyAudioqlty accompany_audioqlty
func AccompanyAudioqlty(localDB *gorm.DB, start string) error {
	logger.Entry().Info("同步　accompany_audioqlty")
	db := model.SongDB
	items, err := db.Model(&song.AccompanyAudioqlty{}).Unscoped().Where("updated_at > ?", start).Rows()
	if items == nil {
		logger.Entry().Info("accompany_audioqlty empty")
		return nil
	}
	defer items.Close()

	if err != nil {
		logger.Entry().WithError(err).Error("accompany_audioqlty error")
		return errors.New("accompany_audioqlty error")
	}

	for items.Next() {
		var item song.AccompanyAudioqlty

		if err := db.ScanRows(items, &item); nil != err {
			logger.Entry().WithError(err).Error("accompany_audioqlty scan error")
			return errors.New("accompany_audioqlty scan error")
		}

		if err := dealAccompanyAudioqlty(localDB, item); nil != err {
			logger.Entry().WithError(err).WithField("id", item.ID).Error("accompany_audioqlty 保存信息错误")
			return fmt.Errorf("accompany audiolty id:%s,保存信息错误", item.ID)
		}
	}

	return nil
}

func dealAccompanyAudioqlty(localDB *gorm.DB, item song.AccompanyAudioqlty) error {
	if item.DeletedAt != nil {
		return localDB.Where("audioqlty_id = ?", item.ID).Delete(&localdb.AccompanyAudioQlty{}).Error
	}

	var count int
	localDB.Table(localdb.TableAccompanyAudioQlty).Where("audioqlty_id = ?", item.ID).Count(&count)

	a := makeAccompanyAudioqlty(item)
	if count > 0 {
		update := util.StructToMap(a)
		return localDB.Model(&localdb.AccompanyAudioQlty{}).Where("audioqlty_id = ?", item.ID).Update(update).Error
	}

	return localDB.Create(&a).Error
}

func makeAccompanyAudioqlty(item song.AccompanyAudioqlty) localdb.AccompanyAudioQlty {
	return localdb.AccompanyAudioQlty{
		AudioqltyID:    item.ID,
		AudioqltyCode:  item.Code,
		Seq:            item.Seq,
		IsShow:         item.IsShow,
		AudioqltyImage: item.Image,
	}
}
