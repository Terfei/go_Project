package export

import (
	"errors"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// AccompanyTag accompany_tag
func AccompanyTag(localDB *gorm.DB, start string) error {
	logger.Entry().Info("同步 accompany_tag")
	db := model.SongDB
	items, err := db.Model(&song.AccompanyTag{}).Unscoped().Where("updated_at > ?", start).Rows()
	if items == nil {
		logger.Entry().Info("accompany_tag empty")
		return nil
	}
	defer items.Close()

	if err != nil {
		logger.Entry().WithError(err).Error("accompany_tag error")
		return errors.New("accompany_tag error")
	}

	for items.Next() {
		var item song.AccompanyTag

		if err := db.ScanRows(items, &item); nil != err {
			logger.Entry().WithError(err).Error("accompany_tag scan error")
			return errors.New("accompany_tag scan error")
		}

		if err := dealAccompanyTag(localDB, item); nil != err {
			logger.Entry().WithError(err).WithField("id", item.ID).Error("accompany_tag 保存数据信息")
			return errors.New("accompany_tag 保存数据信息")
		}
	}

	return nil
}

func dealAccompanyTag(localDB *gorm.DB, item song.AccompanyTag) error {
	if item.DeletedAt != nil {
		return localDB.Where("tag_id = ?", item.ID).Delete(&localdb.AccompanyTag{}).Error
	}

	var count int
	localDB.Table(localdb.TableAccompanyTag).Where("tag_id = ?", item.ID).Count(&count)

	a := makeAccompanyTag(item)
	if count > 0 {
		update := util.StructToMap(a)
		return localDB.Model(&localdb.AccompanyTag{}).Where("tag_id = ?", item.ID).Update(update).Error
	}
	return localDB.Create(&a).Error
}

func makeAccompanyTag(item song.AccompanyTag) localdb.AccompanyTag {
	return localdb.AccompanyTag{
		TagID:   item.ID,
		TagName: item.Name,
		Seq:     item.Seq,
		IsShow:  item.IsShow,
	}
}
