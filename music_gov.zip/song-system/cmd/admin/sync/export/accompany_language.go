package export

import (
	"errors"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// AccompanyLanguage accompany_language
func AccompanyLanguage(LocalDB *gorm.DB, start string) error {
	logger.Entry().Info("同步 accompany_language")
	db := model.SongDB
	items, err := db.Model(&song.AccompanyLanguage{}).Unscoped().Where("updated_at > ?", start).Rows()
	if items == nil {
		logger.Entry().Info("accompany_language empty")
		return nil
	}
	defer items.Close()

	if err != nil {
		logger.Entry().WithError(err).Error("accompany_language error")
		return errors.New("accompany_language error")
	}

	for items.Next() {
		var item song.AccompanyLanguage

		if err := db.ScanRows(items, &item); nil != err {
			logger.Entry().WithError(err).Error("accompany_language scan error")
			return errors.New("accompany_language scan error")
		}

		if err := dealAccompanyLanguage(LocalDB, item); nil != err {
			logger.Entry().WithError(err).WithField("id", item.ID).Error("accompany_language 保存数据信息")
			return errors.New("accompany_language error")
		}
	}

	return nil
}

func dealAccompanyLanguage(LocalDB *gorm.DB, item song.AccompanyLanguage) error {
	if item.DeletedAt != nil {
		return LocalDB.Where("language_id = ?", item.ID).Delete(&localdb.AccompanyLanguage{}).Error
	}

	var count int
	LocalDB.Table(localdb.TableAccompanyLanguage).Where("language_id = ?", item.ID).Count(&count)

	a := makeAccompanyLanguage(item)
	if count > 0 {
		update := util.StructToMap(a)
		return LocalDB.Model(&localdb.AccompanyLanguage{}).Where("language_id = ?", item.ID).Update(update).Error
	}
	return LocalDB.Create(&a).Error
}

func makeAccompanyLanguage(item song.AccompanyLanguage) localdb.AccompanyLanguage {
	return localdb.AccompanyLanguage{
		LanguageID:      item.ID,
		LanguageName:    item.Name,
		LanguageNameKey: item.NameKey,
		LanguageImage:   item.Image,
		Seq:             item.Seq,
		IsShow:          item.Seq,
	}
}
