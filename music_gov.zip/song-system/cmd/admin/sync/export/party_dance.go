package export

import (
	"database/sql"
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"strings"
	"time"
)

// PartyDance 跳舞视频
func PartyDance(localDB *gorm.DB, start string, version branch.Version) error {
	logger.Entry().WithField("version", version.VersionCode).Info("同步 PartyDance")
	db := model.SongDB
	var items *sql.Rows
	var err error
	if version.DeletedAt == nil && version.CanDownload == 1 {
		items, err = db.Table(song.TablePartyDance).Where("updated_at > ?", start).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	} else {
		items, err = db.Table(song.TablePartyDance).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	}

	if items == nil || err != nil {
		logger.Entry().Info("PartyDance empty or error")
		return nil
	}
	defer items.Close()

	var category branch.VersionCategory
	if version.DeletedAt == nil {
		category = songVersionCategory(version, branch.VersionCategoryTypeDance)
	}
	for items.Next() {
		var party song.PartyDance
		if err := db.ScanRows(items, &party); nil != err {
			logger.Entry().WithError(err).Error("party dance scan err")
			return errors.New("party dance scan err")
		}

		if version.DeletedAt == nil && version.CanDownload == 1 {
			if err := dealPartyDance(localDB, category, party); nil != err {
				logger.Entry().WithField("party dance id", party.ID).WithError(err).Error("party dance save error")
				return fmt.Errorf("party dance id:%d,保存数据错误,err:%s", party.ID, err.Error())
			}
		} else {
			logger.Entry().WithField("id", party.AccompanyID).Info("删除 party dance")

			if err := localDB.Where("accompany_id = ?", party.AccompanyID).Delete(&localdb.PartyDance{}).Error; nil != err {
				logger.Entry().WithField("party dance id", party.ID).WithError(err).Error("批次删除party dance save error")
				return fmt.Errorf("party dance id:%d,批次删除,保存数据错误,err:%s", party.ID, err.Error())
			}
		}

		time.Sleep(time.Microsecond * 100)
	}

	return resetBranchCategory(category)
}

func dealPartyDance(localDB *gorm.DB, category branch.VersionCategory, item song.PartyDance) error {
	partyDance := makePartyDance(item)

	return localDB.Transaction(func(tx *gorm.DB) error {
		resetBranchDetail(category.BranchID, item.ID, branch.VersionCategoryTypeDance)
		if item.DeletedAt != nil {
			logger.Entry().WithField("id", partyDance.AccompanyID).Info("删除 party dance")

			return tx.Where("accompany_id = ?", partyDance.AccompanyID).Delete(&localdb.PartyDance{}).Error
		}

		if err := dealPartyDanceFile(tx, category, item); nil != err {
			logger.Entry().WithError(err).WithField("party dance id", item.ID).Error("处理文件失败")
			return err
		}

		var count int
		tx.Table(localdb.TablePartyDance).Where("accompany_id = ?", partyDance.AccompanyID).Count(&count)
		if count > 0 {
			update := util.StructToMap(partyDance)
			update["update_time"] = item.UpdateTime.String()
			return tx.Table(localdb.TablePartyDance).Where("accompany_id = ?", partyDance.AccompanyID).Update(update).Error
		}

		return tx.Create(&partyDance).Error
	})
}

func dealPartyDanceFile(db *gorm.DB, category branch.VersionCategory, item song.PartyDance) error {
	var files []detailFile

	files = append(files, detailFile{
		File:    fmt.Sprintf("%s.%s", item.AccompanyFilename, item.Codec),
		OssFile: fmt.Sprintf("%s/%s.%s", config.Setting.Aliyun.Oss.Song, item.AccompanyFilename, item.Codec),
	})

	if item.Image != "" {
		files = append(files, detailFile{
			File:    fmt.Sprintf("%s", item.Image),
			OssFile: fmt.Sprintf("%s/%s", config.Setting.Aliyun.Oss.Image, item.Image),
		})
	}

	if item.AccompanyTitleFilename != "" {
		files = append(files, detailFile{
			File:    fmt.Sprintf("%s", item.AccompanyTitleFilename),
			OssFile: fmt.Sprintf("%s/%s", config.Setting.Aliyun.Oss.Song, item.AccompanyTitleFilename),
		})
	}

	for _, file := range files {
		if err := saveVersionDetail(db, category, file, item.ID, branch.VersionCategoryTypeDance); nil != err {
			return fmt.Errorf("保存文件详情, err:%s", err.Error())
		}
	}
	return nil
}

func makePartyDance(item song.PartyDance) localdb.PartyDance {
	filename := splitFilename(item.AccompanyFilename)

	return localdb.PartyDance{
		AccompanyID:            item.AccompanyID,
		AccompanyName:          item.AccompanyName,
		AccompanyNameSpell:     item.AccompanyNameSpell,
		CharCount:              item.CharCount,
		Audio:                  item.Audio,
		Image:                  item.Image,
		CategoryID:             item.CategoryID,
		CategoryName:           item.CategoryName,
		Rank:                   item.Rank,
		AccompanyFilename:      filename,
		AccompanyTitleFilename: item.AccompanyTitleFilename,
		HostIP:                 item.HostIP,
		UpdateTime:             util.StringToDateTime(item.UpdatedAt.String()),
		Codec:                  item.Codec,
		LampID:                 item.LampID,
		EffectID:               item.EffectID,
		ReverberationID:        item.ReverberationID,
		StrLevel:               item.StrLevel,
		Volume:                 item.Volume,
		Songno:                 item.Songno,
	}
}

// splitFilename 文件名
func splitFilename(s string) string {
	split := strings.Split(s, ".")

	return split[0]
}
