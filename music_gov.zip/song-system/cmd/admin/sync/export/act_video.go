package export

import (
	"database/sql"
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// ActVideo 跳舞视频
func ActVideo(localDB *gorm.DB, start string, version branch.Version) error {
	logger.Entry().WithField("version", version.VersionCode).Info("同步 act_video")
	db := model.SongDB
	var items *sql.Rows
	var err error
	if version.DeletedAt == nil && version.CanDownload == 1 {
		items, err = db.Table(song.TableActVideo).Where("updated_at > ?", start).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	} else {
		items, err = db.Table(song.TableActVideo).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	}

	if items == nil || err != nil {
		logger.Entry().Info("act video empty or error")
		return nil
	}
	defer items.Close()

	var category branch.VersionCategory
	if version.DeletedAt == nil {
		category = songVersionCategory(version, branch.VersionCategoryTypeActVideo)
	}

	for items.Next() {
		var video song.ActVideo
		if err := db.ScanRows(items, &video); nil != err {
			logger.Entry().WithError(err).Error("act video scan err")
			return errors.New("act video scan err")
		}

		if version.DeletedAt == nil && version.CanDownload == 1 {
			if err := dealActVideo(localDB, category, video); nil != err {
				logger.Entry().WithError(err).WithField("act video id", video.ID).Error("act video save error")
				return fmt.Errorf("act video:%d, 保存信息错误, err:%s", video.ID, err.Error())
			}
		} else {
			logger.Entry().WithField("act video accompany id", video.AccompanyID).Info("批次删除 act video")
			if err := localDB.Where("accompany_id = ?", video.AccompanyID).Delete(&localdb.ActVideo{}).Error; nil != err {
				logger.Entry().WithError(err).WithField("act video id", video.ID).Error("批次删除act video save error")
				return fmt.Errorf("act video:%d,批次删除, 保存信息错误, err:%s", video.ID, err.Error())
			}
		}

		time.Sleep(time.Microsecond * 100)
	}

	return resetBranchCategory(category)
}

func dealActVideo(localDB *gorm.DB, category branch.VersionCategory, item song.ActVideo) error {
	video := makeActVide(item)

	return localDB.Transaction(func(tx *gorm.DB) error {
		resetBranchDetail(category.BranchID, item.ID, branch.VersionCategoryTypeActVideo)
		if item.DeletedAt != nil {
			logger.Entry().WithField("act video accompany id", video.AccompanyID).Info("删除 act video")

			return tx.Where("accompany_id = ?", video.AccompanyID).Delete(&localdb.ActVideo{}).Error
		}
		if err := dealActVideoFile(tx, category, item); nil != err {
			logger.Entry().WithError(err).WithField("act video id", item.ID).Error("处理文件失败")
			return err
		}
		var count int
		tx.Table(localdb.TableActVideo).Where("accompany_id = ?", video.AccompanyID).Count(&count)
		if count > 0 {
			update := util.StructToMap(video)
			return tx.Table(localdb.TableActVideo).Where("accompany_id = ?", video.AccompanyID).Update(update).Error
		}

		return tx.Create(&video).Error
	})
}

func dealActVideoFile(db *gorm.DB, category branch.VersionCategory, item song.ActVideo) error {
	var files []detailFile

	files = append(files, detailFile{
		File:    fmt.Sprintf("%s", item.AccompanyFilename),
		OssFile: fmt.Sprintf("%s/%s", config.Setting.Aliyun.Oss.Song, item.AccompanyFilename),
	})

	if item.Image != "" {
		files = append(files, detailFile{
			File:    fmt.Sprintf("%s", item.Image),
			OssFile: fmt.Sprintf("%s/%s", config.Setting.Aliyun.Oss.Image, item.Image),
		})
	}

	for _, file := range files {
		if err := saveVersionDetail(db, category, file, item.ID, branch.VersionCategoryTypeActVideo); nil != err {
			return fmt.Errorf("保存文件详情, err:%s", err.Error())
		}
	}
	return nil
}

func makeActVide(item song.ActVideo) localdb.ActVideo {
	return localdb.ActVideo{
		AccompanyID:        item.AccompanyID,
		AccompanyName:      item.AccompanyName,
		Audio:              item.Audio,
		AccompanyNameSpell: item.AccompanyNameSpell,
		HostIP:             item.HostIP,
		AccompanyFilename:  item.AccompanyFilename,
		Image:              item.Image,
		CategoryID:         item.CategoryID,
		Type:               item.ActVideoType,
		CharCount:          item.CharCount,
		Rank:               item.Rank,
		LampID:             item.LampID,
		EffectID:           item.EffectID,
		ReverberationID:    item.ReverberationID,
		Songno:             item.Songno,
	}
}
