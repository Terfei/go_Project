package export

import (
	"database/sql"
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// Wallpaper 动态壁纸
func Wallpaper(localDB *gorm.DB, start string, version branch.Version) error {
	logger.Entry().WithField("version", version.VersionCode).Info("同步 wallpaper")
	db := model.SongDB
	var items *sql.Rows
	var err error
	if version.DeletedAt == nil && version.CanDownload == 1 {
		items, err = db.Table(song.TableWallpaper).Where("updated_at > ?", start).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	} else {
		items, err = db.Table(song.TableWallpaper).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	}

	if items == nil || err != nil {
		logger.Entry().Info("wallpaper empty or error")
		return nil
	}
	defer items.Close()
	var category branch.VersionCategory
	if version.DeletedAt == nil {
		category = songVersionCategory(version, branch.VersionCategoryTypeWallpaper)
	}

	for items.Next() {
		var wallpaper song.Wallpaper
		if err := db.ScanRows(items, &wallpaper); nil != err {
			logger.Entry().WithError(err).Error("scan wallpaper err")
			return errors.New("scan wallpaper err")
		}

		if version.DeletedAt == nil && version.CanDownload == 1 {
			if err := dealWallpaper(localDB, category, wallpaper); nil != err {
				logger.Entry().WithField("wallpaper id", wallpaper.ID).WithError(err).Error("wallpaper save error")
				return fmt.Errorf("wallpaper id:%d,保存文件失败,err:%s", wallpaper.ID, err.Error())
			}
		} else {
			logger.Entry().WithField("id", wallpaper.ID).Info("批次删除 wallpaper")
			if err := localDB.Where("wallpaper_id = ?", wallpaper.ID).Delete(&localdb.Wallpaper{}).Error; nil != err {
				logger.Entry().WithField("wallpaper id", wallpaper.ID).WithError(err).Error("批次删除wallpaper save error")
				return fmt.Errorf("wallpaper id:%d,批次删除,保存文件失败,err:%s", wallpaper.ID, err.Error())
			}
		}

		time.Sleep(time.Microsecond * 100)
	}

	return resetBranchCategory(category)
}

func dealWallpaper(localDB *gorm.DB, category branch.VersionCategory, item song.Wallpaper) error {
	wallpaper := makeWallpaper(item)
	return localDB.Transaction(func(tx *gorm.DB) error {
		resetBranchDetail(category.BranchID, item.ID, branch.VersionCategoryTypeWallpaper)
		if item.DeletedAt != nil {
			logger.Entry().WithField("id", wallpaper.WallpaperID).Info("删除 wallpaper")
			return tx.Where("wallpaper_id = ?", wallpaper.WallpaperID).Delete(&localdb.Wallpaper{}).Error
		}

		if err := dealWallpaperFile(tx, category, item); nil != err {
			logger.Entry().WithError(err).WithField("wallpaper id", item.ID).Error("处理文件失败")
			return err
		}

		var count int
		tx.Table(localdb.TableWallpaper).Where("wallpaper_id = ?", wallpaper.WallpaperID).Count(&count)
		if count > 0 {
			update := util.StructToMap(wallpaper)
			return tx.Table(localdb.TableWallpaper).Where("wallpaper_id = ?", wallpaper.WallpaperID).Update(update).Error
		}

		return tx.Create(&wallpaper).Error
	})
}

func dealWallpaperFile(db *gorm.DB, category branch.VersionCategory, item song.Wallpaper) error {
	var files []detailFile

	files = append(files, detailFile{
		File:    fmt.Sprintf("%s", item.WallpaperFilename),
		OssFile: fmt.Sprintf("%s/%s", config.Setting.Aliyun.Oss.Song, item.WallpaperFilename),
	})

	//todo 壁纸下载信息，位置
	//wallpaperNo
	//png_count
	//wallpaperNo/001.jpg

	for _, file := range files {
		if err := saveVersionDetail(db, category, file, item.ID, branch.VersionCategoryTypeWallpaper); nil != err {
			return fmt.Errorf("保存文件详情, err:%s", err.Error())
		}
	}
	return nil
}

func makeWallpaper(item song.Wallpaper) localdb.Wallpaper {
	wallpaper := localdb.Wallpaper{
		WallpaperID:       item.ID,
		WallpaperNo:       item.WallpaperNo,
		WallpaperName:     item.WallpaperName,
		WallpaperFilename: item.WallpaperFilename,
		Codec:             item.Codec,
		Width:             item.Width,
		Height:            item.Height,
		HostIP:            item.HostIP,
		Location:          item.Location,
		PipX:              item.PipX,
		PipY:              item.PipY,
		PngX:              item.PngX,
		PngY:              item.PngY,
		Pip2X:             item.Pip2X,
		Pip2Y:             item.Pip2Y,
		Png2X:             item.Png2X,
		Png2Y:             item.Png2Y,
		PipWidth:          item.PipWidth,
		PipHeight:         item.PipHeight,
		PngHostIP:         item.PngHostIP,
		PngCount:          item.PngCount,
		EmoTagID:          "",
	}

	emos := util.Int64ArrayToIntString(item.EmoTagIds)

	wallpaper.EmoTagID = model.EmoTagID(emos)

	return wallpaper
}
