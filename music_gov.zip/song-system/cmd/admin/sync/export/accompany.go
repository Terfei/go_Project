package export

import (
	"database/sql"
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

var languageMap map[int]string

// Accompany 导出伴奏
func Accompany(localDB *gorm.DB, start string, version branch.Version) error {
	logger.Entry().WithField("version", version.VersionCode).Info("同步 accompany")
	languageMap = song.GetLanguageMap()
	db := model.SongDB

	var items *sql.Rows
	var err error
	if version.DeletedAt == nil && version.CanDownload == 1 {
		items, err = db.Table(song.TableAccompany).Where("updated_at > ?", start).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	} else {
		items, err = db.Table(song.TableAccompany).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	}

	if items == nil || err != nil {
		logger.Entry().Info("accompany empty or error")
		return nil
	}
	defer items.Close()

	var category branch.VersionCategory
	if version.DeletedAt == nil {
		category = songVersionCategory(version, branch.VersionCategoryTypeSong)
	}

	for items.Next() {
		var accompany song.Accompany

		if err := db.ScanRows(items, &accompany); nil != err {
			logger.Entry().WithError(err).Error("accompany scan err")
			return errors.New("accompany scan err")
		}

		if version.DeletedAt == nil && version.CanDownload == 1 {
			if err := dealAccompany(localDB, category, accompany); nil != err {
				logger.Entry().WithError(err).WithField("accompany_id", accompany.ID).Error("accompany 保存信息错误")
				return fmt.Errorf("accompany_id:%d, 保存信息错误, err:%s", accompany.ID, err.Error())
			}
		} else {
			logger.Entry().WithField("id", accompany.ID).Info("批次删除 accompany")
			if err := localDB.Where("songno = ?", accompany.Songno).Delete(&localdb.Accompany{}).Error; nil != err {
				logger.Entry().WithError(err).WithField("accompany_id", accompany.ID).Error("批次删除 accompany 保存信息错误")
				return fmt.Errorf("accompany_id:%d, 批次删除，保存信息错误, err:%s", accompany.ID, err.Error())
			}
		}

		time.Sleep(time.Microsecond * 100)
	}

	return resetBranchCategory(category)
}

func dealAccompany(localDB *gorm.DB, category branch.VersionCategory, item song.Accompany) error {
	accompany := makeAccompany(item)

	return localDB.Transaction(func(tx *gorm.DB) error {
		resetBranchDetail(category.BranchID, item.ID, branch.VersionCategoryTypeSong)

		if item.DeletedAt != nil {
			logger.Entry().WithField("id", accompany.AccompanyID).Info("删除 accompany")

			return tx.Where("songno = ?", accompany.Songno).Delete(&localdb.Accompany{}).Error
		}

		if err := dealAccompanyFile(tx, category, item); nil != err {
			logger.Entry().WithError(err).WithField("id", item.ID).Error("处理文件失败")
			return err
		}

		var count int
		tx.Table(localdb.TableAccompany).Where("songno = ?", accompany.Songno).Count(&count)
		if count > 0 {
			update := util.StructToMap(accompany)
			update["release_time"] = accompany.ReleaseTime.String()
			return tx.Table(localdb.TableAccompany).Where("songno = ?", accompany.Songno).Update(update).Error
		}

		return tx.Create(&accompany).Error
	})
}

func dealAccompanyFile(db *gorm.DB, category branch.VersionCategory, item song.Accompany) error {
	var files []detailFile

	files = append(files, detailFile{
		File:    fmt.Sprintf("%s.%s", item.Filename, item.Ext),
		OssFile: fmt.Sprintf("%s/%s.%s", config.Setting.Aliyun.Oss.Song, item.Filename, item.Ext),
	})

	for _, file := range files {
		if err := saveVersionDetail(db, category, file, item.ID, branch.VersionCategoryTypeSong); nil != err {
			return fmt.Errorf("保存文件详情, err:%s", err.Error())
		}
	}
	return nil
}

func makeAccompany(item song.Accompany) localdb.Accompany {
	accompany := localdb.Accompany{
		AccompanyID:        item.ID,
		AccompanyName:      item.Name,
		AccompanyNameSpell: item.NameSpell,
		CharCount:          item.CharCount,
		SingerID:           item.Singers.SingerOne.ID,
		SingerIDTwo:        item.Singers.SingerTwo.ID,
		SingerIDThree:      item.Singers.SingerThree.ID,
		SingerIDFour:       item.Singers.SingerFour.ID,
		SingerNameAll:      item.SingerNameAll,
		LanguageID:         item.LanguageID,
		CategoryID:         item.CategoryID,
		VersionID:          item.VersionID,
		AccompanyFilename:  item.Filename,
		HostIP:             item.ServerPath,
		ReleaseTime:        item.ReleaseTime,
		Codec:              item.Ext,
		Channel:            item.Channel,
		LampID:             item.LampID,
		EffectID:           item.EffectID,
		Audio:              item.Audio,
		Songno:             item.Songno,
		MidFilepath:        item.MidFilepath,
		ReverberationGroup: item.ReverberationGroup,
		TagID:              item.TagID,
		VideoqltyID:        item.VideoqltyID,
		AudioqltyID:        item.AudioqltyID,
	}

	emos := util.Int64ArrayToIntString(item.EmoTagIds)

	accompany.EmoTagID = model.EmoTagID(emos)

	if l, ok := languageMap[item.LanguageID]; ok {
		accompany.LanguageType = l
	}

	return accompany
}
