package export

import (
	"errors"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// AccompanyVersion accompany_version
func AccompanyVersion(localDB *gorm.DB, start string) error {
	logger.Entry().Info("同步　accompany_version")
	db := model.SongDB
	items, err := db.Model(&song.AccompanyVersion{}).Unscoped().Where("updated_at > ?", start).Rows()
	if items == nil {
		logger.Entry().Info("accompany_version empty")
		return nil
	}
	defer items.Close()

	if err != nil {
		logger.Entry().WithError(err).Error("accompany_version error")
		return errors.New("accompany_version error")
	}

	for items.Next() {
		var item song.AccompanyVersion

		if err := db.ScanRows(items, &item); nil != err {
			logger.Entry().WithError(err).Error("accompany_version scan error")
			return errors.New("accompany_version scan error")
		}

		if err := dealAccompanyVersion(localDB, item); nil != err {
			logger.Entry().WithError(err).WithField("id", item.ID).Error("accompany_version 保存信息错误")
			return errors.New("accompany_version 保存信息错误")
		}
	}

	return nil
}

func dealAccompanyVersion(localDB *gorm.DB, item song.AccompanyVersion) error {
	if item.DeletedAt != nil {
		return localDB.Where("version_id = ?", item.ID).Delete(&localdb.AccompanyVersion{}).Error
	}

	var count int
	localDB.Table(localdb.TableAccompanyVersion).Where("version_id = ?", item.ID).Count(&count)

	a := makeAccompanyVersion(item)
	if count > 0 {
		update := util.StructToMap(a)
		return localDB.Model(&localdb.AccompanyVersion{}).Where("version_id = ?", item.ID).Update(update).Error
	}

	return localDB.Create(&a).Error
}

func makeAccompanyVersion(item song.AccompanyVersion) localdb.AccompanyVersion {
	return localdb.AccompanyVersion{
		Seq:         item.Seq,
		VersionID:   item.ID,
		VersionName: item.Name,
	}
}
