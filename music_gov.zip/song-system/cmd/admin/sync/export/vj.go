package export

import (
	"database/sql"
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// Vj 导出vj
func Vj(localDB *gorm.DB, start string, version branch.Version) error {
	logger.Entry().WithField("version", version.VersionCode).Info("同步 vj")
	db := model.SongDB
	var items *sql.Rows
	var err error
	if version.DeletedAt == nil && version.CanDownload == 1 {
		items, err = db.Table(song.TableVj).Where("updated_at > ?", start).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	} else {
		items, err = db.Table(song.TableVj).Where("overview_id = ?", version.VersionID).Order("updated_at").Rows()
	}
	if items == nil || err != nil {
		logger.Entry().Info("vj empty or error")
		return nil
	}
	defer items.Close()

	var category branch.VersionCategory
	if version.DeletedAt == nil {
		category = songVersionCategory(version, branch.VersionCategoryTypeVj)
	}

	for items.Next() {
		var vj song.Vj
		if err := db.ScanRows(items, &vj); nil != err {
			logger.Entry().WithError(err).Error("vj scan err")
			return errors.New("vj scan error")
		}

		if version.DeletedAt == nil && version.CanDownload == 1 {
			if err := dealVj(localDB, category, vj); nil != err {
				logger.Entry().WithError(err).Error("vj save error")
				return fmt.Errorf("vj id:%d, 保存数据错误, err:%s", vj.ID, err.Error())
			}
		} else {
			logger.Entry().WithField("id", vj.ID).Info("批次 删除 vj")
			if err := localDB.Where("vj_id = ?", vj.ID).Delete(&localdb.VJ{}).Error; nil != err {
				logger.Entry().WithError(err).Error("vj save error")
				return fmt.Errorf("vj id:%d, 保存数据错误, err:%s", vj.ID, err.Error())
			}
		}

		time.Sleep(time.Microsecond * 100)
	}

	return resetBranchCategory(category)
}

func dealVj(localDB *gorm.DB, category branch.VersionCategory, item song.Vj) error {
	vj := makeVj(item)

	return localDB.Transaction(func(tx *gorm.DB) error {
		resetBranchDetail(category.BranchID, item.ID, branch.VersionCategoryTypeVj)
		if item.DeletedAt != nil {
			logger.Entry().WithField("id", vj.VjID).Info("删除 vj")
			return tx.Where("vj_id = ?", vj.VjID).Delete(&localdb.VJ{}).Error
		}

		if err := dealVjFile(tx, category, item); nil != err {
			logger.Entry().WithError(err).WithField("vj id", item.ID).Error("处理文件失败")
			return err
		}

		var count int
		tx.Table(localdb.TableVJ).Where("vj_id = ?", vj.VjID).Count(&count)
		if count > 0 {
			update := util.StructToMap(vj)
			return tx.Table(localdb.TableVJ).Where("vj_id = ?", vj.VjID).Update(update).Error
		}

		return tx.Create(&vj).Error
	})
}

func dealVjFile(db *gorm.DB, category branch.VersionCategory, item song.Vj) error {
	var files []detailFile

	files = append(files, detailFile{
		File:    fmt.Sprintf("%s.%s", item.Filename, item.Codec),
		OssFile: fmt.Sprintf("%s/%s.%s", config.Setting.Aliyun.Oss.Song, item.Filename, item.Codec),
	})

	for _, file := range files {
		if err := saveVersionDetail(db, category, file, item.ID, branch.VersionCategoryTypeVj); nil != err {
			return fmt.Errorf("保存文件详情, err:%s", err.Error())
		}
	}
	return nil
}

func makeVj(item song.Vj) localdb.VJ {
	return localdb.VJ{
		VjID:       item.ID,
		VjName:     item.Name,
		VjFilename: item.Filename,
		Codec:      item.Codec,
		HostIP:     item.HostIP,
		CategoryID: item.CategoryID,
	}
}
