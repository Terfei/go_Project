package export

import (
	"errors"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// AccompanyVideoqlty accompany_videoqlty
func AccompanyVideoqlty(localDB *gorm.DB, start string) error {
	logger.Entry().Info("同步　accompany_videoqlty")
	db := model.SongDB
	items, err := db.Model(&song.AccompanyVideoqlty{}).Unscoped().Where("updated_at > ?", start).Rows()
	if items == nil {
		logger.Entry().Info("accompany_videoqlty empty")
		return nil
	}
	defer items.Close()

	if err != nil {
		logger.Entry().WithError(err).Error("accompany_videoqlty error")
		return errors.New("accompany_videoqlty error")
	}

	for items.Next() {
		var item song.AccompanyVideoqlty

		if err := db.ScanRows(items, &item); nil != err {
			logger.Entry().WithError(err).Error("accompany_videoqlty scan error")
			return errors.New("accompany_videoqlty scan error")
		}

		if err := dealAccompanyVideoqlty(localDB, item); nil != err {
			logger.Entry().WithError(err).WithField("id", item.ID).Error("accompany_videoqlty 保存信息错误")
			return errors.New("accompany_videoqlty 保存信息错误")
		}
	}

	return nil
}

func dealAccompanyVideoqlty(localDB *gorm.DB, item song.AccompanyVideoqlty) error {
	if item.DeletedAt != nil {
		return localDB.Where("videoqlty_id = ?", item.ID).Delete(&localdb.AccompanyVideoQlty{}).Error
	}

	var count int
	localDB.Table(localdb.TableAccompanyVideoQlty).Where("videoqlty_id = ?", item.ID).Count(&count)

	a := makeAccompanyVideoqlty(item)
	if count > 0 {
		update := util.StructToMap(a)
		return localDB.Model(&localdb.AccompanyVideoQlty{}).Where("videoqlty_id = ?", item.ID).Update(update).Error
	}

	return localDB.Create(&a).Error
}

func makeAccompanyVideoqlty(item song.AccompanyVideoqlty) localdb.AccompanyVideoQlty {
	return localdb.AccompanyVideoQlty{
		VideoqltyID:    item.ID,
		VideoqltyCode:  item.Code,
		Seq:            item.Seq,
		IsShow:         item.IsShow,
		VideoqltyImage: item.Image,
	}
}
