package export

import (
	"errors"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// AccompanyCategory accompany_category
func AccompanyCategory(localDB *gorm.DB, start string) error {
	logger.Entry().Info("同步 accompany_category")
	db := model.SongDB
	items, err := db.Model(&song.AccompanyCategory{}).Unscoped().Where("updated_at > ?", start).Rows()

	if items == nil {
		logger.Entry().Info("accompany_category empty")
		return nil
	}

	if err != nil {
		logger.Entry().WithError(err).Error("accompany_category error")
		return errors.New("accompany_category error")
	}

	for items.Next() {
		var item song.AccompanyCategory

		if err := db.ScanRows(items, &item); nil != err {
			logger.Entry().WithError(err).Error("accompany_category scan error")
			return errors.New("accompany_category scan error")
		}

		if err := dealAccompanyCategory(localDB, item); nil != err {
			logger.Entry().WithError(err).WithField("id", item.ID).Error("accompany_category 保存数据信息")
			return errors.New("accompany_category 保存数据信息")
		}
	}

	return nil
}

func dealAccompanyCategory(localDB *gorm.DB, item song.AccompanyCategory) error {
	if item.DeletedAt != nil {
		return localDB.Where("category_id = ?", item.ID).Delete(&localdb.AccompanyCategory{}).Error
	}

	var count int
	localDB.Table(localdb.TableAccompanyCategory).Where("category_id = ?", item.ID).Count(&count)

	a := makeAccompanyCategory(item)
	if count > 0 {
		update := util.StructToMap(a)
		return localDB.Model(&localdb.AccompanyCategory{}).Where("category_id = ?", item.ID).Update(update).Error
	}
	return localDB.Create(&a).Error
}

func makeAccompanyCategory(item song.AccompanyCategory) localdb.AccompanyCategory {
	return localdb.AccompanyCategory{
		CategoryID:      item.ID,
		CategoryName:    item.Name,
		CategoryNameKey: item.NameKey,
		CategoryImage:   item.Image,
		Seq:             item.Seq,
		Type:            item.Type,
		IsShow:          item.IsShow,
	}
}
