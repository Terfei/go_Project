package export

import (
	"github.com/jinzhu/gorm"
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
)

type detailFile struct {
	File    string
	OssFile string
}

func resetBranchDetail(branchID uuid.UUID, id int, t branch.VersionCategoryType) {
	model.SongDB.Where("branch_id = ?", branchID).
		Where("relation_id = ?", id).
		Where("relation_type = ?", t).
		Delete(&branch.VersionDetail{})
}

func songVersionCategory(version branch.Version, t branch.VersionCategoryType) branch.VersionCategory {
	where := map[string]interface{}{
		"branch_id":     version.BranchID,
		"version_id":    version.VersionID,
		"relation_type": t,
	}

	var item branch.VersionCategory
	model.SongDB.Table(branch.TableVersionCategory).Where(where).First(&item)

	if item.ID > 0 {
		return item
	}

	category := branch.VersionCategory{
		VersionBase: branch.VersionBase{
			BranchID:    version.BranchID,
			VersionID:   version.VersionID,
			VersionCode: version.VersionCode,
		},
		RelationType: t,
		FileCount:    0,
		DoneCount:    0,
		UndoneCount:  0,
		DealStatus:   branch.VersionCategoryStatusInit,
	}

	model.SongDB.Create(&category)

	return category
}

func resetBranchCategory(category branch.VersionCategory) error {
	var count int
	var success int
	var fail int
	query := model.SongDB.Table(branch.TableVersionDetail).Where("version_category_id = ?", category.ID)

	query.Count(&count)
	query.Where("is_download = 1").Count(&success)
	query.Where("is_download = 0").Count(&fail)

	update := map[string]interface{}{
		"file_count":   count,
		"done_count":   success,
		"undone_count": fail,
	}

	return model.SongDB.Model(&category).Update(update).Error
}

func saveVersionDetail(db *gorm.DB, category branch.VersionCategory, file detailFile, relationID int, relationType branch.VersionCategoryType) error {
	s := branch.VersionDetail{
		VersionBase: branch.VersionBase{
			BranchID:    category.BranchID,
			VersionID:   category.VersionID,
			VersionCode: category.VersionCode,
		},
		VersionCategoryID: category.ID,
		RelationType:      relationType,
		RelationID:        relationID,
		Filename:          file.File,
		OssFile:           file.OssFile,
		DiskFile:          "",
		IsDownload:        0,
	}

	if err := model.SongDB.Create(&s).Error; nil != err {
		logger.Entry().WithField("accompany detail", s).Error("保存歌曲文件详情错误")
		return err
	}

	l := localdb.BranchVersionDetail{
		ID:                s.ID,
		VersionID:         s.VersionID,
		VersionCode:       s.VersionCode.String(),
		VersionCategoryID: s.VersionCategoryID,
		RelationType:      s.RelationType.String(),
		RelationID:        s.RelationID,
		Dir:               "",
		Filename:          s.Filename,
		OssFilename:       s.OssFile,
		IsDownload:        0,
	}

	if err := db.Create(&l).Error; nil != err {
		logger.Entry().WithField("local accompany detail", l).Error("保存歌曲文件详情错误")
		return err
	}

	return nil
}
