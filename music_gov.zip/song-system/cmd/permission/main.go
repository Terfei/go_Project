package main

import (
	"bufio"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"strings"

	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/user"
)

var conf string
var path string

// Page 页权限
type Page struct {
	Page    string   `json:"page"`
	Actions []string `json:"actions"`
}

// Module 模块权限
type Module struct {
	Module string `json:"module"`
	Pages  []Page `json:"pages"`
}

// System 系统权限
type System struct {
	Type    user.SystemType `json:"type"`
	System  string          `json:"system"`
	Modules []Module        `json:"modules"`
}

func init() {
	flag.StringVar(&conf, "c", "", "指定参数配置文件")
	// flag.StringVar(&path, "p", "", "指定权限配置文件")
	flag.Parse()
	if conf == "" {
		panic("请指定参数配置文件")
	}
	// if path == "" {
	// 	panic("请指定权限配置文件")
	// }

	path = `configs/permissions.json`
	// 载入配置文件
	config.Load(conf)
	// 数据库连接
	model.SongSystemConnection(config.Setting.Database.Song)
}

func main() {
	data, err := permissions(path)
	if err != nil {
		fmt.Println("ERROR:", err)
	}

	for _, sys := range data {
		// savePermission([]string{sys.System}, sys.Type)
		for _, module := range sys.Modules {
			savePermission([]string{module.Module}, sys.Type)
			for _, page := range module.Pages {
				savePermission([]string{module.Module, page.Page}, sys.Type)
				for _, act := range page.Actions {
					savePermission([]string{module.Module, page.Page, act}, sys.Type)
				}
			}
		}
	}
}

func savePermission(permissions []string, sysTitle user.SystemType) {
	p := strings.Join(permissions, `>`)
	_, err := user.FindByPermission(p)
	if err == nil {
		return
	}

	permission := user.Permission{
		System:     sysTitle,
		Permission: p,
	}

	if err = model.SongDB.Create(&permission).Error; nil != err {
		fmt.Println(p)
		fmt.Println("新增权限点失败" + err.Error())
		return
	}
}

func permissions(filePath string) (data []System, err error) {
	result, err := readJSONFile(filePath)

	err = json.Unmarshal([]byte(result), &data)
	if err != nil {
		return nil, err
	}

	return data, nil
}

func readJSONFile(filePath string) (result string, err error) {
	file, err := os.Open(filePath)
	defer file.Close()
	if err != nil {
		return ``, err
	}

	buf := bufio.NewReader(file)
	for {
		s, err := buf.ReadString('\n')
		result += s
		if err != nil {
			if err == io.EOF {
				// fmt.Println("Read is ok")
				break
			}

			return ``, err
		}
	}

	return result, nil
}
