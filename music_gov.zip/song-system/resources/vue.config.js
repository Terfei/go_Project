const path = require('path');
const currentDir = process.env.current || 'admin';
const PORT = process.env.port || '8800';
function resolve(dir) {
    return path.join(__dirname, dir);
}
// let fs = require('fs');
// let dirs = [];
// fs.readdir(__dirname, function (err, files) {
//     // console.log('files');
//     // console.log(files);
//     for (let i = 0; i < files.length; i++) {
//         fs.stat(path.join(pathName, files[i]), function (err, data) {
//             if (data.isFile()) {
//                 dirs.push(files[i]);
//             }
//         });
//     }
//     console.log(dirs);
// });
function getLocalIP() {
    const interfaces = require('os').networkInterfaces(); // 在开发环境中获取局域网中的本机iP地址
    for (var devName in interfaces) {
        var iface = interfaces[devName];
        for (var i = 0; i < iface.length; i++) {
            var alias = iface[i];
            if (alias.family === 'IPv4' && alias.address !== '127.0.0.1' && !alias.internal) {
                return alias.address;
            }
        }
    }
    return '127.0.0.1';
}
module.exports = {
    // 基本路径
    publicPath: `/assets/${currentDir}`,
    // 输出文件目录
    outputDir: `../public/assets/${currentDir}`,
    productionSourceMap: false,
    // css相关配置
    css: {
        // 是否使用css分离插件 ExtractTextPlugin
        extract: false,
        // 开启 CSS source maps?
        sourceMap: false,
        // css预设器配置项
        loaderOptions: {
            sass: {
                // @/ is an alias to src/
                // so this assumes you have a file named `src/variables.scss`
                // 新版sass-loader prependData   旧版sass-loader data
                prependData: `@import "@sass/base/primitve_variables.scss";
                    @import "@sass/base/variables.scss";
                    @import "@sass/base/mixins.scss";
                    @import "@sass/base/placeholders.scss";`
            }
        },
        // 启用 CSS modules for all css / pre-processor files.
        // modules: false
        requireModuleExtension: true
    },
    // // use thread-loader for babel & TS in production build
    // // enabled by default if the machine has more than 1 cores
    // parallel: require('os').cpus().length > 1,
    // // 是否启用dll
    // // See https://github.com/vuejs/vue-cli/blob/dev/docs/cli-service.md#dll-mode
    // dll: false,
    // // PWA 插件相关配置
    // // see https://github.com/vuejs/vue-cli/tree/dev/packages/%40vue/cli-plugin-pwa
    // pwa: {},
    configureWebpack: {
        entry: {
            app: path.join(__dirname, `./${currentDir}/main.ts`),
        },
        output: {
            filename: 'js/[name].js?v=[hash]',
            chunkFilename: 'js/[name].js?v=[hash]'    //这种是给打包后的chunk文件加版本号。
        },
    },
    //  webpack 配置
    chainWebpack: (config) => {
        // 别名相关配置
        config.resolve.alias
            .set('@', resolve(`${currentDir}`))
            .set('img', resolve(`${currentDir}/assets/images`))
            .set('@sass', resolve(`${currentDir}/assets/sass`))
            .set('@utils', resolve(`${currentDir}/utils`))
            .set('@components', resolve(`${currentDir}/components`))
            .set('@views', resolve(`${currentDir}/views`))
        // 图片处理
        config.module
            .rule('images')
            .use('url-loader')
            .loader('url-loader')
            // .tap(options => Object.assign(options, { // tap修改参数的方法
            //     limit: 10240
            // })) //10kb
            .tap(options => {
                // 修改它的选项...
                options.fallback.options.name = 'img/[name].[ext]?[hash]'; //去除图片hash
                options.limit = 1024; //这是字节(Byte)限制，1KB = 1024Byte ,当图片的大小小于 1KB ,则会被转为 base64格式，打包进js文件，大于1KB,则会被打包进 img 文件夹，供链接请求获取。 
                return options;
            });
        // 图片压缩
        config.module
            .rule('images')
            .use('image-webpack-loader')
            .loader('image-webpack-loader')
            .options({
                bypassOnDebug: true,
            })
            .end();
        // svg处理
        // 清除cli3自带的svg规则（使用了file-loader，并且把路径指定为在img文件夹下）
        // 如果你不这样做，接下来的 loader 会附加在该规则现有的 loader 之后
        const svgRule = config.module.rule('svg')
        svgRule.uses.clear()
        // 添加要替换的 loader
        svgRule
            .include.add(resolve(`${currentDir}/assets/svg`))
            .end()
            .use('svg-sprite-loader')
            .loader('svg-sprite-loader')
            .tap(options => Object.assign(options || {}, {
                symbolId: "svg-icon-[name]",
            }))
        const fileRule = config.module.rule('file')
        fileRule.uses.clear()
        fileRule
            .test(/\.svg$/)
            .exclude.add(resolve(`${currentDir}/assets/svg`))
            .end()
            .use('file-loader')
            .loader('file-loader');

        config.module.rule('fonts')
            .test(/\.(woff2?|eot|ttf|otf)(\?.*)?$/)
            .use('url-loader')
            .tap(options => {
                options.fallback.options.name = 'fonts/[name].[ext]?[hash]';
                return options;
            });
        config.plugin('html').tap(args => {
            args[0].title = '云后台管理系统';
            args[0].template = resolve(`${currentDir}/index.html`);
            args[0].favicon = resolve(`${currentDir}/favicon.ico`);
            return args;
        })
        // DefinePlugin 允许创建一个在编译时可以配置的全局常量
        // config.plugin('define')
        //     .tap(args => {
        //         console.log('args');
        //         console.log(args);
        //         return args
        //     })
    },
    devServer: {
        // open: process.platform === 'darwin',
        open: true, //自动打开浏览器
        host: getLocalIP(), //host设置的是服务器的主机号
        port: PORT, //端口
        https: false,
        // hotOnly: true,
        proxy: {
            '/api': {
                target: 'http://song-system.omytech.com.cn',
                // target: 'http://192.168.3.252:11001',
                changeOrigin: true,
                // pathRewrite: { '^/api': '' },
            },
        }, // 设置代理
        historyApiFallback: { //应对返回404页面时定向到特定页面用的
            rewrites: [
                // { from: /./, to: '/404.html' }
            ]
        },
        before: app => { },
    },
    // 第三方插件配置
    pluginOptions: {
        // 全局样式引入(没有引入成功)
        // 'style-resources-loader': {
        //     'patterns': [
        //         path.resolve(__dirname, 'src/assets/sass/base/*.scss'),
        //     ]
        // }
    },
}