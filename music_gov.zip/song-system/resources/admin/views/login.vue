<template>
    <div class="container">
        <div class="login-title">云后台管理系统</div>
        <el-form
            class="login-box"
            ref="form"
            :rules="rules"
            :model="form"
        >
            <el-form-item prop="username">
                <el-input
                    placeholder="账号"
                    class="account"
                    v-model="form.username"
                >
                    <SvgIcon
                        slot="prefix"
                        class="account-icon"
                        propHref="account"
                    />
                </el-input>
            </el-form-item>

            <el-form-item prop="password">
                <el-input
                    placeholder="密码 "
                    class="password"
                    type="password"
                    v-model="form.password"
                    @keyup.enter.native="loginIn"
                >
                    <SvgIcon
                        slot="prefix"
                        class="password-icon"
                        propHref="password"
                    />
                </el-input>
            </el-form-item>
            <el-button
                class="btn-login"
                @click="loginIn()"
            >登录</el-button>
        </el-form>
    </div>
</template>
<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator';
@Component
export default class Login extends Vue {
    rules = {
        username: [{ required: true, message: '请输入您的账号', trigger: 'blur' },],
        password: [{ required: true, message: '请输入您的密码', trigger: 'blur' },],
    };
    form: any = {
        username: '',
        password: '',
    };
    loginIn() {
        let pram = {
            username: this.form.username.trim(),
            password: this.form.password.trim(),
        };
        (this.$refs.form as any).validate((valid) => {
            if (!valid) {
                return false;
            } else {
                this.mixPost(`/api/login`, pram).then(async res => {
                    let info = res.data.data;
                    await this.$store.dispatch('loginInfoAct', info.staff);
                    await this.$store.dispatch('tokenAct', info.token);
                    await this.checkRouterPermission();
                    this.$router.push('/home');
                });
            }
        });
    }
}
</script>
<style lang="scss" scoped>
.container {
    background: url("~img/login/login.jpg") no-repeat center / cover;
    width: 100vw;
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}
.login-title {
    color: var(--theme);
    margin-bottom: 0.5rem;
    font-size: 0.32rem;
}
.login-box {
    width: 3.8rem;
    @at-root {
        .account-icon {
            font-size: 0.2rem;
        }
        .password-icon {
            font-size: 0.26rem;
        }
        .password-icon,
        .account-icon {
            color: $c-grey;
        }
        /deep/ .el-input--prefix .el-input__inner {
            padding-left: 0.4rem;
            height: 0.5rem;
        }
        /deep/ .el-input__prefix {
            left: 0.1rem;
            display: flex;
            align-items: center;
        }
    }
    .btn-login {
        font-size: 0.2rem;
        width: 100%;
        letter-spacing: 2px;
        margin-top: 0.2rem;
        color: #fff;
        height: 0.5rem;
        background-color: var(--theme);
        border: none;
    }
    .el-button {
        &:hover {
            filter: brightness(85%);
        }
        &:active {
            filter: brightness(75%);
        }
    }
}
</style>