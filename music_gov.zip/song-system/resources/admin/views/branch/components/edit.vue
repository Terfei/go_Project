<template>
    <el-dialog
        :title="(info.id ? '编辑' : '新增') + '门店权限'"
        :visible.sync="isShow"
        :close-on-click-modal="false"
        custom-class="dialog-box-middle"
    >
        <el-form
            ref="form"
            :model="info"
            :rules="rules"
            label-width="80px"
            v-if="isShow"
        >
            <el-form-item
                label="门店编号"
                v-if="info.branch_code"
            >
                <el-input
                    class="form-input"
                    v-model="info.branch_code"
                    disabled
                ></el-input>
            </el-form-item>
            <el-form-item label="门店名称">
                <SelectBranch
                    v-model="info.branch_id"
                    :disabled="info.id"
                />
            </el-form-item>
            <el-form-item label="授权类别">
                <el-select
                    v-model="info.category"
                    :disabled="!!info.id"
                >
                    <el-option
                        v-for="(val, key) in categoryMap"
                        :key="key"
                        :value="key"
                        :label="val"
                    ></el-option>
                </el-select>
            </el-form-item>
            <el-form-item
                label="日期"
                prop="month_range"
                v-if="!info.id"
            >
                <el-date-picker
                    v-model="info.month_range"
                    type="monthrange"
                    format="yyyy-MM"
                    value-format="yyyy-MM"
                    range-separator="~"
                    start-placeholder="开始月份"
                    end-placeholder="结束月份"
                />
            </el-form-item>
            <el-form-item
                label="启用日期"
                v-if="info.id"
            >
                <span
                    v-for="n in 12"
                    :key="'months' + n"
                    :class="{'month-label': true, 'checked' : info.months.includes(n)}"
                    @click="chooseMonth(n)"
                >{{n}}</span>
            </el-form-item>
            <el-form-item label="备注">
                <el-input
                    type="textarea"
                    class="form-textarea"
                    v-model="info.remark"
                ></el-input>
            </el-form-item>
            <el-form-item
                label="下载权限"
                v-if="false"
            >
                <el-checkbox
                    v-model="info.can_download"
                    :true-label="1"
                    :false-label="0"
                >启用</el-checkbox>
            </el-form-item>
        </el-form>
        <div
            slot="footer"
            class="dialog-footer"
        >
            <el-button @click="isShow = false">取消</el-button>
            <el-button
                type="primary"
                @click="onSubmit"
            >确定</el-button>
        </div>
    </el-dialog>
</template>
<script lang="ts">
import { Component, Mixins, Prop } from 'vue-property-decorator';
@Component
export default class BranchEdit extends Mixins() {
    @Prop({
        default() {
            return {};
        }
    })
    categoryMap: any;

    isShow = false;

    info: any = {
        id: '',
        branch_id: '',
        branch_name: '',
        category: '',
        can_download: '',
        month_range: [],
        months: [],
        remark: '',
    };
    rules = {
        month_range: [
            {
                validator: (rule, value, callback) => {
                    if (!value || !value.length || !value[0] || !value[1]) {
                        callback(new Error('日期不可为空'));
                    } else {
                        callback();
                    }
                }, trigger: 'blur'
            },
        ],
    };
    callback: any = null;
    mounted() {

    }

    open(item, callback) {
        this.info = Object.assign({
            id: '',
            branch_id: '',
            branch_name: '',
            category: '',
            can_download: '',
            month_range: [],
            months: [],
            remark: '',
        }, JSON.parse(JSON.stringify(item)));
        this.callback = callback;
        this.isShow = true;
        this.$nextTick(() => {
            (this.$refs.form as any).resetFields();
        });
    }
    chooseMonth(n) {
        let index = this.info.months.indexOf(n);
        if (index < 0) {
            this.info.months.push(n);
        }
        else {
            this.info.months.splice(index, 1);
        }
    }
    onSubmit() {
        (this.$refs.form as any).validate((valid) => {
            if (valid) {
                this.save();
            }
        });
    }
    save() {
        let method = this.mixPatch;
        let url = `/api/branch/authorize/${this.info.id}`;
        let data: any = {
            remark: this.info.remark,
        };
        if (this.info.id) {
            data.months = this.info.months.sort((x, y) => x > y ? 1 : -1);
        }
        else {
            method = this.mixPost;
            url = '/api/branch/authorize';
            data.can_download = 1;
            data.begin_month = this.info.month_range[0];
            data.end_month = this.info.month_range[1];
            data.branch_id = this.info.branch_id;
            data.category = this.info.category;
        }
        method(url, data).then(res => {
            this.$message({ message: '保存成功', type: 'success' });
            this.callback && this.callback();
            this.isShow = false;
        });
    }
}
</script>
<style lang="scss" scoped>
.month-label {
    display: inline-block;
    text-align: center;
    min-width: 0.24rem;
    line-height: 0.24rem;
    border-radius: 0.12rem;
    padding: 0 0.08rem;
    background-color: $c-bg;
    border: $border-dark;
    color: $c-grey;
    cursor: pointer;
    &:not(:last-child) {
        margin-right: 0.05rem;
    }
    &.checked {
        color: $c-w;
        background-color: var(--theme);
        border-color: var(--theme);
    }
}
</style>