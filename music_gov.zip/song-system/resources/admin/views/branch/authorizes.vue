<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">{{formTitle}}</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-default btn-add-icon"
                    @click="openEdit()"
                >新增</button>
                <ExportButton @click="exportExcel()">导出</ExportButton>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">门店类型</label>
                    <SelectBiztype v-model="queryData.branch_biz_type" />
                </li>
                <li class="query-item">
                    <label class="label">门店</label>
                    <SelectBranch
                        :bizType="queryData.branch_biz_type"
                        v-model="queryData.branch_id"
                    />
                </li>
                <li class="query-item">
                    <label class="label">授权类别</label>
                    <el-select v-model="queryData.category">
                        <el-option
                            value=""
                            label="全部"
                        >
                        </el-option>
                        <el-option
                            v-for="(val, key) in categoryMap"
                            :key="key"
                            :value="key"
                            :label="val"
                        ></el-option>
                    </el-select>
                </li>
                <li class="query-item">
                    <label class="label">时间</label>
                    <el-select v-model="queryData.year">
                        <el-option
                            v-for="n in 20"
                            :key="'year' + n"
                            :value="new Date().getFullYear() + n - 10"
                        >
                        </el-option>
                    </el-select>
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="cpList"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop === 'months'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length > 0 ? item.width:''"
                    >
                        <template v-slot="{ row }">
                            <span
                                v-for="n in 12"
                                :key="row.id + '' + n"
                                :class="{'month-label': true, 'checked': row.months.includes(n)}"
                            >{{n}}</span>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop === 'category'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length > 0 ? item.width:''"
                    >
                        <template v-slot="{ row }">{{categoryMap[row.category]}}</template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                    </el-table-column>
                </template>
                <el-table-column label="操作">
                    <template v-slot="{row}">
                        <span
                            class="table-opt"
                            @click="openEdit(row)"
                        >编辑</span>
                        <!-- <span
                            class="table-opt"
                            @click="goDetail(row)"
                        >历史记录</span> -->
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
        <Edit
            ref="edit"
            :categoryMap="categoryMap"
        />
    </div>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
import Edit from './components/edit.vue';
@Component({
    components: {
        Edit,
    },
})
export default class Authorize extends Mixins(Query) {
    formTitle = '门店授权管理';
    url = '/api/branch/authorize';
    exportUrl = '/api/branch/authorize/export';
    queryData: any = {
        branch_biz_type: '',
        branch_id: '',
        category: '',
        year: '',
    };
    categoryMap: any = {};
    get columnItems() {
        return [
            { prop: 'branch_code', label: '门店编号' },
            { prop: 'branch_name', label: '门店名称' },
            { prop: 'category', label: '授权类别' },
            { prop: 'months', label: `${this.queryData.year}年1-12月下载权限`, width: 400 },
            { prop: 'remark', label: '备注' },
        ];
    }
    get cpList() {
        return this.list.map(x => {
            return {
                id: x.id || '',
                branch_code: x.branch_code || '',
                branch_id: x.branch_id || '',
                branch_name: x.branch_name || '',
                category: x.category || '',
                months: x.months,
                remark: x.remark || '',
            };
        });
    }
    created() {
        this.queryData.year = new Date().getFullYear();
    }
    mounted() {
        this.getCategory();
    }
    getCategory() {
        this.mixGet('/api/support/authorize/category', null, { loading: false }).then(res => {
            this.categoryMap = res.data.data;
        });
    }
    openEdit(item: any = {}) {
        item.year = this.queryData.year;
        (this.$refs.edit as any).open(item, () => {
            this.getList();
        });
    }
    // goDetail(item) {
    //     this.$router.push({
    //         path: '/branch/history',
    //         query: {
    //             id: item.id,
    //         },
    //     });
    // }
}
</script>
<style lang="scss" scoped>
.month-label {
    display: inline-block;
    text-align: center;
    min-width: 0.24rem;
    line-height: 0.24rem;
    border-radius: 0.12rem;
    padding: 0 0.08rem;
    background-color: $c-bg;
    &:not(:last-child) {
        margin-right: 0.05rem;
    }
    &.checked {
        background-color: var(--theme);
        color: $c-w;
    }
}
</style>