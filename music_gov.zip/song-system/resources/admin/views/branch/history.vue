<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">门店授权记录</span>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">操作人</label>
                    <el-input
                        class="input"
                        v-model="queryData.staff_name"
                    />
                </li>
                <li class="query-item">
                    <label class="label">日期</label>
                    <SearchDateRange
                        :begin_date.sync="queryData.begin"
                        :end_date.sync="queryData.end"
                    />
                </li>
                <li class="query-item">
                    <label class="label">门店类型</label>
                    <SelectBiztype v-model="queryData.branch_biz_type" />
                </li>
                <li class="query-item">
                    <label class="label">门店</label>
                    <SelectBranch
                        :bizType="queryData.branch_biz_type"
                        v-model="queryData.branch_id"
                    />
                </li>
                <li class="query-item">
                    <label class="label">类别</label>
                    <el-select v-model="queryData.category">
                        <el-option
                            value=""
                            label="全部"
                        >
                        </el-option>
                        <el-option
                            v-for="(val, key) in categoryMap"
                            :key="key"
                            :value="key"
                            :label="val"
                        ></el-option>
                    </el-select>
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop === 'can_download'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length > 0 ? item.width:''"
                    >
                        <template v-slot="{ row }">
                            <span :class="{'warn':row.can_download == 0}">{{row.can_download == 1 ? '启用' : '禁用'}}</span>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop === 'category'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length > 0 ? item.width:''"
                    >
                        <template v-slot="{ row }">{{categoryMap[row.category]}}</template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                    </el-table-column>
                </template>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
@Component({
    components: {
    },
})
export default class History extends Mixins(Query) {
    url = '/api/branch/authorize-history';
    queryData = {
        staff_name: '',
        branch_biz_type: '',
        branch_id: '',
        category: '',
        can_download: '',
        begin: '',
        end: '',
    };
    categoryMap: any = {};
    columnItems: any = [
        { prop: 'staff_name', label: '操作人' },
        { prop: 'created_at', label: '操作时间' },
        { prop: 'branch_name', label: '操作门店' },
        { prop: 'category', label: '操作类别' },
        { prop: 'begin_month', label: '开始时间' },
        { prop: 'end_month', label: '结束时间' },
        { prop: 'can_download', label: '下载权限' },
        { prop: 'remark', label: '备注' },
    ];
    mounted() {
        this.getCategory();
    }
    getCategory() {
        this.mixGet('/api/support/authorize/category', null, { loading: false }).then(res => {
            this.categoryMap = res.data.data;
        });
    }
}
</script>