<template>
    <div class="welcome-container">
        <div>
            <h2 class="welcome-title">欢迎进入云后台系统</h2>
            <img
                class="welcome-img"
                src="~img/welcome/welcome.png"
            >
        </div>
    </div>
</template>
<script>
export default {
    data() {
        return {
        };
    }
};
</script>
<style lang="scss" scoped>
.welcome-container {
    width: 100%;
    height: 100%;
    display: flex;
    background-color: $c-w;
    > div {
        text-align: center;
        margin: auto;
    }
    @at-root {
        .welcome-title {
            font-size: 0.48rem;
            color: var(--theme);
            margin-bottom: 0.1rem;
        }
        .welcome-img {
            width: 8rem;
            height: auto;
        }
    }
}
</style>

