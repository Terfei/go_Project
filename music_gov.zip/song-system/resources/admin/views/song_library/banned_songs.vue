<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">{{formTitle}}</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-default btn-add-icon"
                    @click="mod()"
                >新增</button>
                <ImportButton @change="excelEdit">导入新增</ImportButton>
                <ExportButton @click="exportExcel()">导出</ExportButton>
                <button
                    class="btn button-default"
                    @click="batchDelete"
                >批量删除</button>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">歌曲名</label>
                    <input
                        class="input"
                        type="text"
                        v-model="queryData.song_name"
                    >
                </li>
                <li class="query-item">
                    <label class="label">歌星名</label>
                    <input
                        class="input"
                        type="text"
                        v-model="queryData.singer_name"
                    >
                </li>
                <li class="query-item">
                    <label class="label">日期</label>
                    <SearchDateRange
                        :begin_date.sync="queryData.begin"
                        :end_date.sync="queryData.end"
                    />
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                @selection-change="checkItem"
                v-loading="loading"
            >
                <el-table-column
                    type="selection"
                    width="55"
                >
                </el-table-column>
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop == 'status'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            <el-checkbox
                                v-model="row.status"
                                :true-label="1"
                                :false-label="0"
                            >启用</el-checkbox>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >

                    </el-table-column>
                </template>
                <el-table-column
                    label="操作"
                    :width="list.length>0?120:''"
                >
                    <template v-slot="{row}">
                        <span
                            class="table-opt"
                            @click="mod(row)"
                        >编辑</span>
                        <span
                            class="table-opt"
                            @click="batchDelete(row)"
                        >删除</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
        <el-dialog
            :title="currItem.id?'编辑':'新增' + '禁歌信息'"
            :visible.sync="isShow"
            :close-on-click-modal="false"
            custom-class="dialog-box-middle"
            @close="close()"
        >
            <el-form
                ref="form"
                :model="currItem"
                :rules="rules"
                label-width="80px"
                v-if="isShow"
            >
                <el-form-item
                    label="歌曲名"
                    prop="song_name"
                >
                    <el-input
                        class="form-input"
                        v-model="currItem.song_name"
                    ></el-input>
                </el-form-item>
                <el-form-item
                    label="歌星名"
                    prop="singer_name"
                >
                    <el-input
                        class="form-input"
                        v-model="currItem.singer_name"
                    ></el-input>
                </el-form-item>
                <el-form-item
                    label="备注"
                    prop="remark"
                >
                    <el-input
                        class="form-textarea"
                        v-model="currItem.remark"
                        type="textarea"
                    ></el-input>
                </el-form-item>
                <el-form-item
                    label="被禁日期"
                    prop="ban_date"
                >
                    <el-date-picker
                        type="date"
                        placeholder="选择日期"
                        v-model="currItem.ban_date"
                        value-format='yyyy-MM-dd'
                    >
                    </el-date-picker>
                </el-form-item>
            </el-form>
            <div
                slot="footer"
                class="dialog-footer"
            >
                <el-button @click="close()">取消</el-button>
                <el-button
                    type="primary"
                    @click="onSubmit"
                >确定</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
@Component
export default class BannedSongs extends Mixins(Query) {
    formTitle = '禁歌管理';
    url: any = '/api/song/banned';
    deleteUrl: any = '/api/song/batch/banned';
    addUrl: any = '/api/song/import-banned';
    exportUrl: any = '/api/song/export-banned';
    queryData: any = {
        song_name: '',
        singer_name: '',
        begin: '',
        end: '',
    };
    columnItems: any = [
        { prop: 'song_name', label: '歌曲名' },
        { prop: 'singer_name', label: '歌星名' },
        { prop: 'remark', label: '备注' },
        { prop: 'ban_date', label: '被禁日期' },
    ];
    isShow: Boolean = false;
    currItem: any = {
        id: '',
        song_name: '',
        singer_name: '',
        remark: '',
        ban_date: ''
    };
    rules: any = {
        song_name: [
            {
                required: true, message: '请输入歌曲名', trigger: 'blur'
            }
        ],
        singer_name: [
            {
                required: true, message: '请输入歌星名', trigger: 'blur'
            }
        ],
        remark: [
            {
                required: true, message: '请输入备注', trigger: 'blur'
            }
        ],
        ban_date: [
            {
                required: true, message: '请选择被禁日期', trigger: 'blur'
            }
        ],
    };
    mod(row) {
        this.currItem = Object.assign(this.currItem, row);
        this.isShow = true;
    }
    close() {
        this.currItem = {
            id: '',
            song_name: '',
            singer_name: '',
            remark: '',
            ban_date: ''
        };
        this.isShow = false;
    }
    onSubmit() {
        (this.$refs.form as any).validate((valid) => {
            if (valid) {
                this.save();
            }
        });
    }
    save() {
        let method: any = this.currItem.id ? 'mixPatch' : 'mixPost';
        let url: any = this.currItem.id ? `/api/song/banned/${this.currItem.id}` : '/api/song/banned';
        let data: any = {
            song_name: this.currItem.song_name,
            singer_name: this.currItem.singer_name,
            remark: this.currItem.remark,
            ban_date: this.currItem.ban_date
        };
        this[method](url, data).then(res => {
            this.$message({
                type: 'success',
                message: `${this.currItem.id ? '编辑' : '新增'}成功!`
            });
            this.getList();
            this.close();
        });
    }
}
</script>