<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">公播管理</span>
            </div>
            <div class="title-right">
                <ImportButton @change="excelEdit">导入新增</ImportButton>
                <ImportButton
                    @change="excelEdit"
                    requestType="edit"
                >导入编辑</ImportButton>
                <button
                    class="btn button-default"
                    @click="batchDelete"
                >批量删除</button>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">类型选择</label>
                    <el-select v-model="queryData.acc_type">
                        <el-option
                            :value="key"
                            :label="el"
                            v-for="(el,key) in types"
                            :key="key"
                        >
                        </el-option>
                    </el-select>
                </li>
                <li class="query-item">
                    <label class="label">歌曲编号/歌曲名</label>
                    <input
                        class="input"
                        type="text"
                        v-model="queryData.keyword"
                    >
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                @selection-change="checkItem"
                v-loading="loading"
            >
                <el-table-column
                    type="selection"
                    width="55"
                >
                </el-table-column>
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >

                    </el-table-column>
                </template>
                <el-table-column
                    label="操作"
                    :width="list.length>0?120:''"
                >
                    <template v-slot='{row}'>
                        <span
                            class="table-opt"
                            @click="batchDelete(row)"
                        >删除</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
@Component
export default class Broadcast extends Mixins(Query) {
    url = '/api/song/acc';
    deleteUrl = '/api/song/batch/acc';
    queryData = {
        keyword: '',
        acc_type: '0'
    };
    columnItems: any = [
        { prop: 'acc_id', label: '歌曲编号 ' },
        { prop: 'filename', label: '文件名' },
        { prop: 'host_ip', label: '盘符' },
        { prop: 'acc_name', label: '歌曲名' },
        { prop: 'seq', label: '排序' },
        { prop: 'start_time', label: '开始时间' },
        { prop: 'end_time', label: '结束时间' }
    ];
    types: any = {};
    mounted() {
        this.getTypes();
    }
    getTypes() {
        this.mixGet('/api/support/acc-type', null, { loading: false }).then(res => {
            this.types = res.data.data;
        });
    }
}
</script>