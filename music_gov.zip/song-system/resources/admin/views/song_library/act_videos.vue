<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">跳舞视频</span>
            </div>
            <div class="title-right">
                <ImportButton @change="excelEdit">导入新增</ImportButton>
                <ImportButton
                    @change="excelEdit"
                    requestType="edit"
                >导入编辑</ImportButton>
                <button
                    class="btn button-default"
                    @click="batchDelete"
                >批量删除</button>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">歌曲编号/歌曲名</label>
                    <input
                        class="input"
                        type="text"
                        v-model="queryData.keyword"
                    >
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                @selection-change="checkItem"
                v-loading="loading"
            >
                <el-table-column
                    type="selection"
                    width="55"
                >
                </el-table-column>
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop == 'image'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            <el-image
                                class="table-img"
                                :src="image_domain + row.image"
                                :preview-src-list="[image_domain + row.image]"
                            >
                            </el-image>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                    </el-table-column>
                </template>
                <el-table-column
                    label="操作"
                    :width="list.length>0?120:''"
                >
                    <template v-slot="{row}">
                        <span
                            class="table-opt"
                            @click="batchDelete(row)"
                        >删除</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
import { Action, Getter } from 'vuex-class';
import Query from '../common/query';
@Component
export default class ActVideos extends Mixins(Query) {
    url = '/api/song/act/video';
    deleteUrl = '/api/song/batch/act/video';
    queryData = {
        keyword: '',
    };
    columnItems: any = [
        { prop: 'songno', label: '歌曲编号 ' },
        { prop: 'accompany_name', label: '歌曲名', width: 150 },
        { prop: 'accompany_name_spell', label: '歌曲名简拼', width: 100 },
        { prop: 'host_ip', label: '存储路径', width: 150 },
        { prop: 'accompany_filename', label: '文件名', width: 150 },
        { prop: 'image', label: '图片', width: 150 },
        { prop: 'category_id', label: '类别' },
        { prop: 'char_count', label: '歌曲名字数', width: 100 },
        { prop: 'act_video_type', label: 'Type' },
        { prop: 'lamp_id', label: '灯光' },
        { prop: 'effect_id', label: '音效' },
        { prop: 'reverberation_id', label: '混响' },

    ];
    currItem: any = {};
    @Getter settingInfo: any;
    image_domain: any = '';
    mounted() {
        this.image_domain = this.settingInfo.image_domain;
    }
}
</script>
<style lang="scss" scoped>
.proportion-container {
    width: 4.5rem;
    margin: auto;
}
</style>