<template>
    <el-dialog
        :title="(info.id ? '编辑' : '新增') + '歌曲标签'"
        :visible.sync="show"
        :close-on-click-modal="false"
        custom-class="dialog-box-middle"
    >
        <el-form
            ref="form"
            :model="info"
            :rules="rules"
            label-width="80px"
            v-if="show"
        >
            <el-form-item
                label="编号"
                prop="id"
                v-if="info.id"
            >
                <el-input
                    class="form-input"
                    v-model="info.id"
                    disabled
                ></el-input>
            </el-form-item>
            <el-form-item
                label="标签名称"
                prop="name"
            >
                <el-input
                    class="form-input"
                    v-model="info.name"
                ></el-input>
            </el-form-item>
            <el-form-item
                label="排序"
                prop="seq"
            >
                <el-input
                    type="number"
                    class="form-input"
                    v-model.number="info.seq"
                ></el-input>
            </el-form-item>
            <el-form-item label="是否显示">
                <el-checkbox
                    v-model="info.is_show"
                    :true-label="1"
                    :false-label="0"
                >是</el-checkbox>
            </el-form-item>
        </el-form>
        <div
            slot="footer"
            class="dialog-footer"
        >
            <el-button @click="show = false">取消</el-button>
            <el-button
                type="primary"
                @click="onSubmit"
            >确定</el-button>
        </div>
    </el-dialog>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
@Component
export default class TagEdit extends Mixins() {
    show = false;
    info: any = {
        id: '',
        name: '',
        seq: '',
        is_show: '',
    };
    callback: any = null;
    rules = {
        name: [
            { required: true, message: '请输入标签名称', trigger: 'blur' },
        ],
        seq: [
            { required: true, message: '请输入排序值', trigger: 'blur' },
            { type: 'number', message: '排序值必须为数字值' },
        ],
    };
    mounted() {

    }
    open(item, callback) {
        this.info = Object.assign({
            id: '',
            name: '',
            seq: '',
            is_show: 1,
        }, item || {});
        this.callback = callback;
        this.show = true;
    }
    onSubmit() {
        (this.$refs.form as any).validate((valid) => {
            if (valid) {
                this.sure();
            } else {
                return false;
            }
        });
    }
    sure() {
        let url = `/api/tag/accompany-tag`;
        let method = this.mixPost;
        if (this.info.id) {
            url = `${url}/${this.info.id}`;
            method = this.mixPatch;
        }
        method(url, {
            name: this.info.name,
            seq: Number(this.info.seq),
            is_show: this.info.is_show,
        }).then(res => {
            this.$message({ message: '保存成功', type: 'success' });
            this.callback && this.callback();
            this.show = false;
        });
    }
}
</script>