<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span
                    class="title"
                    @click="$router.go(-1)"
                >禁歌管理</span>
                <span class="title">编辑</span>
            </div>
            <div class="title-right">
                <button class="btn button-primary">保存</button>
                <button
                    class="btn button-default"
                    @click="$router.go(-1)"
                >返回</button>
            </div>
        </div>
        <div class="main-content">
            <el-form
                ref="form"
                :model="form"
                label-width="90px"
            >
                <el-form-item label="编号/歌曲名">
                    <el-input
                        class="form-input"
                        type="input"
                    ></el-input>
                </el-form-item>
                <el-form-item label="编号/歌曲名">
                    <SearchInput />
                </el-form-item>
                <el-form-item label="反馈门店">
                    <SearchInput />
                </el-form-item>
                <el-form-item label="日期">
                    <SearchDateRange />
                </el-form-item>
                <el-form-item label="备注">
                    <!-- <SearchDateRange /> -->
                    <el-input
                        class="form-textarea"
                        type="textarea"
                    ></el-input>
                    <!-- <textarea class="form-textarea"></textarea> -->
                </el-form-item>
                <el-form-item label="应用门店">
                    <el-transfer
                        v-model="value"
                        :data="data"
                    ></el-transfer>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
@Component
export default class BannedSongsEdit extends Vue {

}
</script>
<style lang="scss" scoped>
.form-input {
    width: 2rem;
    height: 0.4rem;
}
.form-textarea {
    width: 3.5rem;
}
</style>