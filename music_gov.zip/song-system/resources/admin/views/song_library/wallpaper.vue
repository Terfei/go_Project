<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">动态壁纸管理</span>
            </div>
            <div class="title-right">
                <ImportButton @change="excelEdit">导入新增</ImportButton>
                <ImportButton
                    @change="excelEdit"
                    requestType="edit"
                >导入编辑</ImportButton>
                <button
                    class="btn button-default"
                    @click="batchDelete"
                >批量删除</button>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">壁纸编号</label>
                    <input
                        class="input"
                        type="text"
                        v-model="queryData.no"
                    >
                </li>
                <li class="query-item">
                    <label class="label">壁纸名</label>
                    <input
                        class="input"
                        type="text"
                        v-model="queryData.name"
                    >
                </li>
                <li class="query-item">
                    <label class="label">文件名</label>
                    <input
                        class="input"
                        type="text"
                        v-model="queryData.filename"
                    >
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                @selection-change="checkItem"
                v-loading="loading"
            >
                <el-table-column
                    type="selection"
                    width="55"
                >
                </el-table-column>
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop == 'emos'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            <span>{{row.emos && row.emos.join('，')}}</span>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >

                    </el-table-column>
                </template>
                <el-table-column
                    label="操作"
                    :width="list.length>0?120:''"
                >
                    <template v-slot="{row}">
                        <span
                            class="table-opt"
                            @click="batchDelete(row)"
                        >删除</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
@Component
export default class Wallpaper extends Mixins(Query) {
    url = '/api/song/wallpaper';
    deleteUrl = '/api/song/batch/wallpaper';
    queryData = {
        no: '',
        name: '',
        filename: '',
    };
    columnItems: any = [
        { prop: 'wallpaper_no', label: '壁纸编号 ' },
        { prop: 'wallpaper_name', label: '壁纸名', width: 150 },
        { prop: 'wallpaper_filename', label: '文件名' },
        { prop: 'host_ip', label: '存储路径' },
        { prop: 'pip_x', label: 'X坐标' },
        { prop: 'pip_y', label: 'Y坐标' },
        { prop: 'pip2_x', label: 'X坐标2' },
        { prop: 'pip2_y', label: 'Y坐标2' },
        { prop: 'pip_height', label: '高度' },
        { prop: 'pip_width', label: '宽度' },
        { prop: 'png_count', label: 'png数量' },
        { prop: 'emos', label: '情绪标签', width: 150 },
    ];
}
</script>