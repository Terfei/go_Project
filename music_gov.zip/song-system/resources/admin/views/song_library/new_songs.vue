<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">新歌列表</span>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">歌曲名</label>
                    <input
                        class="input"
                        type="text"
                        v-model="queryData.name"
                    >
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="refreshQuery()"
                    >刷新</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <el-table-column
                    type="index"
                    label=""
                    width='100'
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">

                    <el-table-column
                        v-if="item.prop === 'accompany_name'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                    >
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                    </el-table-column>
                </template>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import axios from 'axios';
import { Component, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
@Component
export default class Newsongs extends Mixins(Query) {
    url = '/api/song/new-songs';
    queryData = {
        name: '',
    };
    columnItems: any = [
        { prop: 'accompany_name', label: '歌曲名 ' },
        { prop: 'singer_name', label: '歌星名' },
        { prop: 'language', label: '语种' },
    ];
    refreshQuery() {
        location.reload();
    }
}
</script>