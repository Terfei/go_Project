<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">歌曲管理</span>
                <span class="title">禁歌</span>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <ul class="query-container">
                <li class="tips">
                    <p>
                        操作提示：以下歌曲可能为禁歌，请确认是否删除！
                    </p>
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="batchDelete"
                    >删除</Throttle>
                    <button
                        class="btn button-default"
                        @click="goBack()"
                    >返回</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                @selection-change="checkItem"
                v-loading="loading"
                ref="multipleTable"
            >
                <el-table-column
                    fixed
                    type="selection"
                    width="55"
                >
                </el-table-column>
                <el-table-column
                    type="index"
                    label="序号"
                    width='80'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop == 'category'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            {{row.category.name}}
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop == 'language'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            {{row.language.name}}
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop == 'audioqlty'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            {{row.audioqlty.code}}11
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop == 'videoqlty'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            {{row.videoqlty.code}}22
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                    </el-table-column>
                </template>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Mixins, Watch } from 'vue-property-decorator';
import Query from '../../common/query';
@Component
export default class SongsBanSongs extends Mixins(Query) {
    columnItems: any = [
        { prop: 'songno', label: '歌曲编号 ' },
        { prop: 'filename', label: '文件名', width: 120 },
        { prop: 'name', label: '歌曲名', width: 120 },
        { prop: 'char_count', label: '歌曲名字数' },
        { prop: 'name_spell', label: '歌曲名简拼' },
        { prop: 'category', label: '歌曲类型' },
        { prop: 'singer_name_all', label: '歌星名', width: 120 },
        { prop: 'language', label: '语种' },
        { prop: 'tag_id', label: '标签' },
        { prop: 'audioqlty', label: '音频质量' },
        { prop: 'videoqlty_id', label: '视频质量' },
        { prop: 'audio', label: '音量值' },
        // { prop: 'name', label: '原唱声道' },
        { prop: 'channel', label: '伴唱声道' },
        { prop: 'created_at', label: '入库时间', width: 150 },
        { prop: 'release_time', label: '新歌发布时间', width: 120 },
        { prop: 'server_path', label: '存储路径' },
    ];
    url: any = '/api/song/accompany';
    deleteUrl = '/api/song/batch/accompany';
    total: any = 0;
    queryData: any = {
        songnos: []
    };

    @Watch('list')
    watchList(val) {
        if (val && val.length) {
            this.$nextTick(() => {
                val.forEach(x => {
                    (this.$refs.multipleTable as any).toggleRowSelection(x, true);
                });
            });
        }
    }

    created() {
        this.queryData.songnos = this.$route.query.banned;
        this.total = this.$route.query.total;
    }
    // 批量删除
    batchDelete() {
        let self = this;
        if (this.checkedList.length > 0) {
            this.$confirm('确定要删除选中项吗?', '温馨提示', {
                type: 'warning'
            }).then(() => {
                let ids = this.checkedList.map(x => x.id);
                this.mixDelete(this.deleteUrl, { ids }).then(res => {
                    this.$message.success({
                        message: `删除成功,本次成功导入${this.total - this.checkedList.length}条数据！`,
                        onClose() {
                            self.$router.go(-1);
                        }
                    });
                }).catch(() => {
                    this.$message.error('操作失败!');
                });
            });
        }
        else {
            this.$message.warning('请至少选择一项，再进行删除操作!');
        }
    }
    goBack() {
        let self = this;
        this.$message.success({
            message: `本次成功导入${this.total}条数据！`,
            onClose() {
                self.$router.go(-1);
            }
        });
    }
}
</script>
<style lang="scss" scoped>
.tips {
    height: 0.3rem;
    line-height: 0.3rem;
    margin-bottom: 0.2rem;
    margin-right: 0.2rem;
}
</style>