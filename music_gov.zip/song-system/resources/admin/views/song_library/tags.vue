<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">标签管理</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-default btn-add-icon"
                    @click="openEdit()"
                >新增</button>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <el-tabs
                v-model="currTag"
                @tab-click="setTag"
            >
                <el-tab-pane
                    v-for="item in tags"
                    :key="item.name"
                    :label="item.label"
                    :name="item.name"
                >
                    <el-table
                        :data="item.list"
                        height="100%"
                        border
                    >
                        <template v-for="(item1,index1) in item.columns">
                            <el-table-column
                                :key="item1.prop + index1"
                                :prop="item1.prop"
                                :label="item1.label"
                                :width="item.list.length > 0 ? item1.width : ''"
                                :formatter="item1.formatter || null"
                            >
                            </el-table-column>
                        </template>
                        <el-table-column
                            label="操作"
                            :width="item.list.length > 0 ? 150 : ''"
                        >
                            <template v-slot="{row}">
                                <span
                                    class="table-opt"
                                    @click="openEdit(row)"
                                >编辑</span>
                                <span
                                    class="table-opt"
                                    @click="delItem(row)"
                                >删除</span>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-tab-pane>
            </el-tabs>
        </div>
        <AudioqltyEdit ref="accompany-audioqlty" />
        <VideoqltyEdit ref="accompany-videoqlty" />
        <CategoryEdit ref="accompany-category" />
        <TagEdit ref="accompany-tag" />
        <EmoEdit ref="emo" />
        <SingerareaEdit ref="singer-area" />
        <LanguageEdit ref="accompany-language" />
        <VersionEdit ref="accompany-version" />
    </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import AudioqltyEdit from './components/audioqlty_edit.vue';
import VideoqltyEdit from './components/videoqlty_edit.vue';
import CategoryEdit from './components/category_edit.vue';
import TagEdit from './components/tag_edit.vue';
import EmoEdit from './components/emo_edit.vue';
import SingerareaEdit from './components/singerarea_edit.vue';
import LanguageEdit from './components/language_edit.vue';
import VersionEdit from './components/version_edit.vue';
@Component({
    components: {
        AudioqltyEdit,
        VideoqltyEdit,
        CategoryEdit,
        TagEdit,
        EmoEdit,
        SingerareaEdit,
        LanguageEdit,
        VersionEdit,
    },
})
export default class Tags extends Vue {
    currTag = 'accompany-audioqlty';
    tags: Array<any> = [
        {
            label: '歌曲音频质量',
            name: 'accompany-audioqlty',
            list: [],
            columns: [
                { prop: 'id', label: '编号', width: 150 },
                { prop: 'code', label: '音频质量' },
                { prop: 'seq', label: '排序' },
                { prop: 'is_show', label: '是否显示', formatter: (row, col, val) => val == 1 ? '是' : '否' },
                { prop: 'image', label: '图片名' },
            ],
        },
        {
            label: '歌曲视频质量',
            name: 'accompany-videoqlty',
            list: [],
            columns: [
                { prop: 'id', label: '编号', width: 150 },
                { prop: 'code', label: '视频质量' },
                { prop: 'seq', label: '排序' },
                { prop: 'is_show', label: '是否显示', formatter: (row, col, val) => val == 1 ? '是' : '否' },
                { prop: 'image', label: '图片名' },
            ],
        },
        {
            label: '歌曲版本',
            name: 'accompany-version',
            list: [],
            columns: [
                { prop: 'id', label: '编号', width: 150 },
                { prop: 'name', label: '版本名称' },
                { prop: 'seq', label: '排序' },
            ],
        },
        {
            label: '歌曲分类',
            name: 'accompany-category',
            list: [],
            columns: [
                { prop: 'id', label: '编号', width: 150 },
                { prop: 'name', label: '分类名称' },
                { prop: 'name_key', label: '拼写' },
                { prop: 'seq', label: '排序' },
                { prop: 'is_show', label: '是否显示', formatter: (row, col, val) => val == 1 ? '是' : '否' },
                { prop: 'image', label: '图片名' },
            ],
        },
        {
            label: '歌曲标签',
            name: 'accompany-tag',
            list: [],
            columns: [
                { prop: 'id', label: '编号', width: 150 },
                { prop: 'name', label: '标签名称' },
                { prop: 'seq', label: '排序' },
                { prop: 'is_show', label: '是否显示', formatter: (row, col, val) => val == 1 ? '是' : '否' },
            ],
        },
        {
            label: '情绪标签',
            name: 'emo',
            list: [],
            columns: [
                { prop: 'id', label: '编号', width: 150 },
                { prop: 'name', label: '标签名称' },
                { prop: 'name_key', label: '拼写' },
                { prop: 'seq', label: '排序' },
                { prop: 'is_show', label: '是否显示', formatter: (row, col, val) => val == 1 ? '是' : '否' },
                { prop: 'image', label: '图片名' },
            ],
        },
        {
            label: '歌曲语种',
            name: 'accompany-language',
            list: [],
            columns: [
                { prop: 'id', label: '编号', width: 150 },
                { prop: 'name', label: '歌曲语种' },
                { prop: 'name_key', label: '拼写' },
                { prop: 'seq', label: '排序' },
                { prop: 'is_show', label: '是否显示', formatter: (row, col, val) => val == 1 ? '是' : '否' },
                { prop: 'image', label: '图片名' },
            ],
        },
        {
            label: '歌星区域',
            name: 'singer-area',
            list: [],
            columns: [
                { prop: 'id', label: '编号', width: 150 },
                { prop: 'name', label: '歌星区域' },
                { prop: 'seq', label: '排序' },
                { prop: 'image', label: '图片名' },
            ],
        },
    ];

    mounted() {
        this.init();
    }
    init() {
        let tag = this.tags.find(x => x.name === this.currTag);
        this.mixGet(`/api/tag/${this.currTag}`, null, { loading: false }).then(res => {
            tag.list = res.data.data;
        }).catch(res => {
        });
    }
    setTag() {
        this.init();
    }
    openEdit(item) {
        (this.$refs[this.currTag] as any).open(item, () => {
            this.init();
        });
    }


    delItem(item) {
        this.$confirm('确定要删除该数据吗?', '删除', {
            type: 'warning'
        }).then(async () => {
            await this.mixDelete(`/api/tag/${this.currTag}/${item.id}`);
            this.$message({ message: '删除成功', type: 'success' });
            this.init();
        }).catch(() => {
        });
    }
}
</script>
<style lang="scss" scoped>
.el-tabs {
    display: flex;
    flex-direction: column;
    flex: 1;
    overflow: hidden;
}
/deep/ .el-tabs__content {
    flex: 1;
}
/deep/ .el-tab-pane {
    height: 100%;
}
</style>