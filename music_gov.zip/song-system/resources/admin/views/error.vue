<template>
    <div class="container">
        <div class="info">
            <p class="message">糟糕，页面出错了！</p>
            <button
                class="button-primary"
                @click="$router.go(-1)"
            >返回上一页</button>
        </div>
    </div>
</template>
<style lang="scss" scoped>
.container {
    display: flex;
    min-height: 100vh;
}
.message {
    margin-bottom: 0.3rem;
}
.info {
    margin: auto;
    text-align: center;
    font-size: 0.2rem;
}
</style>