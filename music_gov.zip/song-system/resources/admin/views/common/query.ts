import { Component, Vue } from 'vue-property-decorator';
import axios, { AxiosPromise, AxiosError, AxiosResponse } from 'axios';
@Component
export default class Query extends Vue {
    url = '';
    deleteUrl = '';
    addUrl = '';
    // editUrl = '';
    exportUrl = '';
    list: Array<any> = [];
    queryData: any = {};
    queryDataRequire: any = {};
    formTitle: any = '';
    checkedList: Array<any> = [];
    // 分页
    isPaging = true;// 是否有分页
    pagination = {};
    currPageSize = 20;
    currPage = 1;
    loading = false;
    mounted() {
        this.getList().then(res => {
            this.pagination = (res && res.pagination) || {};
        });
    }
    getList() {
        let data: any = {};
        if (this.isPaging) {
            data.page = this.currPage;
            data.page_size = this.currPageSize;
        }
        let regx = /.+/;// 不为空
        for (let key in this.queryData) {
            if (typeof (this.queryData[key]) == 'string') {
                if (regx.test(this.queryData[key].trim())) {
                    data[key] = this.queryData[key].trim();
                }
            }
            else {
                data[key] = this.queryData[key];
            }
        }
        this.loading = true;
        return this.mixGet(this.url, data, { loading: false }).then(res => {
            let info = res.data.data;
            if ('list' in info) {
                this.list = info.list || [];
            }
            else {
                this.list = info || [];
            }
            this.loading = false;
            this.pagination = info.pagination;
            return info;
        }).catch(res => {
            this.loading = false;
        });
    }
    query() {
        this.currPage = 1;
        this.getList();
    }
    clearQuery() {
        for (let key in this.queryData) {
            this.queryData[key] = '';
        }
    }
    // 分页
    paginationChange(val, type) {
        this[type] = val;
        this.getList();
    }
    // 计算index
    computedIndex(num) {
        return (this.currPage - 1) * this.currPageSize + num + 1;
    }
    // 批量操作
    checkItem(value) {
        this.checkedList = value;
    }
    // 删除
    deleteOne(row) {
        this.$confirm('确定要删除该项吗?', '温馨提示', {
            type: 'warning'
        }).then(() => {
            this.mixDelete(`${this.deleteUrl}/${row.id}`).then(res => {
                this.$message.success('删除成功!');
                this.getList();
            }).catch(() => {
                this.$message.error('操作失败!');
            });
        });
    }
    // 批量删除
    batchDelete(row) {
        if ((row && row.id) || this.checkedList.length > 0) {
            let msg = row && row.id ? '确定要删除该项吗?' : '确定要删除选中项吗?';
            this.$confirm(msg, '温馨提示', {
                type: 'warning'
            }).then(() => {
                let ids = (row && row.id && [row.id]) || this.checkedList.map(x => x.id);
                this.mixDelete(this.deleteUrl, { ids }).then(res => {
                    this.$message.success('删除成功!');
                    this.getList();
                }).catch(() => {
                    this.$message.error('操作失败!');
                });
            });

        }
        else {
            this.$message.warning('请至少选择一项，再进行删除操作!');
        }
    }
    // 导入新增
    excelEdit(file: File, type: any) {
        let url = type == 'add' && this.addUrl ? this.addUrl : this.url;
        let typeMap = {
            add: {
                tips: '成功导入',
                method: 'mixPost',
            },
            edit: {
                tips: '成功编辑',
                method: 'mixPatch',
            },
            delete: {
                tips: '成功删除',
                method: 'mixDelete',
            }
        };
        let data = new FormData();
        data.append('file', file);
        this[typeMap[type].method](url, data).then(res => {
            let status = res.status;
            if (status == 200) {
                let fail = res.data.data && res.data.data.fail;
                if (fail) {
                    this.$message.error(fail);
                }
                else {
                    let total = res.data.data && res.data.data.total;
                    this.$message.success(`${typeMap[type].tips}${total}条数据！`);
                    this.getList();
                }
            }
            else {
                let fail = res.data.data && res.data.data.fail;
                fail && this.$message.error(fail);
            }
        });
    }
    // 导出
    exportExcel() {
        let data: any = {};
        for (let key in this.queryData) {
            if (this.queryData[key]) {
                data[key] = this.queryData[key];
            }
            else {
                if (this.queryDataRequire[key]) {
                    this.$message({
                        type: 'warning',
                        message: `${this.queryDataRequire[key]}不可为空`
                    });
                }
            }
        }
        // let baseURL = process.env.NODE_ENV === 'development' ? '/api' : '';
        // let url = `${baseURL}${this.ExportUrl || this.URL}?${qs.stringify(data)}`;
        // location.href = url;
        // return;
        axios.get(`${this.exportUrl || this.url}`, {
            // baseURL,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': window.vm.$store.getters.token,
            },
            transformRequest: [function (info, headers) {
                data = JSON.stringify(info);
                return data;
            }],
            responseType: 'arraybuffer',
            params: data,
        }).then(res => {
            let blob = new Blob([res.data], { type: 'application/vnd.ms-excel' });
            let fileUrl = URL.createObjectURL(blob);
            let a = document.createElement('a');
            a.setAttribute('href', fileUrl);
            a.setAttribute('download', this.getformTitle());
            a.click();
        }).catch(err => {
            if (err.response.status == 401) {
                this.$message({
                    type: 'warning',
                    message: `没有权限！`
                });
            }
            else {
                this.$message({
                    type: 'warning',
                    message: `下载出错了!`
                });
            }
        });
    }
    getformTitle() {
        let now = new Date();
        let time = `${now.getFullYear()}年${(now.getMonth() + 1).toString().padStart(2, '0')}月${now.getDate().toString().padStart(2, '0')}日`;
        return `${this.formTitle}_${time}.xlsx`;
    }
}
