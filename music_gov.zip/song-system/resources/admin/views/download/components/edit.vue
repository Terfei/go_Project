<template>
    <el-dialog
        :title="info.id ? '编辑权限' : '新增权限'"
        :visible.sync="isShow"
        :close-on-click-modal="false"
        custom-class="dialog-box-middle"
    >
        <el-form
            ref="form"
            :model="info"
            :rules="rules"
            label-width="80px"
            v-if="isShow"
        >
            <el-form-item label="批次编号">
                <el-input
                    class="form-input"
                    v-model="info.version_code"
                    disabled
                ></el-input>
            </el-form-item>
            <el-form-item
                label="门店"
                prop="branch_id"
            >
                <SelectBranch
                    v-model="info.branch_id"
                    :disabled="info.id"
                />
            </el-form-item>
            <el-form-item label="备注">
                <el-input
                    type="textarea"
                    class="form-textarea"
                    v-model="info.remarks"
                ></el-input>
            </el-form-item>
            <el-form-item label="下载权限">
                <el-checkbox
                    v-model="info.can_download"
                    :true-label="1"
                    :false-label="0"
                >启用</el-checkbox>
            </el-form-item>
        </el-form>
        <div
            slot="footer"
            class="dialog-footer"
        >
            <el-button @click="isShow = false">取消</el-button>
            <el-button
                type="primary"
                @click="onSubmit"
            >确定</el-button>
        </div>
    </el-dialog>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
@Component
export default class DownLoadEdit extends Mixins() {
    isShow = false;
    info: any = {
        id: '',
        version_code: '',
        branch_id: '',
        can_download: 1,
        remarks: '',
    };
    rules = {
        branch_id: [
            { required: true, message: '请选择门店', trigger: 'blur' },
        ],
    };
    callback: any = null;
    mounted() {

    }

    open(item, callback) {
        this.info = Object.assign({
            id: '',
            version_code: '',
            branch_id: '',
            can_download: 1,
            remarks: '',
        }, item);
        this.callback = callback;
        this.isShow = true;
        this.$nextTick(() => {
            (this.$refs.form as any).resetFields();
        });
    }
    onSubmit() {
        (this.$refs.form as any).validate((valid) => {
            if (valid) {
                this.save();
            }
        });
    }
    save() {
        let method = this.mixPatch;
        let url = `/api/branch/versions/${this.info.id}`;
        let data: any = {
            can_download: Number(this.info.can_download),
            remarks: this.info.remarks,
        };
        if (!this.info.id) {
            method = this.mixPost;
            url = '/api/branch/versions';
            data.version_code = this.info.version_code;
            data.branch_id = this.info.branch_id;
        }
        method(url, data).then(res => {
            this.$message({ message: '保存成功', type: 'success' });
            this.callback && this.callback();
            this.isShow = false;
        });
    }
}
</script>