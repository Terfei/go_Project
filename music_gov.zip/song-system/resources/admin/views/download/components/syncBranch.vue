<template>
    <el-dialog
        title="勾选同步门店"
        :visible.sync="isShow"
        :close-on-click-modal="false"
        custom-class="dialog-box-middle"
    >
        <div class="customer-body">
            <el-tree
                :data="treeData"
                show-checkbox
                node-key="id"
                :default-checked-keys="defaultCheckedKeys"
                default-expand-all
                :props="defaultProps"
                ref="tree"
            >
            </el-tree>
        </div>
        <div
            slot="footer"
            class="dialog-footer"
        >
            <el-button @click="isShow = false">取消</el-button>
            <el-button
                type="primary"
                @click="save"
            >确定</el-button>
        </div>
    </el-dialog>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
@Component
export default class SyncBranch extends Mixins() {
    isShow = false;
    treeData: any = [];
    defaultCheckedKeys: any = [];
    defaultProps = {
        children: 'children',
        label: 'label'
    };
    callback: any = null;
    mounted() {

    }

    open(callback) {
        this.init();
        this.callback = callback;
        this.isShow = true;
    }

    init() {
        Promise.all([this.getBizTypes(), this.getDistricts(), this.getBranches()]).then(resList => {
            let treeData: any = [];
            for (let key in resList[0]) {
                let treeItem: any = {
                    id: key,
                    label: resList[0][key],
                    children: [],
                };
                for (let district of resList[1]) {
                    let branches = resList[2].filter(x => x.district_id === district.district_id && x.biz_type == key);
                    if (branches && branches.length) {
                        treeItem.children.push({
                            id: district.district_id,
                            label: district.district_name,
                            children: branches.map(x => {
                                return {
                                    id: x.branch_id,
                                    label: x.branch_name,
                                    isBranch: true,
                                };
                            })
                        });
                    }
                }
                treeData.push(treeItem);
            }
            this.treeData = treeData.filter(x => x.children.length);
            this.defaultCheckedKeys = resList[2].map(x => x.branch_id);
        });
    }
    getBizTypes() {
        return this.mixGet('/api/support/biz-type', null, { loading: false }).then(res => {
            return res.data.data;
        });
    }
    getDistricts() {
        return this.mixGet('/api/support/meta-district', null, { loading: false }).then(res => {
            return res.data.data;
        });
    }
    getBranches() {
        return this.mixGet('/api/support/branches', null, { loading: false }).then(res => {
            return res.data.data;
        });
    }
    save() {
        let branches = (this.$refs.tree as any).getCheckedNodes().filter(x => x.isBranch).map(x => x.id);
        if (!branches.length) {
            this.$message({ message: '请选择门店', type: 'error' });
            return;
        }
        this.mixPost(`/api/meta/branch/version/sync`, {
            branches
        }).then(res => {
            this.$message({ message: '同步成功', type: 'success' });
            this.callback && this.callback();
            this.isShow = false;
        });
    }
}
</script>
<style lang="scss" scoped>
.customer-body {
    overflow: auto;
    max-height: 6rem;
}
</style>