<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span
                    class="title"
                    @click="$router.go(-1)"
                >批次下载记录</span>
                <span class="title">未下载文件详情</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-default"
                    @click="$router.go(-1)"
                >返回</button>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <el-table
                :data="list"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                        :formatter="item.formatter || null"
                    >
                    </el-table-column>
                </template>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
import Query from '../../common/query';
@Component({
    components: {
    },
})
export default class RecordsDetail extends Mixins(Query) {
    url = '/api/branch/version/fail-files';
    queryData = {
        category_id: '',
    };
    versionTypeMap: any = {};
    columnItems: any = [
        { prop: 'version_code', label: '批次编号' },
        { prop: 'filename', label: '文件名' },
    ];
    created() {
        this.queryData.category_id = this.$route.query.id as string;
    }
}
</script>