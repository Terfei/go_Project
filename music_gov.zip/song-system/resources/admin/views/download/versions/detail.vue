<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span
                    class="title"
                    @click="$router.go(-1)"
                >批次管理</span>
                <span class="title">批次详情</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-primary btn-add-icon"
                    @click="openEdit()"
                >新增权限</button>
                <button
                    class="btn button-default"
                    @click="$router.go(-1)"
                >返回</button>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">门店类型</label>
                    <SelectBiztype v-model="queryData.branch_biz_type" />
                </li>
                <li class="query-item">
                    <label class="label">门店</label>
                    <SelectBranch
                        :bizType="queryData.branch_biz_type"
                        v-model="queryData.branch_id"
                    />
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="cpList"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop === 'can_download'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length > 0 ? item.width:''"
                    >
                        <template v-slot="{ row }">
                            <span :class="{'warn':row.can_download == 0}">{{row.can_download == 1 ? '启用' : '禁用'}}</span>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                    </el-table-column>
                </template>
                <el-table-column
                    label="操作"
                    :width="list.length > 0 ? 150 : ''"
                >
                    <template v-slot="{row}">
                        <span
                            class="table-opt"
                            @click="openEdit(row)"
                        >编辑</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
        <Edit ref="edit" />
    </div>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
import Query from '../../common/query';
import Edit from '../components/edit.vue';
@Component({
    components: {
        Edit,
    },
})
export default class VersionsDetail extends Mixins(Query) {
    url = '/api/branch/versions';
    queryData = {
        branch_biz_type: '',
        branch_id: '',
        version_code: '',
    };
    columnItems: any = [
        { prop: 'version_code', label: '批次编号' },
        { prop: 'branch_name', label: '门店' },
        { prop: 'can_download', label: '权限' },
        { prop: 'remarks', label: '备注' },
    ];
    get cpList() {
        return this.list.map(x => {
            return {
                id: x.version && x.version.id || '',
                version_code: x.version && x.version.version_code || '',
                branch_id: x.branch && x.branch.branch_id || '',
                branch_name: x.branch && x.branch.branch_name || '',
                can_download: x.version && x.version.can_download || '',
                remarks: x.version && x.version.remarks || '',
            };
        });
    }
    created() {
        this.queryData.version_code = this.$route.query.version_code as string;

    }
    clearQuery() {
        for (let key in this.queryData) {
            if (key !== 'version_code') {
                this.queryData[key] = '';
            }
        }
    }
    openEdit(item: any = {}) {
        item.version_code = this.$route.query.version_code as string;
        (this.$refs.edit as any).open(item, () => {
            this.getList();
        });
    }
    goDetail(item) {
        this.$router.push({
            path: '/branch/history',
            query: {
                id: item.id,
            },
        });
    }
}
</script>