<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">生成批次</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-primary"
                    @click="createVersion()"
                >生成最新批次</button>
                <button
                    class="btn button-primary"
                    @click="openBranch()"
                >同步到门店</button>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">批次编号</label>
                    <input
                        type="text"
                        v-model="queryData.code"
                    >
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="item in columnItems">

                    <el-table-column
                        :key="item.prop"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                    </el-table-column>
                </template>
                <el-table-column
                    label="操作"
                    :width="list.length > 0 ? 150 : ''"
                >
                    <template v-slot="{row}">
                        <span
                            class="table-opt"
                            @click="goDetail(row)"
                            v-if="!row.deleted_at"
                        >查看详情</span>
                        <span
                            class="table-opt"
                            @click="delItem(row)"
                            v-if="!row.deleted_at"
                        >删除</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
        <SyncBranch ref="syncBranch" />
    </div>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
import SyncBranch from './components/syncBranch.vue';
@Component({
    components: {
        SyncBranch,
    },
})
export default class DownloadVersions extends Mixins(Query) {
    url = '/api/meta/version/overview';
    queryData = {
        code: '',
    };
    columnItems: any = [
        { prop: 'version_code', label: '批次编号' },
    ];

    mounted() {
    }

    createVersion() {
        this.mixPost('/api/meta/version/overview').then(res => {
            this.$message({ message: '生成成功', type: 'success' });
            this.getList();
        });
    }

    openBranch() {
        (this.$refs.syncBranch as any).open();
    }
    delItem(item) {
        this.$confirm('确定要删除该数据吗?', '删除', {
            type: 'warning'
        }).then(async () => {
            await this.mixDelete(`/api/meta/version/overview/${item.id}`);
            this.$message({ message: '删除成功', type: 'success' });
            this.getList();
        }).catch(() => {
        });
    }
    goDetail(item) {
        this.$router.push({
            path: '/download/versions/detail',
            query: { version_code: item.version_code },
        });
    }
}
</script>