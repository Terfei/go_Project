<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">{{formTitle}}</span>
            </div>
            <div
                class="title-right"
                v-if="false"
            >
                <ExportButton @click="exportExcel()">导出</ExportButton>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">批次编号</label>
                    <input
                        type="text"
                        v-model="queryData.version_code"
                    >
                </li>
                <li class="query-item">
                    <label class="label">门店类型</label>
                    <SelectBiztype v-model="queryData.branch_biz_type" />
                </li>
                <li class="query-item">
                    <label class="label">门店</label>
                    <SelectBranch
                        :bizType="queryData.branch_biz_type"
                        v-model="queryData.branch_id"
                    />
                </li>
                <li class="query-item">
                    <label class="label">文件类型</label>
                    <el-select v-model="queryData.type">
                        <el-option
                            label="全部"
                            value=""
                        ></el-option>
                        <el-option
                            v-for="(val, key) in versionTypeMap"
                            :key="key"
                            :label="val"
                            :value="key"
                        ></el-option>
                    </el-select>
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="cpList"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="item in columnItems">
                    <el-table-column
                        :key="item.prop"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                        v-if="item.prop === 'relation_type'"
                    >
                        <template v-slot="{row}">{{versionTypeMap[row.relation_type] || ''}}</template>
                    </el-table-column>
                    <el-table-column
                        :key="item.prop"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                        :formatter="item.formatter || null"
                        v-else
                    >
                    </el-table-column>
                </template>
                <el-table-column
                    label="操作"
                    :width="list.length > 0 ? 150 : ''"
                >
                    <template v-slot="{row}">
                        <span
                            class="table-opt"
                            @click="goDetail(row)"
                        >查看未下载文件</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
@Component({
    components: {
    },
})
export default class DownloadRecords extends Mixins(Query) {
    formTitle = '批次下载记录';
    url = '/api/branch/versions/stats';
    queryData = {
        version_code: '',
        branch_biz_type: '',
        branch_id: '',
        type: '',
    };
    versionTypeMap: any = {};
    columnItems: any = [
        { prop: 'branch_name', label: '门店' },
        { prop: 'version_code', label: '批次编号' },
        { prop: 'deal_status', label: '数据库更新状态' },
        { prop: 'file_count', label: '文件总数量' },
        { prop: 'done_count', label: '已下载文件数量' },
        { prop: 'undone_count', label: '未下载文件数量' },
        { prop: 'relation_type', label: '文件类型' },
    ];
    dealStatus = {
        init: '待处理',
        fail: '失败',
        success: '成功',
    };
    get cpList() {
        return this.list.map(x => {
            return {
                id: x.stat && x.stat.id || '',
                version_code: x.stat && x.stat.version_code || '',
                deal_status: this.dealStatus[x.stat && x.stat.deal_status || ''] || '',
                file_count: x.stat && x.stat.file_count,
                done_count: x.stat && x.stat.done_count,
                undone_count: x.stat && x.stat.undone_count,
                relation_type: x.stat && x.stat.relation_type || '',
                branch_id: x.branch && x.branch.branch_id || '',
                branch_name: x.branch && x.branch.branch_name || '',
                can_download: x.version && x.version.can_download || '',
                remarks: x.version && x.version.remarks || '',
            };
        });
    }

    created() {
        this.getVersionType();
    }

    getVersionType() {
        this.mixGet('/api/support/version-type', null, { loading: false }).then(res => {
            this.versionTypeMap = res.data.data;
        });
    }
    goDetail(item) {
        this.$router.push({
            path: '/download/records/detail',
            query: { id: item.id },
        });
    }
}
</script>