<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">角色分类管理</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-default btn-add-icon"
                    @click="mod"
                >新增</button>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">名称</label>
                    <input
                        type="text"
                        class="input"
                        v-model="queryData.name"
                    >
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >

                    </el-table-column>
                </template>
                <el-table-column
                    label="操作"
                    :width="list.length>0?120:''"
                >
                    <template v-slot="{row}">
                        <span
                            class="table-opt"
                            @click="mod(row)"
                        >编辑</span>
                        <span
                            class="table-opt"
                            @click="delItem(row.id)"
                        >删除</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
        <el-dialog
            :title="currItem.id?'编辑类别':'新增类别'"
            :visible.sync="show"
            :close-on-click-modal="false"
            custom-class="dialog-box-xsmall"
        >
            <div>
                <el-form
                    ref="form"
                    :model="currItem"
                    :rules="formRules"
                    label-width="60px"
                    v-if="show"
                >
                    <el-form-item
                        label="编号"
                        v-if="currItem.id"
                    >
                        <span>{{currItem.id}}</span>
                    </el-form-item>
                    <el-form-item
                        label="名称"
                        prop='name'
                    >
                        <el-input
                            class="form-input"
                            v-model="currItem.name"
                        ></el-input>
                    </el-form-item>
                </el-form>
            </div>
            <div
                slot="footer"
                class="dialog-footer"
            >
                <el-button @click="close()">取消</el-button>
                <el-button
                    type="primary"
                    @click="save()"
                >确定</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
@Component
export default class RoleClassify extends Mixins(Query) {
    columnItems: any = [
        { prop: 'id', label: '编号', width: 150 },
        { prop: 'name', label: '名称' },
    ];
    url: any = '/api/user/role-classify';
    queryData: any = {
        name: ''
    };
    currItem: any = {
        id: '',
        name: '',
    };
    show: Boolean = false;
    formRules: any = {
        name: [
            {
                required: true, message: '请输入名称', trigger: 'blur'
            }
        ]
    };
    mod(row) {
        if (row) {
            this.currItem = {
                id: row.id,
                name: row.name
            };
        } else {
            this.currItem = {
                id: '',
                name: ''
            };
        }
        this.show = true;
    }
    delItem(id) {
        this.$confirm('确定要删除该账号吗?', '删除', {
            type: 'warning'
        }).then(() => {
            this.mixDelete(`/api/user/role-classify/${id}`).then(res => {
                this.getList();
                this.$message({
                    type: 'success',
                    message: '删除成功!'
                });
            });
        });
    }
    close() {
        this.currItem = {
            id: '',
            name: ''
        };
        this.show = false;
    }
    save() {
        (this.$refs.form as any).validate((valid) => {
            if (!valid) {
                return false;
            } else {
                let method: any = this.currItem.id ? 'mixPatch' : 'mixPost';
                let url: any = this.currItem.id ? `/api/user/role-classify/${this.currItem.id}` : '/api/user/role-classify';
                this[method](url, { name: this.currItem.name }).then(res => {
                    this.$message({
                        type: 'success',
                        message: '保存成功!'
                    });
                    this.getList();
                    this.close();
                });
            }
        });
    }
}
</script>