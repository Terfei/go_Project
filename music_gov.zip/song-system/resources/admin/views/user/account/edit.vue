<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">账号管理</span>
                <span class="title">编辑账号</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-primary"
                    @click="save()"
                >保存</button>
                <button
                    class="btn button-default"
                    @click="$router.go(-1)"
                >返回</button>
            </div>
        </div>
        <div
            class="main-content"
            v-loading="loading"
        >
            <el-form
                ref="form"
                :model="form"
                :rules="rules"
                label-width="80px"
            >
                <el-form-item
                    label="编号"
                    v-if="form.view_code"
                >
                    <span>{{form.view_code}}</span>
                </el-form-item>
                <el-form-item label="用户名">
                    <el-input
                        disabled
                        class="form-input"
                        v-model="form.staff_name"
                    ></el-input>
                </el-form-item>
                <el-form-item label="总部">
                    <div>
                        <el-checkbox v-model="form.is_center">是</el-checkbox>
                    </div>
                </el-form-item>
                <el-form-item
                    label="角色选择"
                    prop="role_ids"
                >
                    <el-transfer
                        v-model="checkedRoles"
                        :data="roles"
                        :titles="['全部角色', '已选角色']"
                        @change="changeCheckedRoles"
                    ></el-transfer>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator';
let validatePass: any = (rule, value, callback) => {
    if (!value.length) {
        callback(new Error('请至少选择一个角色'));
    } else {
        callback();
    }
};
@Component
export default class AccountEdit extends Vue {
    roles: Array<any> = [];
    checkedRoles: Array<any> = [];
    id: any = '';
    form: any = {
        view_code: '',
        name: '',
        is_center:false,
        role_ids: [],

    };
    rules: any = {
        role_ids: [
            { validator: validatePass, trigger: 'blur' }
        ]
    };
    loading: Boolean = true;
    async mounted() {
        this.id = this.$route.query.id;
        this.form.staff_name = this.$route.query.staff_name;
        await this.getRoles();
        this.init();
    }

    changeCheckedRoles(val) {
        this.form.role_ids = this.checkedRoles;
        (this.$refs.form as any).validateField('role_ids');
    }
    async getRoles() {
        await this.mixGet('/api/support/roles', null, { loading: false }).then(res => {
            let list: Array<any> = res.data.data.list;
            let roles: Array<any> = [];
            for (let el of list) {
                roles.push({
                    key: el.id,
                    label: el.name
                });
            }
            this.roles = roles;
        });
    }
    init() {
        this.mixGet(`/api/user/staff/${this.id}`, null, { loading: false }).then(res => {
            let info: any = res.data && res.data.data.list || {};
            this.form.view_code = info && info.view_code;
            this.form.role_ids = info && info.roles && info.roles.map(x => x = x.id) || [];
            this.form.is_center = info&&info.extra&&info.extra.center;
            this.checkedRoles = this.form.role_ids;
            this.loading = false;
        });
    }
    save() {
        this.form.role_ids = this.checkedRoles;
        (this.$refs.form as any).validate((valid) => {
            if (!valid) {
                return false;
            } else {
                this.mixPatch(`/api/user/staff/${this.id}`, { role_ids: this.checkedRoles,is_center:this.form.is_center }).then(res => {
                    this.$message({
                        type: 'success',
                        message: '操作成功!'
                    });
                    this.$router.go(-1);
                });
            }
        });
    }
}
</script>