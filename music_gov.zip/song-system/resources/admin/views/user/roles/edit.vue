<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">角色管理</span>
                <span class="title">{{id?'编辑':'新增'}}角色</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-primary"
                    @click="save()"
                >保存</button>
                <button
                    class="btn button-default"
                    @click="$router.go(-1)"
                >返回</button>
            </div>
        </div>
        <div
            class="main-content"
            v-loading="loading"
        >
            <el-form
                ref="form"
                :model="form"
                :rules="formRules"
                label-width="80px"
            >
                <el-form-item
                    label="编号"
                    v-if="id"
                >
                    <span>{{form.view_code}}</span>
                </el-form-item>
                <el-form-item
                    label="名称"
                    prop="name"
                >
                    <el-input
                        class="form-input"
                        v-model="form.name"
                    ></el-input>
                </el-form-item>
                <el-form-item
                    label="状态"
                    prop="status"
                >
                    <el-checkbox
                        v-model="form.status"
                        true-label="opened"
                        false-label="closed"
                    >启用</el-checkbox>
                </el-form-item>
                <el-form-item
                    label="角色类别"
                    prop="classify_id"
                >
                    <el-select
                        class="form-select"
                        v-model="form.classify_id"
                        placeholder="请选择"
                    >
                        <el-option
                            v-for="item in classify"
                            :key="item.id"
                            :label="item.name"
                            :value="item.id"
                        >
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item
                    label="备注"
                    prop="remarks"
                >
                    <el-input
                        type="textarea"
                        class="form-textarea"
                        v-model="form.remarks"
                    ></el-input>
                </el-form-item>
                <el-form-item
                    label="权限"
                    prop="permission_ids"
                >
                    <el-table
                        :data="permissions"
                        border
                        :span-method="objectSpanMethod"
                    >
                        >
                        <el-table-column
                            prop="module_name"
                            label="模块"
                        >
                            <template v-slot="{row}">
                                <div>
                                    <input
                                        type="checkbox"
                                        v-model="row.module_checked"
                                    >
                                    <label @click="chooseModule(row)">{{row.module_name}}</label>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column
                            prop="page_name"
                            label="页面"
                        >
                            <template v-slot="{row}">
                                <div>
                                    <input
                                        type="checkbox"
                                        v-model="row.page_checked"
                                    >
                                    <label @click="choosePage(row)">{{row.page_name}}</label>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column
                            prop="actions"
                            label="功能点"
                        >
                            <template v-slot="{row}">
                                <div class="actions-box">
                                    <div
                                        class="actions"
                                        v-for="(el,index) in row.actions"
                                        :key="'actions' + row.page_name + index"
                                    >
                                        <input
                                            type="checkbox"
                                            v-model="el.checked"
                                        >
                                        <label @click="chooseAction(el,row)">{{el.name}}</label>
                                    </div>
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue,Watch } from 'vue-property-decorator';
let validatePass:any = (rule,value,callback)=>{
        if(!value.length){
            callback(new Error('请至少选择一个权限点'));
        }else{
            callback();
        }
    };
@Component
export default class RolesEdit extends Vue {
    id: any = '';
    spanArr: any = [];
    permissions: any = [];
    form: any = {
        view_code: '',
        name: '',
        status: 'opened',
        classify_id: '',
        remarks: '',
        permission_ids: []
    };
    formRules: any = {
        name: [
            {
                required: true, message: '请输入角色名称', trigger: 'blur'
            }
        ],
        classify_id: [
            {
                required: true, message: '请选择角色类别id', trigger: 'change'
            }
        ],
        permission_ids: [
            {validator:validatePass,trigger:'change'}
        ]
    };
    classify: Array<any> = [];
    loading: Boolean = true;
    
    get checkedAll() {
        return this.permissions.every(x => x.module_checked && x.page_checked && x.actions.every(y => y.checked));
    }
    @Watch('permissions',{ deep: true })
    permissionsChanged(newVal,oldVal){
        let ids: Array<any> = [];
        for (let item of newVal) {
            if (item.module_checked && (ids.length && !ids.filter(x => x == item.module_id).length)) {
                ids.push(item.module_id);
            }
            if (item.page_checked) {
                ids.push(item.page_id);
            }
            ids = ids.concat(item.actions.filter(x => x.checked).map(x => x.id));
        }
        this.form.permission_ids = ids;
        if(oldVal.length){
            (this.$refs.form as any).validateField('permission_ids');
        }   
    }
    async  mounted() {
        this.id = this.$route.query.id || '';
        await this.getClassify();
        this.init();
    }
    async getClassify() {
        await this.mixGet('/api/support/role-classify', null, { loading: false }).then(res => {
            this.classify = res.data.data.list || [];
        });
    }
    init() {
        if (!this.id) {
            this.getPermissions();
            return;
        }
        this.mixGet(`/api/user/role/${this.id}`, null, { loading: false }).then(res => {
            let info: any = res.data.data.list;
            this.form = {
                view_code: info.view_code,
                name: info.name,
                status: info.status,
                classify_id: info.classify_id,
                remarks: info.remarks,
                permission_ids: info.permissions && info.permissions.map(x => x = x.id)
            };
            this.getPermissions(info.permissions && info.permissions.map(x => x.id));
        });
    }
    getPermissions(hasIds: any = []) {
        this.mixGet('/api/support/permissions', null, { loading: false }).then(res => {
            let list: any = res.data.data.list.sort((x, y) => x.permission > y.permission ? -1 : 1);
            this.spanArr = [];

            let permissions = list.filter(x => x.permission.split('>').length == 2).map(x => {
                let names: any = x.permission.split('>');
                let modul: any = list.find(y => y.permission == names[0]);
                let actions: any = list.filter(y => y.permission.split('>').length === 3 && y.permission.includes(x.permission)).map(z => {
                    z.checked = hasIds.includes(z.id);
                    z.name = z.permission.split('>')[2];
                    return z;
                });
                return {
                    module_name: modul.permission,
                    module_checked: hasIds.includes(x.id),
                    module_id: modul.id,
                    page_checked: hasIds.includes(x.id),
                    page_id: x.id,
                    page_name: names[1],
                    actions,
                };
            });
            this.permissions = permissions;
            this.loading = false;
        });
    }
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {

        // 纵向合并第一个单元格
        if (columnIndex === 0) {
            let _row = rowIndex > 0 && row.module_name == this.permissions[rowIndex - 1].module_name ? 0 : this.permissions.filter(x => x.module_name == row.module_name).length;// 7 0
            let _col = _row > 0 ? 1 : 0;
            return [_row, _col];
        }
    }
    chooseAll() {
        let newChecked = !this.checkedAll;
        for (let item of this.permissions) {
            item.module_checked = newChecked;
            item.page_checked = newChecked;
            for (let action of item.actions) {
                action.checked = newChecked;
            }
        }
    }
    // 模块选择
    chooseModule(row) {
        row.module_checked = !row.module_checked;
        this.permissions.forEach(x => {
            if (x.module_id == row.module_id) {
                x.module_checked = row.module_checked;
                x.page_checked = row.module_checked;
                x.actions.forEach(y => {
                    y.checked = row.module_checked;
                });
            }
        });
    }
    // 页面选择
    choosePage(row) {
        row.page_checked = !row.page_checked;
        row.actions.forEach(x => {
            x.checked = row.page_checked;
        });
        // 反选模块
        let curr_module = this.permissions.filter(x => x.module_name == row.module_name);
        for (let el of curr_module) {
            if (curr_module.every(y => !y.page_checked)) {
                el.module_checked = false;
            } else {
                el.module_checked = true;
            }
        }
    }
    // 功能点选择
    chooseAction(el, row) {
        el.checked = !el.checked;
        // 反选页面
        if (row.actions.every(x => x.checked)) {
            row.page_checked = true;
        } else {
            row.page_checked = false;
        }
        // 反选模块
        let curr_module = this.permissions.filter(x => x.module_id == row.module_id);
        let curr_page = this.permissions.filter(x => x.page_id == row.page_id)[0];
        if (curr_page.actions.every(y => !y.checked)) {
            curr_page.page_checked = false;
        } else {
            curr_page.page_checked = true;
        }

        for (let item of curr_module) {
            if (curr_module.every(y => !y.page_checked)) {
                item.module_checked = false;
            } else {
                item.module_checked = true;
            }
        }
    }
    save() {
        (this.$refs.form as any).validate((valid) => {
            if (!valid) {
                return false;
            } else {
                let method: any = this.id ? 'mixPatch' : 'mixPost';
                let url: any = this.id ? `/api/user/role/${this.id}` : '/api/user/role';
                this[method](url, this.form).then(res => {
                    this.$message({
                        type: 'success',
                        message: '操作成功!'
                    });
                    this.$router.go(-1);
                });
            }
        });
    }
}
</script>
<style lang="scss" scoped>
.actions-box {
    display: flex;
    flex-wrap: wrap;
}
.actions {
    margin-right: 0.3rem;
}
</style>