<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">账号管理</span>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">门店类型</label>
                    <el-select v-model="queryData.biz_type">
                        <el-option
                            value=""
                            label="全部"
                        >
                        </el-option>
                        <el-option
                            v-for="(val, key) in bizTypeMap"
                            :key="'bizTypeMap' + key"
                            :label="val"
                            :value="key"
                        ></el-option>
                    </el-select>
                </li>
                <li class="query-item">
                    <label class="label">门店</label>
                    <SelectBranch
                        :bizType="queryData.biz_type"
                        v-model="queryData.branch_id"
                    />
                </li>
                <li class="query-item">
                    <label class="label">用户名</label>
                    <input
                        type="text"
                        class="input"
                        v-model="queryData.name"
                    >
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop == 'branches'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            {{getBranchName(row.branch_ids)}}
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop == 'is_center'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            <span>{{row.is_center?'是':'否'}}</span>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop == 'status'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            <span :class="{'warn':row.delete_time}">{{!row.delete_time?'启用':'禁用'}}</span>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop == 'roles'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            {{row.roles&&row.roles.map(x=>x=x.name).join('、')}}
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                    </el-table-column>
                </template>
                <el-table-column
                    label="操作"
                    :width="list.length>0?120:''"
                >
                    <template v-slot="{row}">
                        <span
                            class="table-opt"
                            @click="reset(row.staff_id)"
                        >重置密码</span>
                        <span
                            class="table-opt"
                            @click="mod(row)"
                        >编辑</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
@Component
export default class Account extends Mixins(Query) {
    value: any = [];
    columnItems: any = [
        { prop: 'branches', label: '所属门店 ', width: 320 },
        { prop: 'staff_number', label: '帐号' },
        { prop: 'staff_name', label: '用户名' },
        { prop: 'view_code', label: '编号' },
        { prop: 'roles', label: '角色' },
        { prop: 'is_center', label: '总部' },
        { prop: 'status', label: '状态', width: 100 },
    ];
    url: any = '/api/user/staffs';
    queryData: any = {
        biz_type: '',
        branch_id: '',
        name: ''
    };
    branches: any = [];
    bizTypeMap: any = {};
    async mounted() {
        this.getBizTypes();
        await this.getBranches();
    }
    getBizTypes() {
        this.mixGet('/api/support/biz-type', null, { loading: false }).then(res => {
            this.bizTypeMap = res.data.data;
        });
    }
    async getBranches() {
        await this.mixGet('/api/support/branches', null, { loading: false }).then(res => {
            this.branches = res.data.data;
        });
    }
    getBranchName(branchIds) {
        let list: any = [];
        if (branchIds) {
            for (let id of branchIds) {
                for (let el of this.branches) {
                    if (el.branch_id == id) {
                        list.push(el.branch_name);
                    }
                }
            }
        }
        return list.join('、');
    }
    reset(id) {
        this.$confirm('确定要重置密码吗?', '重置密码', {
            type: 'warning'
        }).then(() => {
            this.mixPatch(`/api/user/staff/${id}/reset-password`).then(res => {
                this.$message({
                    type: 'success',
                    message: '重置密码将在1分钟后生效!'
                });
            });
        });
    }
    mod(row) {
        this.$router.push({ path: '/user/account/edit', query: { id: row.staff_id, staff_name: row.staff_name } });
    }
}
</script>
