<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">角色管理</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-default btn-add-icon"
                    @click="mod()"
                >新增</button>
                <!-- <button
                    class="btn button-default"
                    @click="batchDel()"
                >批量删除</button> -->
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">角色名称</label>
                    <input
                        type="text"
                        class="input"
                        v-model="queryData.name"
                    >
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <!-- <el-table-column
                    type="selection"
                    width="55"
                >
                </el-table-column> -->
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop == 'status'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            <span :class="{'warn':row.status == 'closed'}">{{row.status == 'opened'?'启用':'禁用'}}</span>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop == 'classify_name'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            {{row.classify.name || ''}}
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >

                    </el-table-column>
                </template>
                <el-table-column
                    label="操作"
                    :width="list.length>0?120:''"
                >
                    <template v-slot="{row}">
                        <span
                            class="table-opt"
                            @click="mod(row.id)"
                        >编辑</span>
                        <span
                            class="table-opt"
                            @click="delItem(row.id)"
                        >删除</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
@Component
export default class Roles extends Mixins(Query) {
    url = '/api/user/roles';
    queryData = {
        name: ''
    };
    columnItems: any = [
        { prop: 'view_code', label: '编号' },
        { prop: 'name', label: '角色名称' },
        { prop: 'classify_name', label: '角色类别' },
        { prop: 'status', label: '状态' },
        { prop: 'remarks', label: '备注' },
    ];
    // checkedList: Array<any> = [];
    mod(id) {
        let query: any = {};
        if (id) {
            query.id = id;
        }
        this.$router.push({ path: '/user/roles/edit', query });
    }
    // checkTable(val) {
    //     this.checkedList = val;
    // }
    // batchDel() {
    //     if (!this.checkedList.length) {
    //         this.$message({
    //             message: '请选择至少一项，再进行删除操作',
    //             type: 'warning'
    //         });
    //     } else {
    //         this.$confirm('确定要删除选中项吗?', '删除', {
    //             type: 'warning'
    //         }).then(() => {
    //             this.$message({
    //                 type: 'success',
    //                 message: '删除成功!'
    //             });
    //         }).catch(() => {
    //             this.$message({
    //                 type: 'info',
    //                 message: '已取消删除'
    //             });
    //         });
    //     }
    // }
    delItem(id) {
        this.$confirm('确定要删除该角色吗?', '删除', {
            type: 'warning'
        }).then(() => {
            this.mixDelete(`/api/user/role/${id}`).then(res => {
                this.getList();
                this.$message({
                    type: 'success',
                    message: '删除成功!'
                });
            });
        });
    }
}
</script>