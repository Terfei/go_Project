<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">{{formTitle}}</span>
            </div>
            <div class="title-right">
                <ExportButton @click="exportExcel()">导出</ExportButton>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">操作人</label>
                    <input
                        class="input"
                        type="text"
                        v-model="queryData.staff_name"
                    >
                </li>
                <li class="query-item">
                    <label class="label">操作时间</label>
                    <el-date-picker
                        type="date"
                        value-format="yyyy-MM-dd"
                        placeholder="选择日期"
                        v-model="queryData.log_date"
                    >
                    </el-date-picker>
                </li>
                <li class="query-item">
                    <label class="label">操作模块</label>
                    <el-select v-model="queryData.module">
                        <el-option
                            value=""
                            label="全部"
                        >
                        </el-option>
                        <el-option
                            v-for="(val, key) in modules"
                            :key="key"
                            :label="val"
                            :value="key"
                        ></el-option>
                    </el-select>
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <!-- <el-table-column
                    type="selection"
                    width="55"
                >
                </el-table-column> -->
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop == 'module'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            {{row.module && modules[row.module]}}
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop === 'action'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                    >
                        <template v-slot="{row}">
                            {{row.action && actionMap[row.action]}}
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                    </el-table-column>
                </template>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import axios from 'axios';
import { Component, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
@Component
export default class Log extends Mixins(Query) {
    formTitle = '操作日志';
    url = '/api/meta/system-log';
    exportUrl = '/api/meta/export/system-log';
    queryData = {
        staff_name: '',
        log_date: '',
        module: '',
    };
    actionMap = {
        insert: '新增',
        delete: '删除',
        update: '修改',
    };
    modules: any = {};
    columnItems: any = [
        { prop: 'staff_name', label: '操作人 ' },
        { prop: 'created_at', label: '操作时间' },
        { prop: 'module', label: '操作模块' },
        { prop: 'action', label: '操作类型' },
        { prop: 'remark', label: '备注' },
    ];
    mounted() {
        this.getModules();
    }
    getModules() {
        this.mixGet('/api/support/system-log-modules', null, { loading: false }).then(res => {
            this.modules = res.data.data;
        });
    }
}
</script>