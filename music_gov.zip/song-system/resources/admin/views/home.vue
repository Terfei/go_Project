<template>
    <div class="home">
        <Nav />
        <!-- <main class="main"> -->
        <keep-alive>
            <router-view v-if="$route.meta.keepAlive"></router-view>
        </keep-alive>
        <router-view v-if="!$route.meta.keepAlive"></router-view>
        <!-- </main> -->
    </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import Nav from '@components/nav.vue';
@Component({
    components: {
        Nav
    }
})
export default class Home extends Vue {
    mounted() {
        this.getSetting();
    }
    getSetting() {
        this.mixGet('/api/setting', null, { loading: false }).then(res => {
            let info = res.data.data;
            info.image_domain = `http://${info.oss_domain}/${info.oss_path}/`;
            this.$store.dispatch('settingInfoAct', info);
        });
    }
}
</script>
<style lang="scss" scoped>
.home {
    display: flex;
    height: 100vh;
    width: 100vw;
}
// .main {
//     flex: 1;
//     display: flex;
//     overflow: hidden;
// }
</style>
