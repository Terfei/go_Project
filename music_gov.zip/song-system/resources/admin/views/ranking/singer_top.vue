<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">歌星置顶列表</span>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <el-table
                :data="list"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <el-table-column
                    type="index"
                    label="排行"
                    width='100'
                >
                </el-table-column>
                <template v-for="item in columnItems">
                    <el-table-column
                        :key="item.prop"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                    </el-table-column>
                </template>
                <el-table-column
                    label="操作"
                    :width="list.length>0?140:''"
                >
                    <template v-slot="{row,$index}">
                        <SvgIcon
                            class="svg-icon table-opt"
                            :class="{'forbidden':$index == 0}"
                            propHref="up"
                            @click="setTop(row,$index)"
                        />
                        <SvgIcon
                            class="svg-icon table-opt"
                            :class="{'forbidden':$index == list.length - 1}"
                            propHref="down"
                            @click="setTop(row,$index,false)"
                        />
                        <SvgIcon
                            class="svg-icon table-opt"
                            propHref="cancel"
                            @click="cancelTop(row,$index)"
                        />
                    </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
@Component
export default class SingerTop extends Mixins(Query) {
    url = '/api/report/singer/top';
    columnItems: any = [
        { prop: 'singer_code', label: '歌星编号' },
        { prop: 'singer_name', label: '歌星名' },
        { prop: 'area_name', label: '区域' },
    ];
    setTop(row, index, isUp = true) {
        if ((index == 0 && isUp) || (index == this.list.length - 1 && !isUp)) {
            return;
        }
        let changeRow = isUp ? this.list[index - 1] : this.list[index + 1];
        let params = [
            { id: row.id, weight: changeRow.weight },
            { id: changeRow.id, weight: row.weight }
        ];
        this.mixPatch(this.url, { params }).then(res => {
            this.getList();
        });
    }
    cancelTop(row, index) {
        this.mixDelete(`${this.url}/${row.id}`).then(res => {
            this.$message.success('操作成功');
            this.list.splice(index, 1);
            this.getList();
        });
    }
}
</script>

<style lang="scss" scoped>
.svg-icon {
    font-size: 0.18rem;
    padding: 2px;
    &.forbidden {
        color: $c-grey-light;
        pointer-events: none;
    }
}
</style>