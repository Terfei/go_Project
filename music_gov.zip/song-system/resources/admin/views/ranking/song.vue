<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">{{formTitle}}</span>
            </div>
            <div class="title-right">
                <ImportButton>导入查询</ImportButton>
                <ExportButton @click="exportExcel()">导出</ExportButton>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">门店类型</label>
                    <SelectBiztype v-model="queryData.branch_biz_type" />
                </li>
                <li class="query-item">
                    <label class="label">门店</label>
                    <SelectBranch
                        :bizType="queryData.branch_biz_type"
                        v-model="queryData.branch_id"
                    />
                </li>
                <li class="query-item">
                    <label class="label">歌曲名</label>
                    <input
                        class="input"
                        type="text"
                        v-model="queryData.accompany_name"
                    >
                </li>
                <li class="query-item">
                    <label class="label">歌曲类型</label>
                    <el-select v-model="queryData.accompany_category">
                        <el-option
                            value=""
                            label="全部"
                        >
                        </el-option>
                        <el-option
                            v-for="item in categories"
                            :key="item.id"
                            :value="item.id"
                            :label="item.name"
                        ></el-option>
                    </el-select>
                </li>
                <li class="query-item">
                    <label class="label">日期</label>
                    <SearchDateRange
                        :begin_date.sync="queryData.begin_date"
                        :end_date.sync="queryData.end_date"
                    />
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <el-table-column
                    type="index"
                    label="排行"
                    width='100'
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop == 'is_top'"
                        :key="item.prop"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?120:''"
                    >
                        <template v-slot="{row}">
                            <SvgIcon
                                @click="setTop(row)"
                                v-if="!row.is_top"
                                class="svg-icon table-opt"
                                propHref="top"
                            />
                            <span v-else>已置顶</span>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >

                    </el-table-column>
                </template>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
@Component
export default class Song extends Mixins(Query) {
    formTitle = '歌曲排行';
    url = '/api/report/accompany/rank';
    exportUrl = '/api/report/export/accompany/rank';
    queryData = {
        branch_biz_type: '',
        branch_id: '',
        accompany_name: '',
        accompany_category: '',
        begin_date: '',
        end_date: '',
    };
    columnItems: any = [
        { prop: 'songno', label: '歌曲编号' },
        { prop: 'accompany_name', label: '歌曲名' },
        { prop: 'singer_name', label: '歌星名' },
        { prop: 'accompany_language', label: '语种' },
        { prop: 'accompany_category', label: '歌曲类型' },
        { prop: 'times', label: '点击数' },
        { prop: 'is_top', label: '是否置顶' },
    ];
    categories: Array<any> = [];
    mounted() {
        this.getCategory();
    }
    getCategory() {
        this.mixGet('/api/support/accompany/category', null, { loading: false }).then(res => {
            this.categories = res.data.data;
        });
    }
    setTop(row) {
        this.mixPost('/api/report/accompany-top', { accompany_id: row.accompany_id }).then(res => {
            this.$message.success('操作成功');
            this.getList();
        });
    }
}
</script>

<style lang="scss" scoped>
.svg-icon {
    font-size: 0.18rem;
    padding: 2px;
}
</style>