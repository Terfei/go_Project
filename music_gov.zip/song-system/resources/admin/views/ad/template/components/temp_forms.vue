<template>
    <div v-loading="loading">
        <el-form
            ref="form"
            :model="form"
            :rules="rules"
            label-width="80px"
        >
            <el-form-item
                label="模板编号"
                v-if="id"
            >
                <span>{{form.code}}</span>
            </el-form-item>
            <el-form-item
                label="模板名称"
                prop="title"
            >
                <el-input
                    class="form-input"
                    v-model="form.title"
                ></el-input>
            </el-form-item>
            <el-form-item
                label="图库类型"
                prop="category_id"
            >
                <SelectCategory
                    v-model="form.category_id"
                    :requireId='true'
                />
            </el-form-item>
            <el-form-item
                label="图片选择"
                prop="image_ids"
            >
                <div class="choose-image">
                    <div class="checked-images">
                        <div class="title">已选图片</div>
                        <div class="image-box">
                            <p
                                class="empty"
                                v-if="!choosedImages.length"
                            >暂无数据</p>
                            <div
                                v-for="(el,index) in choosedImages"
                                :key="'list'+index"
                                class="image-item"
                            >
                                <div class="img">
                                    <el-image
                                        :src="el.url"
                                        :lazy="true"
                                        :preview-src-list='[el.url]'
                                    >
                                    </el-image>
                                    <span
                                        class="delete-icon sub"
                                        @click="delImg(el,index)"
                                    ></span>
                                </div>
                                <span class="image-name">{{el.filename}}</span>
                            </div>
                        </div>
                    </div>
                    <div class="library-images">
                        <div class="title">
                            <span>云端图库</span>
                            <div class="search">
                                <SvgIcon propHref="search"></SvgIcon>
                                <input
                                    type="text"
                                    placeholder="请输入图片名称"
                                    v-model="keyword"
                                    @input="debounce()"
                                >
                            </div>
                        </div>
                        <div class="image-box">
                            <p
                                class="empty"
                                v-if="!cloundImages.length"
                            >暂无数据</p>
                            <div
                                v-for="(el,index) in cloundImages"
                                :key="'list'+index"
                                class="image-item"
                            >
                                <div
                                    class="img"
                                    :class="el.checked?'forbbiden':''"
                                >
                                    <el-image
                                        :src="el.url"
                                        :lazy="true"
                                        :preview-src-list='[el.url]'
                                    >
                                    </el-image>
                                    <span
                                        class="delete-icon add"
                                        v-if="!el.checked"
                                        @click="addImg(el)"
                                    ></span>
                                </div>
                                <span class="image-name">{{el.filename}}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </el-form-item>
        </el-form>
    </div>
</template>
<script lang="ts">
import { Component, Mixins, Prop, Watch } from 'vue-property-decorator';
import { Action, Getter } from 'vuex-class';
let validatePass: any = (rule, value, callback) => {
    if (!value.length) {
        callback(new Error('请至少选择一张图片'));
    } else {
        callback();
    }
};
@Component
export default class TempForms extends Mixins() {
    @Prop({
        default: ''
    })
    id: String;

    @Prop({
        default: ''
    })
    categoryId: String;

    @Prop({
        default: ''
    })
    type: String;

    @Getter settingInfo: any;
    keyword: any = '';
    loading: any = false;
    cloundImages: any = [];
    choosedImages: any = [];
    form: any = {
        code: '',
        title: '',
        category_id: '',
        image_ids: []
    };
    rules = {
        title: [
            {
                required: true,
                message: '请输入模板名',
                trigger: 'blur'
            }
        ],
        category_id: [
            {
                required: true,
                message: '请选择图库类型',
                trigger: 'change'
            }
        ],
        image_ids: [
            { required: true, validator: validatePass, trigger: 'change' }
        ]
    };

    debounce: any = () => { };

    @Watch('form.category_id')
    async changeCategory(val, oldVal) {
        if (!this.id) {
            this.choosedImages = [];
            await this.getImage();
        } else {
            if (oldVal && oldVal != val) {
                this.choosedImages = [];
                await this.getImage();
            }
        }
    }

    @Watch('choosedImages')
    changeChooseImages(val) {
        this.form.image_ids = this.choosedImages.map(x => x.id);
        (this.$refs.form as any).validateField('image_ids');
    }
    async created() {
        this.form.category_id = this.categoryId;
        await this.getImage();
        if (this.id) {
            this.init();
        }
    }
    mounted() {
        this.debounce = this.mixDebounce(this.getImage, 1000);
    }
    init() {
        this.loading = true;
        this.mixGet(`/api/image/template/${this.type}/${this.id}`, null, { loading: false }).then(res => {
            let info: any = res.data.data.list;
            this.form.code = info.code;
            this.form.title = info.title;
            this.form.image_ids = info.image_ids;
            for (let img of this.form.image_ids) {
                for (let el of this.cloundImages) {
                    if (img == el.id) {
                        el.checked = true;
                        this.choosedImages.push(el);
                    }
                }
            }
            this.loading = false;
        });
    }
    async getImage() {
        if (!this.form.category_id && !this.keyword) {
            return;
        }
        if (this.keyword && !this.form.category_id) {
            return this.$message({
                type: 'warning',
                message: '请选择图片类型!'
            });
        }
        let data: any = {
            category_id: this.form.category_id,
            title: this.keyword
        };
        await this.mixGet('/api/support/images', data, { loading: false }).then(res => {
            let list: any = res.data.data;
            if (list.length) {
                list.forEach(x => {
                    x.checked = false;
                    x.url = `http://${this.settingInfo.oss_domain}/${this.settingInfo.oss_ad}/${x.filename}`;
                });
            }
            this.cloundImages = list;
        });
    }
    addImg(el) {
        el.checked = true;
        this.choosedImages.push(el);

    }
    delImg(el, index) {
        this.choosedImages.splice(index, 1);
        for (let item of this.cloundImages) {
            if (item.id == el.id) {
                item.checked = false;
            }
        }
    }
}
</script>
<style lang="scss" scoped>
.choose-image {
    display: flex;
}
.checked-images {
    width: 5rem;
    height: 6rem;
    margin-right: 0.5rem;
    border: $border-dark;
    overflow: auto;
    display: flex;
    flex-direction: column;
}
.library-images {
    width: 8rem;
    height: 6rem;
    border: $border-dark;
    display: flex;
    flex-direction: column;
}
.title {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #3e3a38;
    color: $c-w;
    padding: 0 0.2rem;
}
.search {
    background: rgba(255, 255, 255, 0.25);
    height: 0.3rem;
    padding-left: 0.1rem;
    border-radius: 9999px;
    display: flex;
    align-items: center;
    input {
        background: transparent;
        border: none;
        height: 100%;
        padding: 0;
        color: $c-w;
        padding: 0 0.1rem;
    }
    input::-webkit-input-placeholder {
        color: $c-grey-white !important;
    }
}
.image-box {
    flex: 1;
    display: flex;
    flex-wrap: wrap;
    padding: 0.2rem;
    overflow: auto;
    .empty {
        margin: auto;
        color: $c-grey-deep;
    }
}
.image-item {
    display: flex;
    flex-direction: column;
    margin-right: 0.2rem;
    margin-bottom: 0.2rem;
    @at-root {
        .img {
            display: flex;
            margin-bottom: 0.1rem;
            position: relative;
            cursor: pointer;
            /deep/ .el-image {
                width: 1rem;
                height: calc(1rem * 1.7);
            }
            &.forbbiden {
                &:after {
                    content: "\3000";
                    background: rgba(255, 255, 255, 0.7);
                    position: absolute;
                    top: 0;
                    right: 0;
                    left: 0;
                    bottom: 0;
                    pointer-events: none;
                }
            }
            .add,
            .sub {
                transform: scale(0.65) rotate(45deg);
            }
            .sub {
                &::after {
                    display: none;
                }
            }
        }
    }
    .image-name {
        display: inline-block;
        max-width: 1rem;
        line-height: 1.5;
        word-break: break-all;
        white-space: pre-wrap;
    }
}
</style>