<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">门店模板</span>
                <span class="title">{{id?'编辑':'新增'}}</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-primary"
                    @click="save()"
                >保存</button>
                <button
                    class="btn button-default"
                    @click="$router.go(-1)"
                >返回</button>
            </div>
        </div>
        <div class="main-content">
            <TempForms
                ref="tempforms"
                :id="id"
                :categoryId='categoryId'
                type='branch'
            />
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Mixins, Prop } from 'vue-property-decorator';
import TempForms from '../components/temp_forms.vue';
@Component({
    components: {
        TempForms,
    },
})
export default class TemplateBranchEdit extends Mixins() {
    id: any = '';
    categoryId: any = '';
    created() {
        this.id = this.$route.query.id;
        this.categoryId = this.$route.query.category_id;
    }
    save() {
        let info: any = this.$refs.tempforms;
        info.$refs.form.validate((valid) => {
            if (!valid) {
                return false;
            } else {
                let data: any = {
                    category_id: parseInt(info.form.category_id),
                    title: info.form.title,
                    image_ids: info.form.image_ids
                };
                let url: any = this.id ? `/api/image/template/branch/${this.id}` : '/api/image/template/branch';
                let method: any = this.id ? 'mixPatch' : 'mixPost';
                this[method](url, data).then(res => {
                    this.$message({
                        type: 'success',
                        message: '保存成功！'
                    });
                    this.$router.go(-1);
                });
            }
        });
    }
}
</script>
