<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">总部模板</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-default btn-add-icon"
                    @click="mod()"
                >新增</button>
                <button
                    class="btn button-default"
                    @click="batchDelete()"
                >批量删除</button>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">模板编号</label>
                    <input
                        type="text"
                        class="input"
                        v-model="queryData.code"
                    >
                </li>
                <li class="query-item">
                    <label class="label">模板名称</label>
                    <input
                        type="text"
                        class="input"
                        v-model="queryData.title"
                    >
                </li>
                <li class="query-item">
                    <label class="label">图库类型</label>
                    <SelectCategory v-model="queryData.category_id" />
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query(true)"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="cpList"
                border
                height="300"
                stripe
                @selection-change="checkItem"
                v-loading="loading"
            >
                <el-table-column
                    fixed="left"
                    type="selection"
                    width="55"
                >
                </el-table-column>
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop == 'images'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            <div class="template-content">
                                <div
                                    v-for="img in row.imageList"
                                    class="template-content-item"
                                >

                                    <el-image
                                        class="table-img"
                                        :src="img.url"
                                        :preview-src-list="row.previewList"
                                    >
                                    </el-image>
                                    <p class="img-name">{{img.filename}}</p>
                                </div>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                    </el-table-column>
                </template>
                <el-table-column
                    label="操作"
                    :width="list.length>0?150:''"
                >
                    <template v-slot="{row}">
                        <span
                            class="table-opt"
                            @click="mod(row)"
                        >
                            编辑
                        </span>
                        <span
                            class="table-opt"
                            @click="batchDelete(row)"
                        >删除</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Mixins } from 'vue-property-decorator';
import { Action, Getter } from 'vuex-class';
import Query from '../../common/query';
@Component({})
export default class TemplateCenter extends Mixins(Query) {
    url = '/api/image/template/centre';
    deleteUrl = '/api/image/template/centre';
    queryData = {
        code: '',
        title: '',
        category_id: '',
    };
    columnItems: any = [
        { prop: 'code', label: '模板编号' },
        { prop: 'title', label: '模板名称' },
        { prop: 'category_title', label: '图库类型' },
        { prop: 'images', label: '模板内容', width: 340 }
    ];
    @Getter settingInfo: any;
    get cpList() {
        let list = this.list;
        for (let el of list) {
            el.category_title = el.category.title;
            el.previewList = [];
            el.imageList = [];
            if (el.images) {
                for (let img of el.images) {
                    let obj: any = {
                        url: `http://${this.settingInfo.oss_domain}/${this.settingInfo.oss_ad}/${img}`,
                        filename: img
                    };
                    el.previewList.push(`http://${this.settingInfo.oss_domain}/${this.settingInfo.oss_ad}/${img}`);
                    el.imageList.push(obj);
                }
            }
        }
        return list;
    }
    mod(info) {
        let query: any = {};
        if (info) {
            query.id = info.id;
            query.category_id = info.category_id;
        }
        this.$router.push({ path: '/ad/template/center/edit', query });
    }
}
</script>
<style lang="scss" scoped>
.template-content {
    display: flex;
    flex-wrap: wrap;
}
.template-content-item {
    display: flex;
    flex-direction: column;
    max-width: 1rem;
    margin-bottom: 5px;
    &:not(:last-child) {
        margin-right: 0.1rem;
    }
}
.table-img {
    margin-bottom: 5px;
}
.img-name {
    max-width: 0.8rem;
    line-height: 1.2;
}
</style>