<template>
    <el-cascader
        v-model="chose"
        :options="cpOptions"
        :props="props"
        clearable
        :show-all-levels="false"
        @change="handleChange"
        :disabled="!!disabled"
    ></el-cascader>
</template>
<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
@Component({})
export default class ApplyBranch extends Vue {
    @Prop({
        default: '',
    })
    value: any;

    @Prop({
        default: false,
        required: false,
    })
    disabled: boolean;

    chose: Array<any> = [];
    districts: Array<any> = [];
    branches: Array<any> = [];
    props = { multiple: true };

    get cpOptions() {
        let arr: Array<any> = [];
        for (let item of this.districts) {
            let district: any = {
                value: item.district_id,
                label: item.district_name,
                children: this.branches.filter(x => x.district_id === item.district_id).map(x => {
                    return {
                        value: x.branch_id,
                        label: x.branch_name,
                    };
                }),
            };
            if (!district.children.length) {
                district.disabled = true;
            }
            arr.push(district);
        }
        return arr;
    }

    @Watch('value', { immediate: true })
    onValueChanged(val) {
        if (!val) {
            this.chose = [];
        } else {
            let list: any = [];
            for (let el of this.value) {
                let item = this.branches.find(x => x.branch_id === el);
                if (item) {
                    list.push([item.district_id, el]);
                }
            }
            this.chose = list;
        }
    }

    mounted() {
        this.getDistricts();
        this.getBranches();
    }
    getDistricts() {
        return this.mixGet('/api/support/meta-district', null, { loading: false }).then(res => {
            this.districts = res.data.data;
        });
    }
    getBranches() {
        return this.mixGet('/api/support/branches', null, { loading: false }).then(res => {
            this.branches = res.data.data;
            // if (this.value.length) {
            //     for (let el of this.value) {
            //         let item = this.branches.find(x => x.branch_id === el);
            //         if (item) {
            //             this.chose.push([item.district_id, el]);
            //         }
            //     }
            //     console.log(this.chose);
            // }
        });
    }
    handleChange(value) {
        let list: any = [];
        for (let el of value) {
            if (el.length == 2) {
                list.push(el[1]);
            }
        }
        this.$emit('input', list);
    }
}
</script>