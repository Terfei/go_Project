<template>
    <div v-loading="loading">
        <el-form
            ref="form"
            :model="form"
            :rules="rules"
            label-width="80px"
        >
            <el-form-item
                label="应用时间"
                prop="begin_time"
            >
                <SearchDateTimeRange
                    :begin_date.sync="form.begin_time"
                    :end_date.sync="form.end_time"
                    :disabled_date="new Date().getTime()-24*60*60*1000"
                    :disabled="id?true:false"
                />
            </el-form-item>
            <el-form-item
                label="图库类型"
                prop="category_id"
            >
                <SelectCategory
                    :requireId='true'
                    v-model="form.category_id"
                    :disabled="id?true:false"
                />
            </el-form-item>
            <el-form-item
                label="应用门店"
                prop="branch_ids"
            >
                <ApplyBranch
                    v-model="form.branch_ids"
                    :disabled="id?true:false"
                />

            </el-form-item>
            <el-form-item label="备注">
                <el-input
                    type="textarea"
                    class="form-textarea"
                    v-model="form.remark"
                ></el-input>
            </el-form-item>
            <el-form-item
                label="广告模板"
                prop="template_id"
            >
                <p
                    v-if="!templateList.length"
                    class="tips"
                    :class="!form.category_id?'warning':''"
                >{{!form.category_id?'请先选择图库类型!':'暂无数据'}}</p>
                <div class="temps-ad">
                    <div
                        class="temp-item"
                        :class="el.checked?'checked':''"
                        v-for="el in templateList"
                        :key="el.id"
                    >
                        <p class="temp-name">
                            <el-checkbox
                                v-model="el.checked"
                                @change="chooseTemplate(el)"
                            >{{el.title}}</el-checkbox>
                        </p>
                        <div class="temp-imgs">
                            <div
                                class="img-box"
                                v-for="img in el.imageList"
                            >
                                <el-image
                                    class="img"
                                    :src="img.url"
                                    :preview-src-list="el.previewList"
                                    :lazy="true"
                                >
                                </el-image>
                                <span class="img-name">{{img.filename}}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </el-form-item>
        </el-form>
    </div>
</template>
<script lang="ts">
import { Component, Mixins, Prop, Watch } from 'vue-property-decorator';
import { Action, Getter } from 'vuex-class';
import ApplyBranch from './apply_branch.vue';
@Component({
    components: {
        ApplyBranch
    }
})
export default class ApplyForms extends Mixins() {
    @Prop({
        default: ''
    })
    id: String;

    @Prop({
        default: ''
    })
    categoryId: any;
    @Prop({
        default: ''
    })
    type: String;
    @Getter settingInfo: any;
    loading: any = false;
    form: any = {
        begin_time: '',
        end_time: '',
        category_id: '',
        branch_ids: [],
        remark: '',
        template_id: ''
    };
    rules = {
        begin_time: [
            {
                required: true,
                message: '请选择应用日期',
                trigger: 'blur'
            }
        ],
        category_id: [
            {
                required: true,
                message: '请选择图库类型',
                trigger: 'change'
            }
        ],
        branch_ids: [
            {
                type: 'array',
                required: true,
                message: '请选择应用门店',
                trigger: 'change'
            }
        ],
        template_id: [
            {
                required: true,
                message: '请选择广告模板',
                trigger: 'change'
            }
        ],
    };
    templateList = [];

    @Watch('form.category_id')
    async changeCategory(val, oldVal) {
        if (!this.id) {
            await this.getTemplates();
        } else {
            if (oldVal && oldVal != val) {
                await this.getTemplates();
            }
        }
    }


    async created() {
        this.form.category_id = this.categoryId;
        await this.getTemplates();
        if (this.id) {
            this.init();
        }
    }
    init() {
        this.loading = true;
        this.mixGet(`/api/image/template/${this.type}-plan/${this.id}`, null, { loading: false }).then(res => {
            let info: any = res.data.data.list;
            this.form.begin_time = info.begin_time;
            this.form.end_time = info.end_time;
            this.form.template_id = info.template_id;
            this.form.remark = info.remark;
            this.form.branch_ids = [info.branch_id];
            for (let el of this.templateList) {
                if (info.template_id == (el as any).id) {
                    (el as any).checked = true;
                }
            }
            this.loading = false;
        });
    }
    async getTemplates() {
        if (!this.form.category_id) {
            return;
        }
        await this.mixGet(`/api/support/${this.type}-templates`, { category_id: this.form.category_id }, { loading: false }).then(res => {
            let list = res.data.data;
            for (let el of list) {
                el.checked = false;
                el.previewList = [];
                el.imageList = [];
                for (let img of el.images) {
                    let obj: any = {
                        url: `http://${this.settingInfo.oss_domain}/${this.settingInfo.oss_ad}/${img}`,
                        filename: img
                    };
                    el.previewList.push(`http://${this.settingInfo.oss_domain}/${this.settingInfo.oss_ad}/${img}`);
                    el.imageList.push(obj);
                }
            }
            this.templateList = list;
        });
    }
    chooseTemplate(el) {
        this.templateList.forEach((x: any) => {
            if (x.id != el.id) {
                x.checked = false;
            }
        });
        this.form.template_id = el.checked ? el.id : '';
    }
}
</script>
<style lang="scss" scoped>
/deep/ .el-cascader {
    .el-input {
        width: 4rem;
        height: auto;
    }
}
/deep/ .el-select {
    .el-input {
        width: 4rem;
    }
}
.form-textarea {
    width: 4rem;
}
.temps-ad {
    display: flex;
    flex-wrap: wrap;
}
.temp-item {
    border: $border-dark;
    width: auto;
    // width: 2.8rem;
    min-width: 2.8rem;
    margin-right: 0.3rem;
    margin-bottom: 0.3rem;
    &.checked {
        border-color: var(--theme);
    }
}
.temp-name {
    background: #3e3a38;
    text-align: center;
    line-height: 0.3rem;
    /deep/ .el-checkbox {
        color: $c-w;
    }
}
.temp-imgs {
    display: flex;
    padding: 0.1rem;
}
.img-box {
    display: flex;
    flex-direction: column;
    &:not(:last-child) {
        margin-right: 0.1rem;
    }
    .img {
        width: 1rem;
        height: calc(1rem * 1.7);
        margin-bottom: 5px;
    }
    .img-name {
        display: inline-block;
        line-height: 1.2;
        max-width: 0.8rem;
        word-break: break-all;
        white-space: pre-wrap;
    }
}
.tips {
    color: $c-grey-deep;
    &.warning {
        color: var(--theme);
    }
}
</style>