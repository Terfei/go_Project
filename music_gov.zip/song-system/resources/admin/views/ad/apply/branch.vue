<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">门店模板应用</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-default btn-add-icon"
                    @click="mod()"
                >新增</button>
                <button
                    class="btn button-default"
                    @click="batchDelete()"
                >批量删除</button>
                <button
                    class="btn button-default"
                    @click="adopt()"
                >批量审核</button>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">门店类型</label>
                    <SelectBiztype v-model="queryData.branch_biz_type" />
                </li>
                <li class="query-item">
                    <label class="label">门店</label>
                    <SelectBranch
                        :bizType="queryData.branch_biz_type"
                        v-model="queryData.branch_id"
                    />
                </li>
                <li class="query-item">
                    <label class="label">图库类型</label>
                    <SelectCategory v-model="queryData.category_id" />
                </li>
                <li class="query-item">
                    <label class="label">状态</label>
                    <SelectStatus v-model="queryData.status" />
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="cpList"
                border
                height="300"
                stripe
                @selection-change="checkItem"
                v-loading="loading"
            >
                <el-table-column
                    fixed="left"
                    type="selection"
                    width="55"
                >
                </el-table-column>
                <el-table-column
                    type="index"
                    label="序号"
                    width='100'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop == 'images'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            <div class="template-content">
                                <div
                                    v-for="img in row.imageList"
                                    class="template-content-item"
                                >
                                    <el-image
                                        class="table-img"
                                        :src="img.url"
                                        :preview-src-list="row.previewList"
                                    >
                                    </el-image>
                                    <p class="img-name">{{img.filename}}</p>
                                </div>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop == 'statusStr'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                        <template v-slot="{row}">
                            <span>{{row.statusStr}}</span>
                            <p v-if="row.status == 'reject'">({{row.reject_explain}})</p>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                    </el-table-column>
                </template>
                <el-table-column
                    fixed="right"
                    label="操作"
                    :width="list.length>0?240:''"
                >
                    <template v-slot="{row}">
                        <span
                            class="table-opt"
                            @click="mod(row)"
                        >
                            编辑
                        </span>
                        <span
                            class="table-opt"
                            @click="batchDelete(row)"
                        >删除</span>
                        <span
                            class="table-opt"
                            @click="adopt(row)"
                            v-if="row.status == 'init'"
                        >
                            审核通过
                        </span>
                        <span
                            v-if="row.status == 'init'"
                            class="table-opt"
                            @click="reject(row)"
                        >
                            审核驳回
                        </span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Mixins } from 'vue-property-decorator';
import { Action, Getter } from 'vuex-class';
import Query from '../../common/query';
@Component
export default class ApplyCenter extends Mixins(Query) {
    @Getter settingInfo: any;
    url = '/api/image/template/branch-plan';
    deleteUrl = '/api/image/template/branch-plan';
    queryData = {
        branch_biz_type: '',
        branch_id: '',
        category_id: '',
        status: ''
    };
    statusMap = {
        'init': '待审核',
        'audit': '已审核待更新',
        'reject': '已驳回',
        'updated': '更新成功',
        'failed': '更新失败'
    };
    columnItems: any = [{
        prop: 'begin_time',
        label: '开始时间',
        width: 150,
    },
    {
        prop: 'end_time',
        label: '结束时间',
        width: 150,
    },
    {
        prop: 'category_title',
        label: '图库类型'
    },
    {
        prop: 'branch_name',
        label: '门店'
    },
    {
        prop: 'images',
        label: '广告图',
        width: 320
    },
    {
        prop: 'statusStr',
        label: '状态',
    },
    {
        prop: 'remark',
        label: '备注',
    }
    ];
    get cpList() {
        let list = this.list;
        for (let el of list) {
            el.category_title = el.category.title;
            el.previewList = [];
            el.imageList = [];
            el.statusStr = this.statusMap[el.status];
            if (el.template.images) {
                for (let img of el.template.images) {
                    let obj: any = {
                        url: `http://${this.settingInfo.oss_domain}/${this.settingInfo.oss_ad}/${img}`,
                        filename: img
                    };
                    el.previewList.push(`http://${this.settingInfo.oss_domain}/${this.settingInfo.oss_ad}/${img}`);
                    el.imageList.push(obj);
                }
            }
        }
        return list;
    }
    mod(info) {
        let query: any = {};
        if (info) {
            query.id = info.id;
            query.category_id = info.category_id;
        }
        this.$router.push({ path: '/ad/apply/branch/edit', query });
    }
    adopt(row) {
        if ((row && row.id) || this.checkedList.length > 0) {
            let msg = row && row.id ? '确定要审核通过该项吗?' : '确定要审核通过选中项吗?';
            this.$confirm(msg, '温馨提示', {
                type: 'warning'
            }).then(() => {
                let ids = (row && row.id && [row.id]) || this.checkedList.map(x => x.id);
                this.mixPatch('/api/image/template/branch-plan-audit', { ids }).then(res => {
                    this.$message.success('审核成功!');
                    this.getList();
                }).catch(() => {
                    this.$message.error('操作失败!');
                });
            });

        }
        else {
            this.$message.warning('请至少选择一项，再进行审核操作!');
        }

    }
    reject(row) {
        this.$prompt('请填写驳回原因', '审核驳回', {
            inputPattern: /^.+$/,
            inputErrorMessage: '驳回原因不能为空',
            inputType: 'textarea'
        }).then(({ value }: any) => {
            this.mixPatch(`/api/image/template/branch-plan/${row.id}/reject`, { reject_explain: value }).then(res => {
                this.$message.success('驳回成功!');
                this.getList();
            });
        });
    }
}
</script>
<style lang="scss" scoped>
.template-content {
    display: flex;
}
.template-content-item {
    display: flex;
    flex-direction: column;
    margin-bottom: 5px;
    &:not(:last-child) {
        margin-right: 0.1rem;
    }
}
.table-img {
    margin-bottom: 5px;
}
.img-name {
    max-width: 0.8rem;
    line-height: 1.2;
}
</style>