<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">门店模板应用</span>
                <span class="title">{{id?'编辑':'新增'}}</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-primary"
                    @click="save()"
                >保存</button>
                <button
                    class="btn button-default"
                    @click="$router.go(-1)"
                >返回</button>
            </div>
        </div>
        <div class="main-content">
            <ApplyForms
                ref="applyforms"
                :id="id"
                :categoryId='categoryId'
                type='branch'
            />
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Mixins, Prop } from 'vue-property-decorator';
import ApplyForms from '../components/apply_forms.vue';
@Component({
    components: {
        ApplyForms,
    },
})
export default class ApplyCenterEdit extends Mixins() {
    id: any = '';
    categoryId: any = '';
    created() {
        this.id = this.$route.query.id;
        this.categoryId = this.$route.query.category_id;
    }
    save() {
        let info: any = this.$refs.applyforms;
        info.$refs.form.validate((valid) => {
            if (!valid) {
                return false;
            } else {
                let data: any = {
                    begin_time: info.form.begin_time,
                    end_time: info.form.end_time,
                    branch_ids: info.form.branch_ids,
                    template_id: info.form.template_id,
                    category_id: parseInt(info.form.category_id),
                    remark: info.form.remark,
                };
                let url: any = this.id ? `/api/image/template/branch-plan/${this.id}` : '/api/image/template/branch-plan';
                let method: any = this.id ? 'mixPatch' : 'mixPost';
                this[method](url, data).then(res => {
                    this.$message({
                        type: 'success',
                        message: '保存成功！'
                    });
                    this.$router.go(-1);
                });
            }
        });
    }
}
</script>
