<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">图库管理</span>
            </div>
            <div class="title-right">
                <button
                    class="btn button-primary"
                    @click="openUpload()"
                >
                    <SvgIcon
                        class="upload-icon"
                        propHref="upload"
                    ></SvgIcon>
                    上传
                </button>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">图库类型</label>
                    <SelectCategory v-model="queryData.category_id" />
                </li>
                <li class="query-item">
                    <label class="label">图片名称</label>
                    <el-input
                        class="input"
                        v-model="queryData.filename"
                    />
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <ul
                class="img-ul"
                v-loading="loading"
            >
                <li
                    class="img-li"
                    v-for="item in list"
                    :key="item.filename"
                    @click="previewImage(item)"
                >
                    <div class="proportion-container">
                        <div class="proportion-size">
                            <img
                                @error="mixImgError"
                                class="proportion-element"
                                :src="`http://${settingInfo.oss_domain}/${settingInfo.oss_ad}/${item.filename}`"
                                alt=""
                            >
                        </div>
                    </div>
                    <p class="name">{{item.filename}}</p>
                </li>
                <div
                    class="empty-tips"
                    v-if="!list || !list.length"
                >暂无数据</div>
            </ul>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
        <UploadDialog
            :categories="categories"
            ref="uploadDialog"
        />
        <div
            class="preview-mask"
            v-if="showPreview"
        >
            <div class="image-container">
                <img
                    class="preview-image"
                    @error="mixImgError"
                    :src="`http://${settingInfo.oss_domain}/${settingInfo.oss_ad}/${currItem.filename}`"
                >
            </div>
            <div class="opt-wrap">
                <SvgIcon
                    @click="closePreview"
                    class="icon"
                    propHref="close"
                ></SvgIcon>
                <SvgIcon
                    @click="deleteImage"
                    class="icon"
                    propHref="trash"
                ></SvgIcon>
            </div>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
import { Action, Getter } from 'vuex-class';
import * as utility from 'utility';
import Query from '../common/query';
import UploadDialog from './components/upload_dialog.vue';
@Component({
    components: {
        UploadDialog,
    },
})
export default class Images extends Mixins(Query) {
    @Getter settingInfo: any;
    url = '/api/image/images';
    queryData = {
        category_id: '',
        filename: '',
    };
    categories: Array<any> = [];
    currItem: any = null;
    showPreview = false;
    mounted() {
        this.getCategory();
    }
    getCategory() {
        this.mixGet('/api/support/image/category', null, { loading: false }).then(res => {
            this.categories = res.data.data;
        });
    }
    // getNames(name) {
    //     name = name.replace(/^\/+/, '');
    //     name = utility.encodeURIComponent(name).replace(/%2F/g, '/').replace(/\+/g, '%2B');
    //     return name;
    // }
    openUpload() {
        (this.$refs as any).uploadDialog.open(() => {
            this.getList();
        });
    }
    previewImage(item) {
        this.showPreview = true;
        this.currItem = item;
    }
    closePreview() {
        this.showPreview = false;
        this.currItem = null;
    }
    deleteImage() {
        this.$confirm('删除图片将会影响使用该图片的模板，确定删除?', '温馨提示', {
            type: 'warning'
        }).then(() => {
            this.mixDelete(`/api/image/images/${this.currItem.id}`).then(res => {
                this.$message.success('删除成功!');
                this.showPreview = false;
                this.getList();
            });
        });
    }
}
</script>
<style lang="scss" scoped>
.upload-icon {
    font-size: 0.16rem;
    margin-top: 2px;
    margin-right: 2px;
}
.img-ul {
    min-height: 5rem;
    display: flex;
    flex-wrap: wrap;
    margin-bottom: -0.15rem;
    margin-right: -0.15rem;
    @at-root {
        .empty-tips {
            margin: auto;
            color: $c-grey;
        }
        .img-li {
            margin: 0 0.15rem 0.15rem 0;
            width: 1.4rem;
            cursor: pointer;
            .proportion-size {
                padding-bottom: 177%; //1080:1920
            }
            .name {
                text-align: center;
                line-height: 2;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                margin-top: 2px;
            }
        }
    }
}
.preview-mask {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    display: flex;
    background: rgba(0, 0, 0, 0.7);
    .close {
        position: absolute;
        right: 0.4rem;
        top: 0.4rem;
        color: $c-w;
        font-size: 40px; // 跟element-ui保持一致
        opacity: 0.8; // 跟element-ui保持一致
    }
    .opt-wrap {
        position: absolute;
        right: 0.2rem;
        top: 0.4rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        min-height: 1.5rem;
        width: 0.44rem;
        padding: 0 0.23rem;
        background-color: #606266;
        transform: translateX(-50%);
        border-radius: 9999px;
        color: $c-w;
        z-index: 1;
        opacity: 0.8; // 跟element-ui保持一致
        svg {
            margin: 0.15rem 0;
            cursor: pointer;
        }
    }
    .icon {
        font-size: 0.23rem;
    }
    @at-root {
        .image-container {
            margin: auto;
        }
        .preview-image {
            max-width: 100vw;
            max-height: 100vh;
            width: initial;
            height: initial;
        }
    }
}
</style>