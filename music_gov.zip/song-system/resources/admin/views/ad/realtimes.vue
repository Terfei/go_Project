<template>
    <div class="main-container">
        <!-- 头部 -->
        <div class="main-title">
            <div class="title-left">
                <span class="title">{{formTitle}}</span>
            </div>
            <div class="title-right">
                <ExportButton @click="exportExcel()">导出</ExportButton>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="main-content">
            <!-- 查询区域 -->
            <ul class="query-container">
                <li class="query-item">
                    <label class="label">门店类型</label>
                    <SelectBiztype v-model="queryData.branch_biz_type" />
                </li>
                <li class="query-item">
                    <label class="label">门店</label>
                    <SelectBranch
                        :bizType="queryData.branch_biz_type"
                        v-model="queryData.branch_id"
                    />
                </li>
                <li class="query-item">
                    <label class="label">图库类型</label>
                    <SelectCategory v-model="queryData.category_id" />
                </li>
                <li class="query-btns">
                    <Throttle
                        class="btn button-primary"
                        @click="query"
                    >查询</Throttle>
                    <button
                        class="btn button-default"
                        @click="clearQuery"
                    >清空</button>
                </li>
            </ul>
            <el-table
                :data="list"
                border
                height="300"
                stripe
                v-loading="loading"
            >
                <el-table-column
                    type="index"
                    label="序号"
                    width='80'
                    :index="computedIndex"
                >
                </el-table-column>
                <template v-for="(item,index) in columnItems">
                    <el-table-column
                        v-if="item.prop === 'category'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length > 0 ? item.width:''"
                    >
                        <template v-slot="{ row }">{{row.category && row.category.title}}</template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop === 'center_template'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length > 0 ? item.width:''"
                    >
                        <template v-slot="{row}">
                            <div
                                class="template-content"
                                v-if="row.center_template && row.center_template.images"
                            >
                                <div
                                    v-for="name in row.center_template.images"
                                    :key="name"
                                    class="template-content-item"
                                >
                                    <el-image
                                        class="table-img"
                                        :src="`http://${settingInfo.oss_domain}/${settingInfo.oss_ad}/${name}`"
                                        :preview-src-list="getPreviewList(row.center_template.images)"
                                    >
                                    </el-image>
                                    <p class="img-name">{{name}}</p>
                                </div>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop === 'center_plan'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length > 0 ? item.width:''"
                    >
                        <template v-slot="{ row }">
                            <div
                                class="table-time"
                                v-if="row.center_plan"
                            >
                                <p>{{row.center_plan.begin_time}}</p>
                                <p>至</p>
                                <p>{{row.center_plan.end_time}}</p>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop === 'branch_template'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length > 0 ? item.width:''"
                    >
                        <template v-slot="{row}">
                            <div
                                class="template-content"
                                v-if="row.branch_template && row.branch_template.images"
                            >
                                <div
                                    v-for="name in row.branch_template.images"
                                    :key="name"
                                    class="template-content-item"
                                >
                                    <el-image
                                        class="table-img"
                                        :src="`http://${settingInfo.oss_domain}/${settingInfo.oss_ad}/${name}`"
                                        :preview-src-list="getPreviewList(row.branch_template.images)"
                                    >
                                    </el-image>
                                    <p class="img-name">{{name}}</p>
                                </div>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else-if="item.prop === 'branch_plan'"
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length > 0 ? item.width:''"
                    >
                        <template v-slot="{ row }">
                            <div
                                class="table-time"
                                v-if="row.branch_plan"
                            >
                                <p>{{row.branch_plan.begin_time}}</p>
                                <p>至</p>
                                <p>{{row.branch_plan.end_time}}</p>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                        v-else
                        :key="item.prop + index"
                        :prop="item.prop"
                        :label="item.label"
                        :width="list.length>0?item.width:''"
                    >
                    </el-table-column>
                </template>
            </el-table>
        </div>
        <div class="main-footer">
            <Pagination
                :pagination="pagination"
                @click="paginationChange"
            >
            </Pagination>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
import Query from '../common/query';
import { Action, Getter } from 'vuex-class';
@Component({
    components: {
    },
})
export default class Realtimes extends Mixins(Query) {
    @Getter settingInfo: any;
    formTitle = '实时广告';
    url = '/api/image/current-ads';
    exportUrl: any = '/api/image/current-ads/export';
    queryData = {
        branch_biz_type: '',
        branch_id: '',
        category_id: '',

    };
    columnItems: any = [
        { prop: 'branch_name', label: '门店', },
        { prop: 'category', label: '图库类型', },
        { prop: 'center_template', label: '总部指定广告', width: 300 },
        { prop: 'center_plan', label: '总部应用时间', },
        { prop: 'branch_template', label: '门店自选广告', width: 300 },
        { prop: 'branch_plan', label: '门店应用时间', },

    ];
    getPreviewList(list) {
        return list.map(x => `http://${this.settingInfo.oss_domain}/${this.settingInfo.oss_ad}/${x}`);
    }
}
</script>
<style lang="scss" scoped>
.template-content {
    display: flex;
    flex-wrap: wrap;
}
.template-content-item {
    display: flex;
    flex-direction: column;
    max-width: 1rem;
    margin-bottom: 5px;
    &:not(:last-child) {
        margin-right: 0.1rem;
    }
}
.table-img {
    margin-bottom: 5px;
}
.img-name {
    max-width: 0.8rem;
    line-height: 1.2;
}
.table-time {
    display: inline-block;
    text-align: center;
}
</style>