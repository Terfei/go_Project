<template>
    <el-dialog
        title="上传图片"
        :visible.sync="show"
        :close-on-click-modal="false"
        custom-class="dialog-box-middle"
    >
        <el-form
            ref="form"
            :model="info"
            :rules="rules"
            label-width="80px"
            v-if="show"
        >
            <el-form-item
                label="图库类型"
                prop="category_id"
            >
                <el-select
                    v-model="info.category_id"
                    @change="changeType()"
                >
                    <el-option
                        v-for="(item, index) in categories"
                        :key="'categories' + index"
                        :value="item.id"
                        :label="item.title"
                    ></el-option>
                </el-select>
                <span class="tips">图片分辨率：{{currCategory.width}}像素&nbsp;*&nbsp;{{currCategory.height}}像素</span>
            </el-form-item>
            <el-form-item
                label="选择图片"
                prop="image"
            >
                <div
                    class="upload-box"
                    :class="info.image?'':'has-border'"
                >
                    <input
                        type="file"
                        accept="image/*"
                        @change="imgChange"
                    >
                    <img
                        :src="info.image"
                        alt=""
                        v-if="info.image"
                    >
                </div>
            </el-form-item>
            <el-form-item
                label="图片名称"
                prop="filename"
            >
                <el-input
                    class="form-input"
                    v-model="info.filename"
                ></el-input>
            </el-form-item>
        </el-form>
        <div
            slot="footer"
            class="dialog-footer"
        >
            <el-button @click="show = false">取消</el-button>
            <el-button
                type="primary"
                @click="onSubmit"
            >确定</el-button>
        </div>
    </el-dialog>
</template>
<script lang="ts">

import { Component, Mixins, Prop, Watch } from 'vue-property-decorator';
import { Action, Getter } from 'vuex-class';
import OSS from 'ali-oss';

@Component
export default class UploadDialog extends Mixins() {
    @Prop({
        default() {
            return [];
        }
    })
    categories: any;

    @Getter settingInfo: any;

    show = false;
    info: any = {
        category_id: '',
        filename: '',
        image: '',
    };
    rules = {
        filename: [
            { required: true, message: '图片名称不可为空', trigger: 'blur' },
        ],
        image: [
            { required: true, message: '图片不可为空', },
        ],
        category_id: [
            { required: true, message: '类型不可为空', trigger: 'blur' },
        ],
    };
    callback: any = null;
    file: any = null;
    currCategory: any = {};
    @Watch('info.category_id')
    onCategoryIdChange(val) {
        this.currCategory = this.categories.find(x => x.id == val);
    }
    mounted() {

    }

    open(callback) {
        this.info = {
            filename: '',
            image: '',
            category_id: this.categories[0] && this.categories[0].id,
        };
        this.callback = callback;
        this.show = true;
        this.$nextTick(() => {
            (this.$refs.form as any).resetFields();
        });
    }
    imgChange(e) {
        let file = e.target.files[0];
        e.target.value = '';
        // if (!file) {
        //     return;
        // }
        // console.log(file);
        // this.info.filename = file.name;
        // this.file = file;
        const URL = window.URL || window.webkitURL;
        let img = new Image();
        img.onload = () => {
            if (this.currCategory.width != img.width || this.currCategory.height != img.height || !file) {
                return this.$message({ message: `请上传${this.currCategory.width}像素 * ${this.currCategory.height}像素的图片`, type: 'error' });
            }
            else {
                this.info.filename = file.name;
                this.file = file;
                this.info.image = URL.createObjectURL(file);
            }
        };
        img.src = URL.createObjectURL(file);
        // let fileReader = new FileReader();
        // fileReader.onloadend = () => {
        //     if (fileReader.readyState == fileReader.DONE) {
        //         this.info.image = fileReader.result;
        //     }
        // };
        // fileReader.readAsDataURL(file);
    }
    changeType() {
        this.info.image = '';
        this.info.filename = '';
    }
    onSubmit() {
        if (!this.file) {
            return this.$message({ message: '请选择图片', type: 'error' });
        }
        (this.$refs.form as any).validate(async (valid) => {
            if (!valid) {
                return;
            }
            let { data: { data: { count } } } = await this.mixGet('/api/image/search-count', { filename: this.info.filename });
            if (count > 0) {
                this.$confirm('该图片名已存在，如要覆盖原图请将系统里原图片删除，如不覆盖原图请重命名。', '温馨提示', {
                    type: 'warning'
                });
                return;
            }
            this.save();
        });
    }

    async save() {
        if (!/^[\u4E00-\u9FA5A-Za-z0-9_.-]+$/.test(this.info.filename)) {
            return this.$message({ message: `图片名称不能包含特殊字符！`, type: 'error' });
        }
        await this.uploadFile(this.file);
        await this.mixPost('/api/image/images', { category_id: this.info.category_id, filename: this.info.filename });
        this.$message({ message: '保存成功', type: 'success' });
        this.callback && this.callback();
        this.show = false;
    }
    uploadFile(file) {
        return new Promise(async (resolve, reject) => {
            let ossConfig: any = {};
            try {
                let { data: { data: config } } = await this.mixGet('/api/support/aliyun/sts-token');
                ossConfig = config;
            } catch (err) {
                reject(err);
                return;
            }
            let client = new OSS({
                region: ossConfig.region,
                accessKeyId: ossConfig.access_key_id,
                accessKeySecret: ossConfig.access_key_secret,
                bucket: ossConfig.bucket,
            });
            // this.mixShowLoading('文件上传中...');
            client.put(`${this.settingInfo.oss_ad}/${this.info.filename}`, file, {
                headers: {
                    'x-oss-security-token': ossConfig.sts_token,
                }
            }).then(res => {
                // this.mixHideLoading();
                let info = res;
                console.log(`http://${ossConfig.domain}/${this.settingInfo.oss_ad}/${this.info.filename}`);
                resolve(info);
            }).catch(res => {
                console.log(res);
                // this.mixHideLoading();
                // this.$message.warning(`上传失败`);
                this.$message({ message: '上传失败', type: 'error' });
                reject(res);
            });

        });
    }
}
</script>
<style lang="scss" scoped>
.upload-box {
    width: 2rem;
    height: 2.5rem;
    position: relative;
    border-radius: 0.04rem;
    outline: 1px dashed $c-bd-dark;
    outline-offset: -0.1rem;
    cursor: pointer;
    overflow: hidden;
    &.has-border {
        border: $border-dark;
    }
    &::before,
    &::after {
        content: "";
        color: #ddd;
        position: absolute;
        display: inline-block;
        left: 50%;
        top: 50%;
        width: 35%;
        height: 2px;
        background-color: currentColor;
        margin-top: -1px;
        z-index: 0;
    }
    &::before {
        transform: translateX(-50%) rotate(180deg);
    }
    &::after {
        transform: translateX(-50%) rotate(90deg);
    }
    &:hover {
        border-color: var(--theme);
        outline-color: var(--theme);
    }
    &:hover::before,
    &:hover::after {
        color: var(--theme);
    }
    input,
    img {
        position: absolute;
        z-index: 1;
    }
    input {
        width: 100%;
        height: 100%;
        z-index: 2;
        opacity: 0;
    }
}
.tips {
    margin-left: 0.1rem;
}
</style>