<template>
    <el-dialog
        :title="currItem.id?'编辑':'新增' "
        :visible.sync="isShow"
        :close-on-click-modal="false"
        custom-class="dialog-box-middle"
        @close="close()"
    >
        <el-form
            ref="form"
            :model="currItem"
            :rules="rules"
            label-width="85px"
            v-if="isShow"
        >
            <el-form-item
                label="编号"
                v-if="currItem.id"
            >
                <el-input
                    disabled
                    class="form-input"
                    v-model="currItem.id"
                ></el-input>
            </el-form-item>
            <el-form-item
                label="名称"
                prop="title"
            >
                <el-input
                    class="form-input"
                    v-model="currItem.title"
                ></el-input>
            </el-form-item>
            <el-form-item
                label="宽度"
                prop="width"
            >
                <el-input
                    class="form-input"
                    v-model="currItem.width"
                    :disabled="currItem.id ? true:false"
                > <i
                        slot="suffix"
                        style="font-style:normal;margin-right: 5px;"
                    >像素</i></el-input>
            </el-form-item>
            <el-form-item
                label="高度"
                prop="height"
            >
                <el-input
                    class="form-input"
                    v-model="currItem.height"
                    :disabled="currItem.id ? true:false"
                ><i
                        slot="suffix"
                        style="font-style:normal;margin-right: 5px;"
                    >像素</i></el-input>
            </el-form-item>
            <el-form-item
                label="存储路径"
                prop="disk"
            >
                <el-input
                    class="form-input"
                    v-model="currItem.disk"
                ></el-input>
            </el-form-item>
        </el-form>
        <div
            slot="footer"
            class="dialog-footer"
        >
            <el-button @click="close()">取消</el-button>
            <el-button
                type="primary"
                @click="onSubmit"
            >确定</el-button>
        </div>
    </el-dialog>
</template>
<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator';
@Component
export default class ImageTypesEdit extends Mixins() {
    isShow: Boolean = false;
    currItem: any = {
        title: '',
        width: '',
        height: '',
        id: '',
        disk: '',
    };
    callback: any = null;
    rules: any = {
        id: [
            {
                required: true, message: '请输入编号', trigger: 'blur'
            }
        ],
        title: [
            {
                required: true, message: '请输入名称', trigger: 'blur'
            }
        ],
        width: [
            {
                required: true, validator: (rule, value, callback) => {
                    if (value === '') {
                        callback(new Error('请输入宽度'));
                    }
                    else if (isNaN(value)) {
                        callback(new Error('请输入数值'));
                    }
                    else {
                        callback();
                    }
                }, trigger: 'blur'
            }
        ],
        height: [
            {
                required: true, validator: (rule, value, callback) => {
                    if (value === '') {
                        callback(new Error('请输入高度'));
                    }
                    else if (isNaN(value)) {
                        callback(new Error('请输入数值'));
                    }
                    else {
                        callback();
                    }
                }, trigger: 'blur'
            }
        ],
        disk: [
            {
                required: true, message: '请输入路径', trigger: 'blur'
            }
        ],
    };
    mounted() {

    }
    close() {
        this.currItem = {
            disk: '',
            title: '',
            width: '',
            height: '',
            id: '',
        };
        this.isShow = false;
    }
    open(item, callback) {
        this.currItem = Object.assign({
            disk: '',
            title: '',
            width: '',
            height: '',
            id: '',
        }, item || {});
        this.callback = callback;
        this.isShow = true;
    }
    onSubmit() {
        (this.$refs.form as any).validate((valid) => {
            if (valid) {
                this.sure();
            } else {
                return false;
            }
        });
    }
    sure() {
        let url = `/api/image/category`;
        let method = this.mixPost;
        if (this.currItem.id) {
            url = `${url}/${this.currItem.id}`;
            method = this.mixPatch;
        }
        method(url, {
            disk: this.currItem.disk,
            title: this.currItem.title,
            width: Number(this.currItem.width),
            height: Number(this.currItem.height)
        }).then(res => {
            this.$message({
                type: 'success',
                message: `${this.currItem.id ? '编辑' : '新增'}成功!`
            });
            this.close();
            this.callback && this.callback();
        });

    }
}
</script>
<style lang="scss" scoped>
</style>