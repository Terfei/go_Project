<template>
    <div id="app">
        <router-view></router-view>
        <LoadingTips />
    </div>
</template>

<style lang="scss">
</style>
