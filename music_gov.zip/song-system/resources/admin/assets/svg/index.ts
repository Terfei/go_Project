const req = require.context('.', true, /\.svg$/);
const reqAll = requireContext => requireContext.keys().map(requireContext);
reqAll(req);
