
import Vue from 'vue';
import VueRouter from 'vue-router';
import Login from '@views/login.vue';
import Home from '@views/home.vue';
// import Error from '@views/error.vue';
import Default from '@views/default.vue';

Vue.use(VueRouter);

const requireComponent = require.context(
    // 其组件目录的相对路径
    '../views',
    // 是否查询其子目录
    true,
    // 匹配基础组件文件名的正则表达式
    /\w+\.vue$/,
    // /[A-Z]\w+\.vue$/
    'lazy'
);

const routes = requireComponent.keys().map(fileName => {
    // 获取组件配置
    // const component = requireComponent(fileName);
    const componentName = fileName.replace(/^\.\/(.*)\.\w+$/, '$1').replace(/_/g, '');
    // console.log(fileName);
    // console.log(componentName);
    // if (componentName.split('/').length > 1) {
    //     let meta = {};
    //     if (component.default.methods && component.default.methods.getRouterInfo) {
    //         meta = component.default.methods.getRouterInfo();
    //     }
    if (componentName.includes('components')) {
        return null;
    }
    let name = componentName.replace(/\//, '-').toLowerCase();
    return {
        path: `/${componentName.toLowerCase()}`,
        name,
        component: () => import(
            /* webpackChunkName: 'chunk' */
            `../views${fileName.substr(1)}`),
        // component: component.default,
        // meta: {},
    };
    // }
}).filter(x => !!x);

let childRoutes: any = [
    {
        path: '/',
        component: Default,
    },
    ...routes,
];
let router = new VueRouter({
    mode: process.env.NODE_ENV === 'development' ? 'hash' : 'history',
    routes: [
        {
            path: '/',
            component: Login,
        },
        // {
        //     path: '/home',
        //     component: Home,
        //     children: childRoutes,
        // },
        // {
        //     path: '*',
        //     component: Error,
        // },
    ],
});

const asyncRouterConfig = {
    path: '/home',
    component: Home,
    children: childRoutes,
};
export {
    router,
    asyncRouterConfig,
};
