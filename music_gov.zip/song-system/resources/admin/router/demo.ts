export default [
    {
        // 测试
        path: '/demo/h5demo',
        meta: {
            keepAlive: true,
        },
        component: () => import('@views/demo/h5_demo.vue'),
    }
];