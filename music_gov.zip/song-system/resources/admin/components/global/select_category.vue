<template>
    <div>
        <el-select
            v-model="chose"
            @change="handleChange"
            :disabled="!!disabled"
        >
            <el-option
                value=""
                label="全部"
                v-if="!requireId"
            >
            </el-option>
            <el-option
                v-for="(el, key) in categories"
                :key="'categories' + key"
                :label="el.title"
                :value="el.id"
            ></el-option>
        </el-select>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
@Component({})
export default class SelectCategory extends Vue {
    @Prop({
        default: '',
    })
    value: any;

    @Prop({
        default: false,
        required: false,
    })
    disabled: boolean;

    @Prop({
        default: false,
        required: false,
    })
    requireId: boolean;

    categories: any = {};
    chose: any = '';

    @Watch('value')
    onValueChanged(val) {
        if (!val) {
            this.chose = '';
        }
    }

    mounted() {
        this.getCategory();
    }
    getCategory() {
        this.mixGet('/api/support/image/category', null, { loading: false }).then(res => {
            this.categories = res.data.data;
            this.chose = this.value ? parseInt(this.value) : '';
        });
    }
    handleChange(value) {
        this.$emit('input', value);

    }
}
</script>