<template>
    <el-dialog
        title="查看大图"
        :visible.sync="show"
        :close-on-click-modal="false"
        custom-class="dialog-box-middle"
    >
        <!-- <div
            class="proportion-container"
            v-if="show"
        > -->
        <!-- <div class="proportion-size">
                <img
                    class="proportion-element"
                    loading="lazy"
                    :src="imgUrl"
                    @error="mixImgError"
                >
            </div> -->
        <el-carousel
            trigger="click"
            :autoplay="false"
            arrow="always"
        >
            <el-carousel-item
                v-for="img in imgList"
                :key="img"
            >
                <div class="proportion-container">
                    <div class="proportion-size">
                        <img
                            class="proportion-element"
                            loading="lazy"
                            :src="img"
                            @error="mixImgError"
                        >
                    </div>
                </div>
            </el-carousel-item>
        </el-carousel>
    </el-dialog>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
@Component
export default class ViewImg extends Vue {
    show = false;
    imgList = [];
    open(list) {
        console.log(list);
        this.imgList = list;
        this.show = true;
    }
}
</script>
<style lang="scss" scoped>
/deep/ .el-carousel__item {
    color: red;
}
</style>