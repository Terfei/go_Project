<template>
    <div
        class="radio"
        @click="changeVal()"
    >
        <input
            ref="radio"
            type="radio"
            :value="label"
            v-model="model"
            @change="handleChange"
            :disabled="isDisabled"
        >
        <label class="radio-label">
            <slot></slot>
        </label>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Mixins, Prop } from 'vue-property-decorator';
@Component({})
export default class Radio extends Vue {
    @Prop() value;
    @Prop() label;
    @Prop({
        default: false
    })
    disabled: Boolean;
    get model() {
        return this.value;
    }
    set model(val) {
        this.$emit('input', val);
        this.$refs.radio && ((this.$refs.radio as any).checked = this.value === this.label);
    }
    get isDisabled() {
        return this.disabled;
    }
    handleChange() {
        this.$nextTick(() => {
            this.$emit('change', this.model);
        });
    }
    changeVal() {
        if (this.isDisabled !== false) {
            return;
        } else {
            this.model = this.label;
        }
    }
}
</script>