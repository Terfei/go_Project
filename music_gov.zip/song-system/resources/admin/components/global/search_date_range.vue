<template>
    <div>
        <el-date-picker
            v-model="dateArr"
            type="daterange"
            format="yyyy-MM-dd"
            value-format="yyyy-MM-dd"
            range-separator="~"
            :picker-options="pickerOptions"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            @change="changeHanlder"
        />
    </div>
</template>
<script lang="ts">

import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
@Component
export default class SearchDateRange extends Vue {
    pickerOptions = {
        shortcuts: [{
            text: '最近3天',
            onClick(picker: any) {
                const end = new Date();
                const start = new Date();
                start.setTime(start.getTime() - 3600 * 1000 * 24 * 2);
                picker.$emit('pick', [start, end]);
            }
        }, {
            text: '最近7天',
            onClick(picker: any) {
                const end = new Date();
                const start = new Date();
                start.setTime(start.getTime() - 3600 * 1000 * 24 * 6);
                picker.$emit('pick', [start, end]);
            }
        }, {
            text: '最近30天',
            onClick(picker: any) {
                const end = new Date();
                const start = new Date();
                start.setTime(start.getTime() - 3600 * 1000 * 24 * 29);
                picker.$emit('pick', [start, end]);
            }
        }]
    };
    dateArr: Array<string> = [];
    @Prop() begin_date;
    @Prop() end_date;
    @Prop({
        default() {
            return [];
        }
    })
    date_range;
    @Watch('begin_date', { immediate: true })
    onBeginDateChanged(val) {
        // if (val) {
        //     this.dateArr[0] = val;
        // }
        if (!val) {
            this.dateArr = [];
        }
        if (val && this.end_date) {
            this.dateArr = [val, this.end_date];
        }
    }
    @Watch('end_date', { immediate: true })
    onEndDateChanged(val) {
        // if (val) {
        //     this.dateArr[1] = val;
        // }
        if (!val) {
            this.dateArr = [];
        }
        if (val && this.begin_date) {
            this.dateArr = [this.begin_date, val];
        }
    }
    @Watch('date_range', { immediate: true })
    onRangeDateChanged(val) {
        // if (val) {
        //     this.dateArr = val;
        // }
        if (!val || !val.length) {
            this.dateArr = [];
        }
        if (val && val.length === 2) {
            this.dateArr = val;
        }
    }
    changeHanlder(vals) {
        if (vals && vals.length === 2) {
            this.$emit('update:begin_date', vals[0] || '');
            this.$emit('update:end_date', vals[1] || '');
            this.$emit('update:date_range', vals);
        }
        else {
            this.$emit('update:begin_date', '');
            this.$emit('update:end_date', '');
            this.$emit('update:date_range', null);
        }
    }
}
</script>