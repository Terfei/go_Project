<template>
    <div>
        <el-cascader
            v-model="chose"
            :options="cpOptions"
            :props="{ expandTrigger: 'hover' }"
            @change="handleChange"
            filterable
            :disabled="!!disabled"
        ></el-cascader>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
@Component({})
export default class SelectBranch extends Vue {
    @Prop({
        default: '',
        required: false,
    })
    bizType: any;

    @Prop({
        default: '',
    })
    value: any;

    @Prop({
        default: false,
        required: false,
    })
    disabled: boolean;

    chose: Array<any> = [];
    districts: Array<any> = [];
    branches: Array<any> = [];

    get cpOptions() {
        let branches: Array<any> = this.branches.filter(x => this.bizType === '' || x.biz_type == this.bizType);
        let arr: Array<any> = [];
        for (let item of this.districts) {
            let district: any = {
                value: item.district_id,
                label: item.district_name,
                children: branches.filter(x => x.district_id === item.district_id).map(x => {
                    return {
                        value: x.branch_id,
                        label: x.branch_name,
                    };
                }),
            };
            arr.push(district);
        }
        // return arr.filter(x => x.children.length);
        return arr;
    }

    // @Watch('bizType')
    // onBizTypeChanged(val) {
    //     this.chose = [];
    //     this.$emit('input', '');
    // }

    @Watch('value')
    onValueChanged(val) {
        if (!val) {
            this.chose = [];
        }
    }

    mounted() {
        this.getDistricts();
        this.getBranches();
    }
    getDistricts() {
        return this.mixGet('/api/support/meta-district', null, { loading: false }).then(res => {
            this.districts = res.data.data;
        });
    }
    getBranches() {
        return this.mixGet('/api/support/branches', null, { loading: false }).then(res => {
            this.branches = res.data.data;
            if (this.value) {
                let item = this.branches.find(x => x.branch_id === this.value);
                if (item) {
                    this.chose = [item.district_id, this.value];
                }
            }
        });
    }
    handleChange(value) {
        if (value.length == 2) {
            this.$emit('input', value[1]);
        }
    }
}
</script>