<template>
    <div class="container">
        <div class="search-input">
            <svgIcon
                class="search-icon"
                propHref="search"
            ></svgIcon>
            <input
                class="input"
                @click.stop
                @focus="inputFocus"
                @blur="inputBlur"
                type="text"
                v-model="keyword"
                @input="debounceFun"
                :disabled="disabled"
                placeholder="输入关键字查询"
            >
        </div>
        <ul
            class="search-info"
            @click.stop
            v-show="show && String(keyword).trim() && searchResult"
        >
            <li
                class="search-item"
                v-for="item in list"
                :key="item.id"
                @click="getProject(item)"
            >{{type=='project'?item.title:item[type+'_title']}}</li>
            <li class="empty-item">没有查询到相关内容~</li>
        </ul>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
@Component({})
export default class SearchInput extends Vue {
    @Prop() project;
    @Prop({
        default: false
    })
    disabled;
    @Prop({ default: 'project' })
    type: string;

    show = false;
    keyword = '';
    list = [];
    isSearch = false;
    searchResult = false;
    debounceFun: any = () => { };
    mounted() {
        window.addEventListener('click', this.closeSearchInfo);
        this.debounceFun = this.debounce(this.debounceCallback, 500);
        this.keyword = (this.project && this.project.name) || '';
    }
    destroyed() {
        window.removeEventListener('click', this.closeSearchInfo);
    }
    @Watch('project', { deep: true })
    onProjectChange(val) {
        this.keyword = (this.type == 'project' ? val.title : val[this.type + '_title']) || this.keyword;
    }

    inputFocus() {
        this.isSearch = true;
    }
    inputBlur() {
        this.isSearch = false;
    }
    closeSearchInfo() {
        if (this.show) {
            if (this.list && this.list.length == 1) {
                this.getProject(this.list[0]);
            }
            else {
                this.show = false;
                this.$emit('update:project', {});
                // this.mixShowTips(`没有该${this.type == 'project' ? '小说' : '章节'}`, 'error');
            }
        }
    }
    getProject(item) {
        this.$emit('update:project', item);
        this.show = false;
    }
    debounceCallback() {
        if (this.disabled) {
            return;
        }
        if (!this.show) {
            this.show = true;
        }
        let keyword = String(this.keyword).trim();
        let url = '';
        let data = {};
        if (keyword && this.isSearch) {
            if (this.type == 'project') {
                url = '/api/com/novels';
                data = {
                    title: keyword
                };
            } else {
                url = '/api/com/chapter/title-seq';
                data = {
                    keyword,
                };
            }
            this.mixGet(url, data).then(res => {
                let list = res.data.data || [];
                if (this.type == 'chapter') {
                    for (let el of list) {
                        el.chapter_title = `${el.seq}-${el.title}`;
                    }
                }
                this.list = list;
                this.searchResult = true;
            });
        }
    }
    debounce(func: any, time = 2000, options: any = { leading: false, context: null }) {
        let timer: any = null;
        const debounce = (...args: any) => {
            if (timer) {
                clearTimeout(timer);
            }
            if (options.leading && !timer) {
                timer = setTimeout(() => { }, time);
                func.apply(options.context, args);
            }
            else {
                timer = setTimeout(() => {
                    // 在vue组件内部无法绑定this,所有回调函数的this都是vue组件
                    func.apply(options.context, args);
                    timer = null;
                }, time);
            }
        };
        debounce.cancel = function () {
            clearTimeout(timer);
            timer = null;
        };
        return debounce;
    }
}
</script>
<style lang="scss" scoped>
.container {
    display: inline-block;
    position: relative;
    @at-root {
        .search-input {
            position: relative;
            display: inline-flex;
            background: linear-gradient(
                to right,
                rgba(0, 0, 0, 0.1) 0,
                rgba(0, 0, 0, 0.1) 0.36rem,
                #fff 0
            );
            border-radius: 4px;
            overflow: hidden;
            .input {
                height: 0.4rem;
                width: 2rem;
                padding-left: 0.42rem;
                font-size: 0.14rem;
                background: transparent;
            }
            .search-icon {
                position: absolute;
                left: 0.1rem;
                top: 50%;
                transform: translateY(-50%);
                font-size: 0.18rem;
                color: rgba(0, 0, 0, 0.25);
            }
        }
        .search-info {
            position: absolute;
            left: 0;
            top: calc(100% + 0.1rem);
            min-width: 100%;
            border-radius: 4px;
            background-color: $c-w;
            filter: drop-shadow(0 0 5px rgba(6, 0, 1, 0.15));
            color: $c-grey-deep;
            z-index: 2;
            &::before {
                content: "";
                position: absolute;
                display: inline-block;
                top: -0.06rem;
                left: 0.2rem;
                width: 0.12rem;
                height: 0.12rem;
                background: linear-gradient(45deg, transparent 50%, $c-w 50%);
                border-top: inherit;
                border-right: inherit;
                transform: rotate(-45deg);
            }
        }
        .search-item {
            cursor: pointer;
            padding: 0.05rem 0.15rem;
            white-space: nowrap;
            &:hover {
                background-color: rgba(0, 0, 0, 0.03);
                color: var(--theme);
            }
        }
        .empty-item {
            display: none;
            padding: 0.2rem;
            color: $c-grey;
            text-align: center;
            &:only-child {
                display: block;
            }
        }
    }
}
</style>