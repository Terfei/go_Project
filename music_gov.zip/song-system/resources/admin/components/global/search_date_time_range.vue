<template>
    <div>
        <el-date-picker
            v-model="dateArr"
            type="datetimerange"
            format="yyyy-MM-dd HH:mm:ss"
            value-format="yyyy-MM-dd HH:mm:ss"
            range-separator="至"
            :picker-options="pickerOptions"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            @change="changeHanlder"
            :disabled="!!disabled"
        />
    </div>
</template>
<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
@Component
export default class SearchDateTimeRange extends Vue {
    pickerOptions = {
        disabledDate: this.disabledDate,
    };
    dateArr: Array<string> = [];
    @Prop() begin_date;
    @Prop() end_date;
    @Prop({
        default() {
            return [];
        }
    })
    date_range;
    @Prop({ default: '' })
    disabled_date;
    @Prop({
        default: false,
        required: false,
    })
    disabled: boolean;
    @Watch('begin_date', { immediate: true })
    onBeginDateChanged(val) {
        // if (val) {
        //     this.date_range[0] = val;
        // }
        if (!val) {
            this.dateArr = [];
        }
        if (val && this.end_date) {
            this.dateArr = [val, this.end_date];
        }
    }
    @Watch('end_date', { immediate: true })
    onEndDateChanged(val) {
        // if (val) {
        //     this.date_range[1] = val;
        // }
        // console.log(this.date_range);
        if (!val) {
            this.dateArr = [];
        }
        if (val && this.begin_date) {
            this.dateArr = [this.begin_date, val];
        }
    }
    @Watch('date_range', { immediate: true })
    onRangeDateChanged(val) {
        // if (val) {
        //     this.dateArr = val;
        // }
        if (!val || !val.length) {
            this.dateArr = [];
        }
        if (val && val.length === 2) {
            this.dateArr = val;
        }
    }
    changeHanlder(vals) {
        if (vals && vals.length === 2) {
            this.$emit('update:begin_date', vals[0] || '');
            this.$emit('update:end_date', vals[1] || '');
            this.$emit('update:date_range', vals);
        }
        else {
            this.$emit('update:begin_date', '');
            this.$emit('update:end_date', '');
            this.$emit('update:range_date', null);
        }
    }
    disabledDate(time) {
        let startTime = true;
        if (this.disabled_date) {
            startTime = time.getTime() < this.disabled_date;
        }
        return startTime;
    }
}
</script>
