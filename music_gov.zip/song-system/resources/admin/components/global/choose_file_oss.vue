<template>
    <!-- <div class="file-container"> -->
    <input
        class="file-input"
        type="file"
        :multiple="quantity>1"
        :accept="accept"
        @change="chooseFile"
    >
    <!-- </div> -->
</template>
<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
import { Action, Getter } from 'vuex-class';
import OSS from 'ali-oss';
@Component
export default class ChooseFileOss extends Vue {
    @Prop({ default: 1 })
    quantity: number;

    @Prop({
        default: () => ['jpg', 'png', 'jpeg', 'gif', 'bmp']
    })
    fileFormats: any;

    @Prop({
        default: () => ['flv', 'mp4', 'mov', 'quicktime', 'wmv']
    })
    videoFormats: any;

    @Prop({
        default: () => ['mp3']
    })
    udioFormats: any;

    @Prop({
        default: 'image/*'
    })
    accept: string;

    @Prop({
        default: () => ['image']
    })
    type: any;

    @Prop({
        default: () => {
            return {
                height: 0,
                width: 0,
            };
        }
    })
    limit: any;

    @Prop({ default: 0 })
    maxsize: number;

    @Prop({ default: '' })
    fileName: any;

    @Getter settingInfo: any;

    chooseFile(e) {
        let files = [...e.target.files];
        e.target.value = '';
        let len = files.length;
        if (!len) {
            return;
        }
        if (this.quantity && len > this.quantity) {
            this.$message.warning(`最多只可上传${this.quantity}个文件`);
            return;
        }
        for (let i = 0; i < len; i++) {
            let file = files[i];
            let fileType = file.type.split('/')[0];
            // if (!this.type.includes(fileType)) { //判断支持视频或者图片
            //     return this.mixShowTips(`抱歉，暂不支持${fileType}类型`, 'error');
            // }
            // if (!fileType) {
            //     let fileFormat = file.name.split('.').pop().toLowerCase();
            //     if (this.type.includes('video') && this.videoFormats.includes(fileFormat)) {
            //         fileType = 'video';
            //     }
            //     else if (this.type.includes('image') && this.fileFormats.includes(fileFormat)) {
            //         fileType = 'image';
            //     }
            //     else {
            //         return this.mixShowTips(`抱歉，暂不支持${fileFormat}格式`, 'error');
            //     }
            // }
            if (this.maxsize > 0 && file.size > this.maxsize) {
                this.$message.warning(`文件大小不能超过${(this.maxsize / 1024 / 1024).toFixed(1)}M`);
                return;
            }
            if (fileType === 'video') {// 视频上传（兼容霸屏，只能有一个视频）
                let fileFormat = file.name.split('.').pop().toLowerCase();
                if (!this.videoFormats.includes(fileFormat)) {
                    this.$message.warning(`抱歉，暂不支持${fileFormat}格式`);
                    return;
                }
                // if (file.size > 10 * 1024 * 1024) {
                //     return this.mixShowTips('视频大小不能超过10M', 'error');
                // }
                let videoUrl = URL.createObjectURL(file);
                this.$emit('getVideoUrl', videoUrl);
                this.uploadFile({ file, type: fileType }, true).then(res => {
                    this.$emit('getFilesUrl', [res], 'video');
                });
                return;
            }
        }
        // 全部为图片
        this.mixShowLoading('文件上传中');
        Promise.all(files.map(x => this.imagesHandler(x))).then(resList => {
            this.mixHideLoading();
            this.$emit('getFilesUrl', resList, 'image');
        }).catch(resErr => {
            this.mixHideLoading();
        });
    }
    async imagesHandler(file) {
        let fileType = file.type.split('/')[0];
        let fileFormat = file.name.split('.').pop().toLowerCase();
        if (!this.fileFormats.includes(fileFormat)) {
            this.$message.warning(`抱歉，暂不支持${fileFormat}格式`);
            return Promise.reject();
        }
        // 当图片小于一定规格直接上传
        if (file.size <= this.maxsize) {
            return this.uploadFile({ file, type: fileType });
        }
        let src = await this.fileReaderAsync(file);
        let img = await this.loadIamgeAsync(src);
        // let blob = await this.compress(img);
        return this.uploadFile({ file, type: fileType });
    }
    fileReaderAsync(file) {
        return new Promise((resolve, reject) => {
            let reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = (e: any) => { // 异步
                resolve(e.target.result);
            };
        });
    }
    loadIamgeAsync(src) {
        return new Promise((resolve, reject) => {
            let img = new Image();
            img.src = src;
            img.onload = () => {
                if ((this.limit.width > 0 && this.limit.width != img.width) || (this.limit.height > 0 && this.limit.height != img.height)) {
                    this.$message.warning(`图片大小为${this.limit.width}*${this.limit.height}`);
                    reject();
                    return;
                }
                resolve(img);
            };
        });
    }
    uploadFile(data, loading?: boolean) {
        // return this.mixUpLoad(data.file, loading);
        return new Promise(async (resolve, reject) => {
            let ossConfig: any = {};
            try {
                let { data: { data: config } } = await this.mixGet('/api/support/aliyun/sts-token');
                ossConfig = config;
            } catch (err) {
                reject(err);
                return;
            }
            let client = new OSS({
                region: ossConfig.region,
                accessKeyId: ossConfig.access_key_id,
                accessKeySecret: ossConfig.access_key_secret,
                bucket: ossConfig.bucket,
            });
            this.mixShowLoading('文件上传中...');
            let fileName: any = this.fileName ? this.fileName : `${new Date().getTime()}${Math.ceil(Math.random() * 1e5)}`;
            if (data.type === 'video') {
                fileName += '.mp4';
            }
            else if (data.type === 'image') {
                fileName += '.jpg';
            } else if (data.type === 'audio') {
                fileName += '.mp3';
            }
            client.put(`${this.settingInfo.oss_path}/${fileName}`, data.file, {
                headers: {
                    'x-oss-security-token': ossConfig.sts_token,
                }
            }).then(res => {
                this.mixHideLoading();
                let info = res;
                info.imgName = fileName;
                info.url = `http://${ossConfig.domain}/${this.settingInfo.oss_path}/${fileName}`;
                resolve(info);
            })
                .catch(res => {
                    this.mixHideLoading();
                    this.$message.warning(`上传失败`);
                    reject(res);
                });

        });
    }
}
</script>
<style lang="scss" scoped>
.file-input {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    opacity: 0;
    width: 100%;
    cursor: pointer;
}
</style>


