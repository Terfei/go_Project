<template>
    <div>
        <el-select
            v-model="chose"
            @change="handleChange"
            :disabled="!!disabled"
        >
            <el-option
                value=""
                label="全部"
                v-if="!requireId"
            >
            </el-option>
            <el-option
                v-for="(val, key) in statusMap"
                :key="key"
                :value="key"
                :label="val"
            ></el-option>
        </el-select>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
@Component({})
export default class SelectStatus extends Vue {
    statusMap = {
        'init': '待审核',
        'audit': '已审核待更新',
        'reject': '已驳回',
        'updated': '更新成功',
        'failed': '更新失败'
    };
    @Prop({
        default: '',
    })
    value: any;

    @Prop({
        default: false,
        required: false,
    })
    disabled: boolean;

    @Prop({
        default: false,
        required: false,
    })
    requireId: boolean;
    chose: any = '';

    @Watch('value')
    onValueChanged(val) {
        if (!val) {
            this.chose = '';
        }
    }
    handleChange(value) {
        this.$emit('input', value);

    }
}
</script>