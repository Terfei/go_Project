<template>
    <div>
        <el-date-picker
            v-model="dateArr"
            type="monthrange"
            format="yyyy-MM"
            value-format="yyyy-MM"
            range-separator="～"
            :picker-options="pickerOptions"
            start-placeholder="开始月份"
            end-placeholder="结束月份"
            @change="changeHanlder"
        />
    </div>
</template>
<script lang="ts">

import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
@Component
export default class SearchDateRange extends Vue {
    pickerOptions = {
        shortcuts: [{
            text: '最近一个月',
            onClick(picker) {
                const end = new Date();
                picker.$emit('pick', [end, end]);
            }
        },
        {
            text: '最近两个月',
            onClick(picker) {
                const end = new Date();
                const start = new Date();
                start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                picker.$emit('pick', [start, end]);
            }
        },
        {
            text: '最近三个月',
            onClick(picker) {
                const end = new Date();
                const start = new Date();
                start.setTime(start.getTime() - 3600 * 1000 * 24 * 60);
                picker.$emit('pick', [start, end]);
            }
        }]
    };
    dateArr: Array<string> = [];
    @Prop() begin_date;
    @Prop() end_date;
    @Prop({
        default() {
            return [];
        }
    })
    date_range;
    @Watch('begin_date', { immediate: true })
    onBeginDateChanged(val) {
        if (val) {
            this.date_range[0] = val;
        }
    }
    @Watch('end_date', { immediate: true })
    onEndDateChanged(val) {
        if (val) {
            this.date_range[1] = val;
        }
    }
    @Watch('date_range', { immediate: true })
    onRangeDateChanged(val) {
        if (val) {
            this.dateArr = val;
        }
    }
    changeHanlder(vals) {
        if (vals && vals.length === 2) {
            this.$emit('update:begin_date', vals[0] || '');
            this.$emit('update:end_date', vals[1] || '');
            this.$emit('update:date_range', vals);
        }
        else {
            this.$emit('update:begin_date', '');
            this.$emit('update:end_date', '');
            this.$emit('update:date_range', null);
        }
    }
}
</script>

