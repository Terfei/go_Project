<template>
    <el-pagination
        background
        @size-change="pageSizeChange"
        @current-change="currPageChange"
        :page-sizes="pageSize"
        :page-size="pagination.page_size"
        :current-page="pagination.page"
        layout="total, sizes, prev, pager, next, jumper"
        :total="pagination.total"
        :hide-on-single-page="true"
    >
    </el-pagination>
</template>
<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
@Component
export default class Pagination extends Vue {
    @Prop({
        default: () => ({}),
        required: true,
    })
    pagination!: Object;

    pageSize = [20, 50, 100];
    pageSizeChange(val) {
        this.$emit('click', val, 'currPageSize');
    }
    currPageChange(val) {
        this.$emit('click', val, 'currPage');
    }
}
</script>