<template>
    <button
        class="btn button-default"
        @click="clickCallback"
    >
        <SvgIcon
            class="excel-icon"
            propHref="export"
        ></SvgIcon>
        <slot></slot>
    </button>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
@Component
export default class ExportButton extends Vue {
    mounted() {
    }
    clickCallback() {
        this.$emit('click');
    }
}
</script>
<style lang="scss" scoped>
.btn {
    position: relative;
}
.file-input {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
}
.excel-icon {
    font-size: 0.13rem;
    margin-right: 0.06rem;
}
</style>