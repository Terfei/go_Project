<template>
    <svg
        :class="['svg-icon',svgClass]"
        aria-hidden="true"
        @click="triggerCallback"
    >
        <use :xlink:href="svgHref" />
    </svg>
</template>

<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
@Component({
    name: 'SvgIcon',
})
export default class SvgIcon extends Vue {
    @Prop()
    propHref: {
        type: String,
        required: true,
    };
    @Prop()
    propClass: {
        type: String,
    };
    get svgClass() {
        return this.propClass ? `svg-icon-${this.propClass}` : '';
    }
    get svgHref() {
        return `#svg-icon-${this.propHref}`;
    }
    triggerCallback() {
        this.$emit('click');
    }
}
</script>
<style lang="scss" scoped>
.svg-icon {
    box-sizing: content-box;
    width: 1em;
    height: 1em;
    vertical-align: -0.15em;
    fill: currentColor;
    overflow: hidden;
}
</style>
