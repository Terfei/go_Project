<template>
    <div class="search-input">
        <svgIcon
            class="search-icon"
            propHref="search"
        ></svgIcon>
        <input
            @click.stop
            type="text"
            v-model="keyword"
            @input="debounceFun"
            :disabled="disabled"
            :placeholder="placeholder"
            :style="{'width':widthH}"
        >
    </div>
</template>
<script>
export default {
    props: {
        placeholder: {
            default: '输入关键字搜索',
        },
        disabled: {
            default: false,
        },
        width: Number,
    },
    computed: {
        widthH() {
            return this.width ? `${this.width / 100}rem` : '2rem';
        }
    },
    data() {
        return {
            keyword: '',
            debounceFun: () => { },
        };
    },
    mounted() {
        this.debounceFun = this.debounce(this.debounceCallback, 500);
    },
    methods: {
        debounceCallback() {
            if (this.disabled) {
                return;
            }
            let keyword = String(this.keyword).trim();
            if (keyword) {
                this.$emit('searchInit', keyword);
            } else {
                this.$emit('searchInit', '');
            }
        },
        debounce(func, time = 2000, options = { leading: false, context: null }) {
            let timer = null;
            const debounce = (...args) => {
                if (timer) {
                    clearTimeout(timer);
                }
                if (options.leading && !timer) {
                    timer = setTimeout(() => { }, time);
                    func.apply(options.context, args);
                }
                else {
                    timer = setTimeout(() => {
                        // 在vue组件内部无法绑定this,所有回调函数的this都是vue组件
                        func.apply(options.context, args);
                        timer = null;
                    }, time);
                }
            };
            debounce.cancel = function () {
                clearTimeout(timer);
                timer = null;
            };
            return debounce;
        },
        clear() {
            this.keyword = '';
        },
        getValue(val) {
            this.keyword = val;
        }
    }
};
</script>
<style lang="scss" scoped>
.search-input {
    background: linear-gradient(
        to right,
        rgba(0, 0, 0, 0.1) 0,
        rgba(0, 0, 0, 0.1) 0.36rem,
        #fff 0
    );
    position: relative;
    border-radius: 4px;
    input {
        width: 2rem;
        padding-left: 0.42rem;
        font-size: 0.14rem;
        background: transparent;
    }
}
.search-icon {
    position: absolute;
    left: 0.1rem;
    top: 50%;
    transform: translateY(-50%);
    font-size: 0.18rem;
    color: rgba(0, 0, 0, 0.5);
}
</style>