<template>
    <div
        class="checkbox"
        @click="changeVal()"
    >
        <input
            type="checkbox"
            :disabled="isDisabled"
            :true-value="trueVal"
            :false-value="falseVal"
            v-model="model"
            @change="handleChange"
        >
        <label class="checkbox-label">
            <slot></slot>
        </label>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Mixins, Prop } from 'vue-property-decorator';
@Component({})
export default class Checkbox extends Vue {
    @Prop() value;
    @Prop({
        default: true
    })
    trueVal: any;
    @Prop({
        default: false
    })
    falseVal: any;
    @Prop({
        default: false
    })
    disabled: Boolean;
    get model() {
        return this.value;
    }
    set model(val) {
        this.$emit('input', val);
    }
    get isDisabled() {
        return this.disabled;
    }
    handleChange(e) {
        let value: any;
        if (e.target.checked) {
            value = this.trueVal === undefined ? true : this.trueVal;
        } else {
            value = this.falseVal === undefined ? true : this.falseVal;
        }
        this.$emit('change', value, e);
    }
    changeVal() {
        if (this.isDisabled !== false) {
            return;
        } else {
            this.model = this.model == this.trueVal ? this.falseVal : this.trueVal;
        }
    }
}
</script>