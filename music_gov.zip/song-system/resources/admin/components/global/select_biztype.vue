<template>
    <div>
        <el-select
            v-model="chose"
            @change="handleChange"
        >
            <el-option
                value=""
                label="全部"
            >
            </el-option>
            <el-option
                v-for="(val, key) in bizTypeMap"
                :key="'bizTypeMap' + key"
                :label="val"
                :value="key"
            ></el-option>
        </el-select>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
@Component({})
export default class SelectBiztype extends Vue {
    @Prop({
        default: '',
    })
    value: any;

    bizTypeMap: any = {};
    chose: any = '';

    @Watch('value')
    onValueChanged(val) {
        if (!val) {
            this.chose = '';
        }
    }

    mounted() {
        this.getBizTypes();
    }
    getBizTypes() {
        this.mixGet('/api/support/biz-type', null, { loading: false }).then(res => {
            this.bizTypeMap = res.data.data;
        });
    }
    handleChange(value) {
        this.$emit('input', value);

    }
}
</script>