<template>
    <button
        @click="throttleClick()"
        v-if="tag === 'button'"
    >
        <slot></slot>
    </button>
    <a
        @click="throttleClick()"
        v-else-if="tag === 'a'"
    >
        <slot></slot>
    </a>
    <p
        @click="throttleClick()"
        v-else-if="tag === 'p'"
    >
        <slot></slot>
    </p>
</template>
<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
@Component
export default class Throttle extends Vue {

    @Prop({ default: 'button' })
    tag: string;
    @Prop({ default: 2000 })
    time: number;

    throttleClick: any = () => { };

    mounted() {
        this.throttleClick = this.mixThrottle(this.sure, this.time, true);
    }
    sure() {
        this.$emit('click');
    }
}

</script>