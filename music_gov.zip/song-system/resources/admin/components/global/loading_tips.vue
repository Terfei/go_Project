<template>
    <div
        class="mask-loading"
        v-show="show"
    >
        <div class="bubble">
            <LoadingIcon></LoadingIcon>
            <p class="msg">{{msg}}</p>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
@Component({})
export default class LoadingTips extends Vue {
    msg: String = '请稍后...';
    show: Boolean = false;
    mounted() {
        this.$root.eventBus.$on('showloading', this.showLoading);
    }
    destroyed() {
        this.$root.eventBus.$off('showloading');
    }
    showLoading(msg: string, show: boolean) {
        this.msg = msg || '请稍后...';
        this.show = show;
    }
}
</script>
<style lang="scss" scoped>
.mask-loading {
    position: fixed;
    display: flex;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    z-index: 2;
}

.bubble {
    display: inline-block;
    margin: auto;
    border-radius: 1em;
    padding: 1.5em 2.5em 1.5em;
    text-align: center;
    min-width: 7em;
    min-height: 7em;
    background-color: rgba(0, 0, 0, 0.6);
    color: #fff;
    font-size: 0.14rem;
    &:empty {
        display: none;
    }
}
</style>
