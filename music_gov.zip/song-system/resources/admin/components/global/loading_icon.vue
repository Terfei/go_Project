<template>
    <div class="loading-icon-com">
        <i
            class="loading-icon-item"
            :class="['loading-icon-'+i]"
            v-for="i in 10"
            :key="i"
        ></i>
    </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
@Component({})
export default class LoadingIcon extends Vue {
}
</script>
<style lang="scss" scoped>
.loading-icon-com {
    width: 0.7rem;
    height: 0.7rem;
    position: relative;
    margin: auto;
}
.loading-icon-item {
    position: absolute;
    left: 50%;
    top: 40%;
    display: inline-block;
    width: 0.7em;
    height: 0.02rem;
    border-radius: 9999px;
    background: currentColor;
    transform-origin: left center;
    animation: loading 0.7s linear infinite;
}
$angle: 36deg;
@for $i from 1 through 10 {
    .loading-icon-#{$i} {
        transform: rotate($i * $angle - $angle) translateX(60%);
        animation-delay: 0.1s * $i - 0.1s;
    }
}
@keyframes loading {
    from {
        opacity: 0.1;
    }
    to {
        opacity: 1;
    }
}
</style>
