<template>
    <div
        class="empty-com"
        :class="{'fill-container':fillContainer}"
    >
        <img
            class="empty-image"
            v-if="image == 'empty'"
            src="~img/empty/empty.png"
            alt=""
        >
        <slot></slot>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Prop } from 'vue-property-decorator';
@Component({
    name: 'Empty',
})
export default class Empty extends Vue {
    @Prop({
        default: 'empty'
    })
    image: String;
    @Prop({
        default: false
    })
    fillContainer: Boolean;
}
</script>
<style lang="scss" scoped>
.empty-com {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: rgba(0, 0, 0, 0.3);
    // background: $c-w;
    font-size: 0.28rem;
    padding-bottom: 30vh;
    &.fill-container {
        position: initial;
        padding-top: 1.5rem;
        padding-bottom: 0;
    }
    .empty-image {
        width: 3.5rem;
        height: 1.5rem;
        margin-bottom: 0.2rem;
    }
}
</style>