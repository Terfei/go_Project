<template>
    <!-- <div class="nav-container"> -->
    <div class="nav-container">
        <h1 class="system-title">
            <img
                class="logo"
                src="~img/logo/logo.png"
                alt="logo"
            >
            <span
                class="text"
                v-if="!isCollapse"
            >云后台管理系统</span>
        </h1>
        <div
            class="collapse"
            @click.stop="isCollapse = !isCollapse"
        >
            <p>
                <SvgIcon
                    :class="{'open':isCollapse}"
                    propHref="double_arrow"
                ></SvgIcon>
            </p>
        </div>
        <div class="nav">
            <el-menu
                class="el-menu-vertical-demo"
                :default-active="defaultActive"
                :default-openeds="defaultOpeneds"
                @open="handleOpen"
                @close="handleClose"
                :collapse="isCollapse"
                background-color="#323232"
                text-color="#fff"
            >
                <template v-for="(item, index) in menus">
                    <!-- v-for="(item, index) in menus" -->
                    <el-submenu
                        v-if="item.children"
                        :key="item.link"
                        :index="item.link"
                    >
                        <template slot="title">
                            <p
                                class="nav-svg-icon"
                                :class="{'open':isCollapse}"
                            >
                                <SvgIcon :propHref="item.icon"></SvgIcon>
                            </p>
                            <span slot="title">{{item.title}}</span>
                        </template>
                        <template v-for="(item1, index1) in item.children">
                            <el-menu-item
                                :key="'' + index + index1"
                                :index="item1.link"
                                @click="goPage(item1)"
                                v-if="!item1.group"
                            >{{item1.title}}</el-menu-item>
                            <template v-if="item1.group && (index1 === 0 || item.children[index1 - 1].group !== item1.group)">
                                <el-menu-item-group
                                    :title="item1.group"
                                    :key="'' + index + index1"
                                >
                                    <el-menu-item
                                        v-for="(item2, index2) in item.children.filter(x=>x.group === item1.group)"
                                        :key="'' + index + index1 + index2"
                                        :index="item2.link"
                                        @click="goPage(item2)"
                                    >{{item2.title}}</el-menu-item>
                                </el-menu-item-group>
                            </template>
                        </template>
                    </el-submenu>
                    <el-menu-item
                        v-else
                        :key="item.link"
                        :index="item.link"
                        @click="goPage(item)"
                    >
                        <p
                            class="nav-svg-icon"
                            :class="{'open':isCollapse}"
                        >
                            <SvgIcon :propHref="item.icon"></SvgIcon>
                        </p>
                        <span slot="title">{{item.title}}</span>
                    </el-menu-item>
                </template>
            </el-menu>
        </div>
        <p
            v-if="isCollapse"
            class="user-info-icon"
            @click="isCollapse = !isCollapse"
        >
            <SvgIcon propHref="setting"></SvgIcon>
        </p>
        <div
            class="user-info"
            v-else
        >
            <div class="user-name">{{loginInfo && loginInfo.staff_name}}</div>
            <div class="user-opt">
                <span
                    class="change-pwd"
                    @click="changePwd()"
                >修改密码</span>
                <span
                    class="logout"
                    @click="logout()"
                >退出</span>
            </div>
            <el-dialog
                title="修改密码"
                :visible.sync="dialogShow"
                :close-on-click-modal="false"
                custom-class="dialog-box-xsmall"
            >
                <el-form
                    ref="form"
                    :rules="rules"
                    :model="form"
                    label-width="95px"
                >
                    <el-form-item
                        label="原密码"
                        prop="password"
                    >
                        <el-input
                            class="form-input"
                            type="password"
                            v-model="form.password"
                        ></el-input>
                    </el-form-item>
                    <el-form-item
                        label="新密码"
                        prop="newPassword"
                    >
                        <el-input
                            class="form-input"
                            type="password"
                            v-model="form.newPassword"
                        ></el-input>
                    </el-form-item>
                    <el-form-item
                        label="重复新密码"
                        prop="reNewPassword"
                    >
                        <el-input
                            class="form-input"
                            v-model="form.reNewPassword"
                            type="password"
                        ></el-input>
                    </el-form-item>
                </el-form>
                <span
                    slot="footer"
                    class="dialog-footer"
                >
                    <el-button @click="dialogShow = false">取消</el-button>
                    <el-button
                        type="primary"
                        @click="resetPassword() "
                    >确定</el-button>
                </span>
            </el-dialog>
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import { Action, Getter } from 'vuex-class';
// declare var require: any;
@Component({})
export default class Nav extends Vue {
    rules = {
        password: [
            { required: true, message: '请输入初始密码', trigger: 'blur' },
        ],
        newPassword: [{
            required: true,
            validator: (rule, value, callback) => {
                if (value === '') {
                    callback(new Error('请输入新密码'));
                }
                else if (!/^[0-9a-zA-Z]{6,}$/.test(this.form.newPassword)) {
                    callback(new Error('最少输入六位数密码'));
                }
                else if (this.form.newPassword.trim() == this.form.password.trim()) {
                    callback(new Error('新密码与原密码相同'));
                }
                else {
                    callback();
                }
            }, trigger: 'blur'
        },],
        reNewPassword: [
            {
                required: true,
                validator: (rule, value, callback) => {
                    if (value === '') {
                        callback(new Error('请再次输入密码'));
                    }
                    else if (value !== this.form.newPassword) {
                        callback(new Error('两次输入密码不一致'));
                    }
                    else {
                        callback();
                    }
                }, trigger: 'blur'
            },
        ],
    };
    form: any = {
        password: '',
        newPassword: '',
        reNewPassword: '',
    };
    [x: string]: any;
    dialogShow: Boolean = false;
    exitShow: Boolean = false;

    @Getter loginInfo: Array<any>;

    @Getter menus: Array<any>;

    isCollapse = false;
    defaultActive: any = '';
    defaultOpeneds: Array<any> = [];
    // computed: {
    //     loginInfo() {
    //         return this.$store.getters.loginInfoGet || {};
    //     },
    mounted() {
        this.defaultOpeneds = JSON.parse(window.sessionStorage.getItem('defaultOpeneds') as string) || [];
        this.defaultActive = window.sessionStorage.getItem('defaultActive');
        // this.initMenus();
    }
    // initMenus() {
    //     // 需要权限
    //     // this.mixGet('/api/menus', {}, { loading: false }).then(res => {
    //     //     let list = res.data.data || [];
    //     // });
    //     // 不需要权限
    //     let list = require('../menus.json');
    //     this.menus = list;
    // }
    goPage(item) {
        if (this.$route.path === item.link) {
            return;
        }
        window.sessionStorage.setItem('defaultActive', item.link);
        this.$router.push(item.link);
    }
    changePwd() {
        this.dialogShow = true;
        (this.$refs.form as any).resetFields();
    }
    resetPassword() {
        (this.$refs.form as any).validate((valid) => {
            if (!valid) {
                return false;
            } else {
                let data = {
                    new_password: this.form.reNewPassword.trim(),
                    password: this.form.password.trim(),
                };
                this.mixPatch('/api/modify-password', data).then(res => {
                    this.$message({ type: 'success', message: '新密码将在1分钟后生效！' });
                    this.dialogShow = false;
                });
            }
        });
    }
    logout() {
        this.$confirm('确定要退出账号吗?', '温馨提示', {
            type: 'warning'
        }).then(() => {
            this.$router.push('/');
            sessionStorage.clear();
            this.$store.dispatch('loginInfoAct', '');
            this.$store.dispatch('tokenAct', '');
        });
    }
    handleOpen(key, keyPath) {
        sessionStorage.setItem('defaultOpeneds', JSON.stringify(this.defaultOpeneds));
    }
    handleClose(key, keyPath) {
        sessionStorage.setItem('defaultOpeneds', JSON.stringify(this.defaultOpeneds));
    }
}
</script>
<style lang="scss" scoped>
$c-nav-bg: #323232;
$c-nav-checked: #36373f;
.nav-container {
    display: flex;
    flex-direction: column;
    flex-shrink: 0;
    background: $c-nav-bg;
    overflow: hidden;
    @at-root {
        .system-title {
            height: 0.6rem;
            font-size: 0.2rem;
            display: flex;
            align-items: center;
            background: var(--theme);
            color: #fff;
            padding: 0.1rem 20px; // 20px跟饿了么ui保持一致
            .logo {
                flex-shrink: 0;
                width: 24px; // 24px跟饿了么ui保持一致
                height: 0.33rem;
                object-fit: contain;
                margin-bottom: 2px;
            }
            .text {
                white-space: nowrap;
                margin-left: 0.1rem;
            }
        }
        .collapse {
            display: flex;
            align-items: center;
            min-height: 0.3rem;
            color: #fff;
            padding: 0 20px; // 20px跟饿了么ui保持一致
            border-bottom: $border-white;
            cursor: pointer;
            p {
                display: flex;
                justify-content: center;
                width: 24px; // 24px跟饿了么ui保持一致
            }
            .open {
                transform: rotate(180deg);
            }
        }
        .nav {
            flex: 1;
            overflow: auto;
        }
    }
}
.el-menu-vertical-demo:not(.el-menu--collapse) {
    width: 2.6rem;
}
.el-menu {
    border-right: none;
}

// 箭头颜色
/deep/ .el-submenu__title i {
    color: $c-w;
}
/deep/ .el-submenu__title {
    display: flex;
    align-items: center;
}
/deep/ .el-menu-item-group__title {
    background-color: rgba(0, 0, 0, 0.3) !important;
}
.el-menu--inline .el-menu-item {
    background-color: #1b1b1b !important;
}
.el-menu-item.is-active .nav-svg-icon {
    color: var(--theme);
}
.nav-svg-icon {
    display: inline-flex;
    justify-content: center;
    width: 24px;
    font-size: 16px;
    margin-right: 5px;
    &.open {
        margin-right: 0;
    }
}
// 用户信息
.user-info-icon {
    min-height: 0.6rem;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 16px;
    border-top: $border-white;
    cursor: pointer;
}
.user-info {
    font-size: 0.14rem;
    background-color: lighten($c-nav-bg, 5%);
    color: $c-w;
    @at-root {
        .user-name {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 0.5rem;
            border-bottom: $border-white;
            padding: 0.1rem 0.2rem;
            text-align: center;
        }
        .user-opt {
            display: flex;
            min-height: 0.5rem;
        }
        .change-pwd,
        .logout {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }
        .logout {
            color: var(--theme);
            border-left: $border-white;
        }
    }
}
</style>