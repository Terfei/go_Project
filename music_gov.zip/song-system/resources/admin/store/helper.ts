export default class Helper {
    createMuts(stateObj: any) {
        let obj: any = {};
        for (let key in stateObj) {
            obj[`${key}Mut`] = (state: any, info: any) => {
                state[key] = info;
            };
        }

        return obj;
    }
    creatGets(stateObj: any, flag?: string) {
        let obj: any = {};
        for (let key in stateObj) {
            obj[`${key}`] = (state: any) => {
                let info = state[key];
                if (flag) {
                    try {
                        if (!info) {
                            info = JSON.parse(window[flag].getItem(key)) || '';
                        }
                        if ((info instanceof Array) && !info.length) {
                            info = JSON.parse(window[flag].getItem(key)) || [];
                        }
                    } catch (error) {

                    }
                }

                return info;
            };
        }

        return obj;
    }
    createActs(state: any, flag?: any) {
        let obj: any = {};
        for (let key in state) {
            obj[`${key}Act`] = function (content: any, info?: any) {
                if (flag) {
                    try {
                        window[flag].setItem(key, JSON.stringify(info));
                    } catch (error) {
                        // console.log(error);
                    }
                }
                content.commit(`${key}Mut`, info);
            };
        }

        return obj;
    }
    getStore(state = {}, stateSessionStorage = {}, stateLocalStorage = {}, namespaced = false) {
        return {
            namespaced,
            state: {
                ...state,
                ...stateSessionStorage,
                ...stateLocalStorage,
            },
            mutations: this.createMuts({
                ...state,
                ...stateSessionStorage,
                ...stateLocalStorage,
            }),
            getters: {
                ...(this.creatGets(state)),
                ...(this.creatGets(stateSessionStorage, 'sessionStorage')),
                ...(this.creatGets(stateLocalStorage, 'localStorage')),
            },
            actions: {
                ...(this.createActs(state)),
                ...(this.createActs(stateSessionStorage, 'sessionStorage')),
                ...(this.createActs(stateLocalStorage, 'localStorage')),
            },
        };
    }
}
