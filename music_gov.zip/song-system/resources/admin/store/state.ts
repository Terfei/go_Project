import Helper from './helper';
let state = {
    menus: [],

};
let stateSessionStorage = {
    loginInfo: null,
    settingInfo: null,
    token: '',
};
let stateLocalStorage = {

};
export default new Helper().getStore(state, stateSessionStorage, stateLocalStorage);