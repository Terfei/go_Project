import Vue from 'vue';
import App from './App.vue';
import { router } from './router';
import store from './store';

Vue.config.productionTip = false;

// mixins
import Mixins from '@/utils/mixins/index';
Vue.mixin(Mixins);
// 全局组件
import '@utils/global_component';
// import '@utils/ui_component';
import ElementUI from 'element-ui';
Vue.use(ElementUI);

// svg图标
import '@/assets/svg';

// 样式
import '@sass/index.scss';

window.vm = new Vue({
    router,
    store,
    render: (h) => h(App),
    data() {
        return {
            eventBus: new Vue(),
        };
    },
    created() {
        // console.log();
        this.mixShowLoading();
        this.checkRouterPermission();
    },
    mounted() {
    }
}).$mount('#app');
