import Vue from 'vue';

import axios from 'axios';
let CancelToken = axios.CancelToken;
// var source = CancelToken.source();

// 默认请求
let defaultAxios = axios.create({

    headers: { 'X-Requested-With': 'XMLHttpRequest' },
});
// 添加请求拦截器
defaultAxios.interceptors.request.use(
    config => {
        // config.cancelToken = new axios.CancelToken(cancel => {
        //     window._axiosPromiseArr.push({ cancel })
        // })
        let token = window.vm.$store.getters.token;
        if (token) {
            config.headers['Authorization'] = token;
        }
        return config;
    },
    error => {
        return Promise.reject(error);
    }
);
// 请求出错
const ajaxError = (err, showErr) => {
    switch (err.status) {
        case 401:
            sessionStorage.clear();
            localStorage.clear();
            window.vm.$router.replace('/');
            break;
        case 403:
            window.vm && window.vm && window.vm.$message && window.vm.$message({
                type: 'error',
                message: '账户没有权限!',
            });
            break;
        case 404:
            break;
        case 502:
            window.vm && window.vm && window.vm.$message && window.vm.$message({
                type: 'error',
                message: '服务器出错，请稍后再试！',
            });
            break;
        default:
            if (showErr) {
                window.vm && window.vm && window.vm.$message && window.vm.$message({
                    type: 'error',
                    message: err.data.message || err.data,
                });
            }
            break;
    }
};
const ajax = (method, url, data, { loading = true, showErr = true, header = {}, cancelAjaxCallback = false } = { loading: true, showErr: true, header: {}, cancelAjaxCallback: false }) => {
    if (loading) {
        window.vm && window.vm.mixShowLoading();
    }
    let headerKeys = Object.keys(header);
    if (headerKeys.length) {
        for (let key of headerKeys) {
            defaultAxios.defaults.headers[method][key] = header[key];
        }
    }
    if (cancelAjaxCallback) {
        data.cancelToken = new CancelToken((cancel) => {
            (cancelAjaxCallback as any)(cancel);
            // window._axiosPromiseArr.push({ cancel })
        });
    }
    return defaultAxios[method](url, data).then(res => {
        if (loading) {
            window.vm && window.vm.mixHideLoading();
        }
        return res;
    }).catch(res => {
        if (loading) {
            window.vm && window.vm.mixHideLoading();
        }
        // 取消接口请求是一个Cancel对象{message: undefined};
        if (res.response) {
            ajaxError(res.response, showErr);
        }
        throw res;
    });
};
const requestArr = ['get', 'post', 'put', 'delete', 'patch'];
const funArr = requestArr.map(method => {
    return function (path, data, config) {
        if (method == 'get') {
            return ajax(method, path, { params: data }, config);
        }
        else if (method == 'delete') {
            return ajax(method, path, { data }, config);
        }
        else {
            return ajax(method, path, data, config);
        }
    };
});
const [mixGet, mixPost, mixPut, mixDelete, mixPatch] = funArr;
export default {
    methods: {
        mixGet, mixPost, mixPut, mixDelete, mixPatch
    }
};
