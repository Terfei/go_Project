
import { Component, Vue } from 'vue-property-decorator';
import { asyncRouterConfig } from '../../router/index';
import Error from '@views/error.vue';
@Component({})
export default class RouterPermission extends Vue {
    async checkRouterPermission() {
        if (!this.$store.getters.loginInfo) {
            return;
        }
        let menus = [];
        try {
            if (process.env.NODE_ENV === 'development') {
                menus = require('../../../../configs/admin/menus.json');
            }
            else {
                ({ data: { data: { menus } } } = await this.mixGet('/api/menus'));
            }
        } catch (error) {
            menus = require('../../../../configs/admin/menus.json');
        }
        // let localMenu = JSON.parse(localStorage.getItem('chunkMenus') || '[]');
        // menus.map((x: any) => {
        //     let obj = (localMenu || []).find(y => y.title === x.title) || null;
        //     x.fold = obj ? obj.fold : false;
        // });
        await this.$store.dispatch('menusAct', menus);
        let routerConfigs: any = [];
        for (let item of menus) {
            // 得到菜单路由
            routerConfigs = routerConfigs.concat(asyncRouterConfig.children.filter(x => x.path === '/' || x.path.indexOf((item as any).link) === 0));
        }
        // if (routerConfigs.length) {
        //     routerConfigs.push({
        //         path: '/home',
        //         redirect: routerConfigs[0].path,
        //     });
        // }
        asyncRouterConfig.children = routerConfigs;
        this.$router.addRoutes([
            asyncRouterConfig,
            {
                path: '*',
                component: Error,
            },
        ]);
    }
}
