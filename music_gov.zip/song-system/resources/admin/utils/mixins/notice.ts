

import { Component, Vue } from 'vue-property-decorator';
@Component
export default class Notice extends Vue {
    mixShowLoading(msg?: string) {
        this.$root.eventBus.$emit('showloading', msg, true);
    }
    mixHideLoading(msg?: string) {
        this.$root.eventBus.$emit('showloading', msg, false);
    }
    mixImgError(e: any) {
        e.target.src = require('img/default/default.jpg');
        e.target.onerror = null; // 控制不要一直跳动
    }
    mixDebounce(fn: any, delay: number) {
        let timer: any = null;
        return function () {
            if (timer) {
                clearTimeout(timer);
            }
            timer = setTimeout(fn, delay);
        };
    }
    mixThrottle(fn: any, delay: number, isImmediate: boolean = true) {
        let timer: any = null;
        let that: any = this;
        let request: Boolean = true;
        return function () {
            if (isImmediate) {
                if (request) {
                    fn.apply(that, arguments);
                    request = false;
                    setTimeout(() => {
                        request = true;
                    }, delay);
                }

            } else {
                if (timer) {
                    clearTimeout(timer);
                }
                timer = setTimeout(() => {
                    timer = null;
                    fn.apply(that, arguments);
                }, delay);
            }
        };
    }
}