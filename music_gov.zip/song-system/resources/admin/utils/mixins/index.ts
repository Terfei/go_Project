import Ajax from './ajax';
import Notice from './notice';
import RouterPermission from './router_permission';
export default {
    mixins: [Ajax, Notice, RouterPermission],
};