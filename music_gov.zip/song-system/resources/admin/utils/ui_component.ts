// import Vue from 'vue';
// import {
//     TimePicker, DatePicker, Select, Option, OptionGroup, Cascader, Table, TableColumn, Button, Transfer, Checkbox, Menu,
//     Submenu,
//     MenuItem,
//     MenuItemGroup,
//     Pagination,
//     Tabs,
//     TabPane,
//     Form,
//     FormItem,
//     MessageBox,
//     Message,
//     Notification
// } from 'element-ui';
// Vue.use(TimePicker);
// Vue.use(DatePicker);
// Vue.use(Select);
// Vue.use(Option);
// Vue.use(OptionGroup);
// Vue.use(Cascader);
// Vue.use(Table);
// Vue.use(TableColumn);
// Vue.use(Button);
// Vue.use(Transfer);
// Vue.use(Checkbox);
// Vue.use(Pagination);
// Vue.use(Tabs);
// Vue.use(TabPane);
// Vue.use(Menu);
// Vue.use(Submenu);
// Vue.use(MenuItem);
// Vue.use(MenuItemGroup);
// Vue.use(Form);
// Vue.use(FormItem);
// Vue.use(Message);
// Vue.use(MessageBox);
// Vue.use(Notification);
