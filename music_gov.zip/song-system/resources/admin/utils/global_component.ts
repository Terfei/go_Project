import Vue from 'vue';
const requireComponent = require.context(
    // 其组件目录的相对路径
    '../components/global',
    // 是否查询其子目录
    true,
    // 匹配基础组件文件名的正则表达式
    /\w+\.vue$/
    // /[A-Z]\w+\.vue$/
);
requireComponent.keys().forEach(fileName => {
    // 获取组件配置
    const componentConfig = requireComponent(fileName);
    // 获取组件的 PascalCase 命名
    let strArr = fileName.replace(/^\.\/(.*)\.\w+$/, '$1').split('_');
    strArr = strArr.map(i => (i.replace(/^\w/, j => j.toUpperCase())));
    // 全局注册组件
    Vue.component(
        strArr.join(''),
        componentConfig.default,
    );
});