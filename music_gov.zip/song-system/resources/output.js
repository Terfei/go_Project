args
[{
    'process.env': { NODE_ENV: '"development"', BASE_URL: '"/assets/admin/"' },
        title: '88888'
    }]
{
    mode: 'development',
        context: 'F:\\projects\\song-system\\resources',
            node: {
        setImmediate: false,
            process: 'mock',
                dgram: 'empty',
                    fs: 'empty',
                        net: 'empty',
                            tls: 'empty',
                                child_process: 'empty'
    },
    output: {
        path: 'F:\\projects\\song-system\\public\\assets\\admin',
            filename: 'js/[name].js?v=[hash]',
                publicPath: '/assets/admin/',
                    chunkFilename: 'js/[name].js?v=[hash]'
    },
    resolve: {
        alias: {
            '@': 'F:\\projects\\song-system\\resources\\admin',
                vue$: 'vue/dist/vue.runtime.esm.js',
                    img: 'F:\\projects\\song-system\\resources\\admin\\assets\\images',
                        '@sass': 'F:\\projects\\song-system\\resources\\admin\\assets\\sass',
                            '@utils': 'F:\\projects\\song-system\\resources\\admin\\utils',
                                '@components': 'F:\\projects\\song-system\\resources\\admin\\components',
                                    '@views': 'F:\\projects\\song-system\\resources\\admin\\views'
        },
        extensions: [
            '.tsx',
            '.ts',
            '.mjs',
            '.js',
            '.jsx',
            '.vue',
            '.json',
            '.wasm'
        ],
            modules: [
                'node_modules',
                'F:\\projects\\song-system\\resources\\node_modules',
                'F:\\projects\\song-system\\resources\\node_modules\\_@vue_cli-service@4.4.6@@vue\\cli-service\\node_modules'
            ],
                plugins: [
                    {
                        apply: function nothing() {
                            // ¯\_(ツ)_/¯
                        },
                        makePlugin: function () { /* omitted long function */ },
                        moduleLoader: function () { /* omitted long function */ },
                        topLevelLoader: {
                            apply: function nothing() {
                                // ¯\_(ツ)_/¯
                            }
                        },
                        bind: function () { /* omitted long function */ },
                        tsLoaderOptions: function () { /* omitted long function */ },
                        forkTsCheckerOptions: function () { /* omitted long function */ }
                    }
                ]
    },
    resolveLoader: {
        modules: [
            'F:\\projects\\song-system\\resources\\node_modules\\_@vue_cli-plugin-typescript@4.4.6@@vue\\cli-plugin-typescript\\node_modules',
            'F:\\projects\\song-system\\resources\\node_modules\\_@vue_cli-plugin-babel@4.4.6@@vue\\cli-plugin-babel\\node_modules',
            'node_modules',
            'F:\\projects\\song-system\\resources\\node_modules',
            'F:\\projects\\song-system\\resources\\node_modules\\_@vue_cli-service@4.4.6@@vue\\cli-service\\node_modules'
        ],
            plugins: [
                {
                    apply: function nothing() {
                        // ¯\_(ツ)_/¯
                    }
                }
            ]
    },
    module: {
        noParse: /^(vue|vue-router|vuex|vuex-router-sync)$/,
            rules: [
                /* config.module.rule('vue') */
                {
                    test: /\.vue$/,
                    use: [
                        {
                            loader: 'F:\\projects\\song-system\\resources\\node_modules\\_cache-loader@4.1.0@cache-loader\\dist\\cjs.js',
                            options: {
                                cacheDirectory: 'F:\\projects\\song-system\\resources\\node_modules\\.cache\\vue-loader',
                                cacheIdentifier: '1390b656'
                            }
                        },
                        {
                            loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-loader@15.9.3@vue-loader\\lib\\index.js',
                            options: {
                                compilerOptions: {
                                    whitespace: 'condense'
                                },
                                cacheDirectory: 'F:\\projects\\song-system\\resources\\node_modules\\.cache\\vue-loader',
                                cacheIdentifier: '1390b656'
                            }
                        }
                    ]
                },
                /* config.module.rule('images') */
                {
                    test: /\.(png|jpe?g|gif|webp)(\?.*)?$/,
                    use: [
                        {
                            loader: 'url-loader',
                            options: {
                                limit: 1024,
                                fallback: {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_file-loader@4.3.0@file-loader\\dist\\cjs.js',
                                    options: {
                                        name: 'img/[name].[ext]?[hash]'
                                    }
                                }
                            }
                        },
                        {
                            loader: 'image-webpack-loader',
                            options: {
                                bypassOnDebug: true
                            }
                        }
                    ]
                },
                /* config.module.rule('svg') */
                {
                    test: /\.(svg)(\?.*)?$/,
                    include: [
                        'F:\\projects\\song-system\\resources\\admin\\assets\\svg'
                    ],
                    use: [
                        {
                            loader: 'svg-sprite-loader',
                            options: {
                                symbolId: 'svg-icon-[name]'
                            }
                        }
                    ]
                },
                /* config.module.rule('media') */
                {
                    test: /\.(mp4|webm|ogg|mp3|wav|flac|aac)(\?.*)?$/,
                    use: [
                        {
                            loader: 'F:\\projects\\song-system\\resources\\node_modules\\_url-loader@2.3.0@url-loader\\dist\\cjs.js',
                            options: {
                                limit: 4096,
                                fallback: {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_file-loader@4.3.0@file-loader\\dist\\cjs.js',
                                    options: {
                                        name: 'media/[name].[hash:8].[ext]'
                                    }
                                }
                            }
                        }
                    ]
                },
                /* config.module.rule('fonts') */
                {
                    test: /\.(woff2?|eot|ttf|otf)(\?.*)?$/,
                    use: [
                        {
                            loader: 'F:\\projects\\song-system\\resources\\node_modules\\_url-loader@2.3.0@url-loader\\dist\\cjs.js',
                            options: {
                                limit: 4096,
                                fallback: {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_file-loader@4.3.0@file-loader\\dist\\cjs.js',
                                    options: {
                                        name: 'fonts/[name].[ext]?[hash]'
                                    }
                                }
                            }
                        }
                    ]
                },
                /* config.module.rule('pug') */
                {
                    test: /\.pug$/,
                    oneOf: [
                        /* config.module.rule('pug').rule('pug-vue') */
                        {
                            resourceQuery: /vue/,
                            use: [
                                {
                                    loader: 'pug-plain-loader'
                                }
                            ]
                        },
                        /* config.module.rule('pug').rule('pug-template') */
                        {
                            use: [
                                {
                                    loader: 'raw-loader'
                                },
                                {
                                    loader: 'pug-plain-loader'
                                }
                            ]
                        }
                    ]
                },
                /* config.module.rule('css') */
                {
                    test: /\.css$/,
                    oneOf: [
                        /* config.module.rule('css').rule('vue-modules') */
                        {
                            resourceQuery: /module/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2,
                                        modules: {
                                            localIdentName: '[name]_[local]_[hash:base64:5]'
                                        }
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('css').rule('vue') */
                        {
                            resourceQuery: /\?vue/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('css').rule('normal-modules') */
                        {
                            test: /\.module\.\w+$/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2,
                                        modules: {
                                            localIdentName: '[name]_[local]_[hash:base64:5]'
                                        }
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('css').rule('normal') */
                        {
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                }
                            ]
                        }
                    ]
                },
                /* config.module.rule('postcss') */
                {
                    test: /\.p(ost)?css$/,
                    oneOf: [
                        /* config.module.rule('postcss').rule('vue-modules') */
                        {
                            resourceQuery: /module/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2,
                                        modules: {
                                            localIdentName: '[name]_[local]_[hash:base64:5]'
                                        }
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('postcss').rule('vue') */
                        {
                            resourceQuery: /\?vue/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('postcss').rule('normal-modules') */
                        {
                            test: /\.module\.\w+$/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2,
                                        modules: {
                                            localIdentName: '[name]_[local]_[hash:base64:5]'
                                        }
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('postcss').rule('normal') */
                        {
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                }
                            ]
                        }
                    ]
                },
                /* config.module.rule('scss') */
                {
                    test: /\.scss$/,
                    oneOf: [
                        /* config.module.rule('scss').rule('vue-modules') */
                        {
                            resourceQuery: /module/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2,
                                        modules: {
                                            localIdentName: '[name]_[local]_[hash:base64:5]'
                                        }
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_sass-loader@8.0.2@sass-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        prependData: '@import "@sass/base/primitve_variables.scss";\n                    @import "@sass/base/variables.scss";\n                    @import "@sass/base/mixins.scss";\n                    @import "@sass/base/placeholders.scss";'
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('scss').rule('vue') */
                        {
                            resourceQuery: /\?vue/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_sass-loader@8.0.2@sass-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        prependData: '@import "@sass/base/primitve_variables.scss";\n                    @import "@sass/base/variables.scss";\n                    @import "@sass/base/mixins.scss";\n                    @import "@sass/base/placeholders.scss";'
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('scss').rule('normal-modules') */
                        {
                            test: /\.module\.\w+$/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2,
                                        modules: {
                                            localIdentName: '[name]_[local]_[hash:base64:5]'
                                        }
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_sass-loader@8.0.2@sass-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        prependData: '@import "@sass/base/primitve_variables.scss";\n                    @import "@sass/base/variables.scss";\n                    @import "@sass/base/mixins.scss";\n                    @import "@sass/base/placeholders.scss";'
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('scss').rule('normal') */
                        {
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_sass-loader@8.0.2@sass-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        prependData: '@import "@sass/base/primitve_variables.scss";\n                    @import "@sass/base/variables.scss";\n                    @import "@sass/base/mixins.scss";\n                    @import "@sass/base/placeholders.scss";'
                                    }
                                }
                            ]
                        }
                    ]
                },
                /* config.module.rule('sass') */
                {
                    test: /\.sass$/,
                    oneOf: [
                        /* config.module.rule('sass').rule('vue-modules') */
                        {
                            resourceQuery: /module/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2,
                                        modules: {
                                            localIdentName: '[name]_[local]_[hash:base64:5]'
                                        }
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_sass-loader@8.0.2@sass-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        prependData: '@import "@sass/base/primitve_variables.scss";\n                    @import "@sass/base/variables.scss";\n                    @import "@sass/base/mixins.scss";\n                    @import "@sass/base/placeholders.scss";',
                                        sassOptions: {
                                            indentedSyntax: true
                                        }
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('sass').rule('vue') */
                        {
                            resourceQuery: /\?vue/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_sass-loader@8.0.2@sass-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        prependData: '@import "@sass/base/primitve_variables.scss";\n                    @import "@sass/base/variables.scss";\n                    @import "@sass/base/mixins.scss";\n                    @import "@sass/base/placeholders.scss";',
                                        sassOptions: {
                                            indentedSyntax: true
                                        }
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('sass').rule('normal-modules') */
                        {
                            test: /\.module\.\w+$/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2,
                                        modules: {
                                            localIdentName: '[name]_[local]_[hash:base64:5]'
                                        }
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_sass-loader@8.0.2@sass-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        prependData: '@import "@sass/base/primitve_variables.scss";\n                    @import "@sass/base/variables.scss";\n                    @import "@sass/base/mixins.scss";\n                    @import "@sass/base/placeholders.scss";',
                                        sassOptions: {
                                            indentedSyntax: true
                                        }
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('sass').rule('normal') */
                        {
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_sass-loader@8.0.2@sass-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        prependData: '@import "@sass/base/primitve_variables.scss";\n                    @import "@sass/base/variables.scss";\n                    @import "@sass/base/mixins.scss";\n                    @import "@sass/base/placeholders.scss";',
                                        sassOptions: {
                                            indentedSyntax: true
                                        }
                                    }
                                }
                            ]
                        }
                    ]
                },
                /* config.module.rule('less') */
                {
                    test: /\.less$/,
                    oneOf: [
                        /* config.module.rule('less').rule('vue-modules') */
                        {
                            resourceQuery: /module/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2,
                                        modules: {
                                            localIdentName: '[name]_[local]_[hash:base64:5]'
                                        }
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'less-loader',
                                    options: {
                                        sourceMap: false
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('less').rule('vue') */
                        {
                            resourceQuery: /\?vue/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'less-loader',
                                    options: {
                                        sourceMap: false
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('less').rule('normal-modules') */
                        {
                            test: /\.module\.\w+$/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2,
                                        modules: {
                                            localIdentName: '[name]_[local]_[hash:base64:5]'
                                        }
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'less-loader',
                                    options: {
                                        sourceMap: false
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('less').rule('normal') */
                        {
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'less-loader',
                                    options: {
                                        sourceMap: false
                                    }
                                }
                            ]
                        }
                    ]
                },
                /* config.module.rule('stylus') */
                {
                    test: /\.styl(us)?$/,
                    oneOf: [
                        /* config.module.rule('stylus').rule('vue-modules') */
                        {
                            resourceQuery: /module/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2,
                                        modules: {
                                            localIdentName: '[name]_[local]_[hash:base64:5]'
                                        }
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'stylus-loader',
                                    options: {
                                        sourceMap: false,
                                        preferPathResolver: 'webpack'
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('stylus').rule('vue') */
                        {
                            resourceQuery: /\?vue/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'stylus-loader',
                                    options: {
                                        sourceMap: false,
                                        preferPathResolver: 'webpack'
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('stylus').rule('normal-modules') */
                        {
                            test: /\.module\.\w+$/,
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2,
                                        modules: {
                                            localIdentName: '[name]_[local]_[hash:base64:5]'
                                        }
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'stylus-loader',
                                    options: {
                                        sourceMap: false,
                                        preferPathResolver: 'webpack'
                                    }
                                }
                            ]
                        },
                        /* config.module.rule('stylus').rule('normal') */
                        {
                            use: [
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_vue-style-loader@4.1.2@vue-style-loader\\index.js',
                                    options: {
                                        sourceMap: false,
                                        shadowMode: false
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_css-loader@3.6.0@css-loader\\dist\\cjs.js',
                                    options: {
                                        sourceMap: false,
                                        importLoaders: 2
                                    }
                                },
                                {
                                    loader: 'F:\\projects\\song-system\\resources\\node_modules\\_postcss-loader@3.0.0@postcss-loader\\src\\index.js',
                                    options: {
                                        sourceMap: false,
                                        plugins: [
                                            function () { /* omitted long function */ }
                                        ]
                                    }
                                },
                                {
                                    loader: 'stylus-loader',
                                    options: {
                                        sourceMap: false,
                                        preferPathResolver: 'webpack'
                                    }
                                }
                            ]
                        }
                    ]
                },
                /* config.module.rule('js') */
                {
                    test: /\.m?jsx?$/,
                    exclude: [
                        function () { /* omitted long function */ }
                    ],
                    use: [
                        {
                            loader: 'F:\\projects\\song-system\\resources\\node_modules\\_cache-loader@4.1.0@cache-loader\\dist\\cjs.js',
                            options: {
                                cacheDirectory: 'F:\\projects\\song-system\\resources\\node_modules\\.cache\\babel-loader',
                                cacheIdentifier: '77816b29'
                            }
                        },
                        {
                            loader: 'F:\\projects\\song-system\\resources\\node_modules\\_babel-loader@8.1.0@babel-loader\\lib\\index.js'
                        }
                    ]
                },
                /* config.module.rule('ts') */
                {
                    test: /\.ts$/,
                    use: [
                        {
                            loader: 'F:\\projects\\song-system\\resources\\node_modules\\_cache-loader@4.1.0@cache-loader\\dist\\cjs.js',
                            options: {
                                cacheDirectory: 'F:\\projects\\song-system\\resources\\node_modules\\.cache\\ts-loader',
                                cacheIdentifier: '71fe4a3a'
                            }
                        },
                        {
                            loader: 'F:\\projects\\song-system\\resources\\node_modules\\_babel-loader@8.1.0@babel-loader\\lib\\index.js'
                        },
                        {
                            loader: 'F:\\projects\\song-system\\resources\\node_modules\\_ts-loader@6.2.2@ts-loader\\index.js',
                            options: {
                                transpileOnly: true,
                                appendTsSuffixTo: [
                                    '\\.vue$'
                                ],
                                happyPackMode: false
                            }
                        }
                    ]
                },
                /* config.module.rule('tsx') */
                {
                    test: /\.tsx$/,
                    use: [
                        {
                            loader: 'F:\\projects\\song-system\\resources\\node_modules\\_cache-loader@4.1.0@cache-loader\\dist\\cjs.js',
                            options: {
                                cacheDirectory: 'F:\\projects\\song-system\\resources\\node_modules\\.cache\\ts-loader',
                                cacheIdentifier: '71fe4a3a'
                            }
                        },
                        {
                            loader: 'F:\\projects\\song-system\\resources\\node_modules\\_babel-loader@8.1.0@babel-loader\\lib\\index.js'
                        },
                        {
                            loader: 'F:\\projects\\song-system\\resources\\node_modules\\_ts-loader@6.2.2@ts-loader\\index.js',
                            options: {
                                transpileOnly: true,
                                happyPackMode: false,
                                appendTsxSuffixTo: [
                                    '\\.vue$'
                                ]
                            }
                        }
                    ]
                },
                /* config.module.rule('file') */
                {
                    test: /\.svg$/,
                    exclude: [
                        'F:\\projects\\song-system\\resources\\admin\\assets\\svg'
                    ],
                    use: [
                        {
                            loader: 'file-loader'
                        }
                    ]
                }
            ]
    },
    optimization: {
        splitChunks: {
            cacheGroups: {
                vendors: {
                    name: 'chunk-vendors',
                        test: /[\\\/]node_modules[\\\/]/,
                            priority: -10,
                                chunks: 'initial'
                },
                common: {
                    name: 'chunk-common',
                        minChunks: 2,
                            priority: -20,
                                chunks: 'initial',
                                    reuseExistingChunk: true
                }
            }
        },
        minimizer: [
            {
                options: {
                    test: /\.m?js(\?.*)?$/i,
                    chunkFilter: () => true,
                    warningsFilter: () => true,
                    extractComments: false,
                    sourceMap: false,
                    cache: true,
                    cacheKeys: defaultCacheKeys => defaultCacheKeys,
                    parallel: true,
                    include: undefined,
                    exclude: undefined,
                    minify: undefined,
                    terserOptions: {
                        compress: {
                            arrows: false,
                            collapse_vars: false,
                            comparisons: false,
                            computed_props: false,
                            hoist_funs: false,
                            hoist_props: false,
                            hoist_vars: false,
                            inline: false,
                            loops: false,
                            negate_iife: false,
                            properties: false,
                            reduce_funcs: false,
                            reduce_vars: false,
                            switches: false,
                            toplevel: false,
                            typeofs: false,
                            booleans: true,
                            if_return: true,
                            sequences: true,
                            unused: true,
                            conditionals: true,
                            dead_code: true,
                            evaluate: true
                        },
                        mangle: {
                            safari10: true
                        }
                    }
                }
            }
        ]
    },
    plugins: [
        /* config.plugin('vue-loader') */
        new VueLoaderPlugin(),
        /* config.plugin('define') */
        new DefinePlugin(
            {
                'process.env': {
                    NODE_ENV: '"development"',
                    BASE_URL: '"/assets/admin/"'
                },
            }
        ),
        /* config.plugin('case-sensitive-paths') */
        new CaseSensitivePathsPlugin(),
        /* config.plugin('friendly-errors') */
        new FriendlyErrorsWebpackPlugin(
            {
                additionalTransformers: [
                    function () { /* omitted long function */ }
                ],
                additionalFormatters: [
                    function () { /* omitted long function */ }
                ]
            }
        ),
        /* config.plugin('html') */
        new HtmlWebpackPlugin(
            {
                title: '云后台管理系统',
                templateParameters: function () { /* omitted long function */ },
                template: 'F:\\projects\\song-system\\resources\\admin\\index.html',
                favicon: 'F:\\projects\\song-system\\resources\\admin\\favicon.ico'
            }
        ),
        /* config.plugin('preload') */
        new PreloadPlugin(
            {
                rel: 'preload',
                include: 'initial',
                fileBlacklist: [
                    /\.map$/,
                    /hot-update\.js$/
                ]
            }
        ),
        /* config.plugin('prefetch') */
        new PreloadPlugin(
            {
                rel: 'prefetch',
                include: 'asyncChunks'
            }
        ),
        /* config.plugin('fork-ts-checker') */
        new ForkTsCheckerWebpackPlugin(
            {
                vue: {
                    enabled: true,
                    compiler: 'vue-template-compiler'
                },
                tslint: true,
                formatter: 'codeframe',
                checkSyntacticErrors: false
            }
        )
    ],
        entry: {
        app: 'F:\\projects\\song-system\\resources\\admin\\main.ts'
    }
}
