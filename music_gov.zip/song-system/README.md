## song-system

曲库管理中心

### 目录结构
- `cmd` main函数文件，执行文件
    - `cmd/admin` 后台服务
    - `cmd/branch` 门店服务
    - `cmd/import` 数据导入迁移
    - `cmd/migrate` 数据库迁移
    - `cmd/permission` 权限
- `configs` 配置文件
- `internal` 项目文件
    - `internal/admin` 后台
    - `internal/branch` 门店

### 部署

#### 后台服务

- 配置文件例子 `configs/admin.toml.example`，复制为`.toml`文件
- 启动 `go run cmd/admin/main.go -c 配置文件 -m {server cron}`

#### 门店服务

- 配置文件例子 `configs/branch.toml.example`，复制为`.toml`文件
- 启动 `go run cmd/admin/main.go -c 配置文件 -m {server cron}`

### 数据库迁移

- 生成迁移 `migrate create -ext sql -dir database/migrations -seq xxxxx`

- 执行迁移 `go run cmd/migrate/main.go -c configs/setting.toml -p database/migrations -a up`

- 回滚迁移 `go run cmd/migrate/main.go -c configs/setting.toml -p database/migrations -a down`

### 同步步骤

后台创建批次，对批次为空的数据，生成最新批次号，保存批次总览以及门店批次信息

- 批次20200501005
- 门店江北店 20200501005 

点击同步，选择门店信息存入`redis`，后台异步处理，暂定１小时内不能处理

后台异步处理，需同步的数据，数据类型信息，localdb信息，通知门店

门店判断所有数据下载信息，下载完成，请求后台，同步下载数据统计，下载sqlite, 更新sqlite

后台异步处理，需同步的数据，数据类型信息，通知门店

- 歌曲
    - `excel`导入字段 `DISKNAME` 对应数据库 `accompany_filename`字段
    - 下载 `update-song/encode_songs/{accompany_filename}.{ext}`

- 歌手
    - `excel` 导入字段 `SONGERNAME` 对于数据库 `name`字段
    - 下载 `update-song/pic/{name}.jpg`

- 动态壁纸
    - `excel` 导入字段 `wallpaper_filename` 对应数据库 `wallpaper_filename`
    -  下载 `update-song/encode_songs/{wallpaper_filename}`
    - 图片 `{wallpaper_no}/001.png` 对应 `{png_count}数量`
    
- 派对舞曲
    - 下载 `update-song/encode_songs/{accompany_filename}.{codec}`
    - 下载 `update-song/encode_songs/{accompany_title_filename}`
    - 下载 `update-song/pic/{image}`
    
- 跳舞视频
    - 下载 `update-songs/encode_songs/{accompany_filename}`
    - 下载 `update-songs/pic/{image}`
    
- vj
    - 下载 `update-songs/encode_songs/{filename}.{codec}`

### 打包发布

`cmd/build.ini` 写入本地代码发布需打包的文件夹

`CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build -o xxx`