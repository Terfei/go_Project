CREATE TABLE IF NOT EXISTS Sync_Version_Detail(
	id integer PRIMARY KEY AUTOINCREMENT,
    version_id int not null,
	version_code CHAR(11) not null,
	relation_type varchar(32) not null,
	relation_id int not null,
	is_download smallint default 0
);