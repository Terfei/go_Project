CREATE TABLE IF NOT EXISTS image.images (
    id SERIAL primary key,
    filename varchar(64) not null,
    category_id int not null default 0,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);

COMMENT ON TABLE image.images IS '图库';