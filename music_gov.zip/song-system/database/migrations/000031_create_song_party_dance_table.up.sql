CREATE TABLE IF NOT EXISTS song.party_dance (
    id SERIAL primary key,
    songno varchar(128),
    accompany_id int default 0,
    accompany_name varchar(128),
    accompany_name_spell varchar(128),
    accompany_filename varchar(128),
    accompany_title_filename varchar(128),
    audio int default 0,
    host_ip varchar(32),
    image varchar(128),
    category_id int default 0,
    category_name varchar(64),
    char_count int default 0,
    rank int default 0,
    lamp_id int default 0,
    effect_id int default 0,
    reverberation_id int default 0,
    codec varchar(32),
    volume int default 0,
    str_level int default 0,
    overview_id int default 0,
    update_time date,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);

COMMENT ON TABLE song.party_dance IS '派对舞曲';
