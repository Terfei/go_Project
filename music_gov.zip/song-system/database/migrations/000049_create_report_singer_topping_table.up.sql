CREATE TABLE IF NOT EXISTS report.singer_topping (
    id SERIAL primary key,
    singer_id int not null default 0,
    singer_name varchar(64) default '',
    singer_code varchar(32) default '',
    area_id int not null default 0,
    area_name varchar(32) default '',
    weight int not null default 0,
    created_at timestamp not null,
    updated_at timestamp not null
);

COMMENT ON TABLE report.accompany_topping IS '歌手置顶';

