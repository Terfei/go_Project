CREATE TABLE IF NOT EXISTS meta.disks (
    id SERIAL primary key,
    category varchar(32) not null,
    local_disk varchar(32) not null,
    share_disk varchar(32) not null,
    created_at timestamp not null,
    updated_at timestamp not null
);

insert into meta.disks (category,local_disk,share_disk,created_at,updated_at) values('song.accompany','','',now(),now());
insert into meta.disks (category,local_disk,share_disk,created_at,updated_at) values('song.singer','','',now(),now());
insert into meta.disks (category,local_disk,share_disk,created_at,updated_at) values('song.acc','','',now(),now());
insert into meta.disks (category,local_disk,share_disk,created_at,updated_at) values('song.wallpaper','','',now(),now());
insert into meta.disks (category,local_disk,share_disk,created_at,updated_at) values('song.vj','','',now(),now());
insert into meta.disks (category,local_disk,share_disk,created_at,updated_at) values('song.party_dance','','',now(),now());
insert into meta.disks (category,local_disk,share_disk,created_at,updated_at) values('song.act_video','','',now(),now());

COMMENT ON TABLE meta.disks IS '盘符路径';
COMMENT ON COLUMN meta.disks.category IS '分类 song.wallpaper song.acc song.vj song.party_dance song.accompany song.singer';