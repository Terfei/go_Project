DROP TABLE IF EXISTS "user".role_classify;
