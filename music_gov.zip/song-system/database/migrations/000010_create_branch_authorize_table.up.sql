CREATE TABLE IF NOT EXISTS branch.authorize (
    id SERIAL primary key,
    branch_id uuid not null,
    branch_code varchar(64) not null,
    category varchar(16)not null,
    year char(4) not null,
    months smallint[] not null,
    remark varchar(256),
    created_at timestamp not null,
    updated_at timestamp not null
);

COMMENT ON TABLE branch.authorize IS '门店授权';
COMMENT ON COLUMN branch.authorize.branch_id IS '门店id';
COMMENT ON COLUMN branch.authorize.branch_code IS '门店编号';
COMMENT ON COLUMN branch.authorize.year IS '年';
COMMENT ON COLUMN branch.authorize.category IS '分类';
COMMENT ON COLUMN branch.authorize.months IS '月份';
COMMENT ON COLUMN branch.authorize.remark IS '备注';

