CREATE TABLE IF NOT EXISTS song.vj (
    id SERIAL primary key,
    name varchar(32),
    filename varchar(32),
    codec varchar(32),
    host_ip varchar(32),
    category_id int default 0,
    overview_id int default 0,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);

COMMENT ON TABLE song.vj IS 'VJ视频';
