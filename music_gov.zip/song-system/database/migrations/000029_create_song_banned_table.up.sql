CREATE TABLE IF NOT EXISTS song.accompany_banned (
    id SERIAL primary key,
    song_name varchar(128) not null,
    singer_name varchar(256) not null,
    remark varchar(256) not null,
    ban_date varchar(64) not null,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);

COMMENT ON TABLE song.accompany_banned IS '禁歌';
COMMENT ON COLUMN song.accompany_banned.ban_date IS '封禁日期';

