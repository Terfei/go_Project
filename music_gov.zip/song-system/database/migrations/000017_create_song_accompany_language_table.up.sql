CREATE TABLE IF NOT EXISTS song.accompany_language (
    id serial primary key,
    name varchar(128) not null,
    name_key varchar(128),
    image varchar(256),
    seq int default 0,
    is_show int default 0,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);

COMMENT ON TABLE song.accompany_language IS '伴奏语种';
