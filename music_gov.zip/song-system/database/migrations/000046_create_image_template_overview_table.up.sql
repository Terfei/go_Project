CREATE TABLE IF NOT EXISTS image.overview (
    id SERIAL primary key,
    category_id int not null default 0,
    branch_id uuid not null,
    branch_name varchar(64) not null,
    biz_type int not null default 0,
    center_plan_id int not null default 0,
    branch_plan_id int not null default 0,
    center_plan jsonb,
    branch_plan jsonb,
    center_template_id int not null default 0,
    branch_template_id int not null default 0,
    center_template jsonb,
    branch_template jsonb,
    created_at timestamp not null,
    updated_at timestamp not null
);
COMMENT ON TABLE image.overview IS '图库总览';