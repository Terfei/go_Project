CREATE TABLE IF NOT EXISTS "user".roles (
    id SERIAL primary key,
    name varchar(32) not null,
    code int4 not null,
    status varchar(10) not null,
    classify_id int not null,
    remarks varchar(256),
    extra jsonb,
    created_at timestamp not null,
    updated_at timestamp not null
);

CREATE INDEX idx_user_role_name ON "user".roles (name);

COMMENT ON TABLE "user".roles IS '角色';
COMMENT ON COLUMN "user".roles.name IS '名';
COMMENT ON COLUMN "user".roles.code IS '编号';
COMMENT ON COLUMN "user".roles.remarks IS '备注';
COMMENT ON COLUMN "user".roles.status IS '状态 enabled unabled';

