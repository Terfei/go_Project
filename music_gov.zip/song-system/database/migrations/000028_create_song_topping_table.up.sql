CREATE TABLE IF NOT EXISTS report.accompany_topping (
    id SERIAL primary key,
    songno varchar(16) not null,
    accompany_id int not null default 0,
    accompany_name varchar(64) default '',
    accompany_category_id int default 0,
    accompany_category varchar(64) not null default '',
    accompany_language_id int not null default 0,
    accompany_language varchar(32) not null default '',
    singer_id int not null default 0,
    singer_name varchar(32) default '',
    weight int not null default 0,
    created_at timestamp not null,
    updated_at timestamp not null
);

COMMENT ON TABLE report.accompany_topping IS '伴奏置顶';

