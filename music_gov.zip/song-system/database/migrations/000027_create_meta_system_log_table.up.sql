CREATE TABLE IF NOT EXISTS meta.system_log (
    id serial primary key,
    staff_id uuid not null,
    staff_name varchar(32),
    module varchar(64) not null,
    action varchar(64) not null,
    relation_id int,
    remark varchar(256),
    extra jsonb,
    created_at timestamp not null,
    updated_at timestamp not null
);

COMMENT ON TABLE meta.system_log IS '操作日志';
