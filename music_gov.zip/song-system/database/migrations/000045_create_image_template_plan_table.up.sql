CREATE TABLE IF NOT EXISTS image.template_plan (
    id SERIAL primary key,
    module char(6) not null,
    category_id int not null default 0,
    template_id int not null default 0,
    branch_id uuid not null,
    begin_time timestamp not null,
    end_time timestamp not null,
    remark varchar(128),
    status varchar(10),
    reject_explain varchar(128),
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);
COMMENT ON TABLE image.template_plan IS '模板应用';
COMMENT ON COLUMN image.template_plan.module IS 'centre branch';
COMMENT ON COLUMN image.template_plan.category_id IS '分类';
COMMENT ON COLUMN image.template_plan.template_id IS '模板';
COMMENT ON COLUMN image.template_plan.branch_id IS '门店';
COMMENT ON COLUMN image.template_plan.begin_time IS '开始时间';
COMMENT ON COLUMN image.template_plan.end_time IS '结束时间';
COMMENT ON COLUMN image.template_plan.status IS '状态 init audit reject updated failed';
COMMENT ON COLUMN image.template_plan.reject_explain IS '拒绝提示';