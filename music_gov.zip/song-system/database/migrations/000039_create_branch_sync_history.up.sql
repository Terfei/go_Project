CREATE TABLE IF NOT EXISTS branch.sync_history (
    id SERIAL primary key,
    branch_id uuid not null,
    sync_code varchar(32) not null,
    status varchar(12) not null,
    remark character varying(256),
    created_at timestamp not null,
    updated_at timestamp not null
);

COMMENT ON TABLE branch.sync_history IS '门店同步历史';
