CREATE TABLE IF NOT EXISTS branch.authorize_logs (
    id SERIAL primary key,
    staff_id uuid not null,
    staff_name varchar(64) not null,
    branch_id uuid not null,
    branch_name varchar(64) not null,
    branch_code varchar(64) not null,
    category varchar(16) not null,
    begin_month char(7) not null,
    end_month char(7) not null,
    can_download SMALLINT not null,
    remark varchar(256),
    authorize_id integer not null,
    created_at timestamp not null,
    updated_at timestamp not null
);
COMMENT ON TABLE branch.authorize_logs IS '门店授权记录';
COMMENT ON COLUMN branch.authorize_logs.staff_id IS '员工id';
COMMENT ON COLUMN branch.authorize_logs.staff_name IS '员工名称';
COMMENT ON COLUMN branch.authorize_logs.branch_id IS '门店id';
COMMENT ON COLUMN branch.authorize_logs.branch_code IS '门店编号';
COMMENT ON COLUMN branch.authorize_logs.branch_name IS '门店名称';
COMMENT ON COLUMN branch.authorize_logs.category IS '分类';
COMMENT ON COLUMN branch.authorize_logs.begin_month IS '开始月';
COMMENT ON COLUMN branch.authorize_logs.end_month IS '结束月';
COMMENT ON COLUMN branch.authorize_logs.can_download IS '启用/禁用';
COMMENT ON COLUMN branch.authorize_logs.remark IS '备注';
COMMENT ON COLUMN branch.authorize_logs.authorize_id IS '授权记录id';