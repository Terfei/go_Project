CREATE TABLE IF NOT EXISTS song.accompany_version (
    id serial primary key,
    seq int default 0,
    name varchar(128),
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);

COMMENT ON TABLE song.accompany_version IS '伴奏版本';
