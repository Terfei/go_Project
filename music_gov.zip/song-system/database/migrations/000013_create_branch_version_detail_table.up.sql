CREATE TABLE IF NOT EXISTS branch.version_detail (
    id SERIAL primary key,
    branch_id uuid not null,
    version_id int not null,
    version_code char(11) not null,
    version_category_id int not null,
    relation_type varchar(32) not null,
    relation_id int not null,
    is_download smallint default 0,
    filename varchar(128),
    oss_file varchar(128),
    disk_file varchar(128),
    created_at timestamp not null,
    updated_at timestamp not null
);

create INDEX idx_branch_version_detail_branch ON branch.version_detail (branch_id);
create INDEX idx_branch_version_detail_version ON branch.version_detail (version_id);
create INDEX idx_branch_version_detail_relation ON branch.version_detail (relation_type);
create INDEX idx_branch_version_detail_relation_id ON branch.version_detail (relation_id);

COMMENT ON TABLE branch.version_detail IS '门店批次详情信息';
COMMENT ON COLUMN branch.version_detail.branch_id IS '门店';
COMMENT ON COLUMN branch.version_detail.version_category_id IS '门店批次分类id';
COMMENT ON COLUMN branch.version_detail.version_code IS '批次号';
COMMENT ON COLUMN branch.version_detail.relation_type IS '关联数据信息';
COMMENT ON COLUMN branch.version_detail.is_download IS '是否下载';