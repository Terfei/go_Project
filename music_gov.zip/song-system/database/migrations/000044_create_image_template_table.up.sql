CREATE TABLE IF NOT EXISTS image.template (
    id SERIAL primary key,
    module char(6) not null,
    code char(7) not null,
    title varchar(64) not null,
    category_id int not null default 0,
    image_ids _int4 not null,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp,
    constraint uk_image_template_module_code unique (module, code)
);
COMMENT ON TABLE image.template IS '模板';