CREATE TABLE IF NOT EXISTS branch.version_category (
    id SERIAL primary key,
    branch_id uuid not null,
    version_id int not null,
    version_code char(11) not null,
    relation_type varchar(32) not null,
    file_count int default 0,
    done_count int default 0,
    undone_count int default 0,
    deal_status varchar(16) default 'init',
    deal_remark varchar(128),
    created_at timestamp not null,
    updated_at timestamp not null
);

create INDEX idx_branch_version_category_branch ON branch.version_category (branch_id);
create INDEX idx_branch_version_category_version ON branch.version_category (version_id);
create INDEX idx_branch_version_category_relation ON branch.version_category (relation_type);

COMMENT ON TABLE branch.version_category IS '门店批次分类汇总';
COMMENT ON COLUMN branch.version_category.branch_id IS '门店';
COMMENT ON COLUMN branch.version_category.version_id IS '批次';
COMMENT ON COLUMN branch.version_category.version_code IS '批次号';
COMMENT ON COLUMN branch.version_category.relation_type IS '关联数据类型';
COMMENT ON COLUMN branch.version_category.file_count IS '总共需处理数量';
COMMENT ON COLUMN branch.version_category.done_count IS '已处理数量';
COMMENT ON COLUMN branch.version_category.undone_count IS '未处理数量';