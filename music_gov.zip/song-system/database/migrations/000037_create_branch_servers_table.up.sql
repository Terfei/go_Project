CREATE TABLE IF NOT EXISTS branch.servers (
    id SERIAL primary key,
    branch_id uuid not null,
    domain varchar(64) not null,
    created_at timestamp not null,
    updated_at timestamp not null
);

COMMENT ON TABLE branch.servers IS '门店服务配置';