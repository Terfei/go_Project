CREATE TABLE IF NOT EXISTS song.accompany_tag (
    id serial primary key,
    name varchar(128) not null,
    seq int default 0,
    is_show int default 0,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);

COMMENT ON TABLE song.accompany_tag IS '伴奏标签';
