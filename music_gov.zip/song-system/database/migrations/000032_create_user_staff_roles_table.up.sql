CREATE TABLE IF NOT EXISTS "user".staff_roles (
    id SERIAL primary key,
    staff_id uuid not null,
    role_id int not null
);

create UNIQUE INDEX idx_unique_user_staff_roles ON "user".staff_roles (staff_id,role_id);

COMMENT ON TABLE "user".staff_roles IS '员工角色';
COMMENT ON COLUMN "user".staff_roles.staff_id IS '员工';
COMMENT ON COLUMN "user".staff_roles.role_id IS '角色';

