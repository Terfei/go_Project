CREATE TABLE IF NOT EXISTS song.singer (
    id serial primary key,
    code varchar(10) not null,
    name varchar(128) not null,
    nickname varchar(128),
    name_spell varchar(256),
    char_count int default 0,
    gender int default 0,
    language_type varchar(10),
    area_id int default 0,
    image varchar(256),
    bh varchar(50),
    rank int default 0,
    weight int default 0,
    overview_id int default 0,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);

COMMENT ON TABLE song.singer IS '歌手';
COMMENT ON COLUMN song.singer.code IS '编号';
COMMENT ON COLUMN song.singer.name IS '名';
COMMENT ON COLUMN song.singer.nickname IS 'nickname';
COMMENT ON COLUMN song.singer.name_spell IS '拼音';
COMMENT ON COLUMN song.singer.char_count IS '字数';
COMMENT ON COLUMN song.singer.gender IS '性别';
COMMENT ON COLUMN song.singer.language_type IS '语种';
COMMENT ON COLUMN song.singer.area_id IS '区域';
COMMENT ON COLUMN song.singer.image IS '图片';
COMMENT ON COLUMN song.singer.rank IS '排名';
