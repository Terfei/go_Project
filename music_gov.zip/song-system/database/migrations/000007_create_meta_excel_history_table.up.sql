CREATE TABLE IF NOT EXISTS meta.excel_history (
    id SERIAL primary key,
    category varchar(32) not null,
    action varchar(32) not null,
    relation_id varchar(32) not null,
    import_code varchar(32) not null,
    content jsonb not null,
    created_at timestamp not null,
    updated_at timestamp not null
);

COMMENT ON TABLE meta.excel_history IS 'EXCEL导入历史';
COMMENT ON COLUMN meta.excel_history.category IS '类型';
COMMENT ON COLUMN meta.excel_history.content IS '内容';

