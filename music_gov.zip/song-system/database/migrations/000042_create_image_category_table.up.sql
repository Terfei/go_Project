CREATE TABLE IF NOT EXISTS image.category (
    id SERIAL primary key,
    title varchar(32) not null,
    height int2 not null default 0,
    width int2 not null default 0,
    disk varchar(128) not null,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);

COMMENT ON TABLE image.category IS '图库';