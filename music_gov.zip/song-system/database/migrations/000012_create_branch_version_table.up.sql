CREATE TABLE IF NOT EXISTS branch.versions (
    id SERIAL primary key,
    branch_id uuid not null,
    version_id int not null,
    version_code char(11) not null,
    remarks varchar(256),
    can_download smallint default 0,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp NULL
);

COMMENT ON TABLE branch.versions IS '门店批次信息';
COMMENT ON COLUMN branch.versions.branch_id IS '门店';
COMMENT ON COLUMN branch.versions.version_code IS '批次号';
COMMENT ON COLUMN branch.versions.remarks IS '备注';
COMMENT ON COLUMN branch.versions.can_download IS '是否可以下载';