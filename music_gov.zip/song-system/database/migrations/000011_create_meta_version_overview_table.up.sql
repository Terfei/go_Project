CREATE TABLE IF NOT EXISTS meta.version_overview (
    id SERIAL primary key,
    version_code char(11) not null,
    remark varchar(16),
    is_default smallint default 0,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp NULL
);

COMMENT ON TABLE meta.version_overview IS '批次号总览';
COMMENT ON COLUMN meta.version_overview.version_code IS '批次号';