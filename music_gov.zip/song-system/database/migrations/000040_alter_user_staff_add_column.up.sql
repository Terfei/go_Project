alter table "user".staffs add column extra json;

COMMENT ON COLUMN "user".staffs.extra IS '{"center":true | false}';