CREATE TABLE IF NOT EXISTS song.acc (
    id serial primary key,
    acc_id int not null,
    acc_name varchar(64) not null,
    filename varchar(64),
    filename2 varchar(64),
    list_id int default 0,
    list_name varchar(64),
    seq int default 0,
    codec varchar(10),
    start_time time,
    end_time time,
    host_ip varchar(128),
    audio int default 0,
    channel varchar(10),
    lamp_id int default 0,
    reverberation_id int default 0,
    effect_id int default 3,
    volume int default 330,
    str_level int default 0,
    mode int default 0,
    acc_type int default 0,
    overview_id int default 0,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);

create INDEX idx_unique_song_acc ON song.acc (acc_id, acc_type);

COMMENT ON TABLE song.acc IS '公播';
COMMENT ON COLUMN song.acc.str_level IS '强中弱，默认值0、强＝1、中＝2、弱＝3';
COMMENT ON COLUMN song.acc.acc_type IS '类型　1chunk 2kparty 3gala';