CREATE TABLE IF NOT EXISTS "user".role_classify (
    id SERIAL primary key,
    name varchar(32) not null,
    extra jsonb,
    created_at timestamp not null,
    updated_at timestamp not null
);

CREATE INDEX idx_user_role_classify_name ON "user".role_classify (name);

COMMENT ON TABLE "user".role_classify IS '角色类别';
COMMENT ON COLUMN "user".role_classify.name IS '类别名称';

