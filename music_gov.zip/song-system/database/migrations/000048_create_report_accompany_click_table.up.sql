CREATE TABLE IF NOT EXISTS report.accompany_clicks (
    id BIGSERIAL primary key,
    songno varchar(16) not null,
    accompany_id int not null default 0,
    accompany_name varchar(64) default '',
    accompany_category_id int default 0,
    singer_id int not null default 0,
    singer_name varchar(32) default '',
    times int not null default 1,
    branch_id uuid not null,
    branch_biz_type int not null default 0,
    created_at timestamp not null,
    updated_at timestamp not null
);

CREATE INDEX idx_report_accompany_clicks_name ON report.accompany_clicks (accompany_name);
CREATE INDEX idx_report_accompany_clicks_branch ON report.accompany_clicks (branch_id);

COMMENT ON TABLE report.accompany_clicks IS '歌曲点击记录';