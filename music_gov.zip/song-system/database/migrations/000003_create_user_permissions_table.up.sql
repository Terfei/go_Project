CREATE TABLE IF NOT EXISTS "user".permissions (
    id SERIAL primary key,
    system varchar(16) not null,
    permission varchar(256) not null,
    created_at timestamp not null,
    updated_at timestamp not null
);

COMMENT ON TABLE "user".permissions IS '权限点';
COMMENT ON COLUMN "user".permissions.system IS '系统 admin后台';
COMMENT ON COLUMN "user".permissions.permission IS '权限';

