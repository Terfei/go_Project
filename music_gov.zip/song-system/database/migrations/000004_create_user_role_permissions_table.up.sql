CREATE TABLE IF NOT EXISTS "user".role_permissions (
    id SERIAL primary key,
    role_id int not null,
    permission_id int not null
);

create UNIQUE INDEX idx_unique_user_role_permissions ON "user".role_permissions (role_id,permission_id);

COMMENT ON TABLE "user".role_permissions IS '角色权限';
COMMENT ON COLUMN "user".role_permissions.role_id IS '角色';
COMMENT ON COLUMN "user".role_permissions.permission_id IS '权限';

