CREATE TABLE IF NOT EXISTS song.accompany_audioqlty (
    id serial primary key,
    code varchar(128) not null,
    image varchar(256),
    seq int default 0,
    is_show int default 0,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);

COMMENT ON TABLE song.accompany_audioqlty IS '伴奏音频质量';
