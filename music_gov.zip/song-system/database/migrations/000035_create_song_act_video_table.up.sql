CREATE TABLE IF NOT EXISTS song.act_video (
    id SERIAL primary key,
    accompany_id int default 0,
    accompany_name varchar(64),
    accompany_filename varchar(32),
    accompany_name_spell varchar(64),
    audio int default 0,
    host_ip varchar(16),
    image varchar(32),
    category_id int default 0,
    act_video_type int default 0,
    char_count int default 0,
    rank int default 0,
    lamp_id int default 0,
    effect_id int default 0,
    reverberation_id int default 0,
    songno varchar(32),
    overview_id int default 0,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);

COMMENT ON TABLE song.act_video IS '跳舞视频';
