CREATE TABLE IF NOT EXISTS song.accompany (
    id SERIAL primary key,
    name varchar(128) not null,
    name_spell varchar(128),
    char_count int default 0,
    singers jsonb,
    singer_name_all varchar(256),
    audio int default 0,
    songno varchar(20) not null,
    filename varchar(256) not null,
    release_time date not null,
    ext varchar(10) not null,
    mid_filepath varchar(256),
    language_id int default 0,
    channel varchar(10),
    version_id int default 0,
    category_id int default 0,
    effect_id int  default 0,
    lamp_id int default 0,
    tag_id int default 0,
    reverberation_group varchar(32),
    server_path varchar(128),
    rank int default 0,
    videoqlty_id int default 0,
    audioqlty_id int default 0,
    emo_tag_ids _int4,
    overview_id int default 0,
    created_at timestamp not null,
    updated_at timestamp not null,
    deleted_at timestamp
);

create INDEX idx_unique_song_accompany_songno ON song.accompany (songno);

COMMENT ON TABLE song.accompany IS '伴奏';
COMMENT ON COLUMN song.accompany.id IS '伴奏ＩＤ';
COMMENT ON COLUMN song.accompany.name IS '伴奏名';
COMMENT ON COLUMN song.accompany.name_spell IS '伴奏名拼音';
COMMENT ON COLUMN song.accompany.char_count IS '歌名字数';
COMMENT ON COLUMN song.accompany.singers IS '歌手 {"singer1":{"name" : "张学友", "id" : 1},"singer2":{"name" : "刘德华", "id" : 1}}';
COMMENT ON COLUMN song.accompany.singer_name_all IS '所有歌手名';
COMMENT ON COLUMN song.accompany.audio IS '播放器音量值';
COMMENT ON COLUMN song.accompany.songno IS '歌曲编码';
COMMENT ON COLUMN song.accompany.filename IS '文件名';
COMMENT ON COLUMN song.accompany.release_time IS '更新时间';
COMMENT ON COLUMN song.accompany.language_id IS '语种';
COMMENT ON COLUMN song.accompany.channel IS '伴奏音轨';
COMMENT ON COLUMN song.accompany.version_id IS '播放器音量值';
COMMENT ON COLUMN song.accompany.category_id IS '分类';
COMMENT ON COLUMN song.accompany.ext IS '后缀';
COMMENT ON COLUMN song.accompany.mid_filepath IS 'mid文件路径';
COMMENT ON COLUMN song.accompany.effect_id IS '音乐效果id';
COMMENT ON COLUMN song.accompany.lamp_id IS '灯光效果id';
COMMENT ON COLUMN song.accompany.reverberation_group IS ' 灯光组';
COMMENT ON COLUMN song.accompany.server_path IS ' 歌曲文件映射路径';
COMMENT ON COLUMN song.accompany.channel IS '排名';
COMMENT ON COLUMN song.accompany.videoqlty_id IS '视频质量';
COMMENT ON COLUMN song.accompany.audioqlty_id IS '音频质量';
COMMENT ON COLUMN song.accompany.emo_tag_ids IS '情绪标签';
COMMENT ON COLUMN song.accompany.ext IS '后缀';
COMMENT ON COLUMN song.accompany.mid_filepath IS 'mid文件路径';