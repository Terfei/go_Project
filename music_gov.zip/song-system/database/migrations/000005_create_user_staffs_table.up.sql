CREATE TABLE IF NOT EXISTS "user".staffs (
    id uuid primary key,
    code int4 not null,
    created_at timestamp not null,
    updated_at timestamp not null
);

COMMENT ON TABLE "user".staffs IS '员工角色';
COMMENT ON COLUMN "user".staffs.id IS '员工id';
COMMENT ON COLUMN "user".staffs.code IS '编号';

