package util

import (
	"fmt"
	"os"
	"os/exec"
	"strings"
)

// archive := util.NewArchive(`localedb.7z`, `/Users/alex/`)
// err := archive.Compression([]string{fmt.Sprintf(`%s/*`, config.Setting.App.Root)})
// if err != nil {
// 	log.Fatalf("cmd.Run() failed with %s\n", err)
// }

// Archive 压缩与解压
type Archive struct {
	FileName string
	FilePath string
}

// NewArchive 创建对象
func NewArchive(filename, filepath string) *Archive {
	return &Archive{
		FileName: filename,
		FilePath: filepath,
	}
}

// Compression 压缩
func (ar *Archive) Compression(files []string) (err error) {
	fs := strings.Join(files, ` `)
	cmd := fmt.Sprintf(`7z a -t7z %s/%s %s`, ar.FilePath, ar.FileName, fs)
	err = exec.Command(`/bin/sh`, `-c`, cmd).Run()
	return
}

// File 得到文件对象
func (ar *Archive) File() (os.FileInfo, error) {
	return os.Stat(fmt.Sprintf(`%s/%s`, ar.FilePath, ar.FileName))
}

// CompressionFile 压缩单个文件
func (ar *Archive) CompressionFile() (err error) {
	cmd := fmt.Sprintf("7za a -t7z %s %s", ar.FileName, ar.FilePath)
	err = exec.Command(`/bin/sh`, `-c`, cmd).Run()

	return
}

// UnCompression 解压
func (ar *Archive) UnCompression() (err error) {
	cmd := fmt.Sprintf("7z x -aoa %s -o%s", ar.FileName, ar.FilePath)
	fmt.Println(cmd)
	err = exec.Command(`/bin/sh`, `-c`, cmd).Run()

	return
}
