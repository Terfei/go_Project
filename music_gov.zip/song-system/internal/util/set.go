package util

import (
	"sort"
	"strconv"
	"strings"
	"sync"
)

type (
	// Set 集合
	Set struct {
		sync.RWMutex
		m map[int]bool
	}

	// SetRange 集合区间
	SetRange struct {
		Begin int
		End   int
	}
)

// NewSet 新建集合对象
func NewSet(items ...int) *Set {
	s := &Set{
		m: make(map[int]bool, len(items)),
	}
	s.Add(items...)
	return s
}

// NewSetInt64 新建集合对象
func NewSetInt64(items ...int64) *Set {
	var rs []int
	for _, v := range items {
		rs = append(rs, int(v))
	}

	s := &Set{
		m: make(map[int]bool, len(items)),
	}
	s.Add(rs...)
	return s
}

// Add 添加元素
func (s *Set) Add(items ...int) {
	s.Lock()
	defer s.Unlock()
	for _, v := range items {
		s.m[v] = true
	}
}

// Remove 删除元素
func (s *Set) Remove(items ...int) {
	s.Lock()
	defer s.Unlock()
	for _, v := range items {
		delete(s.m, v)
	}
}

// Has 判断元素是否存在
func (s *Set) Has(items ...int) bool {
	s.RLock()
	defer s.RUnlock()
	for _, v := range items {
		if _, ok := s.m[v]; !ok {
			return false
		}
	}
	return true
}

// Count 元素个数
func (s *Set) Count() int {
	return len(s.m)
}

// Clear 清空集合
func (s *Set) Clear() {
	s.Lock()
	defer s.Unlock()
	s.m = map[int]bool{}
}

// Empty 空集合判断
func (s *Set) Empty() bool {
	return len(s.m) == 0
}

// List 无序列表
func (s *Set) List() []int {
	s.RLock()
	defer s.RUnlock()
	list := make([]int, 0, len(s.m))
	for item := range s.m {
		list = append(list, item)
	}
	return list
}

// SortList 排序列表
func (s *Set) SortList() []int {
	s.RLock()
	defer s.RUnlock()
	list := make([]int, 0, len(s.m))
	for item := range s.m {
		list = append(list, item)
	}
	sort.Ints(list)
	return list
}

// Int64SortList 排序列表
func (s *Set) Int64SortList() []int64 {
	s.RLock()
	defer s.RUnlock()
	list := make([]int, 0, len(s.m))
	for item := range s.m {
		list = append(list, item)
	}
	sort.Ints(list)

	result := make([]int64, 0, len(list))
	for _, v := range list {
		result = append(result, int64(v))
	}

	return result
}

// Union 并集
func (s *Set) Union(sets ...*Set) *Set {
	r := NewSet(s.List()...)
	for _, set := range sets {
		for e := range set.m {
			r.m[e] = true
		}
	}
	return r
}

// Minus 差集
func (s *Set) Minus(sets ...*Set) *Set {
	r := NewSet(s.List()...)
	for _, set := range sets {
		for e := range set.m {
			if _, ok := s.m[e]; ok {
				delete(r.m, e)
			}
		}
	}
	return r
}

// Intersect 交集
func (s *Set) Intersect(sets ...*Set) *Set {
	r := NewSet(s.List()...)
	for _, set := range sets {
		for e := range s.m {
			if _, ok := set.m[e]; !ok {
				delete(r.m, e)
			}
		}
	}
	return r
}

// Complement 补集
func (s *Set) Complement(full *Set) *Set {
	r := NewSet()
	for e := range full.m {
		if _, ok := s.m[e]; !ok {
			r.Add(e)
		}
	}
	return r
}

// Join 连接成字符串
func (s *Set) Join(sep string) string {
	elems := make([]string, 0)
	for _, v := range s.Int64SortList() {
		elems = append(elems, strconv.FormatInt(v, 10))
	}

	return strings.Join(elems, sep)
}

// Equal 是否相等
func (s *Set) Equal(s2 *Set) bool {
	if s.Count() != s2.Count() {
		return false
	}

	if !s.Minus(s2).Empty() {
		return false
	}

	if !s.Complement(s2).Empty() {
		return false
	}

	return true
}

// Ranges 获取对应的区间段
func (s *Set) Ranges() (res []SetRange) {
	s.RLock()
	defer s.RUnlock()

	flag, begin, before := false, 0, 0
	for k, v := range s.SortList() {
		flag = true
		if k == 0 {
			begin, before = v, v
			continue
		}

		if (before + 1) != v {
			res = append(res, SetRange{
				Begin: begin,
				End:   before,
			})
			begin = v
		}
		before = v
	}
	if flag {
		res = append(res, SetRange{
			Begin: begin,
			End:   before,
		})
	}

	return
}
