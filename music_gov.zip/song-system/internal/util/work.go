package util

import (
	"sync"
)

// Work ...
type Work struct {
	data chan interface{}
	wait sync.WaitGroup
}

// NewWork ...
func NewWork(num int) *Work {
	ch := make(chan interface{}, num)

	return &Work{
		data: ch,
		wait: sync.WaitGroup{},
	}
}

// Add ...
func (w *Work) Add(i interface{}) {
	w.data <- i
	w.wait.Add(1)
}

// Done 处理完成
func (w *Work) Done() {
LOOP:
	for {
		select {
		case <-w.data:
			break LOOP
		}
	}
	w.wait.Done()
}

// Wait ...
func (w *Work) Wait() {
	w.wait.Wait()
}
