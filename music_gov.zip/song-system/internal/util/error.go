package util

import "fmt"

// ErrPassword 密码错误
var ErrPassword = fmt.Errorf("密码错误")

// ErrLoginNotFound ...
var ErrLoginNotFound = fmt.Errorf("登录信息不存在")
