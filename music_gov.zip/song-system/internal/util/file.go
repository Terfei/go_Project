package util

import (
	"fmt"
	"github.com/360EntSecGroup-Skylar/excelize"
	"github.com/gin-gonic/gin"
	"github.com/sirupsen/logrus"
	"github.com/tealeg/xlsx"
	"gitlab.omytech.com.cn/gopkg/logger"
	"io/ioutil"
)

// GetHeaderStyle excel头部居中加粗样式
func GetHeaderStyle(f *excelize.File) (int, error) {
	return f.NewStyle(`{"alignment":{"horizontal":"center", "vertical":"middle", "warp_text":true},"font":{"bold":true}}`)
}

// GetCenterStyle excel水平居中样式
func GetCenterStyle() *xlsx.Style {
	// CenterStyle
	CenterStyle := xlsx.NewStyle()
	CenterStyle.ApplyAlignment = true
	CenterStyle.Alignment.WrapText = true
	CenterStyle.Alignment.Horizontal = "Center"

	return CenterStyle
}

// ExportXlsx 导出Excel 文件
func ExportXlsx(xf *excelize.File, filename string, c *gin.Context) {
	c.Header("Content-Type", "application/octet-stream")
	c.Header("Content-Disposition", "attachment;filename="+filename)
	c.Header("Content-Transfer-Encoding", "binary")

	xf.Write(c.Writer)
}

// InitializeXlsx 初始化导出excel
func InitializeXlsx() (xlsx *excelize.File, sheet string) {
	sheet = `Sheet1`
	xlsx = excelize.NewFile()
	xlsx.NewSheet(sheet)

	return
}

// HTTPExcelContents 读取http file excel信息
func HTTPExcelContents(c *gin.Context) (*xlsx.File, error) {
	file, err := c.FormFile("file")
	if nil != err {
		return nil, err
	}
	f, _ := file.Open()
	defer f.Close()

	bytes, err := ioutil.ReadAll(f)
	if nil != err {
		return nil, err
	}

	return xlsx.OpenBinary(bytes)
}

// ExcelData 新增伴奏excel处理
type ExcelData struct {
	Params   []Params
	Titles   map[int]string
	Response ExcelResponse
}

// ExcelResponse excel返回
type ExcelResponse struct {
	Total int    `json:"total"`
	Fail  string `json:"fail"`
}

// NormalizeExcelData 标准化excel数据
func NormalizeExcelData(file *xlsx.File, timeCols map[string]string, relationTag string) (d ExcelData) {
	d.Response.Total = 0
	d.Titles = make(map[int]string)

	for _, sheet := range file.Sheets {
		for i, row := range sheet.Rows {
			if row.Hidden {
				continue
			}

			p := Params{}
			for j, cell := range row.Cells {
				if i == 0 {
					d.Titles[j] = cell.String()
					continue
				}

				t := d.Titles[j]
				p.Set(t, cell.String())
				if _, ok := timeCols[t]; ok {
					c, err := cell.GetTime(false)
					if nil != err {
						logger.Entry().WithFields(logrus.Fields{
							"value": cell.Value,
							"style": cell.GetStyle(),
							"title": t,
						}).Error("time error")
						d.Response.Fail = fmt.Sprintf("行:%d, 列:%d, 表头:%s, 关键词:%s", i, j, t, p.GetString(relationTag))
						return
					}

					p.Set(t, c.Format(`2006-01-02`))
				}
			}

			if i > 0 && p.GetString(relationTag) != `` {
				d.Response.Total++
				d.Params = append(d.Params, p)
			}
		}
	}

	return
}
