package util

import (
	"database/sql/driver"
	"strconv"
	"time"

	"github.com/pkg/errors"
	"github.com/uniplaces/carbon"
)

const (
	// MonthSize 月份长度
	MonthSize = 7
	// MonthFormat 月份格式
	MonthFormat = `2006-01`
	// LocationArea 区域
	LocationArea = `Asia/Chongqing`
)

// Month 报表月
type Month [7]byte

// NilMonth 空ReportMonth
var NilMonth = Month{}

// MarshalText 实现encoding.TextMarshaler
func (r Month) MarshalText() (text []byte, err error) {
	if NilMonth == r {
		return
	}

	dst := make([]byte, len(r[:]))
	copy(dst, r[:])
	text = dst

	return
}

// UnmarshalText 实现encoding.TextUnmarshaler
func (r *Month) UnmarshalText(text []byte) error {
	copy(r[:], text)

	return nil
}

// Value 序列化数据到数据库
func (r Month) Value() (driver.Value, error) {
	return r[:], nil
}

// Scan 反序列化数据库数据到结构体
func (r *Month) Scan(src interface{}) error {
	if nil == src {
		return nil
	}

	reportMonth, err := FromBytes(src.([]byte))
	if nil != err {
		return err
	}
	*r = reportMonth

	return nil
}

// FormatCn 转换为中文显示
// 2020年02月
// func (r Month) FormatCn() string {
// 	if NilMonth == r {
// 		return ""
// 	}

// 	return fmt.Sprintf("%s年%s月", r[:4], r[5:])
// }

// String 转换为字符串
func (r Month) String() string {
	if NilMonth == r {
		return ""
	}

	return string(r[:])
}

// Bytes 返回字节切片
func (r Month) Bytes() []byte {
	return r[:]
}

// Year 返回年
func (r Month) Year() int {
	y := r[:4]
	year, _ := strconv.Atoi(string(y))

	return year
}

// Month 返回月
func (r Month) Month() time.Month {
	m := r[5:]
	month, _ := strconv.Atoi(string(m))

	return time.Month(month)
}

// FirstDayOfMonth 返回月份的第一天零时
func (r Month) FirstDayOfMonth() time.Time {
	// loc, _ := time.LoadLocation(LocationArea)
	// return time.Date(r.Year(), r.Month(), 1, 0, 0, 0, 0, loc)
	cur, _ := carbon.CreateFromMonthAndYear(r.Year(), r.Month(), LocationArea)

	return cur.StartOfMonth().Time

}

// LastDayOfMonth 返回月份的最后一天23:59:59
func (r Month) LastDayOfMonth() time.Time {
	// loc, _ := time.LoadLocation(LocationArea)
	// return time.Date(r.Year(), r.Month(), 1, 0, 0, 0, 0, loc)
	cur, _ := carbon.CreateFromMonthAndYear(r.Year(), r.Month(), LocationArea)

	return cur.EndOfMonth().Time
}

// FromString  通过字符串的方式创建ReportMonth 对象
func FromString(src string) (Month, error) {
	return FromBytes([]byte(src))
}

// FromBytes 通过字节切片的方式创建ReportMonth 对象
func FromBytes(src []byte) (Month, error) {
	if MonthSize != len(src) {
		return NilMonth, errors.New("创建ReportMonth源数据长度不正确")
	}

	if '-' != src[4] {
		return NilMonth, errors.New("创建ReportMonth源数据格式错误")
	}

	var r Month
	err := r.UnmarshalText(src)
	if nil != err {
		return NilMonth, err
	}

	return r, nil
}

// FromStringWithNil 根据字符串创建
func FromStringWithNil(src string) Month {
	r, _ := FromString(src)

	return r
}

// FromBytesWithNil 根据字节切片创建
func FromBytesWithNil(src []byte) Month {
	r, _ := FromBytes(src)

	return r
}

// FromNow 根据当前时间创建
func FromNow() Month {
	t := time.Now().Format(MonthFormat)

	return FromStringWithNil(t)
}

// FromTime 根据给定时间得到报表月
func FromTime(t time.Time) Month {
	return FromStringWithNil(t.Format(MonthFormat))
}
