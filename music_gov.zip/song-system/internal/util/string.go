package util

import (
	"fmt"
	"github.com/lib/pq"
	"strconv"
	"strings"

	"github.com/pkg/errors"
	uuid "github.com/satori/go.uuid"
)

// StringInt 字符串类型的数字
// 主要是用来解决数据库中存储的本来是数字，但是类型确实字符串的情况
// 自定义  StringInt 可以在 UnmarshalJSON 的时候将类型转换成int
type StringInt int

// UnmarshalJSON 实现 json.JSONUnmarshaler 接口
func (si *StringInt) UnmarshalJSON(b []byte) error {
	str := strings.Trim(string(b), `"`)
	i, err := strconv.Atoi(str)
	if nil != err {

		return errors.Wrap(err, "StringInt转换字符串为整型")
	}
	*si = StringInt(i)

	return nil
}

// StringToByte string to byte
func StringToByte(s string) []byte {
	return []byte(s)
}

// StringUUID 字符串bind Request
type StringUUID string

// UnmarshalJSON 实现json.JSONUnmarshaler接口
func (su *StringUUID) UnmarshalJSON(b []byte) error {
	if _, err := su.UUID(); err != nil {
		return err
	}

	return nil
}

// UUID 转换为uuid类型
func (su *StringUUID) UUID() (uuid.UUID, error) {
	return uuid.FromString(su.String())
}

func (su *StringUUID) String() string {
	return string(*su)
}

// IntStringToPqInt64Arr int string to pq int array 1,2,3 => [1,2,3]
func IntStringToPqInt64Arr(s string) (*pq.Int64Array, error) {
	a := pq.Int64Array{}
	if len(s) == 0 {
		return &a, nil
	}

	for _, s := range strings.Split(s, ",") {
		i, _ := strconv.Atoi(s)

		a = append(a, int64(i))
	}

	return &a, nil
}

// Int64ArrayToIntString pq int64 array to int string
func Int64ArrayToIntString(array *pq.Int64Array) string {
	var item []string

	if len(*array) != 0 {
		fmt.Println("len")
		for _, i := range *array {
			item = append(item, strconv.FormatInt(i, 10))
		}
	}

	return strings.Join(item, ",")
}
