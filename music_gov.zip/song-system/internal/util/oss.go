package util

import (
	"fmt"
	"gitlab.omytech.com.cn/gopkg/logger"
	"os"
	"strings"
	"time"

	"github.com/aliyun/aliyun-oss-go-sdk/oss"
	"github.com/aliyun/aliyun-sts-go-sdk/sts"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
)

const (
	// sessionName 阿里云sts会话
	sessionName string = `song-system`
	// expireDuration 过期时间
	expireDuration uint = 3600
)

// AliyunOss 阿里云oss结构体
type AliyunOss struct {
	Config      config.OssConfig
	stsClient   *sts.Client
	ossClient   *oss.Client
	stsSecurity *sts.Response
	bucket      *oss.Bucket
}

// NewAliyunOss 新建对象
func NewAliyunOss(conf config.OssConfig) *AliyunOss {
	stsClient := sts.NewClient(conf.AccessID, conf.AccessKey, conf.AcsRAM, sessionName)
	resp, err := stsClient.AssumeRole(expireDuration)
	if nil != err {
		logger.Entry().Error("获取阿里云sts token错误" + err.Error())
	}

	ossClient, err := oss.New(
		conf.Endpoint,
		resp.Credentials.AccessKeyId,
		resp.Credentials.AccessKeySecret,
		oss.SecurityToken(resp.Credentials.SecurityToken),
	)
	if err != nil {
		logger.Entry().Error("Oss client初始化错误" + err.Error())
	}

	bucket, err := ossClient.Bucket(conf.Bucket)
	if err != nil {
		logger.Entry().Error("Oss bucket初始化错误" + err.Error())
	}

	return &AliyunOss{
		Config:      conf,
		stsClient:   stsClient,
		ossClient:   ossClient,
		stsSecurity: resp,
		bucket:      bucket,
	}
}

// StsToken 获取oss临时签名
func (ao *AliyunOss) StsToken() (*sts.Response, error) {
	if ao.stsSecurity.Credentials.Expiration.Before(time.Now()) {
		return ao.stsSecurity, nil
	}

	resp, err := ao.stsClient.AssumeRole(expireDuration)
	if nil != err {
		logger.Entry().Error("获取阿里云sts token错误" + err.Error())
		return resp, err
	}

	ao.stsSecurity = resp

	return resp, nil
}

// Upload 上传文件
func (ao *AliyunOss) Upload(f *os.File, ossPath string) error {
	err := ao.bucket.PutObject(ossPath, f)
	if err != nil {
		logger.Entry().Error("上传文件至oss报错" + err.Error())
		return err
	}

	return nil
}

// GetObjectMetaCrc64 object meta
func (ao *AliyunOss) GetObjectMetaCrc64(file string) (crc64 string, err error) {
	meta, err := ao.bucket.GetObjectMeta(file)
	if err != nil {
		return
	}
	crc64 = strings.Trim(meta.Get("X-Oss-Hash-Crc64ecma"), `"`)

	return
}

// ListObjects 遍历文件
func (ao *AliyunOss) ListObjects(prefix string) {
	// 遍历文件。
	rst, err := ao.bucket.ListObjects(oss.Marker(""), oss.Prefix(prefix))
	if err != nil {
		logger.Entry().WithError(err).Error("oss list object error")
	}

	for _, obj := range rst.Objects {
		fmt.Println(obj.Key)

		//fmt.Println(ao.DeleteObject(obj.Key))
	}
}

// DeleteObject 删除文件
func (ao *AliyunOss) DeleteObject(filename string) error {
	logger.Entry().WithField("filename", filename).Info("删除aliyun oss")
	return ao.bucket.DeleteObject(filename)
}

// GetToFile 获取文件crc64并下载
func (ao *AliyunOss) GetToFile(localFile, ossFile string) (crc64 string, err error) {
	meta, err := ao.bucket.GetObjectMeta(ossFile)
	if err != nil {
		return
	}

	crc64 = strings.Trim(meta.Get("X-Oss-Hash-Crc64ecma"), `"`)
	err = ao.bucket.GetObjectToFile(ossFile, localFile)

	return
}
