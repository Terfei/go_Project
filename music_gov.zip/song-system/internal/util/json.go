package util

import (
	"bytes"
	"database/sql/driver"
	"encoding/json"
	"fmt"
	"github.com/pkg/errors"
	uuid "github.com/satori/go.uuid"
	"strconv"
	"strings"
)

// IntArr int array
type IntArr []int

// Value 转换为数据库字段类型
func (ua IntArr) Value() (driver.Value, error) {
	var s []string
	for _, u := range ua {
		fmt.Println(u)
		fmt.Println(strconv.Itoa(u))
		s = append(s, string(u))
	}

	return fmt.Sprintf("{%s}", strings.Join(s, ",")), nil
}

// UUIDArr 数组类型的UUID 集合
// 数据库数据格式是 []uuid
type UUIDArr []uuid.UUID

// Value 转换为数据库字段类型
func (ua UUIDArr) Value() (driver.Value, error) {
	var b []byte
	b = append(b, '{')
	for _, u := range ua {
		b = append(b, u.Bytes()...)
	}
	b = append(b, '}')

	return b, nil
}

// Slice slice
func (ua UUIDArr) Slice() []uuid.UUID {
	var response []uuid.UUID

	for _, id := range ua {
		response = append(response, id)
	}

	return response
}

// Scan 将数据库数据映射到结构体
func (ua *UUIDArr) Scan(src interface{}) error {
	if nil == src {
		return nil
	}

	b := src.([]byte)
	b = b[1 : len(b)-1]
	bs := bytes.Split(b, []byte(","))
	ms := make(UUIDArr, len(bs))
	for i, b := range bs {
		u := uuid.FromStringOrNil(string(b))
		ms[i] = u
	}
	*ua = ms

	return nil
}

// UUIDJSON json类型的UUID 集合
// 应对数据库存储数据的时候，数据格式设置成了json
type UUIDJSON []uuid.UUID

// Value 转换为数据库字段类型
func (uj UUIDJSON) Value() (driver.Value, error) {
	return json.Marshal(uj)
}

// Scan 将数据库数据映射到结构体
func (uj *UUIDJSON) Scan(src interface{}) error {
	return ScanJSON(uj, src)
}

// StringJSON 只保存了字符串集合的json格式
type StringJSON []string

// Value 返回数据库可识别类型
func (sj StringJSON) Value() (driver.Value, error) {
	return json.Marshal(sj)
}

// Scan 反解析数据库数据到结构体
func (sj *StringJSON) Scan(src interface{}) error {
	return ScanJSON(sj, src)
}

// ScanJSON 将数据库中的字段数据映射到结构体中
// 因为这个操作大多数都是一样的，这里就做一个简单的helper抽取
func ScanJSON(dest, src interface{}) error {
	if nil == src {
		return nil
	}

	switch v := src.(type) {
	case []byte:
		if err := json.Unmarshal(v, &dest); nil != err {
			return nil
		}

		return json.Unmarshal(v, &dest)
	case string:
		return json.Unmarshal([]byte(v), dest)
	default:
		return errors.WithStack(fmt.Errorf("反解析数据库数据到结构体失败"))
	}
}
