package util

import (
	"fmt"
	"hash/crc64"
	"io/ioutil"
	"net/http"
	"strings"
	"time"
)

// FileCRC64 获取文件 crc64
func FileCRC64(filenameOrURL string) (uint64, error) {
	data, err := FileGetBytes(filenameOrURL)
	if err != nil {
		return 0, err
	}
	return crc64.Checksum(data, crc64.MakeTable(crc64.ECMA)), nil
}

// FileCRC64String 文件 crc64 string
func FileCRC64String(filenameOrURL string) (string, error) {
	data, err := FileGetBytes(filenameOrURL)
	if err != nil {
		return "", err
	}

	i := crc64.Checksum(data, crc64.MakeTable(crc64.ECMA))

	return fmt.Sprintf("%d", i), nil
}

// FileGetBytes 获取文件 byte
func FileGetBytes(filenameOrURL string, timeout ...time.Duration) ([]byte, error) {
	if strings.Contains(filenameOrURL, "://") {
		if strings.Index(filenameOrURL, "file://") == 0 {
			filenameOrURL = filenameOrURL[len("file://"):]
		} else {
			client := http.DefaultClient
			if len(timeout) > 0 {
				client = &http.Client{Timeout: timeout[0]}
			}
			r, err := client.Get(filenameOrURL)
			if err != nil {
				return nil, err
			}
			defer r.Body.Close()
			return ioutil.ReadAll(r.Body)
		}
	}
	return ioutil.ReadFile(filenameOrURL)
}
