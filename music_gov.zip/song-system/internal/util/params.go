package util

import (
	"database/sql/driver"
	"encoding/json"
	"strconv"

	"github.com/pkg/errors"
)

// Params map[string]interface{}
type Params map[string]interface{}

// Set 设置值
func (p Params) Set(k string, v interface{}) Params {
	p[k] = v

	return p
}

// Get 获取值
func (p Params) Get(k string) (v interface{}) {
	if v, ok := p[k]; ok {
		return v
	}

	return nil
}

// GetString 强制获取k对应的v string类型
func (p Params) GetString(k string) string {
	v, _ := p[k]

	return InterfaceToString(v)
}

// GetInt 强制获取k对应的v int类型
func (p Params) GetInt(k string) int {
	v, _ := p[k]

	return InterfaceToInt(v)
}

// Exists 判断是否存在
func (p Params) Exists(k string) bool {
	_, ok := p[k]

	return ok
}

// InterfaceToString 不定类型强制装换为string
func InterfaceToString(value interface{}) string {
	if value == nil {
		return ""
	}

	return value.(string)
}

// InterfaceToInt 不定类型强制装换为int
func InterfaceToInt(value interface{}) int {
	if value == nil {
		return 0
	}

	switch value.(type) {
	case string:
		v, _ := strconv.Atoi(value.(string))
		return v
	case int:
		return value.(int)
	}

	return value.(int)
}

// Value 返回数据库可识别类型
func (p Params) Value() (driver.Value, error) {
	return json.Marshal(p)
}

// Scan ...
func (p *Params) Scan(src interface{}) error {
	bytes, ok := src.([]byte)
	if !ok {
		return errors.New("util params value")
	}

	if err := json.Unmarshal(bytes, p); nil != err {
		return errors.New("util params value error")
	}

	return nil
}

// MakeParams 生成params
func MakeParams(data interface{}) Params {
	p := make(Params)

	j, e := json.Marshal(data)
	if e != nil {
		return p
	}

	if err := json.Unmarshal(j, &p); nil != err {
		return Params{}
	}

	return p
}
