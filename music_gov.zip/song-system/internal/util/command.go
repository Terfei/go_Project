package util

import (
	"fmt"
	"github.com/sirupsen/logrus"
	"gitlab.omytech.com.cn/gopkg/logger"
	"os"
	"os/exec"
)

// CpFile cp 文件
func CpFile(old, new string) error {
	c := fmt.Sprintf("cp %s %s", old, new)

	logger.Entry().WithFields(logrus.Fields{
		"old": old,
		"new": new,
		"cmd": c,
	}).Info("复制文件")

	cmd := exec.Command("/bin/bash", "-c", c)

	if err := cmd.Start(); nil != err {
		return err
	}

	if err := cmd.Wait(); nil != err {
		return err
	}

	return nil
}

// MvFile mv file
func MvFile(old, new string) error {
	c := fmt.Sprintf("mv %s %s", old, new)

	logger.Entry().WithField("mv file", c).Info("移动文件")

	cmd := exec.Command("/bin/bash", "-c", c)

	if err := cmd.Start(); nil != err {
		return err
	}

	if err := cmd.Wait(); nil != err {
		return err
	}

	return nil
}

// Mkdir mkdir
func Mkdir(path string) error {
	logger.Entry().WithField("folder", path).Info("处理文件夹")
	_, err := os.Stat(path)

	if os.IsNotExist(err) {
		return os.MkdirAll(path, os.ModePerm)
	}

	return nil
}

// DelDir 删除文件夹
func DelDir(dir string) error {
	logger.Entry().WithField("folder", dir).Info("删除文件夹")

	_, err := os.Stat(dir)

	if os.IsNotExist(err) {
		return nil
	}

	cmd := exec.Command("/bin/bash", "-c", fmt.Sprintf("rm -rf %s", dir))

	if err := cmd.Start(); nil != err {
		return err
	}

	if err := cmd.Wait(); nil != err {
		return err
	}

	return nil
}

// FileExists 判断文件是否存在
func FileExists(path string) (bool, error) {
	_, err := os.Stat(path)
	if err == nil {
		return true, nil
	}
	if os.IsNotExist(err) {
		return false, nil
	}
	return false, err
}

// DiffDir 文件夹是否相同
func DiffDir(dir1, dir2 string) ([]byte, error) {
	cmd := exec.Command("/bin/bash", "-c", fmt.Sprintf("diff -qr %s %s", dir1, dir2))

	return cmd.Output()
}
