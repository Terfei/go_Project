package util

import (
	"bytes"
	"encoding/json"
	"fmt"
	"github.com/sirupsen/logrus"
	"gitlab.omytech.com.cn/gopkg/logger"
	"io/ioutil"
	"net/http"
)

// HTTPPost http post
func HTTPPost(url string, params Params, code int) ([]byte, error) {
	logger.Entry().WithFields(logrus.Fields{
		"url":    url,
		"params": params,
	}).Info("http post 请求")

	jsonStr, _ := json.Marshal(params)
	req, _ := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	req.Header.Add("content-type", "application/json")
	defer req.Body.Close()

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	logger.Entry().WithFields(logrus.Fields{
		"url":           url,
		"params":        params,
		"response_code": resp.StatusCode,
	}).Info("http post 请求响应")

	if code != resp.StatusCode {
		return nil, fmt.Errorf("status code:%d", resp.StatusCode)
	}

	return ioutil.ReadAll(resp.Body)
}

//HTTPGet get 请求
func HTTPGet(url string) ([]byte, error) {
	logger.Entry().WithField("url", url).Info("http get 请求")
	response, err := http.Get(url)
	if err != nil {
		return nil, err
	}

	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("http get error : uri=%v , statusCode=%v", url, response.StatusCode)
	}
	return ioutil.ReadAll(response.Body)
}
