package model

import (
	"gitlab.omytech.com.cn/gopkg/db/gorm"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
)

// SQLServerDB sql server db
var SQLServerDB gorm.Conn

// SQLServerConnection 初始化　sql server 连接
func SQLServerConnection(c config.DBConfig) {
	param := gorm.Config{
		Dialect:  gorm.ConfigDialectMssql,
		Server:   c.Server,
		Port:     c.Port,
		User:     c.User,
		Database: c.Database,
		Password: c.Password,
	}

	SQLServerDB = gorm.Build(param)

	SQLServerDB.LogMode(c.Log)
}
