package localdb

// TableAccompanyCategory 伴奏分类
const TableAccompanyCategory = `AccompanyCategory`

// AccompanyCategory 结构体
type AccompanyCategory struct {
	CategoryID      int    `json:"category_id"`
	CategoryName    string `json:"category_name"`
	CategoryNameKey string `json:"category_name_key"`
	CategoryImage   string `json:"category_image"`
	Seq             int8   `json:"seq"`
	Type            int8   `json:"type"`
	IsShow          int8   `json:"is_show"`
}

// TableName ...
func (a AccompanyCategory) TableName() string {
	return TableAccompanyCategory
}
