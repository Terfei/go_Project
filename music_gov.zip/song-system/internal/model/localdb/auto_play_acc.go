package localdb

import "gitlab.omytech.com.cn/vod/song-system/internal/util"

// TableAutoPlayAcc 公播
const TableAutoPlayAcc = `AutoPlay_Acc`

// AutoPlayAcc ...
type AutoPlayAcc struct {
	AutoplayAccID        int            `json:"autoplay_acc_id"`
	AutoplayAccName      string         `json:"autoplay_acc_name"`
	HostIP               string         `json:"host_ip"`
	AutoplayAccFilename  string         `json:"autoplay_acc_filename"`
	AutoplayAccFilename2 string         `json:"autoplay_acc_filename2"`
	ListID               int            `json:"list_id"`
	ListName             string         `json:"list_name"`
	Seq                  int            `json:"seq"`
	Codec                string         `json:"codec"`
	Channel              string         `json:"channel"`
	LampID               int            `json:"lamp_id"`
	ReverberationID      int            `json:"reverberation_id"`
	EffectID             int            `json:"effect_id"`
	Volume               int            `json:"volume"`
	Audio                int            `json:"audio"`
	StartTime            util.LocalTime `json:"start_time"`
	EndTime              util.LocalTime `json:"end_time"`
	Mode                 int            `json:"mode"`
	StrLevel             int            `json:"str_level"`
}

// TableName 公播
func (a AutoPlayAcc) TableName() string {
	return TableAutoPlayAcc
}
