package localdb

// TableVJ vj视频
const TableVJ = `vj`

// VJ vj
type VJ struct {
	VjID       int    `json:"vj_id"`
	VjName     string `json:"vj_name"`
	VjFilename string `json:"vj_filename"`
	Codec      string `json:"codec"`
	HostIP     string `json:"host_ip"`
	CategoryID int    `json:"category_id"`
}

// TableName table name
func (v VJ) TableName() string {
	return TableVJ
}
