package localdb

// TableBranchVersionDetail 版本分类
const TableBranchVersionDetail = `Sync_Version_Detail`

// BranchVersionDetail ...
type BranchVersionDetail struct {
	ID                int    `json:"id" gorm:"primary_key"`
	VersionID         int    `json:"version_id"`
	VersionCode       string `json:"version_code"`
	VersionCategoryID int    `json:"version_category_id"`
	RelationType      string `json:"relation_type"`
	RelationID        int    `json:"relation_id"`
	Dir               string `json:"dir"`
	Filename          string `json:"filename"`
	OssFilename       string `json:"oss_filename"`
	DiskFile          string `json:"disk_file"`
	IsDownload        int    `json:"is_download"`
}

// TableName ...
func (b BranchVersionDetail) TableName() string {
	return TableBranchVersionDetail
}
