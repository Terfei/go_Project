package localdb

// TableAccompanyTag 标签
const TableAccompanyTag = `AccompanyTag`

// AccompanyTag 标签结构体
type AccompanyTag struct {
	TagID   int    `json:"tag_id"`
	TagName string `json:"tag_name"`
	Seq     int8   `json:"seq"`
	IsShow  int8   `json:"is_show"`
}

// TableName ...
func (a AccompanyTag) TableName() string {
	return TableAccompanyTag
}
