package localdb

import "gitlab.omytech.com.cn/vod/song-system/internal/model"

// TableWallpaper 动态壁纸 table
const TableWallpaper = `Wallpaper`

// Wallpaper 动态壁纸
type Wallpaper struct {
	WallpaperID       int            `json:"wallpaper_id"`
	WallpaperNo       string         `json:"wallpaper_no"`
	WallpaperName     string         `json:"wallpaper_name"`
	WallpaperFilename string         `json:"wallpaper_filename"`
	Codec             string         `json:"codec"`
	Width             int            `json:"width"`
	Height            int            `json:"height"`
	HostIP            string         `json:"host_ip"`
	Location          string         `json:"location"`
	PipX              int            `json:"pip_x"`
	PipY              int            `json:"pip_y"`
	PngX              int            `json:"png_x"`
	PngY              int            `json:"png_y"`
	Pip2X             int            `json:"pip2_x"`
	Pip2Y             int            `json:"pip2_y"`
	Png2X             int            `json:"png2_x"`
	Png2Y             int            `json:"png2_y"`
	PipWidth          int            `json:"pip_width"`
	PipHeight         int            `json:"pip_height"`
	PngHostIP         string         `json:"png_host_ip"`
	PngCount          int            `json:"png_count"`
	EmoTagID          model.EmoTagID `json:"emo_tag_id"`
}

// TableName table name
func (w Wallpaper) TableName() string {
	return TableWallpaper
}
