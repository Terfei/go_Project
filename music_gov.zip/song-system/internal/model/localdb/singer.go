package localdb

import "gitlab.omytech.com.cn/vod/song-system/internal/model"

// TableSinger table
const TableSinger = `Singer`

// Singer 歌手结构体
type Singer struct {
	SingerID        int    `gorm:"primary_key" json:"singer_id"`
	SingerName      string `json:"singer_name"`
	SingerNickname  string `json:"singer_nickname"`
	SingerNameSpell string `json:"singer_name_spell"`
	CharCount       int    `json:"char_count"`
	SingerGender    int    `json:"singer_gender"`
	AreaID          int    `json:"area_id"`
	SingerImage     string `json:"singer_image"`
	Weight          int    `json:"weight"`
	Rank            int    `json:"rank"`
}

// TableName table name
func (s Singer) TableName() string {
	return TableSinger
}

// SingerByID 通过ＩＤ查询歌手信息
func SingerByID(id int) (singer *Singer, err error) {
	var s Singer

	if err := model.LocalDB.Where("singer_id = ?", id).First(&s).Error; nil != err {
		return nil, err
	}

	return &s, nil
}
