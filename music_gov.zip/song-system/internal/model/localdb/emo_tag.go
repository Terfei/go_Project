package localdb

// TableEmoTag 情绪标签
const TableEmoTag = `Emo_tag`

// EmoTag 情绪标签结构体
type EmoTag struct {
	EmoTagID    int    `json:"emo_tag_id"`
	EmoTagName  string `json:"emo_tag_name"`
	EmoTagKey   string `json:"emo_tag_key"`
	EmoTagImage string `json:"emo_tag_image"`
	Seq         int8   `json:"seq"`
	IsShow      int8   `json:"is_show"`
}

// TableName ...
func (a EmoTag) TableName() string {
	return TableEmoTag
}
