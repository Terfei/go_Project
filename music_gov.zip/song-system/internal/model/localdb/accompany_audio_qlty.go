package localdb

// TableAccompanyAudioQlty 伴奏音质
const TableAccompanyAudioQlty = `AccompanyAudioQlty`

// AccompanyAudioQlty 伴奏音质结构体
type AccompanyAudioQlty struct {
	AudioqltyID    int    `json:"audioqlty_id"`
	AudioqltyCode  string `json:"audioqlty_code"`
	Seq            int8   `json:"seq"`
	IsShow         int8   `json:"is_show"`
	AudioqltyImage string `json:"audioqlty_image"`
}

// TableName ...
func (a AccompanyAudioQlty) TableName() string {
	return TableAccompanyAudioQlty
}
