package localdb

// TableActVideo 跳舞视频
const TableActVideo = `Act_Video`

// ActVideo 跳舞视频
type ActVideo struct {
	AccompanyID        int    `json:"accompany_id"`
	AccompanyName      string `json:"accompany_name"`
	Audio              int    `json:"audio"`
	AccompanyNameSpell string `json:"accompany_name_spell"`
	HostIP             string `json:"host_ip"`
	AccompanyFilename  string `json:"accompany_filename"`
	Image              string `json:"image"`
	CategoryID         int    `json:"category_id"`
	Type               int    `json:"type"`
	CharCount          int    `json:"char_count"`
	Rank               int    `json:"rank"`
	LampID             int    `json:"lamp_id"`
	EffectID           int    `json:"effect_id"`
	ReverberationID    int    `json:"reverberation_id"`
	Songno             string `json:"songno"`
}

// TableName table name
func (a ActVideo) TableName() string {
	return TableActVideo
}
