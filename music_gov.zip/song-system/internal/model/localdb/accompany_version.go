package localdb

// TableAccompanyVersion 伴奏版本
const TableAccompanyVersion = `AccompanyVersion`

// AccompanyVersion 伴奏版本结构体
type AccompanyVersion struct {
	Seq         int8   `json:"seq"`
	VersionID   int    `json:"version_id"`
	VersionName string `json:"version_name"`
}

// TableName ...
func (a AccompanyVersion) TableName() string {
	return TableAccompanyVersion
}
