package localdb

// TableAccompanyLanguage 伴奏语种
const TableAccompanyLanguage = `AccompanyLanguage`

// AccompanyLanguage 伴奏语种结构体
type AccompanyLanguage struct {
	LanguageID      int    `json:"language_id"`
	LanguageName    string `json:"language_name"`
	LanguageNameKey string `json:"language_name_key"`
	LanguageImage   string `json:"language_image"`
	Seq             int8   `json:"seq"`
	IsShow          int8   `json:"is_show"`
}

// TableName ...
func (a AccompanyLanguage) TableName() string {
	return TableAccompanyLanguage
}
