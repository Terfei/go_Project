package localdb

import "gitlab.omytech.com.cn/vod/song-system/internal/util"

// TablePartyDance 排队舞曲
const TablePartyDance = `PartyDance`

// PartyDance 排队舞曲
type PartyDance struct {
	AccompanyID            int           `json:"accompany_id"`
	AccompanyName          string        `json:"accompany_name"`
	AccompanyNameSpell     string        `json:"accompany_name_spell"`
	AccompanyTitleFilename string        `json:"accompany_title_filename"`
	CharCount              int           `json:"char_count"`
	Audio                  int           `json:"audio"`
	Image                  string        `json:"image"`
	CategoryID             int           `json:"category_id"`
	CategoryName           string        `json:"category_name"`
	Rank                   int           `json:"rank"`
	AccompanyFilename      string        `json:"accompany_filename"`
	HostIP                 string        `json:"host_ip"`
	UpdateTime             util.DateTime `json:"update_time"`
	Codec                  string        `json:"codec"`
	LampID                 int           `json:"lamp_id"`
	EffectID               int           `json:"effect_id"`
	ReverberationID        int           `json:"reverberation_id"`
	StrLevel               int           `json:"str_level"`
	Volume                 int           `json:"volume"`
	Songno                 string        `json:"songno"`
}

// TableName ...
func (p PartyDance) TableName() string {
	return TablePartyDance
}
