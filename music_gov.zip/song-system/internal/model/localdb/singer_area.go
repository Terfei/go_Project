package localdb

// TableSingerArea 歌手区域
const TableSingerArea = `SingerArea`

// SingerArea 结构体
type SingerArea struct {
	AreaID    int    `json:"area_id"`
	AreaName  string `json:"area_name"`
	AreaImage string `json:"area_image"`
	Seq       int8   `json:"seq"`
}

// TableName ...
func (s SingerArea) TableName() string {
	return TableSingerArea
}
