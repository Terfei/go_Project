package localdb

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// TableAccompany table
const TableAccompany = `Accompany`

// Accompany 伴奏结构体
type Accompany struct {
	AccompanyID        int            `json:"accompany_id"`
	AccompanyName      string         `json:"accompany_name"`
	AccompanyNameSpell string         `json:"accompany_name_spell"`
	CharCount          int            `json:"char_count"`
	SingerID           int            `json:"singer_id"`
	SingerIDTwo        int            `json:"singer_id_two"`
	SingerIDThree      int            `json:"singer_id_three"`
	SingerIDFour       int            `json:"singer_id_four"`
	SingerNameAll      string         `json:"singer_name_all"`
	LanguageID         int            `json:"language_id"`
	CategoryID         int            `json:"category_id"`
	VersionID          int            `json:"version_id"`
	AccompanyFilename  string         `json:"accompany_filename"`
	HostIP             string         `json:"host_ip"`
	IsRecommand        int            `json:"is_recommand"`
	ReleaseTime        util.DateTime  `json:"release_time"`
	Rank               int            `json:"rank"`
	Codec              string         `json:"codec"`
	Channel            string         `json:"channel"`
	LampID             int            `json:"lamp_id"`
	EffectID           int            `json:"effect_id"`
	ReverberationID    int            `json:"reverberation_id"`
	LanguageType       string         `json:"language_type"`
	Volume             int            `json:"volume"`
	Audio              int            `json:"audio"`
	Songno             string         `json:"songno"`
	MidFilepath        string         `json:"mid_filepath"`
	ReverberationGroup string         `json:"reverberation_group"`
	LocalRank          int            `json:"local_rank"`
	TagID              int            `json:"Tag_id"`
	VideoqltyID        int            `json:"Videoqlty_id"`
	AudioqltyID        int            `json:"Audioqlty_id"`
	EmoTagID           model.EmoTagID `json:"emo_tag_id"`
}

// TableName table name
func (a Accompany) TableName() string {
	return TableAccompany
}
