package localdb

// TableAccompanyVideoQlty 伴奏视频质量
const TableAccompanyVideoQlty = `AccompanyVideoQlty`

// AccompanyVideoQlty 伴奏视频质量结构体
type AccompanyVideoQlty struct {
	VideoqltyID    int    `json:"videoqlty_id"`
	VideoqltyCode  string `json:"Videoqlty_code"`
	Seq            int8   `json:"seq"`
	IsShow         int8   `json:"is_show"`
	VideoqltyImage string `json:"videoqlty_image"`
}

// TableName ...
func (a AccompanyVideoQlty) TableName() string {
	return TableAccompanyVideoQlty
}
