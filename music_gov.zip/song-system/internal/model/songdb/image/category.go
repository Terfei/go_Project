package image

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableCategory 图片分类
const TableCategory = `image.category`

// Category 图片分类
type Category struct {
	ID        int           `gorm:"primary_key" json:"id"`
	Title     string        `json:"title"`
	Height    int           `json:"height"`
	Width     int           `json:"width"`
	Disk      string        `json:"disk"`
	CreatedAt util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt util.NullTime `json:"updated_at" form:"updated_at"`
	DeletedAt *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (i Category) TableName() string {
	return TableCategory
}
