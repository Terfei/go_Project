package image

import (
	"fmt"
	"strconv"
	"strings"
)

// TemplateModule 模块
type TemplateModule string

const (
	// TemplateModuleBranch 门店类别
	TemplateModuleBranch TemplateModule = `branch`
	// TemplateModuleCentre 总部类别
	TemplateModuleCentre TemplateModule = `centre`
)

func (tm TemplateModule) String() string {
	return string(tm)
}

var codeModulePrefixMap = map[TemplateModule]string{
	TemplateModuleBranch: `DM`,
	TemplateModuleCentre: `ZM`,
}

func normalizeCode(t Template, code int) string {
	return fmt.Sprintf(
		`%s%05d`,
		codeModulePrefixMap[t.Module],
		code,
	)
}

// StandardizedTemplateCode 标准化模板code
func StandardizedTemplateCode(code string) int {
	for _, v := range codeModulePrefixMap {
		code = strings.Replace(code, v, ``, 1)
	}

	c, _ := strconv.Atoi(code)

	return c
}
