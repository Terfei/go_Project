package image

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableImage 图库
const TableImage = `image.images`

// Image 图片
type Image struct {
	ID         int           `gorm:"primary_key" json:"id"`
	Filename   string        `json:"filename"`
	CategoryID int           `json:"category_id" form:"category_id"`
	CreatedAt  util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt  util.NullTime `json:"updated_at" form:"updated_at"`
	DeletedAt  *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (i Image) TableName() string {
	return TableImage
}
