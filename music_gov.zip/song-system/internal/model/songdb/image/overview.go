package image

import (
	"database/sql/driver"
	"encoding/json"
	"errors"

	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// TableOverview 门店实时
const TableOverview = `image.overview`

// Overview ....
type Overview struct {
	ID               int               `gorm:"primary_key" json:"id"`
	CategoryID       int               `json:"category_id"`
	BranchID         uuid.UUID         `json:"branch_id"`
	BranchName       string            `json:"branch_name"`
	BizType          int               `json:"biz_type"`
	CenterPlanID     int               `json:"center_plan_id"`
	BranchPlanID     int               `json:"branch_plan_id"`
	CenterPlan       *OverviewPlan     `json:"center_plan"`
	BranchPlan       *OverviewPlan     `json:"branch_plan"`
	CenterTemplateID int               `json:"center_template_id"`
	BranchTemplateID int               `json:"branch_template_id"`
	CenterTemplate   *OverviewTemplate `json:"center_template"`
	BranchTemplate   *OverviewTemplate `json:"branch_template"`
	CreatedAt        util.NullTime     `json:"created_at" form:"created_at"`
	UpdatedAt        util.NullTime     `json:"updated_at" form:"updated_at"`
	Category         Category          `json:"category" gorm:"ForeignKey:CategoryID"`
}

// TableName table name
func (o Overview) TableName() string {
	return TableOverview
}

// OverviewPlan 重新定义 plan 类型
type OverviewPlan TemplatePlan

// OverviewTemplate 重新定义 template 类型
type OverviewTemplate Template

// NewOverviewPlan ...
func NewOverviewPlan(t TemplatePlan) OverviewPlan {
	b, _ := json.Marshal(t)

	var plan OverviewPlan

	_ = json.Unmarshal(b, &plan)

	return plan
}

// NewOverviewTemplate ...
func NewOverviewTemplate(t Template) OverviewTemplate {
	b, _ := json.Marshal(t)

	var plan OverviewTemplate

	_ = json.Unmarshal(b, &plan)

	return plan
}

// Value 返回数据库可识别类型
func (t OverviewTemplate) Value() (driver.Value, error) {
	return json.Marshal(t)
}

// Scan ...
func (t *OverviewTemplate) Scan(src interface{}) error {
	bytes, ok := src.([]byte)
	if !ok {
		return errors.New("template value")
	}

	if err := json.Unmarshal(bytes, t); nil != err {
		return errors.New("template value error")
	}

	return nil
}

// Value 返回数据库可识别类型
func (t OverviewPlan) Value() (driver.Value, error) {
	return json.Marshal(t)
}

// Scan ...
func (t *OverviewPlan) Scan(src interface{}) error {
	bytes, ok := src.([]byte)
	if !ok {
		return errors.New("template plan value")
	}

	if err := json.Unmarshal(bytes, t); nil != err {
		return errors.New("template plan value error")
	}

	return nil
}
