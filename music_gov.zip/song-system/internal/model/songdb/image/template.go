package image

import (
	"github.com/jinzhu/gorm"
	"github.com/lib/pq"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"strconv"
	"time"
)

// TableTemplate 模板表名
const TableTemplate = `image.template`

// Template 模板结构体
type Template struct {
	ID         int            `gorm:"primary_key" json:"id"`
	Module     TemplateModule `gorm:"module" json:"module"`
	Code       string         `gorm:"code" json:"code"`
	CategoryID int            `json:"category_id" form:"category_id"`
	Title      string         `gorm:"title" json:"title"`
	ImageIDs   pq.Int64Array  `json:"image_ids" form:"image_ids"`
	CreatedAt  util.NullTime  `json:"created_at" form:"created_at"`
	UpdatedAt  util.NullTime  `json:"updated_at" form:"updated_at"`
	DeletedAt  *time.Time     `json:"deleted_at" form:"deleted_at"`
	Category   Category       `json:"category" gorm:"ForeignKey:CategoryID"`
	Images     []string       `json:"images"`
}

// TableName table name
func (t Template) TableName() string {
	return TableTemplate
}

// AfterFind 显示逻辑
func (t *Template) AfterFind() error {
	var images []Image
	ids := util.NewSetInt64(t.ImageIDs...)
	model.SongDB.Where("id in (?)", ids.List()).Find(&images)

	for _, image := range images {
		t.Images = append(t.Images, image.Filename)
	}

	return nil
}

// BeforeCreate 创建记录前生成code
func (t *Template) BeforeCreate(scope *gorm.Scope) error {
	lastest := lastestTemplateCode(*t)
	return scope.SetColumn(`Code`, normalizeCode(*t, lastest+1))
}

// lastestTemplateCode 最新的Code
func lastestTemplateCode(t Template) int {
	var temp Template

	query := model.SongDB.Unscoped().Scopes(songdb.ColumnEqualScope(`module`, t.Module))
	if err := query.Order(`code desc`).First(&temp).Error; nil != err {
		return 0
	}

	c, _ := strconv.Atoi(temp.Code[2:])

	return c
}
