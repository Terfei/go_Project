package image

import (
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

type (
	// PlanStatus 应用状态
	PlanStatus string
)

const (
	// TableTemplatePlan 模板应用表名
	TableTemplatePlan = `image.template_plan`
	// PlanStatusInit 待审核
	PlanStatusInit PlanStatus = `init`
	// PlanStatusAudit 已审核待更新
	PlanStatusAudit PlanStatus = `audit`
	// PlanStatusReject 审核驳回
	PlanStatusReject PlanStatus = `reject`
	// PlanStatusUpdated 更新成功
	PlanStatusUpdated PlanStatus = `updated`
	// PlanStatusFailed 更新失败
	PlanStatusFailed PlanStatus = `failed`
)

// TemplatePlan 模板应用
type TemplatePlan struct {
	ID            int            `gorm:"primary_key" json:"id"`
	Module        TemplateModule `gorm:"module" json:"module"`
	CategoryID    int            `json:"category_id" form:"category_id"`
	TemplateID    int            `gorm:"template_id" json:"template_id"`
	BranchID      uuid.UUID      `gorm:"branch_id" json:"branch_id"`
	BeginTime     util.NullTime  `json:"begin_time" form:"begin_time"`
	EndTime       util.NullTime  `json:"end_time" form:"end_time"`
	Remark        string         `gorm:"remark" json:"remark"`
	Status        PlanStatus     `gorm:"status" json:"status"`
	RejectExplain string         `gorm:"reject_explain" json:"reject_explain"`
	CreatedAt     util.NullTime  `json:"created_at" form:"created_at"`
	UpdatedAt     util.NullTime  `json:"updated_at" form:"updated_at"`
	DeletedAt     *time.Time     `json:"deleted_at" form:"deleted_at"`
	Template      Template       `json:"template" gorm:"ForeignKey:TemplateID"`
	Category      Category       `json:"category" gorm:"ForeignKey:CategoryID"`
}

// TableName table name
func (tp TemplatePlan) TableName() string {
	return TableTemplatePlan
}
