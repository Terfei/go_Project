package user

import (
	"database/sql/driver"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	"time"

	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
)

// TableUserStaffs 表名
const TableUserStaffs = `user.staffs`

// StaffCodeTag 码对应tag
const StaffCodeTag = `U`

// Staff 结构体
type Staff struct {
	ID        uuid.UUID   `json:"staff_id" gorm:"primary_key"`
	Code      int8        `json:"code" form:"code"`
	CreatedAt time.Time   `json:"created_at" form:"created_at"`
	UpdatedAt time.Time   `json:"updated_at" form:"updated_at"`
	ViewCode  string      `json:"view_code"`
	Extra     *StaffExtra `json:"extra" form:"extra"`
	Roles     []Role      `json:"roles" gorm:"many2many:user.staff_roles;association_autoupdate:false;"`
}

// StaffExtra staff extra
type StaffExtra struct {
	Center bool `json:"center"`
}

// IsCenter 是否总部
func (s Staff) IsCenter() bool {
	if s.Extra == nil {
		return false
	}

	return s.Extra.Center
}

//Value 转换json存储
func (s StaffExtra) Value() (driver.Value, error) {
	return json.Marshal(s)
}

//Scan 将数据库对象转换成可以使用的golang 属性
func (s *StaffExtra) Scan(src interface{}) error {
	bytes, ok := src.([]byte)
	if !ok {
		return errors.New("staff extra error")
	}

	if err := json.Unmarshal(bytes, s); nil != err {
		return errors.New("staff extra json解析失败")
	}

	return nil
}

// TableName table name
func (s Staff) TableName() string {
	return TableUserStaffs
}

// AfterFind 显示逻辑
func (s *Staff) AfterFind() error {
	s.ViewCode = fmt.Sprintf(`%s%06d`, StaffCodeTag, s.Code)

	return nil
}

// BeforeCreate 创建记录前生成code
func (s *Staff) BeforeCreate(scope *gorm.Scope) error {
	lastest := lastestStaffCode()
	return scope.SetColumn(`Code`, lastest+1)
}

// Permissions 返回员工拥有的权限点集合
func (s *Staff) Permissions() map[string]struct{} {
	if 0 >= len(s.Roles) {
		return nil
	}

	perms := make(map[string]struct{})
	for _, role := range s.Roles {
		for _, p := range role.Permissions {
			perms[p.Permission] = struct{}{}
		}
	}

	return perms
}

// lastestStaffCode 最新的Code
func lastestStaffCode() int8 {
	var staff Staff

	if err := model.SongDB.Order(`code desc`).First(&staff).Error; nil != err {
		return 0
	}

	return staff.Code
}

// LocalStaffByID ID 查找
func LocalStaffByID(id uuid.UUID) (*Staff, error) {
	var staff Staff

	if err := model.SongDB.Model(Staff{}).Preload(`Roles`).Preload(`Roles.Permissions`).Where("id = ?", id).First(&staff).Error; nil != err {
		return nil, err
	}

	return &staff, nil
}
