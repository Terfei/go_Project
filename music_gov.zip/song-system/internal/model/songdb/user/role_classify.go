package user

import (
	"time"
)

// TableRoleClassify 角色类别表
const TableRoleClassify = `user.role_classify`

// RoleClassifyExtra 角色类别冗余字段
type RoleClassifyExtra struct {
}

// RoleClassify 角色类别结构体
type RoleClassify struct {
	ID        uint8     `json:"id" db:"id" gorm:"primary_key"`
	Name      string    `json:"name"`
	Extra     RoleExtra `json:"extra"`
	CreatedAt time.Time `json:"created_at" db:"created_at"`
	UpdatedAt time.Time `json:"updated_at" db:"updated_at"`
	Roles     []Role    `json:"roles" gorm:"AssociationForeignKey:ClassifyID;association_autoupdate:false;"`
}

// TableName 表名
func (rc RoleClassify) TableName() string {
	return TableRoleClassify
}
