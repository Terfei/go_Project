package user

import (
	"time"

	"gitlab.omytech.com.cn/vod/song-system/internal/model"
)

// SystemType 系统类型
type SystemType string

const (
	// SYSTEMCLOUD 云系统
	SYSTEMCLOUD SystemType = `Cloud System`
)

// TablePermission 权限表
const TablePermission = `user.permissions`

// Permission 权限结构体
type Permission struct {
	ID         uint8      `json:"id" db:"id" gorm:"primary_key"`
	System     SystemType `json:"system" form:"system"`
	Permission string     `json:"permission" db:"permission"`
	CreatedAt  time.Time  `json:"created_at" db:"created_at"`
	UpdatedAt  time.Time  `json:"updated_at" db:"updated_at"`
}

// TableName 表名
func (p Permission) TableName() string {
	return TablePermission
}

// FindByPermission 根据权限点查找
func FindByPermission(p string) (*Permission, error) {
	var pm Permission

	if err := model.SongDB.Where("permission = ?", p).First(&pm).Error; nil != err {
		return nil, err
	}

	return &pm, nil
}

// FindByPermissionIDs 权限id集合查找
func FindByPermissionIDs(ids []int) ([]Permission, error) {
	var ps []Permission

	if err := model.SongDB.Where(`id in (?)`, ids).Find(&ps).Error; nil != err {
		return ps, err
	}

	return ps, nil
}
