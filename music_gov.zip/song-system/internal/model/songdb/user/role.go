package user

import (
	"fmt"
	"time"

	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
)

// TableRole 角色表
const TableRole = `user.roles`

// RoleCodeTag 码对应tag
const RoleCodeTag = `R`

// RoleExtra 角色冗余字段
type RoleExtra struct {
}

// Role 角色结构体
type Role struct {
	ID          uint8        `json:"id" db:"id" gorm:"primary_key"`
	Name        string       `json:"name"`
	Code        int8         `json:"code" form:"code"`
	Status      string       `json:"status"`
	Remarks     string       `json:"remarks"`
	Extra       RoleExtra    `json:"extra"`
	CreatedAt   time.Time    `json:"created_at" db:"created_at"`
	UpdatedAt   time.Time    `json:"updated_at" db:"updated_at"`
	ViewCode    string       `json:"view_code"`
	ClassifyID  int          `json:"classify_id" db:"classify_id"`
	Classify    RoleClassify `json:"classify" gorm:"ForeignKey:ClassifyID"`
	Permissions []Permission `json:"permissions" gorm:"many2many:user.role_permissions;association_autoupdate:false;"`
}

// TableName 表名
func (r Role) TableName() string {
	return TableRole
}

// AfterFind 显示逻辑
func (r *Role) AfterFind() error {
	r.ViewCode = fmt.Sprintf(`%s%06d`, RoleCodeTag, r.Code)

	return nil
}

// BeforeCreate 创建记录前生成code
func (r *Role) BeforeCreate(scope *gorm.Scope) error {
	lastest := lastestRoleCode()
	return scope.SetColumn(`Code`, lastest+1)
}

// lastestRoleCode 最新的Code
func lastestRoleCode() int8 {
	var role Role

	if err := model.SongDB.Order(`code desc`).First(&role).Error; nil != err {
		return 0
	}

	return role.Code
}

// FindByRoleIDs 角色id集合查找
func FindByRoleIDs(ids []int) ([]Role, error) {
	var rs []Role

	if err := model.SongDB.Where(`id in (?)`, ids).Find(&rs).Error; nil != err {
		return rs, err
	}

	return rs, nil
}
