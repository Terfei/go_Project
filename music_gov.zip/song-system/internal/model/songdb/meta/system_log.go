package meta

import (
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/users"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// TableSystemLog 权限表
const TableSystemLog = `meta.system_log`

// SystemLogModule 操作模块
type SystemLogModule string

func (slm SystemLogModule) String() string {
	return string(slm)
}

const (
	// LogModuleUserRole 角色模块
	LogModuleUserRole SystemLogModule = `user.roles`
	// LogModuleUserRoleClassify 角色类别模块
	LogModuleUserRoleClassify SystemLogModule = `user.role_classify`
	// LogModuleUserStaff 员工模块
	LogModuleUserStaff SystemLogModule = `user.staffs`

	// LogModuleBranchAuthorize 门店授权
	LogModuleBranchAuthorize SystemLogModule = `branch.authorize`
	// LogModuleMetaVersionOverview 批次总览
	LogModuleMetaVersionOverview SystemLogModule = `meta.version_overview`
	// LogModuleBranchVersion 门店批次
	LogModuleBranchVersion SystemLogModule = `branch.version`

	// LogModuleAccompany 歌曲
	LogModuleAccompany SystemLogModule = `song.accompany`
	// LogModuleSinger 歌手
	LogModuleSinger SystemLogModule = `song.singer`
	// LogModuleWallpaper 动态壁纸
	LogModuleWallpaper SystemLogModule = `song.wallpaper`
	// LogModulePartyDance 派对舞曲
	LogModulePartyDance SystemLogModule = `song.party_dance`
	// LogModuleAcc 公播
	LogModuleAcc SystemLogModule = `song.acc`
	// LogModuleSingerArea 歌手区域
	LogModuleSingerArea SystemLogModule = `song.singer_area`
	// LogModuleActVideo 跳舞视频
	LogModuleActVideo SystemLogModule = `song.act_video`
	// LogModuleAccompanyBanned 禁歌
	LogModuleAccompanyBanned SystemLogModule = `song.accompany_banned`

	// LogModuleEmoTag 情绪标签
	LogModuleEmoTag SystemLogModule = `song.emo_tag`
	// LogModuleAccompanyAudioqlty 音频质量
	LogModuleAccompanyAudioqlty SystemLogModule = `song.accompany_audioqlty`
	// LogModuleAccompanyVideoqlty 视频质量
	LogModuleAccompanyVideoqlty SystemLogModule = `song.accompany_videoqlty`
	// LogModuleAccompanyCategory 歌曲分类
	LogModuleAccompanyCategory SystemLogModule = `song.accompany_category`
	// LogModuleAccompanyLanguage 歌曲语种
	LogModuleAccompanyLanguage SystemLogModule = `song.accompany_language`
	// LogModuleAccompanyTag 歌曲标签
	LogModuleAccompanyTag SystemLogModule = `song.accompany_tag`
	// LogModuleAccompanyVersion 歌曲版本
	LogModuleAccompanyVersion SystemLogModule = `song.accompany_version`
	// LogModuleImageCategory 图片类型
	LogModuleImageCategory SystemLogModule = `image.category`
	// LogModuleImageImages 图库
	LogModuleImageImages SystemLogModule = `image.images`
	// LogModuleImageTemplate 模板表
	LogModuleImageTemplate SystemLogModule = `image.template`
	// LogModuleImageTemplatePlan 模板应用
	LogModuleImageTemplatePlan SystemLogModule = `image.template_plan`

	// LogModuleAccompanyTop 歌曲置顶
	LogModuleAccompanyTop SystemLogModule = `report.accompany_topping`
	// LogModuleSingerTop 歌手置顶
	LogModuleSingerTop SystemLogModule = `report.singer_topping`
)

// ModuleName 模块中文名
var ModuleName = map[SystemLogModule]string{
	LogModuleUserRole:         `角色模块`,
	LogModuleUserRoleClassify: `角色类别模块`,
	LogModuleUserStaff:        `员工模块`,

	LogModuleAcc:             `公播`,
	LogModuleAccompany:       `歌曲`,
	LogModuleAccompanyBanned: `禁歌`,
	LogModuleActVideo:        `跳舞视频`,
	LogModulePartyDance:      `派对舞曲`,
	LogModuleSinger:          `歌手`,
	LogModuleSingerArea:      `歌手区域`,
	LogModuleWallpaper:       `动态壁纸`,

	LogModuleEmoTag:             `情绪标签`,
	LogModuleAccompanyCategory:  `歌曲分类`,
	LogModuleAccompanyLanguage:  `歌曲语种`,
	LogModuleAccompanyTag:       `歌曲标签`,
	LogModuleAccompanyVersion:   `歌曲版本`,
	LogModuleAccompanyAudioqlty: `音频质量`,
	LogModuleAccompanyVideoqlty: `视频质量`,

	LogModuleBranchAuthorize:     `门店授权`,
	LogModuleMetaVersionOverview: `批次总览`,
	LogModuleBranchVersion:       `门店批次`,

	LogModuleImageImages:   `图库`,
	LogModuleImageCategory: `图片类型`,

	LogModuleSingerTop:    `歌手置顶`,
	LogModuleAccompanyTop: `歌曲置顶`,
}

// SystemLogAction 操作类型
type SystemLogAction string

const (
	// LogActionUpdate 修改
	LogActionUpdate SystemLogAction = `update`
	// LogActionInsert 新增
	LogActionInsert SystemLogAction = `insert`
	// LogActionDelete 删除
	LogActionDelete SystemLogAction = `delete`
)

// ActionName action name map
var ActionName = map[SystemLogAction]string{
	LogActionInsert: `新增`,
	LogActionUpdate: `修改`,
	LogActionDelete: `删除`,
}

// SystemLog 结构体
type SystemLog struct {
	ID         int             `json:"id" db:"id" gorm:"primary_key"`
	StaffID    uuid.UUID       `json:"staff_id"`
	StaffName  string          `json:"staff_name"`
	Module     SystemLogModule `json:"module"`
	Action     SystemLogAction `json:"action"`
	Remark     string          `json:"remark"`
	Extra      *util.Params    `json:"extra"`
	RelationID int             `json:"relation_id"`
	CreatedAt  util.NullTime   `json:"created_at"`
	UpdatedAt  util.NullTime   `json:"updated_at"`
}

// TableName 表名
func (s SystemLog) TableName() string {
	return TableSystemLog
}

// SetStaff 设置staff
func (s *SystemLog) SetStaff(staff *users.Staff) *SystemLog {
	s.StaffID = staff.StaffID
	s.StaffName = staff.StaffName

	return s
}

// SetRemark 设置 SetRemark
func (s *SystemLog) SetRemark(remark string) *SystemLog {
	s.Remark = remark

	return s
}

// SetModule ...
func (s *SystemLog) SetModule(module SystemLogModule) *SystemLog {
	s.Module = module

	return s
}

// SetAction ...
func (s *SystemLog) SetAction(action SystemLogAction) *SystemLog {
	s.Action = action

	return s
}

// SetData ....
func (s *SystemLog) SetData(data interface{}) *SystemLog {
	params := util.MakeParams(data)
	s.Extra = &params

	return s
}

// SetRelationID ...
func (s *SystemLog) SetRelationID(id int) *SystemLog {
	s.RelationID = id

	return s
}

// Save ...
func (s *SystemLog) Save() error {
	if err := model.SongDB.Create(&s).Error; nil != err {
		return err
	}

	return nil
}

// SaveSystemLog 保存操作历史
func SaveSystemLog(staff *users.Staff, module SystemLogModule, action SystemLogAction, remark string, extra interface{}, relationID int) error {
	params := util.MakeParams(extra)

	log := SystemLog{
		StaffID:    staff.StaffID,
		StaffName:  staff.StaffName,
		Module:     module,
		Action:     action,
		Remark:     remark,
		Extra:      &params,
		RelationID: relationID,
	}

	return model.SongDB.Create(&log).Error
}
