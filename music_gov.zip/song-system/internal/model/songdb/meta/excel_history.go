package meta

import "gitlab.omytech.com.cn/vod/song-system/internal/util"

// TableExcelHistory excel导入历史
const TableExcelHistory = `meta.excel_history`

// ExcelHistoryCategory 分类
type ExcelHistoryCategory string

const (
	// ExcelHistoryAccompany 歌曲
	ExcelHistoryAccompany ExcelHistoryCategory = `accompany`
	// ExcelHistorySinger 歌手
	ExcelHistorySinger ExcelHistoryCategory = `singer`
	// ExcelHistoryWallpaper 动态壁纸
	ExcelHistoryWallpaper ExcelHistoryCategory = `wallpaper`
	// ExcelHistoryPartyDance 派对舞曲
	ExcelHistoryPartyDance ExcelHistoryCategory = `party_dance`
	// ExcelHistoryAcc 公播
	ExcelHistoryAcc ExcelHistoryCategory = `acc`
	// ExcelHistoryActVideo 跳舞视频
	ExcelHistoryActVideo ExcelHistoryCategory = `act_video`
	// ExcelHistoryAccompanyBanned 禁歌
	ExcelHistoryAccompanyBanned ExcelHistoryCategory = `accompany_banned`
)

// ExcelHistoryAction 类型
type ExcelHistoryAction string

const (
	// ExcelHistoryInsert 新增
	ExcelHistoryInsert ExcelHistoryAction = `insert`
	// ExcelHistoryUpdate 更新
	ExcelHistoryUpdate ExcelHistoryAction = `update`
	// ExcelHistoryDelete 删除
	ExcelHistoryDelete ExcelHistoryAction = `delete`
)

// ExcelHistory 导入历史
type ExcelHistory struct {
	ID         int                  `json:"id" gorm:"primary_key"`
	Category   ExcelHistoryCategory `json:"category"`
	Content    util.Params          `json:"content"`
	Action     ExcelHistoryAction   `json:"action"`
	RelationID string               `json:"relation_id"`
	ImportCode string               `json:"import_code"`
	CreatedAt  util.NullTime        `json:"created_at" form:"created_at"`
	UpdatedAt  util.NullTime        `json:"updated_at" form:"updated_at"`
}

// TableName ...
func (e ExcelHistory) TableName() string {
	return TableExcelHistory
}
