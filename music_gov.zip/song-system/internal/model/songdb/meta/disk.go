package meta

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// TableDisk 盘符
const TableDisk = `meta.disks`

// Disk 盘符映射
type Disk struct {
	ID        int           `json:"id" gorm:"primary_key"`
	Category  string        `json:"category"`
	LocalDisk string        `json:"local_disk"`
	ShareDisk string        `json:"share_disk"`
	CreatedAt util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt util.NullTime `json:"updated_at" form:"updated_at"`
}

// TableName table name
func (d Disk) TableName() string {
	return TableDisk
}
