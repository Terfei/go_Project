package meta

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableVersionOverview 批次总览
const TableVersionOverview = `meta.version_overview`

// VersionCode 批次号
type VersionCode string

// VersionOverview 批次总览
type VersionOverview struct {
	ID          int           `json:"id" gorm:"primary_key"`
	VersionCode VersionCode   `json:"version_code" form:"version_code"`
	Remark      string        `json:"remark"`
	IsDefault   int           `json:"is_default" form:"is_default"`
	CreatedAt   util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt   util.NullTime `json:"updated_at" form:"updated_at"`
	DeletedAt   *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (v VersionOverview) TableName() string {
	return TableVersionOverview
}

// String string...
func (v VersionCode) String() string {
	return string(v)
}

// MakeVersionCode 生成批次号
func MakeVersionCode() VersionCode {
	date := time.Now().Format("2006-01-02")

	var count int
	model.SongDB.Table(TableVersionOverview).Where("created_at > ?", date).Count(&count)

	code := fmt.Sprintf("%s%.3d", time.Now().Format("20060102"), count+1)

	return VersionCode(code)
}
