package songdb

import (
	"fmt"
	"time"

	"github.com/jinzhu/gorm"
	"github.com/sirupsen/logrus"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// Model 统一model结构
type Model struct {
	ID        int           `gorm:"primary_key" json:"id"`
	CreatedAt util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt util.NullTime `json:"updated_at" form:"updated_at"`
}

// ColumnLikeScope 模糊搜索
func ColumnLikeScope(column string, search string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(column) == 0 || len(search) == 0 {
			return db
		}

		return db.Where(fmt.Sprintf("%s like ?", column), fmt.Sprintf("%%%s%%", search))
	}
}

// ColumnNullScope 空匹配
func ColumnNullScope(column string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(column) == 0 {
			logger.Entry().WithFields(logrus.Fields{
				"column": column,
			}).Error("字段不为空Scope错误")
			return db
		}

		return db.Where(fmt.Sprintf(`%s is null`, column))
	}
}

// ColumnNotNullScope 非空匹配
func ColumnNotNullScope(column string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(column) == 0 {
			logger.Entry().WithFields(logrus.Fields{
				"column": column,
			}).Error("字段不为空Scope错误")
			return db
		}

		return db.Where(fmt.Sprintf(`%s is not null`, column))
	}
}

// ColumnStringInScope in匹配
func ColumnStringInScope(column string, s []string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(column) == 0 || len(s) == 0 {
			logger.Entry().WithFields(logrus.Fields{
				"column":       column,
				"string_slice": s,
			}).Error("字段不为空Scope错误")
			return db
		}

		return db.Where(fmt.Sprintf(`%s in (?)`, column), s)
	}
}

// ColumnIDInScope in匹配
func ColumnIDInScope(column string, ids []int) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(column) == 0 || len(ids) == 0 {
			logger.Entry().WithFields(logrus.Fields{
				"column": column,
				"ids":    ids,
			}).Error("字段不为空Scope错误")
			return db
		}

		return db.Where(fmt.Sprintf(`%s in (?)`, column), ids)
	}
}

// ColumnEqualScope 字段全等匹配
func ColumnEqualScope(column string, val interface{}) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(column) == 0 {
			logger.Entry().WithFields(logrus.Fields{
				`column`: column,
				`val`:    val,
			}).Error("字段值相等Scope错误")
			return db
		}

		return db.Where(fmt.Sprintf(`%s = ?`, column), val)
	}
}

// ColumnBetweenDateScope 区间匹配
func ColumnBetweenDateScope(column string, begin, end time.Time) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(column) == 0 || begin.IsZero() || end.IsZero() {
			logger.Entry().WithFields(logrus.Fields{
				`column`: column,
				`begin`:  begin,
				`end`:    end,
			}).Error("字段值区间Scope错误")
			return db
		}

		return db.Where(fmt.Sprintf(`%s between ? and ?`, column), begin.Format(`2006-01-02`), end.Format(`2006-01-02`))
	}

}

// BranchIDScope branch id
func BranchIDScope(branchID string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(branchID) == 0 {
			return db
		}

		return db.Where("branch_id = ?", branchID)
	}
}
