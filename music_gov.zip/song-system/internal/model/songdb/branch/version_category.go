package branch

import (
	"fmt"
	"github.com/jinzhu/gorm"
)

// TableVersionCategory 批次分类汇总
const TableVersionCategory = `branch.version_category`

// VersionCategoryType 分类
type VersionCategoryType string

const (
	// VersionCategoryTypeSong 歌曲
	VersionCategoryTypeSong VersionCategoryType = `song.accompany`
	// VersionCategoryTypeSinger 歌手
	VersionCategoryTypeSinger VersionCategoryType = `song.singer`
	// VersionCategoryTypeWallpaper 动态壁纸
	VersionCategoryTypeWallpaper VersionCategoryType = `song.wallpaper`
	// VersionCategoryTypeAcc 公播
	VersionCategoryTypeAcc VersionCategoryType = `song.acc`
	// VersionCategoryTypeVj vj
	VersionCategoryTypeVj VersionCategoryType = `song.vj`
	// VersionCategoryTypeDance 派对舞曲
	VersionCategoryTypeDance VersionCategoryType = `song.party_dance`
	// VersionCategoryTypeActVideo 跳舞视频
	VersionCategoryTypeActVideo VersionCategoryType = `song.act_video`
)

// AllVersionCategoryType 获取所有类型
func AllVersionCategoryType() []VersionCategoryType {
	return []VersionCategoryType{
		VersionCategoryTypeSong,
		VersionCategoryTypeSinger,
		VersionCategoryTypeWallpaper,
		VersionCategoryTypeAcc,
		VersionCategoryTypeVj,
		VersionCategoryTypeDance,
		VersionCategoryTypeActVideo,
	}
}

func (t VersionCategoryType) String() string {
	return string(t)
}

// VersionCategoryStatus 状态
type VersionCategoryStatus string

const (
	// VersionCategoryStatusInit 初始
	VersionCategoryStatusInit VersionCategoryStatus = `init`
	// VersionCategoryStatusSuccess 成功
	VersionCategoryStatusSuccess VersionCategoryStatus = `success`
	// VersionCategoryStatusFail 失败
	VersionCategoryStatusFail VersionCategoryStatus = `fail`
)

// VersionCategory 批次分类
type VersionCategory struct {
	VersionBase
	RelationType VersionCategoryType   `json:"relation_type"`
	FileCount    int                   `json:"file_count"`
	DoneCount    int                   `json:"done_count"`
	UndoneCount  int                   `json:"undone_count"`
	DealStatus   VersionCategoryStatus `json:"deal_status"`
	DealRemark   string                `json:"deal_remark"`
}

// TableName ...
func (v VersionCategory) TableName() string {
	return TableVersionCategory
}

// CategoryColumnEqualScope 字段全等匹配
func CategoryColumnEqualScope(column, val string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(val) == 0 {
			return db
		}

		return db.Where(fmt.Sprintf(`%s = ?`, column), val)
	}
}
