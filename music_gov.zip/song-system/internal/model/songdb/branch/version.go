package branch

import (
	"time"
)

// TableVersion 门店批次
const TableVersion = `branch.versions`

// Version 门店批次信息
type Version struct {
	VersionBase
	Remarks     string     `json:"remarks"`
	CanDownload int8       `json:"can_download"`
	DeletedAt   *time.Time `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (v Version) TableName() string {
	return TableVersion
}
