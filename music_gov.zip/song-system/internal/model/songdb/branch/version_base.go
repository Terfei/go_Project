package branch

import (
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// VersionBase 批次版本基础信息
type VersionBase struct {
	ID          int              `json:"id" gorm:"primary_key" form:"id"`
	BranchID    uuid.UUID        `json:"branch_id"`
	VersionID   int              `json:"version_id"`
	VersionCode meta.VersionCode `json:"version_code"`
	CreatedAt   util.NullTime    `json:"created_at" form:"created_at"`
	UpdatedAt   util.NullTime    `json:"updated_at" form:"updated_at"`
}
