package branch

import (
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// TableAuthorizeLog 门店授权表
const TableAuthorizeLog = `branch.authorize_logs`

// AuthorizeLog 结构体
type AuthorizeLog struct {
	ID          int               `json:"id" gorm:"primary_key" form:"id"`
	StaffID     uuid.UUID         `json:"staff_id"`
	StaffName   string            `json:"staff_name"`
	BranchID    uuid.UUID         `json:"branch_id"`
	BranchCode  string            `json:"branch_code"`
	BranchName  string            `json:"branch_name"`
	Category    AuthorizeCategory `json:"category"`
	BeginMonth  util.Month        `json:"begin_month"`
	EndMonth    util.Month        `json:"end_month"`
	CanDownload int               `json:"can_download"`
	Remark      string            `json:"remark"`
	AuthorizeID int               `json:"authorize_id"`
	CreatedAt   util.NullTime     `json:"created_at" form:"created_at"`
	UpdatedAt   util.NullTime     `json:"updated_at" form:"updated_at"`
}

// TableName table name
func (al AuthorizeLog) TableName() string {
	return TableAuthorizeLog
}
