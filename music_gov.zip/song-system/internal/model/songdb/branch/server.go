package branch

import (
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// TableServer 门店服务
const TableServer = `branch.servers`

// Server 门店服务
type Server struct {
	ID        int           `json:"id" gorm:"primary_key"`
	BranchID  uuid.UUID     `json:"branch_id"`
	Domain    string        `json:"domain"`
	CreatedAt util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt util.NullTime `json:"updated_at" form:"updated_at"`
}

// TableName table name
func (s Server) TableName() string {
	return TableServer
}
