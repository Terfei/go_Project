package branch

import (
	"fmt"
	"strings"

	"github.com/jinzhu/gorm"
	"github.com/lib/pq"
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// TableAuthorize 门店授权表
const TableAuthorize = `branch.authorize`

// AuthorizeCategory 类别
type AuthorizeCategory string

const (
	// AuthorizeCategorySong 曲库
	AuthorizeCategorySong AuthorizeCategory = "song"
)

// AuthorizeCategoryMap 类别名称映射
var AuthorizeCategoryMap = map[AuthorizeCategory]string{
	AuthorizeCategorySong: `曲库`,
}

// String string
func (a AuthorizeCategory) String() string {
	return string(a)
}

// UnmarshalJSON un marshal json
func (a *AuthorizeCategory) UnmarshalJSON(text []byte) (err error) {
	s := strings.Trim(string(text), `"`)

	*a = AuthorizeCategory(s)

	if s == AuthorizeCategorySong.String() {
		return nil
	}

	return fmt.Errorf("授权类型错误:%s", string(text))
}

// Authorize 结构体
type Authorize struct {
	ID         int               `json:"id" gorm:"primary_key" form:"id"`
	BranchID   uuid.UUID         `json:"branch_id"`
	BranchCode string            `json:"branch_code"`
	Category   AuthorizeCategory `json:"category"`
	Year       int               `json:"year"`
	Months     pq.Int64Array     `json:"months"`
	Remark     string            `json:"remark"`
	CreatedAt  util.NullTime     `json:"created_at" form:"created_at"`
	UpdatedAt  util.NullTime     `json:"updated_at" form:"updated_at"`
}

// TableName table name
func (a Authorize) TableName() string {
	return TableAuthorize
}

// IsAuthedMonth 是否认证某月
func (a *Authorize) IsAuthedMonth(month int) bool {
	for _, m := range a.Months {
		if m == int64(month) {
			return true
		}
	}

	return false
}

// YearMonthMap yyyymm => yyyymm
func (a *Authorize) YearMonthMap() map[string]string {
	response := map[string]string{}

	for _, month := range a.Months {
		key := fmt.Sprintf("%d%02d", a.Year, month)

		response[key] = key
	}

	return response
}

// IntMonths 将months转为int
func (a *Authorize) IntMonths() (IDs []int) {
	for _, m := range a.Months {
		IDs = append(IDs, int(m))
	}

	return
}

// AuthorizeLikeBranchNameScope 依据门店ID筛选
func AuthorizeLikeBranchNameScope(branchName string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if branchName != "" {
			var MetaBranches []branch.MetaBranch
			model.BridgeDB.Where("branch_name LIKE ?", "%"+branchName+"%").Find(&MetaBranches)
			var branchIDs []uuid.UUID
			for _, item := range MetaBranches {
				branchIDs = append(branchIDs, item.BranchID)
			}
			return db.Where("branch_id IN (?)", branchIDs)
		}
		return db
	}
}

// AuthorizeByCategoryScope 依据分类筛选
func AuthorizeByCategoryScope(category AuthorizeCategory) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if category != "" {
			return db.Where("category = ?", category)
		}
		return db
	}
}

// AuthorizeByCanDownloadScope 依据是否可以下载筛选
func AuthorizeByCanDownloadScope(canDownload int) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if canDownload != 0 {
			return db.Where("can_download = ?", canDownload)
		}
		return db
	}
}
