package branch

// TableVersionDetail 批次详情
const TableVersionDetail = `branch.version_detail`

// VersionDetail 批次详情
type VersionDetail struct {
	VersionBase
	VersionCategoryID int                 `json:"version_category_id"`
	RelationType      VersionCategoryType `json:"relation_type"`
	RelationID        int                 `json:"relation_id"`
	Filename          string              `json:"filename"`
	OssFile           string              `json:"oss_file"`
	DiskFile          string              `json:"disk_file"`
	IsDownload        int                 `json:"is_download"`
}

// TableName table name
func (v VersionDetail) TableName() string {
	return TableVersionDetail
}
