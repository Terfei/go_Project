package branch

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// TableSyncHistory 同步历史
const TableSyncHistory = `branch.sync_history`

// SyncHistory 同步详情
type SyncHistory struct {
	ID        int           `json:"id" gorm:"primary_key" form:"id"`
	BranchID  string        `json:"branch_id"`
	SyncCode  string        `json:"sync_code"`
	Status    string        `json:"status"`
	Remark    string        `json:"remark"`
	CreatedAt util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt util.NullTime `json:"updated_at" form:"updated_at"`
}

// TableName table name
func (s SyncHistory) TableName() string {
	return TableSyncHistory
}
