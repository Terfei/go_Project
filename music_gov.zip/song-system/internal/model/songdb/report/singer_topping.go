package report

import "gitlab.omytech.com.cn/vod/song-system/internal/util"

// TableSingerTopping 歌手置顶
const TableSingerTopping = `report.singer_topping`

// SingerTopping 结构体
type SingerTopping struct {
	ID         int           `gorm:"primary_key" json:"id"`
	SingerID   int           `json:"singer_id"`
	SingerName string        `json:"singer_name"`
	SingerCode string        `json:"singer_code"`
	AreaID     int           `json:"area_id"`
	AreaName   string        `json:"area_name"`
	Weight     int           `json:"weight"`
	CreatedAt  util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt  util.NullTime `json:"updated_at" form:"updated_at"`
}

// TableName table name
func (s SingerTopping) TableName() string {
	return TableSingerTopping
}
