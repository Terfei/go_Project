package report

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// TableAccompanyTopping 置顶伴奏表
const TableAccompanyTopping = `report.accompany_topping`

// AccompanyTopping 结构体
type AccompanyTopping struct {
	ID                  int           `gorm:"primary_key" json:"id"`
	Songno              string        `json:"songno"`
	AccompanyID         int           `json:"accompany_id"`
	AccompanyName       string        `json:"accompany_name"`
	AccompanyCategoryID int           `json:"accompany_category_id"` //冗余 方便查询 todo 修改
	AccompanyCategory   string        `json:"accompany_category"`
	AccompanyLanguageID int           `json:"accompany_language_id"`
	AccompanyLanguage   string        `json:"accompany_language"`
	SingerID            int           `json:"singer_id"`
	SingerName          string        `json:"singer_name"`
	Weight              int           `json:"weight"`
	CreatedAt           util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt           util.NullTime `json:"updated_at" form:"updated_at"`
}

// TableName table name
func (a AccompanyTopping) TableName() string {
	return TableAccompanyTopping
}
