package report

import (
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// TableReportAccompanyClicks 歌曲点播
const TableReportAccompanyClicks = `report.accompany_clicks`

// AccompanyClick 歌曲点击信息
type AccompanyClick struct {
	ID                  int           `gorm:"primary_key" json:"id"`
	Songno              string        `json:"songno"`
	AccompanyID         int           `json:"accompany_id"`
	AccompanyName       string        `json:"accompany_name"`
	AccompanyCategoryID int           `json:"accompany_category_id"` //冗余 方便查询 todo 修改
	SingerID            int           `json:"singer_id"`
	SingerName          string        `json:"singer_name"`
	Times               int           `json:"times"`
	BranchID            uuid.UUID     `json:"branch_id"`
	BranchBizType       int           `json:"branch_biz_type"` //冗余 方便查询 todo 修改
	CreatedAt           util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt           util.NullTime `json:"updated_at" form:"updated_at"`
}

// TableName table name
func (a AccompanyClick) TableName() string {
	return TableReportAccompanyClicks
}
