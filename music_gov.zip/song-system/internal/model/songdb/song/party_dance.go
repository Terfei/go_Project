package song

import (
	"fmt"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TablePartyDance 派对舞曲
const TablePartyDance = `song.party_dance`

// PartyDance 派对舞曲
type PartyDance struct {
	ID                     int           `json:"id" gorm:"primary_key" form:"id"`
	Songno                 string        `json:"songno"`
	AccompanyID            int           `json:"accompany_id"`
	AccompanyName          string        `json:"accompany_name"`
	AccompanyNameSpell     string        `json:"accompany_name_spell"`
	AccompanyFilename      string        `json:"accompany_filename"`
	AccompanyTitleFilename string        `json:"accompany_title_filename"`
	Audio                  int           `json:"audio"`
	HostIP                 string        `json:"host_ip"`
	Image                  string        `json:"image"`
	CategoryID             int           `json:"category_id"`
	CategoryName           string        `json:"category_name"`
	CharCount              int           `json:"char_count"`
	Rank                   int           `json:"rank"`
	LampID                 int           `json:"lamp_id"`
	EffectID               int           `json:"effect_id"`
	ReverberationID        int           `json:"reverberation_id"`
	Codec                  string        `json:"codec"`
	Volume                 int           `json:"volume"`
	StrLevel               int           `json:"str_level"`
	UpdateTime             util.DateTime `json:"update_time"`
	OverviewID             int           `json:"overview_id"`
	CreatedAt              util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt              util.NullTime `json:"updated_at" form:"updated_at"`
	DeletedAt              *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (p PartyDance) TableName() string {
	return TablePartyDance
}

// PartyDanceNoOrNameLikeScope 模糊搜索
func PartyDanceNoOrNameLikeScope(search string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(search) == 0 {
			return db
		}

		s := fmt.Sprintf("%%%s%%", search)

		return db.Where("songno like ? OR accompany_name like ?", s, s)
	}
}
