package song

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableEmoTag 情绪标签表
const TableEmoTag = `song.emo_tag`

// EmoTag 结构体
type EmoTag struct {
	ID        int           `json:"id" gorm:"primary_key" form:"id"`
	Name      string        `json:"name"`
	NameKey   string        `json:"name_key"`
	Image     string        `json:"image"`
	Seq       int8          `json:"seq"`
	IsShow    int8          `json:"is_show"`
	CreatedAt util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt util.NullTime `json:"updated_at" form:"updated_at"`
	DeletedAt *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (a EmoTag) TableName() string {
	return TableEmoTag
}

// EmoTagMap id => name
func EmoTagMap() map[int]string {
	var items []EmoTag
	model.SongDB.Find(&items)

	response := make(map[int]string)

	for _, item := range items {
		response[item.ID] = item.Name
	}

	return response
}
