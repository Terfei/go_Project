package song

import (
	"database/sql/driver"
	"encoding/json"
	"errors"
	"github.com/jinzhu/gorm"
	"github.com/lib/pq"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableAccompany table
const TableAccompany = `song.accompany`

// Accompany 伴奏结构体
type Accompany struct {
	ID                 int                `gorm:"primary_key" json:"id"`
	CreatedAt          util.NullTime      `json:"created_at" form:"created_at"`
	UpdatedAt          util.NullTime      `json:"updated_at" form:"updated_at"`
	Name               string             `json:"name"`
	NameSpell          string             `json:"name_spell"`
	CharCount          int                `json:"char_count"`
	Singers            AccompanySingers   `json:"singers"`
	SingerNameAll      string             `json:"singer_name_all"`
	Audio              int                `json:"audio"`
	Songno             string             `json:"songno"`
	Filename           string             `json:"filename"`
	ReleaseTime        util.DateTime      `json:"release_time"`
	Ext                string             `json:"ext"`
	MidFilepath        string             `json:"mid_filepath"`
	LanguageID         int                `json:"language_id"`
	Language           AccompanyLanguage  `json:"language" gorm:"ForeignKey:LanguageID"`
	Channel            string             `json:"channel"`
	VersionID          int                `json:"version_id"`
	Version            AccompanyVersion   `json:"version" gorm:"ForeignKey:VersionID"`
	CategoryID         int                `json:"category_id"`
	Category           AccompanyCategory  `json:"category" gorm:"ForeignKey:CategoryID"`
	EffectID           int                `json:"effect_id"`
	LampID             int                `json:"lamp_id"`
	TagID              int                `json:"tag_id"`
	Tag                AccompanyTag       `json:"tag" gorm:"ForeignKey:TagID"`
	ReverberationGroup string             `json:"reverberation_group"`
	ServerPath         string             `json:"server_path"`
	Rank               int                `json:"rank"`
	VideoqltyID        int                `json:"videoqlty_id"`
	Videoqlty          AccompanyVideoqlty `json:"videoqlty" gorm:"ForeignKey:CategoryID"`
	AudioqltyID        int                `json:"audioqlty_id"`
	Audioqlty          AccompanyAudioqlty `json:"audioqlty" gorm:"ForeignKey:AudioqltyID"`
	OverviewID         int                `json:"overview_id"`
	EmoTagIds          *pq.Int64Array     `json:"emo_tag_ids"`
	DeletedAt          *time.Time         `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (a Accompany) TableName() string {
	return TableAccompany
}

// AccompanySingers 伴奏歌手
type AccompanySingers struct {
	SingerOne   AccompanySinger `json:"singer_one"`
	SingerTwo   AccompanySinger `json:"singer_two"`
	SingerThree AccompanySinger `json:"singer_three"`
	SingerFour  AccompanySinger `json:"singer_four"`
}

// AccompanySinger 歌手
type AccompanySinger struct {
	Name string `json:"name"`
	ID   int    `json:"id"`
}

//Value 转换json存储
func (a AccompanySingers) Value() (driver.Value, error) {
	return json.Marshal(a)
}

//Scan 将数据库对象转换成可以使用的golang 属性
func (a *AccompanySingers) Scan(src interface{}) error {
	bytes, ok := src.([]byte)
	if !ok {
		return errors.New("解析伴奏歌手信息错误")
	}

	if err := json.Unmarshal(bytes, a); nil != err {
		return errors.New("song.accompany.singers json解析失败")
	}

	return nil
}

// AccompanyLanguageNameLikeScope 语种名
func AccompanyLanguageNameLikeScope(s string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(s) == 0 {
			return db
		}

		languageIds := GetLanguageIDByNameLike(s)

		return db.Where("language_id in (?)", languageIds)
	}
}
