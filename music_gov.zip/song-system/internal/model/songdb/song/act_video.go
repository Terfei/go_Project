package song

import (
	"fmt"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableActVideo 跳舞视频
const TableActVideo = `song.act_video`

// ActVideo 跳舞视频
type ActVideo struct {
	ID                 int           `json:"id" gorm:"primary_key"`
	AccompanyID        int           `json:"accompany_id"`
	Songno             string        `json:"songno"`
	AccompanyName      string        `json:"accompany_name"`
	AccompanyNameSpell string        `json:"accompany_name_spell"`
	AccompanyFilename  string        `json:"accompany_filename"`
	Audio              int           `json:"audio"`
	HostIP             string        `json:"host_ip"`
	Image              string        `json:"image"`
	CategoryID         int           `json:"category_id"`
	ActVideoType       int           `json:"act_video_type" form:"act_video_type"`
	CharCount          int           `json:"char_count"`
	Rank               int           `json:"rank"`
	LampID             int           `json:"lamp_id"`
	EffectID           int           `json:"effect_id"`
	ReverberationID    int           `json:"reverberation_id"`
	OverviewID         int           `json:"overview_id"`
	CreatedAt          util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt          util.NullTime `json:"updated_at" form:"updated_at"`
	DeletedAt          *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (a ActVideo) TableName() string {
	return TableActVideo
}

// ActVideoNoOrNameLikeScope 模糊搜索
func ActVideoNoOrNameLikeScope(search string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(search) == 0 {
			return db
		}

		s := fmt.Sprintf("%%%s%%", search)

		return db.Where("songno like ? OR accompany_name like ?", s, s)
	}
}
