package song

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// AccompanyCategory 伴奏分类结构体
type AccompanyCategory struct {
	ID        int           `json:"id" gorm:"primary_key" form:"id"`
	Name      string        `json:"name"`
	NameKey   string        `json:"name_key"`
	Image     string        `json:"image"`
	Seq       int8          `json:"seq"`
	IsShow    int8          `json:"is_show"`
	Type      int8          `json:"type"`
	CreatedAt util.NullTime `json:"created_at"`
	UpdatedAt util.NullTime `json:"updated_at"`
	DeletedAt *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableAccompanyCategory 表名
const TableAccompanyCategory = `song.accompany_category`

// TableName 表名
func (a AccompanyCategory) TableName() string {
	return TableAccompanyCategory
}
