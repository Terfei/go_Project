package song

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableAccompanyTag 伴奏标签表
const TableAccompanyTag = `song.accompany_tag`

// AccompanyTag 结构体
type AccompanyTag struct {
	ID        int           `json:"id" gorm:"primary_key" form:"id"`
	Name      string        `json:"name"`
	Seq       int8          `json:"seq"`
	IsShow    int8          `json:"is_show"`
	CreatedAt util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt util.NullTime `json:"updated_at" form:"updated_at"`
	DeletedAt *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (a AccompanyTag) TableName() string {
	return TableAccompanyTag
}
