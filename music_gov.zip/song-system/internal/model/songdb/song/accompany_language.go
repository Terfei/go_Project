package song

import (
	"fmt"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableAccompanyLanguage 伴奏语种表
const TableAccompanyLanguage = `song.accompany_language`

// AccompanyLanguage 结构体
type AccompanyLanguage struct {
	ID        int           `json:"id" gorm:"primary_key" form:"id"`
	Name      string        `json:"name"`
	NameKey   string        `json:"name_key"`
	Image     string        `json:"image"`
	Seq       int8          `json:"seq"`
	IsShow    int8          `json:"is_show"`
	CreatedAt util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt util.NullTime `json:"updated_at" form:"updated_at"`
	DeletedAt *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (a AccompanyLanguage) TableName() string {
	return TableAccompanyLanguage
}

// GetLanguageIDByNameLike 通过名字模糊搜索信息
func GetLanguageIDByNameLike(s string) []int {
	if len(s) == 0 {
		return []int{}
	}

	var ids []int

	if err := model.SongDB.Table(TableAccompanyLanguage).Where("name like ?", fmt.Sprintf("%%%s%%", s)).Pluck("id", &ids).Error; nil != err {
		return []int{}
	}

	return ids
}

// GetLanguageMap 伴奏语种
func GetLanguageMap() map[int]string {
	response := make(map[int]string)
	items, err := model.SongDB.Table(TableAccompanyLanguage).Rows()
	if items == nil || err != nil {
		fmt.Println(err)
		return response
	}

	defer items.Close()

	for items.Next() {
		var item AccompanyLanguage

		if err := model.SongDB.ScanRows(items, &item); nil != err {
			logger.Entry().WithError(err).Error("language map scan error")
			return response
		}

		response[item.ID] = item.Name
	}

	return response
}
