package song

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableAccompanyVideoqlty 伴奏视频质量表
const TableAccompanyVideoqlty = `song.accompany_videoqlty`

// AccompanyVideoqlty 结构体
type AccompanyVideoqlty struct {
	ID        int           `json:"id" gorm:"primary_key" form:"id"`
	Code      string        `json:"code"`
	Image     string        `json:"image"`
	Seq       int8          `json:"seq"`
	IsShow    int8          `json:"is_show"`
	CreatedAt util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt util.NullTime `json:"updated_at" form:"updated_at"`
	DeletedAt *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (a AccompanyVideoqlty) TableName() string {
	return TableAccompanyVideoqlty
}
