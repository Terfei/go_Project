package song

import (
	"fmt"
	"github.com/jinzhu/gorm"
	"github.com/lib/pq"
	"github.com/sirupsen/logrus"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableWallpaper 动态壁纸
const TableWallpaper = `song.wallpaper`

// png是画中画图框的坐标
// pip 指 画中画mv视频左上角坐标

// Wallpaper ...
type Wallpaper struct {
	ID                int            `json:"id" gorm:"primary_key"`
	WallpaperNo       string         `json:"wallpaper_no"`
	WallpaperName     string         `json:"wallpaper_name"`
	WallpaperFilename string         `json:"wallpaper_filename"`
	Codec             string         `json:"codec"`
	Width             int            `json:"width"`
	Height            int            `json:"height"`
	HostIP            string         `json:"host_ip"`
	Location          string         `json:"location"`
	PipX              int            `json:"pip_x"`
	PipY              int            `json:"pip_y"`
	PngX              int            `json:"png_x"`
	PngY              int            `json:"png_y"`
	Pip2X             int            `json:"pip2_x"`
	Pip2Y             int            `json:"pip2_y"`
	Png2X             int            `json:"png2_x"`
	Png2Y             int            `json:"png2_y"`
	PipWidth          int            `json:"pip_width"`
	PipHeight         int            `json:"pip_height"`
	PngHostIP         string         `json:"png_host_ip"`
	PngCount          int            `json:"png_count"`
	EmoTagIds         *pq.Int64Array `json:"emo_tag_ids"`
	OverviewID        int            `json:"overview_id"`
	CreatedAt         util.NullTime  `json:"created_at" form:"created_at"`
	UpdatedAt         util.NullTime  `json:"updated_at" form:"updated_at"`
	DeletedAt         *time.Time     `json:"deleted_at" form:"deleted_at"`
}

// TableName ...
func (w Wallpaper) TableName() string {
	return TableWallpaper
}

// WallpaperLikeScope 模糊搜索
func WallpaperLikeScope(column string, search string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(column) == 0 || len(search) == 0 {
			logger.Entry().WithFields(logrus.Fields{
				"column": column,
				"search": search,
			}).Error("动态壁纸模糊搜索错误")

			return db
		}

		return db.Where(fmt.Sprintf("%s like ?", column), fmt.Sprintf("%%%s%%", search))
	}
}
