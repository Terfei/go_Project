package song

import (
	"time"

	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// TableNameSinger 歌手表
const TableNameSinger = `song.singer`

// Singer 歌手
type Singer struct {
	ID           int           `json:"id"`
	Code         string        `json:"code"`
	Name         string        `json:"name" excel:"SONGERNAME"`
	Nickname     string        `json:"nickname" excel:"SONGERNAME"`
	NameSpell    string        `json:"name_spell" excel:"SPELL"`
	CharCount    int           `json:"char_count" excel:"SINGERNUM"`
	Gender       Gander        `json:"gender" excel:"SEX"`
	LanguageType string        `json:"language_type"`
	AreaID       int           `json:"area_id" excel:"area"`
	Area         SingerArea    `json:"area" gorm:"ForeignKey:AreaID"`
	Image        string        `json:"image"`
	Bh           string        `json:"bh"`
	Rank         int           `json:"rank"`
	Weight       int           `json:"weight"`
	OverviewID   int           `json:"overview_id"`
	CreatedAt    util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt    util.NullTime `json:"updated_at" form:"updated_at"`
	DeletedAt    *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableName 歌手表
func (s Singer) TableName() string {
	return TableNameSinger
}

// Gander 性别枚举
type Gander int

// String string
func (g Gander) String() string {
	return []string{"男", "女", "合"}[g]
}

// Int int
func (g Gander) Int() int {
	return int(g)
}

const (
	// Male 男
	Male Gander = iota
	// Female 女
	Female
	// Combine 合
	Combine
)

// GanderFromString 根据性别中文获取对应数据表值
func GanderFromString(str string) Gander {
	ganderMap := map[string]Gander{
		`男`: Male,
		`女`: Female,
		`合`: Combine,
	}

	if g, ok := ganderMap[str]; ok {
		return g
	}

	return Combine
}

// FindSingerByName 通过歌手名字查询歌手信息
func FindSingerByName(name string) (*Singer, error) {
	var s Singer

	if err := model.SongDB.Where("name = ?", name).First(&s).Error; nil != err {
		return nil, err
	}

	return &s, nil
}

// FindSingerByCode 通过歌手编号查询歌手信息
func FindSingerByCode(code string) (*Singer, error) {
	var s Singer

	if err := model.SongDB.Where("code = ?", code).First(&s).Error; nil != err {
		return nil, err
	}

	return &s, nil
}

// SingerNameLikeScope 歌星名称匹配
func SingerNameLikeScope(name string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if name == `` {
			return db
		}

		return db.Where(`name like ?`, `%`+name+`%`)
	}
}

// SingerCodeLikeScope 歌星编号匹配
func SingerCodeLikeScope(code string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if code == `` {
			return db
		}

		return db.Where(`code like ?`, `%`+code+`%`)
	}
}
