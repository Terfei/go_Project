package song

import (
	"fmt"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableAcc 公播表名
const TableAcc = `song.acc`

// AccType 公播类型
type AccType int

const (
	// AccTypeUnknow 未知
	AccTypeUnknow AccType = iota
	// AccTypeCK chunk
	AccTypeCK
	// AccTypeKP kp
	AccTypeKP
	// AccTypeGala gala
	AccTypeGala
)

// Acc 公播结构提
type Acc struct {
	ID              int            `gorm:"primary_key" json:"id"`
	AccID           int            `json:"acc_id"`
	AccName         string         `json:"acc_name"`
	HostIP          string         `json:"host_ip"`
	Filename        string         `json:"filename"`
	Filename2       string         `json:"filename2" form:"filename2"`
	ListID          int            `json:"list_id"`
	ListName        string         `json:"list_name"`
	Seq             int            `json:"seq"`
	Codec           string         `json:"codec"`
	Channel         string         `json:"channel"`
	LampID          int            `json:"lamp_id"`
	ReverberationID int            `json:"reverberation_id"`
	EffectID        int            `json:"effect_id"`
	Volume          int            `json:"volume"`
	Audio           int            `json:"audio"`
	StartTime       util.LocalTime `json:"start_time"`
	EndTime         util.LocalTime `json:"end_time"`
	StrLevel        int            `json:"str_level"`
	Mode            int            `json:"mode"`
	AccType         AccType        `json:"acc_type"`
	OverviewID      int            `json:"overview_id"`
	CreatedAt       util.NullTime  `json:"created_at" form:"created_at"`
	UpdatedAt       util.NullTime  `json:"updated_at" form:"updated_at"`
	DeletedAt       *time.Time     `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (a Acc) TableName() string {
	return TableAcc
}

// IntToAccType 公播类型转换
func IntToAccType(t int) AccType {
	switch t {
	case 1:
		return AccTypeCK
	case 2:
		return AccTypeKP
	case 3:
		return AccTypeGala
	}
	return AccTypeUnknow
}

// Int 转int
func (a AccType) Int() int {
	return int(a)
}

// AccTypeScope 公播类型
func AccTypeScope(t AccType) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if t == AccTypeUnknow {
			return db
		}
		return db.Where("acc_type = ?", t)
	}
}

// AccNoOrNameLikeScope 编号or名 模糊搜索
func AccNoOrNameLikeScope(search string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if len(search) == 0 {
			return db
		}

		s := fmt.Sprintf("%%%s%%", search)

		return db.Where("acc_id::text like ? or acc_name like ?", s, s)
	}
}
