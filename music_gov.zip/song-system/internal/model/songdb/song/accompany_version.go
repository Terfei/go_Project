package song

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableAccompanyVersion 伴奏视频质量表
const TableAccompanyVersion = `song.accompany_version`

// AccompanyVersion 结构体
type AccompanyVersion struct {
	ID        int           `json:"id" gorm:"primary_key" form:"id"`
	Seq       int8          `json:"seq"`
	Name      string        `json:"name"`
	CreatedAt util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt util.NullTime `json:"updated_at" form:"updated_at"`
	DeletedAt *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (a AccompanyVersion) TableName() string {
	return TableAccompanyVersion
}
