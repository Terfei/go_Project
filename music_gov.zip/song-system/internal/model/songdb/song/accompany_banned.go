package song

import (
	"time"

	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// TableAccompanyBanned 禁歌表
const TableAccompanyBanned = `song.accompany_banned`

// AccompanyBanned 结构体
type AccompanyBanned struct {
	ID         int           `gorm:"primary_key" json:"id"`
	SongName   string        `json:"song_name"`
	SingerName string        `json:"singer_name"`
	Remark     string        `json:"remark"`
	BanDate    string        `json:"ban_date"`
	CreatedAt  util.NullTime `json:"created_at" db:"created_at"`
	UpdatedAt  util.NullTime `json:"updated_at" db:"updated_at"`
	DeletedAt  *time.Time    `json:"deleted_at"`
}

// TableName table name
func (a AccompanyBanned) TableName() string {
	return TableAccompanyBanned
}

// CountBannedBySongName 歌名查找
func CountBannedBySongName(songName string) (count int) {
	model.SongDB.Model(&AccompanyBanned{}).Where(`song_name = ?`, songName).Count(&count)

	return
}
