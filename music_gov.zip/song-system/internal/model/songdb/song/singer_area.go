package song

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableSingerArea singer area
const TableSingerArea = `song.singer_area`

// SingerArea 歌手区域
type SingerArea struct {
	ID        int           `json:"id" gorm:"primary_key"`
	Name      string        `json:"name"`
	Image     string        `json:"image"`
	Seq       int8          `json:"seq"`
	CreatedAt util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt util.NullTime `json:"updated_at" form:"updated_at"`
	DeletedAt *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (s SingerArea) TableName() string {
	return TableSingerArea
}
