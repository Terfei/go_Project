package song

import (
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// TableVj vj
const TableVj = `song.vj`

// Vj 结构
type Vj struct {
	ID         int           `gorm:"primary_key" json:"id"`
	Name       string        `json:"name"`
	Filename   string        `json:"filename"`
	HostIP     string        `json:"host_ip"`
	Codec      string        `json:"codec"`
	CategoryID int           `json:"category_id"`
	OverviewID int           `json:"overview_id"`
	CreatedAt  util.NullTime `json:"created_at" form:"created_at"`
	UpdatedAt  util.NullTime `json:"updated_at" form:"updated_at"`
	DeletedAt  *time.Time    `json:"deleted_at" form:"deleted_at"`
}

// TableName table name
func (a Vj) TableName() string {
	return TableVj
}
