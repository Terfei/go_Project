package model

import (
	"gitlab.omytech.com.cn/gopkg/db/gorm"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
)

// BridgeDB center datebase
var BridgeDB gorm.Conn

// BridgeConnection 初始化 bridge connection
func BridgeConnection(c config.DBConfig) {
	param := gorm.Config{
		Dialect:  gorm.ConfigDialectPostgre,
		Server:   c.Server,
		Port:     c.Port,
		User:     c.User,
		Database: c.Database,
		Password: c.Password,
	}

	BridgeDB = gorm.Build(param)

	BridgeDB.LogMode(c.Log)
}
