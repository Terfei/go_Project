package branch

import "github.com/satori/go.uuid"

// TableMetaDistrict 区域
const TableMetaDistrict = `centre_bridge.meta_district`

// MetaDistrict 结构体
type MetaDistrict struct {
	DistrictID   uuid.UUID `json:"district_id"`
	DistrictName string    `json:"district_name"`
}

// TableName ...
func (a MetaDistrict) TableName() string {
	return TableMetaDistrict
}
