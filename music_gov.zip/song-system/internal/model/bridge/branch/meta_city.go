package branch

import (
	"github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
)

// TableMetaCity 门店
const TableMetaCity = `centre_bridge.meta_city`

// MetaCity city
type MetaCity struct {
	CityID     uuid.UUID `json:"city_id"`
	DistrictID uuid.UUID `json:"district_id"`
}

// TableName ...
func (a MetaCity) TableName() string {
	return TableMetaCity
}

// AllCity city map
func AllCity() map[uuid.UUID]MetaCity {
	var items []MetaCity

	res := make(map[uuid.UUID]MetaCity)
	model.BridgeDB.Find(&items)

	for _, item := range items {
		res[item.CityID] = item
	}

	return res
}
