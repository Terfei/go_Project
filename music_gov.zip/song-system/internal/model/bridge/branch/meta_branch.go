package branch

import (
	"github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
)

// TableMetaBranch 门店
const TableMetaBranch = `centre_bridge.meta_branch`

// biz_type 0直营　１加盟

// MetaBranch 结构体
type MetaBranch struct {
	BranchID   uuid.UUID `json:"branch_id"`
	BranchName string    `json:"branch_name"`
	BizType    int       `json:"biz_type"`
	CityID     uuid.UUID `json:"city_id"`
	Code       string    `json:"code"`
}

// TableName ...
func (a MetaBranch) TableName() string {
	return TableMetaBranch
}

// AllBranchMap 所有门店
func AllBranchMap() map[uuid.UUID]MetaBranch {
	var items []MetaBranch
	model.BridgeDB.Find(&items)
	response := make(map[uuid.UUID]MetaBranch)

	for _, item := range items {
		response[item.BranchID] = item
	}

	return response
}
