package users

import (
	"crypto/md5"
	"database/sql/driver"
	"encoding/json"
	"fmt"

	"github.com/jinzhu/gorm"

	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// TableUserStaff 表名
const TableUserStaff = `centre_bridge.users_staff`

// StaffMore 员工冗余信息
type StaffMore struct {
	IsAdministrator util.StringInt `json:"is_administrator"`
}

// Value 转换为数据库字段类型
func (m StaffMore) Value() (driver.Value, error) {
	return json.Marshal(m)
}

// Scan 将数据库数据映射到结构体
func (m *StaffMore) Scan(src interface{}) error {
	return util.ScanJSON(m, src)
}

// Staff 结构体
type Staff struct {
	StaffID           uuid.UUID     `json:"staff_id" gorm:"primary_key" form:"staff_id"`
	Gender            int8          `json:"gender"`
	StaffName         string        `json:"staff_name" form:"staff_name"`
	StaffNumber       string        `json:"staff_number" form:"staff_number"`
	ErpCode           string        `json:"erp_code" form:"erp_code"`
	Password          string        `json:"-"`
	AuthorizationSalt string        `json:"-" form:"authorization_salt"`
	Phone             string        `json:"phone"`
	BranchIDs         util.UUIDArr  `json:"branch_ids"`
	More              StaffMore     `json:"more"`
	CreateTime        util.NullTime `json:"create_time" form:"create_time"`
	UpdateTime        util.NullTime `json:"update_time" form:"update_time"`
	DeleteTime        util.NullTime `json:"delete_time" form:"delete_time"`
}

// TableName table name
func (s Staff) TableName() string {
	return TableUserStaff
}

// IsAdmin is admin
func (s Staff) IsAdmin() bool {
	return s.More.IsAdministrator == 1
}

// IsPasswordRight 判断密码是否正确
func (s Staff) IsPasswordRight(p string) bool {
	return s.Password == fmt.Sprintf("%x", md5.Sum([]byte(p+":"+s.AuthorizationSalt)))
}

// SignFlag 登陆签名信息
type SignFlag struct{}

// Value 转换为数据库字段类型
func (m SignFlag) Value() (driver.Value, error) {
	return json.Marshal(m)
}

// Scan 将数据库数据映射到结构体
func (m *SignFlag) Scan(src interface{}) error {
	return util.ScanJSON(m, src)
}

// StaffByNumber 根据员工号查询员工对象
func StaffByNumber(n string) (*Staff, error) {
	var staff Staff

	if err := model.BridgeDB.Where("staff_number = ? or erp_code = ?", n, n).Where("delete_time is null").First(&staff).Error; nil != err {
		return nil, err
	}

	return &staff, nil
}

// StaffByID ID 查找
func StaffByID(id uuid.UUID) (*Staff, error) {
	var staff Staff

	if err := model.BridgeDB.Where("staff_id = ?", id).First(&staff).Error; nil != err {
		return nil, err
	}

	return &staff, nil
}

// BranchIDInScope 门店id匹配
func BranchIDInScope(branchID uuid.UUID) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if uuid.Equal(branchID, uuid.Nil) {
			return db
		}

		return db.Where("branch_ids && ?", `{`+branchID.String()+`}`)
	}
}

// StaffNameLikeScope 店员名称匹配
func StaffNameLikeScope(name string) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if name == `` {
			return db
		}

		return db.Where(`staff_name like ?`, `%`+name+`%`)
	}
}
