package model

import (
	"gitlab.omytech.com.cn/gopkg/db/gorm"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
)

// SongDB song date base
var SongDB gorm.Conn

// SongSystemConnection 初始化 SongSystem connection
func SongSystemConnection(c config.DBConfig) {
	param := gorm.Config{
		Dialect:  gorm.ConfigDialectPostgre,
		Server:   c.Server,
		Port:     c.Port,
		User:     c.User,
		Database: c.Database,
		Password: c.Password,
	}

	SongDB = gorm.Build(param)

	SongDB.LogMode(c.Log)
}
