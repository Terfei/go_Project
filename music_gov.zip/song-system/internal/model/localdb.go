package model

import (
	"github.com/lib/pq"
	"gitlab.omytech.com.cn/gopkg/db/gorm"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"strconv"
	"strings"
)

// LocalDB local db链接
var LocalDB gorm.Conn

// LocalDBConnection ...
func LocalDBConnection(c config.DBConfig) {
	param := gorm.Config{
		Dialect: gorm.ConfigDialectSqliteV3,
		Server:  c.Server,
	}

	LocalDB = gorm.Build(param)

	LocalDB.LogMode(c.Log)
}

// EmoTagID 情绪标签类型
type EmoTagID string

// ToPqInt64Arr string=> int arr
func (e EmoTagID) ToPqInt64Arr() (*pq.Int64Array, error) {
	a := pq.Int64Array{}
	str := string(e)
	if len(str) == 0 {
		return &a, nil
	}

	for _, s := range strings.Split(string(e), ",") {
		i, _ := strconv.Atoi(s)

		a = append(a, int64(i))
	}

	return &a, nil
}
