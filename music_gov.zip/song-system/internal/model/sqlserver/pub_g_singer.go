package sqlserver

// TablePubGSinger ...
const TablePubGSinger = `vodmusic.dbo.PubGSinger`

// PubGSinger 歌手
type PubGSinger struct {
	ID           int    `json:"Id"`
	SingerNo     string `json:"SingerNo"`
	SongerName   string `json:"SONGERNAME"`
	LanguageType string `json:"LANGUAGE_TYPE"`
	Bh           string `json:"BH"`
}

// TableName table name
func (p PubGSinger) TableName() string {
	return TablePubGSinger
}
