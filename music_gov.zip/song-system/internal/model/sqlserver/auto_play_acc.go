package sqlserver

import "gitlab.omytech.com.cn/vod/song-system/internal/util"

// AutoPlayAcc 统一定义公播结构体
type AutoPlayAcc struct {
	AutoplayAccID        int            `json:"autoplay_acc_id"`
	AutoplayAccName      string         `json:"autoplay_acc_name"`
	HostIP               string         `json:"host_ip"`
	AutoplayAccFilename  string         `json:"autoplay_acc_filename"`
	AutoplayAccFilename2 string         `json:"autoplay_acc_filename2"`
	ListID               int            `json:"list_id"`
	ListName             string         `json:"list_name"`
	Seq                  int            `json:"seq"`
	Codec                string         `json:"codec"`
	Channel              string         `json:"channel"`
	LampID               int            `json:"lamp_id"`
	ReverberationID      int            `json:"reverberation_id"`
	EffectID             int            `json:"effect_id"`
	Volume               int            `json:"volume"`
	Audio                int            `json:"audio"`
	StartTime            util.LocalTime `json:"start_time"`
	EndTime              util.LocalTime `json:"end_time"`
	Mode                 int            `json:"mode"`
	StrLevel             int            `json:"str_level"`
}

// TableAutoPlayAccCK 纯Ｋ公播结构体
const TableAutoPlayAccCK = `AutoPlay_Acc_CK`

// AutoPlayAccCK chunk
type AutoPlayAccCK AutoPlayAcc

// TableName table name
func (a AutoPlayAccCK) TableName() string {
	return TableAutoPlayAccCK
}

// TableAutoPlayAccKP kp
const TableAutoPlayAccKP = `AutoPlay_Acc_KP`

// AutoPlayAccKP kp
type AutoPlayAccKP AutoPlayAcc

// TableName table name
func (a AutoPlayAccKP) TableName() string {
	return TableAutoPlayAccKP
}

// TableAutoPlayAccGala gala
const TableAutoPlayAccGala = `AutoPlay_Acc_Gala`

// AutoPlayAccGala gala
type AutoPlayAccGala AutoPlayAcc

// TableName table name
func (a AutoPlayAccGala) TableName() string {
	return TableAutoPlayAccGala
}
