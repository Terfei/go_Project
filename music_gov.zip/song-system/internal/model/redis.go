package model

import (
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
)

// Rds redis连接对象
var Rds *redis.Client

// RedisConnection redis connection
func RedisConnection(c config.RedisConfig) error {
	Rds = redis.NewClient(&redis.Options{
		Addr:     fmt.Sprintf("%s:%d", c.Server, c.Port),
		Password: c.Password,
		DB:       c.Database,
	})

	_, err := Rds.Ping(context.Background()).Result()

	return err
}
