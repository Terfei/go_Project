package middleware

import (
	"database/sql"
	"fmt"
	"gitlab.omytech.com.cn/gopkg/logger"
	"net/http"
	"time"

	"github.com/dgrijalva/jwt-go"
	"github.com/dgrijalva/jwt-go/request"
	"github.com/gin-gonic/gin"
	"github.com/pkg/errors"
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/users"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/user"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// Auth 登录校验
func Auth() gin.HandlerFunc {
	return func(c *gin.Context) {
		var staffID string

		token, err := request.ParseFromRequest(c.Request, request.AuthorizationHeaderExtractor, func(token *jwt.Token) (interface{}, error) {
			claims := token.Claims.(jwt.MapClaims)
			id, ok := claims["staff_id"]

			if !ok {
				return nil, util.ErrLoginNotFound
			}

			staffID = id.(string)

			secret := config.Setting.Jwt.Secret

			return util.StringToByte(secret), nil
		})

		if nil != err || !token.Valid {
			api.Unauthorized(c, "Token error")
			c.Abort()
			return
		}

		staff, err := getStaff(staffID)
		if errors.Is(err, sql.ErrNoRows) {
			//api.Error(w, http.StatusUnauthorized, "登陆用户不存在")
			return
		} else if nil != err {
			api.ServerError(c, "服务器出错，请稍后重试")
			c.Abort()
			return
		}

		c.Set("auth_staff", staff)
		c.Next()
	}
}

// Login 登陆
func Login(username, password string) (*users.Staff, string, error) {
	staff, err := users.StaffByNumber(username)
	if nil != err {
		return nil, "", err
	}

	if !staff.IsPasswordRight(password) {
		return nil, "", util.ErrPassword
	}

	secret := config.Setting.Jwt.Secret
	timeout := config.Setting.Jwt.Timeout

	expire := time.Now().Add(time.Hour * timeout)
	claims := jwt.MapClaims{"staff_id": staff.StaffID}
	claims["exp"] = expire.Unix()
	claims["orig_iat"] = time.Now().Unix()

	token, err := jwt.NewWithClaims(jwt.SigningMethodHS256, claims).SignedString(util.StringToByte(secret))

	return staff, token, err
}

func getStaff(id string) (*users.Staff, error) {
	staffID, err := uuid.FromString(id)
	if nil != err {
		return nil, errors.Wrap(err, "uuid字符串转UUID")
	}

	return users.StaffByID(staffID)
}

// StaffFromContext 从上下文中获取登陆员工对象
func StaffFromContext(c *gin.Context) *users.Staff {
	staff, ok := c.Get("auth_staff")
	if !ok {
		panic(fmt.Errorf("从Context中获取登陆用户失败"))
	}

	return staff.(*users.Staff)
}

// Permission 权限点认证
// 输入一批权限点，只有满足其中一个权限的情况，才能访问
func Permission(pids ...string) gin.HandlerFunc {
	return func(c *gin.Context) {
		authStaff, ok := c.Get("auth_staff")
		if !ok {
			logger.Entry().Error("请登陆后访问")
			c.AbortWithStatus(http.StatusUnauthorized)
		}
		staff, _ := authStaff.(*users.Staff)
		if 1 == *&staff.More.IsAdministrator {
			return
		}

		localStaff, err := user.LocalStaffByID(staff.StaffID)
		if nil != err {
			logger.Entry().Error("系统内未找到当前用户，请联系管理员")
			c.AbortWithStatus(http.StatusUnauthorized)
		}

		permissions := localStaff.Permissions()
		// 如果员工没有权限，那么就不能访问
		if 0 >= len(permissions) {
			c.AbortWithStatus(http.StatusForbidden)
		}

		for _, pid := range pids {
			if _, ok := permissions[pid]; ok {
				return
			}
		}

		c.AbortWithStatus(http.StatusForbidden)
	}
}
