package image

import (
	"fmt"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	bridgeBranch "gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/image"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

type responseListItem struct {
	BranchName string `json:"branch_name"`
	image.TemplatePlan
}

// GetCentreTemplatePlan 总部模板应用
func GetCentreTemplatePlan(c *gin.Context) {
	var request struct {
		api.PageRequest
		BranchBizType int    `json:"branch_biz_type" form:"branch_biz_type"`
		BranchID      string `json:"branch_id" form:"branch_id"`
		CategoryID    int    `json:"category_id" form:"category_id"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("总部模板应用列表")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	branchID, err := normalizeGetBranchID(c)
	if nil != err {
		api.Unprocessable(c, err.Error())
		return
	}
	branches, branchIDs, err := listBranches(c, request.BranchBizType, branchID)

	query := model.SongDB.Model(&image.TemplatePlan{}).
		Preload(`Template`).Preload(`Category`).
		Scopes(
			songdb.ColumnEqualScope("module", image.TemplateModuleCentre),
		)
	if request.CategoryID > 0 {
		query = query.Scopes(songdb.ColumnEqualScope(`category_id`, request.CategoryID))
	}
	if len(branchIDs) > 0 {
		query = query.Where("branch_id in (?)", branchIDs)
	} else {
		query = query.Where(`branch_id is null`)
	}

	page := request.PageRequest.OffsetLimit()
	var count int
	var plans []image.TemplatePlan
	query.Count(&count)
	query.Order("created_at desc").Offset(page.Offset).Limit(page.Limit).Find(&plans)

	result := make([]responseListItem, 0)
	for _, item := range plans {
		branch := branches[item.BranchID]
		result = append(result, responseListItem{
			branch.BranchName,
			item,
		})
	}

	api.MakePage(c, result, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// ShowCentreTemplatePlan 查看总部模板应用
func ShowCentreTemplatePlan(c *gin.Context) {
	var plan image.TemplatePlan
	query := model.SongDB.Model(&image.TemplatePlan{}).Preload(`Template`).Preload(`Category`)

	if err := query.Where(c.Param("id")).First(&plan).Error; nil != err {
		logger.Entry().WithError(err).Error("查询总部模板应用，数据无效")
		api.NotFound(c)
		return
	}

	api.Make(c, map[string]interface{}{
		`list`: plan,
	})
}

// PostCentreTemplatePlan 新增总部模板应用
func PostCentreTemplatePlan(c *gin.Context) {
	var request struct {
		BeginTime  util.NullTime `json:"begin_time" binding:"required"`
		EndTime    util.NullTime `json:"end_time" binding:"required"`
		BranchIDs  []string      `json:"branch_ids" binding:"required"`
		CategoryID int           `json:"category_id" binding:"required"`
		TemplateID int           `json:"template_id" binding:"required"`
		Remark     string        `json:"remark"`
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error("总部模板应用新增")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		for _, id := range request.BranchIDs {
			bID, err := uuid.FromString(id)
			if err != nil {
				continue
			}

			plan := image.TemplatePlan{
				Module:     image.TemplateModuleCentre,
				CategoryID: request.CategoryID,
				TemplateID: request.TemplateID,
				BranchID:   bID,
				BeginTime:  request.BeginTime,
				EndTime:    request.EndTime,
				Remark:     request.Remark,
				Status:     image.PlanStatusAudit,
			}
			if err := tx.Omit(`Template`, `Category`).Create(&plan).Error; nil != err {
				logger.Entry().WithError(err).WithField("template_plan", plan).Error("保存总部模板应用")
				return fmt.Errorf("保存数据错误:%s", err.Error())
			}
			if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageTemplatePlan, meta.LogActionInsert, "新增总部模板应用", plan, plan.ID); nil != err {
				logger.Entry().WithError(err).WithField("template_plan", plan).Error("保存总部模板应用新增操作历史")
				// return fmt.Errorf("保存操作历史:%s", err.Error())
			}
		}

		return nil
	})

	if nil != err {
		api.ServerError(c, `新增总部模板应用失败`)
		return
	}

	api.Created(c)
}

// PatchCentreTemplatePlan 修改总部模板应用
func PatchCentreTemplatePlan(c *gin.Context) {
	var request struct {
		TemplateID int    `json:"template_id" binding:"required"`
		Remark     string `json:"remark"`
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error("修改总部模板应用")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var plan image.TemplatePlan
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&plan).Error; nil != err {
		logger.Entry().WithError(err).Error("修改总部模板应用，数据无效")
		api.NotFound(c)
		return
	}

	updateData := util.MakeParams(request)
	if err := model.SongDB.Model(&plan).Where("id = ?", plan.ID).Update(updateData).Error; nil != err {
		logger.Entry().WithError(err).Error("更新总部模板应用")
		api.ServerError(c, fmt.Sprintf("保存数据失败:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageTemplate, meta.LogActionUpdate, "修改总部模板应用", updateData, plan.ID); nil != err {
		logger.Entry().WithError(err).WithField("request", request).Error("保存修改总部模板应用操作历史")
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.NoContent(c)
}

// DeleteCentreTemplatePlan 删除总部模板应用
func DeleteCentreTemplatePlan(c *gin.Context) {
	var request struct {
		IDs []int `json:"ids"`
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error(`删除总部模板应用`)
		api.BadRequest(c, `参数错误`)
		return
	}

	if err := model.SongDB.Where(`id in (?)`, request.IDs).Delete(&image.TemplatePlan{}).Error; nil != err {
		logger.Entry().WithError(err).Error("删除总部模板应用")
		api.ServerError(c, err.Error())
		return
	}

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleImageTemplatePlan).
		SetStaff(middleware.StaffFromContext(c)).SetAction(meta.LogActionDelete).SetRemark(`删除总部模板应用`).SetData(request)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error(`保存删除总部模板应用操作历史`)
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.NoContent(c)
}

func listBranches(c *gin.Context, branchBizType int, branchID uuid.UUID) (map[uuid.UUID]bridgeBranch.MetaBranch, []uuid.UUID, error) {
	IDs := make([]uuid.UUID, 0)
	result := make(map[uuid.UUID]bridgeBranch.MetaBranch, 0)

	q := model.BridgeDB.Model(bridgeBranch.MetaBranch{})
	if _, ok := c.GetQuery("branch_biz_type"); ok {
		q = q.Where("biz_type = ?", branchBizType)
	}
	if !uuid.Equal(branchID, uuid.Nil) {
		q = q.Scopes(songdb.ColumnEqualScope(`branch_id`, branchID))
	}

	var branches []bridgeBranch.MetaBranch
	if err := q.Find(&branches).Error; nil != err {
		return result, IDs, err
	}

	for _, b := range branches {
		result[b.BranchID] = b
		IDs = append(IDs, b.BranchID)
	}

	return result, IDs, nil
}

func normalizeGetBranchID(c *gin.Context) (ID uuid.UUID, err error) {
	ID = uuid.Nil
	if _, ok := c.GetQuery(`branch_id`); ok {
		ID, err = uuid.FromString(c.Query(`branch_id`))

		return
	}

	return
}
