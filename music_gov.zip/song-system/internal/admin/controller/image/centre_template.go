package image

import (
	"fmt"

	"github.com/gin-gonic/gin"
	"github.com/lib/pq"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/image"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
)

// GetCentreTemplate 总部模板
func GetCentreTemplate(c *gin.Context) {
	var request struct {
		api.PageRequest
		Code       string `json:"code" form:"code"`
		Title      string `json:"title" form:"title"`
		CategoryID int    `json:"category_id" form:"category_id"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("总部模板列表")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	query := model.SongDB.Model(&image.Template{}).
		Preload(`Category`).
		Scopes(
			songdb.ColumnLikeScope("code", request.Code),
			songdb.ColumnLikeScope("title", request.Title),
			songdb.ColumnEqualScope("module", image.TemplateModuleCentre),
		)
	if request.CategoryID > 0 {
		query = query.Scopes(songdb.ColumnEqualScope(`category_id`, request.CategoryID))
	}

	page := request.PageRequest.OffsetLimit()
	var count int
	var items []image.Template
	query.Count(&count)
	query.Order("created_at desc").Offset(page.Offset).Limit(page.Limit).Find(&items)

	api.MakePage(c, items, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// ShowCentreTemplate 查看总部模板
func ShowCentreTemplate(c *gin.Context) {
	var template image.Template
	if err := model.SongDB.Preload(`Category`).Where(c.Param("id")).First(&template).Error; nil != err {
		logger.Entry().WithError(err).Error("查询总部模板，数据无效")
		api.NotFound(c)
		return
	}

	api.Make(c, map[string]interface{}{
		`list`: template,
	})
}

// PostCentreTemplate 新增总部模板
func PostCentreTemplate(c *gin.Context) {
	var request struct {
		Title      string        `json:"title" binding:"required"`
		CategoryID int           `json:"category_id" binding:"required"`
		ImageIDs   pq.Int64Array `json:"image_ids" binding:"required"`
	}

	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error("总部模板新增")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	template := image.Template{
		Title:      request.Title,
		Module:     image.TemplateModuleCentre,
		CategoryID: request.CategoryID,
		ImageIDs:   request.ImageIDs,
	}

	if err := model.SongDB.Omit(`Images`, `Category`).Create(&template).Error; nil != err {
		logger.Entry().WithError(err).WithField("template", template).Error("保存总部模板")
		api.ServerError(c, fmt.Sprintf("保存数据错误:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageTemplate, meta.LogActionInsert, "新增总部模板", template, template.ID); nil != err {
		logger.Entry().WithError(err).WithField("template", template).Error("保存总部模板新增操作历史")
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.Created(c)
}

// PatchCentreTemplate 修改图片历史
func PatchCentreTemplate(c *gin.Context) {
	var request struct {
		Title      string        `json:"title" binding:"required"`
		CategoryID int           `json:"category_id" binding:"required"`
		ImageIDs   pq.Int64Array `json:"image_ids" binding:"required"`
	}

	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error("修改总部模板")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var template image.Template
	if err := model.SongDB.Model(&template).Omit(`Images`).Where(c.Param("id")).First(&template).Error; nil != err {
		logger.Entry().WithError(err).Error("修改总部模板，数据无效")
		api.NotFound(c)
		return
	}

	template.Title = request.Title
	template.CategoryID = request.CategoryID
	template.ImageIDs = request.ImageIDs
	if err := model.SongDB.Model(&template).Omit(`Images`).Where(template.ID).Update(template).Error; nil != err {
		logger.Entry().WithError(err).Error("更新总部模板")
		api.ServerError(c, fmt.Sprintf("保存数据失败:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageTemplate, meta.LogActionUpdate, "修改总部模板", request, template.ID); nil != err {
		logger.Entry().WithError(err).WithField("request", request).Error("保存修改总部模板操作历史")
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.NoContent(c)
}

// DeleteCentreTemplate 删除总部模板
func DeleteCentreTemplate(c *gin.Context) {
	var request struct {
		IDs []int `json:"ids"`
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error(`删除总部模板`)
		api.BadRequest(c, `参数错误`)
		return
	}

	if err := model.SongDB.Where(`id in (?)`, request.IDs).Delete(&image.Template{}).Error; nil != err {
		logger.Entry().WithError(err).Error("删除总部模板")
		api.ServerError(c, err.Error())
		return
	}

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleImageTemplate).
		SetStaff(middleware.StaffFromContext(c)).SetAction(meta.LogActionDelete).SetRemark(`删除总部模板`).SetData(request)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error(`保存删除总部模板操作历史`)
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.NoContent(c)
}
