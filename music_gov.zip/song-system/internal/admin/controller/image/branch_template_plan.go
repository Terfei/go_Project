package image

import (
	"fmt"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/image"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetBranchTemplatePlan 门店模板应用
func GetBranchTemplatePlan(c *gin.Context) {
	var request struct {
		api.PageRequest
		BranchBizType int              `json:"branch_biz_type" form:"branch_biz_type"`
		BranchID      string           `json:"branch_id" form:"branch_id"`
		CategoryID    int              `json:"category_id" form:"category_id"`
		Status        image.PlanStatus `json:"status" form:"status"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("门店模板应用列表")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	branchID, err := normalizeGetBranchID(c)
	if nil != err {
		api.Unprocessable(c, err.Error())
		return
	}
	branches, branchIDs, err := listBranches(c, request.BranchBizType, branchID)

	query := model.SongDB.Model(&image.TemplatePlan{}).
		Preload(`Template`).Preload(`Category`).
		Scopes(songdb.ColumnEqualScope("module", image.TemplateModuleBranch))
	if request.CategoryID > 0 {
		query = query.Scopes(songdb.ColumnEqualScope(`category_id`, request.CategoryID))
	}
	if request.Status != `` {
		query = query.Scopes(songdb.ColumnEqualScope(`status`, request.Status))
	}
	if len(branchIDs) > 0 {
		query = query.Where("branch_id in (?)", branchIDs)
	} else {
		query = query.Where(`branch_id is null`)
	}

	page := request.PageRequest.OffsetLimit()
	var count int
	var plans []image.TemplatePlan
	query.Count(&count)
	query.Order("created_at desc").Offset(page.Offset).Limit(page.Limit).Find(&plans)

	result := make([]responseListItem, 0)
	for _, item := range plans {
		branch := branches[item.BranchID]
		result = append(result, responseListItem{
			branch.BranchName,
			item,
		})
	}

	api.MakePage(c, result, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// ShowBranchTemplatePlan 查看门店模板应用
func ShowBranchTemplatePlan(c *gin.Context) {
	var plan image.TemplatePlan
	query := model.SongDB.Model(&image.TemplatePlan{}).Preload(`Template`).Preload(`Category`)

	if err := query.Where(c.Param("id")).First(&plan).Error; nil != err {
		logger.Entry().WithError(err).Error("查询门店模板应用，数据无效")
		api.NotFound(c)
		return
	}

	api.Make(c, map[string]interface{}{
		`list`: plan,
	})
}

// PostBranchTemplatePlan 新增门店模板应用
func PostBranchTemplatePlan(c *gin.Context) {
	var request struct {
		BeginTime  util.NullTime `json:"begin_time" form:"begin_time" time_format:"2006-01-02 15:04:05"`
		EndTime    util.NullTime `json:"end_time" binding:"required"`
		BranchIDs  []string      `json:"branch_ids" binding:"required"`
		CategoryID int           `json:"category_id" binding:"required"`
		TemplateID int           `json:"template_id" binding:"required"`
		Remark     string        `json:"remark"`
	}

	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error("门店模板应用新增")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		for _, id := range request.BranchIDs {
			bID, err := uuid.FromString(id)
			if err != nil {
				continue
			}

			plan := image.TemplatePlan{
				Module:     image.TemplateModuleBranch,
				CategoryID: request.CategoryID,
				TemplateID: request.TemplateID,
				BranchID:   bID,
				BeginTime:  request.BeginTime,
				EndTime:    request.EndTime,
				Remark:     request.Remark,
				Status:     image.PlanStatusInit,
			}
			if err := tx.Omit(`Template`, `Category`).Create(&plan).Error; nil != err {
				logger.Entry().WithError(err).WithField("template_plan", plan).Error("保存门店模板应用")
				return fmt.Errorf("保存数据错误:%s", err.Error())
			}
			if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageTemplatePlan, meta.LogActionInsert, "新增门店模板应用", plan, plan.ID); nil != err {
				logger.Entry().WithError(err).WithField("template_plan", plan).Error("保存门店模板应用新增操作历史")
				// return fmt.Errorf("保存操作历史:%s", err.Error())
			}
		}

		return nil
	})

	if nil != err {
		api.ServerError(c, err.Error())
		return
	}

	api.Created(c)
}

// PatchBranchTemplatePlan 修改门店模板应用
func PatchBranchTemplatePlan(c *gin.Context) {
	var request struct {
		TemplateID int    `json:"template_id" binding:"required"`
		Remark     string `json:"remark"`
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error("修改门店模板应用")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var plan image.TemplatePlan
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&plan).Error; nil != err {
		logger.Entry().WithError(err).Error("修改门店模板应用，数据无效")
		api.NotFound(c)
		return
	}

	updateData := util.MakeParams(request)
	if plan.Status == image.PlanStatusReject {
		updateData.Set(`status`, image.PlanStatusInit)
	}
	if err := model.SongDB.Model(&plan).Where(plan.ID).Update(updateData).Error; nil != err {
		logger.Entry().WithError(err).Error("更新门店模板应用")
		api.ServerError(c, fmt.Sprintf("保存数据失败:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageTemplate, meta.LogActionUpdate, "修改门店模板应用", updateData, plan.ID); nil != err {
		logger.Entry().WithError(err).WithField("request", request).Error("保存修改门店模板应用操作历史")
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.NoContent(c)
}

// DeleteBranchTemplatePlan 删除门店模板应用
func DeleteBranchTemplatePlan(c *gin.Context) {
	var request struct {
		IDs []int `json:"ids"`
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error(`删除门店模板应用`)
		api.BadRequest(c, `参数错误`)
		return
	}

	if err := model.SongDB.Where(`id in (?)`, request.IDs).Delete(&image.TemplatePlan{}).Error; nil != err {
		logger.Entry().WithError(err).Error("删除门店模板应用")
		api.ServerError(c, err.Error())
		return
	}

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleImageTemplatePlan).
		SetStaff(middleware.StaffFromContext(c)).SetAction(meta.LogActionDelete).SetRemark(`删除门店模板应用`).SetData(request)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error(`保存删除门店模板应用操作历史`)
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.NoContent(c)
}

// AuditBranchTemplatePlan 审核门店模板应用
func AuditBranchTemplatePlan(c *gin.Context) {
	var request struct {
		IDs []int `json:"ids"`
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error(`审核门店模板应用`)
		api.BadRequest(c, `参数错误`)
		return
	}

	p := make(util.Params, 0)
	p.Set(`status`, image.PlanStatusAudit)
	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		for _, id := range request.IDs {
			if err := tx.Model(&image.TemplatePlan{}).Where(id).Update(p).Error; nil != err {
				logger.Entry().WithError(err).Error("审核门店模板应用")
				return fmt.Errorf("审核门店模板应用，保存数据失败:%s", err.Error())
			}

			if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageTemplate, meta.LogActionUpdate, "审核门店模板应用", p, id); nil != err {
				logger.Entry().WithError(err).WithField("request", request).Error("保存审核门店模板应用操作历史")
				// return fmt.Errorf("保存操作历史:%s", err.Error())
			}
		}
		return nil
	})

	if nil != err {
		api.ServerError(c, err.Error())
		return
	}

	api.NoContent(c)
}

// RejectBranchTemplatePlan 驳回审核
func RejectBranchTemplatePlan(c *gin.Context) {
	var request struct {
		RejectExplain string `json:"reject_explain"`
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error("驳回门店模板应用审核")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var plan image.TemplatePlan
	if err := model.SongDB.Where(c.Param("id")).First(&plan).Error; nil != err {
		logger.Entry().WithError(err).Error("驳回门店模板应用审核，数据无效")
		api.NotFound(c)
		return
	}

	p := util.MakeParams(request)
	p.Set(`status`, image.PlanStatusReject)
	if err := model.SongDB.Model(&plan).Where(plan.ID).Update(p).Error; nil != err {
		logger.Entry().WithError(err).Error("驳回门店模板应用审核")
		api.ServerError(c, fmt.Sprintf("保存数据失败:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageTemplate, meta.LogActionUpdate, "驳回门店模板应用审核", p, plan.ID); nil != err {
		logger.Entry().WithError(err).WithField("request", request).Error("保存驳回门店模板应用审核操作历史")
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.NoContent(c)
}
