package image

import (
	"fmt"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/lib/pq"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/image"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetBranchTemplate 门店模板
func GetBranchTemplate(c *gin.Context) {
	var request struct {
		api.PageRequest
		Code       string `json:"code" form:"code"`
		Title      string `json:"title" form:"title"`
		CategoryID int    `json:"category_id" form:"category_id"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("门店模板列表")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	query := model.SongDB.Model(&image.Template{}).
		Preload(`Category`).
		Scopes(
			songdb.ColumnLikeScope("code", request.Code),
			songdb.ColumnLikeScope("title", request.Title),
			songdb.ColumnEqualScope("module", image.TemplateModuleBranch),
		)
	if request.CategoryID > 0 {
		query = query.Scopes(songdb.ColumnEqualScope(`category_id`, request.CategoryID))
	}

	page := request.PageRequest.OffsetLimit()
	var count int
	var items []image.Template
	query.Count(&count)
	query.Order("created_at desc").Offset(page.Offset).Limit(page.Limit).Find(&items)

	api.MakePage(c, items, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// ShowBranchTemplate 查看门店模板
func ShowBranchTemplate(c *gin.Context) {
	var template image.Template
	if err := model.SongDB.Preload(`Category`).Where(c.Param("id")).First(&template).Error; nil != err {
		logger.Entry().WithError(err).Error("查询门店模板，数据无效")
		api.NotFound(c)
		return
	}

	api.Make(c, map[string]interface{}{
		`list`: template,
	})
}

// PostBranchTemplate 新增门店模板
func PostBranchTemplate(c *gin.Context) {
	var request struct {
		Title      string        `json:"title" binding:"required"`
		CategoryID int           `json:"category_id" binding:"required"`
		ImageIDs   pq.Int64Array `json:"image_ids" binding:"required"`
	}

	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error("门店模板新增")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	template := image.Template{
		Title:      request.Title,
		Module:     image.TemplateModuleBranch,
		CategoryID: request.CategoryID,
		ImageIDs:   request.ImageIDs,
	}

	if err := model.SongDB.Omit(`Images`, `Category`).Create(&template).Error; nil != err {
		logger.Entry().WithError(err).WithField("template", template).Error("保存门店模板")
		api.ServerError(c, fmt.Sprintf("保存数据错误:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageTemplate, meta.LogActionInsert, "新增门店模板", template, template.ID); nil != err {
		logger.Entry().WithError(err).WithField("template", template).Error("保存门店模板新增操作历史")
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.Created(c)
}

// PatchBranchTemplate 修改图片历史
func PatchBranchTemplate(c *gin.Context) {
	var request struct {
		Title      string        `json:"title" binding:"required"`
		CategoryID int           `json:"category_id" binding:"required"`
		ImageIDs   pq.Int64Array `json:"image_ids" binding:"required"`
	}

	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error("修改门店模板")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var template image.Template
	if err := model.SongDB.Model(&template).Omit(`Images`).Where(c.Param("id")).First(&template).Error; nil != err {
		logger.Entry().WithError(err).Error("修改门店模板，数据无效")
		api.NotFound(c)
		return
	}

	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		oriImageIDs := template.ImageIDs

		template.Title = request.Title
		template.CategoryID = request.CategoryID
		template.ImageIDs = request.ImageIDs
		if err := tx.Model(&template).Omit(`Images`).Where(template.ID).Update(template).Error; nil != err {
			logger.Entry().WithError(err).Error("更新门店模板")
			return fmt.Errorf("保存数据失败:%s", err.Error())
		}

		if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageTemplate, meta.LogActionUpdate, "修改门店模板", request, template.ID); nil != err {
			logger.Entry().WithError(err).WithField("request", request).Error("保存修改门店模板操作历史")
			// return fmt.Errorf("保存操作历史:%s", err.Error())
		}

		if util.NewSetInt64(oriImageIDs...).Equal(util.NewSetInt64(request.ImageIDs...)) {
			return nil
		}

		logger.Entry().Warning("模板图片变化，相关模板将进入待审核状态")
		query := tx.Model(&image.TemplatePlan{}).Where(`template_id = ?`, template.ID)

		var plans []image.TemplatePlan
		if err := query.Find(&plans).Error; nil != err {
			logger.Entry().WithError(err).Error("查询模板相关模板应用出错")
			return err
		}

		p := make(util.Params, 0)
		p.Set(`status`, image.PlanStatusInit)
		for _, plan := range plans {
			if err := tx.Model(&plan).Where(plan.ID).Update(p).Error; nil != err {
				logger.Entry().WithField(`template_plan`, plan).WithError(err).Error("修改模板应用状态为待审核出错")
				return err
			}
			if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageTemplatePlan, meta.LogActionUpdate, "修改门店模板引起的模板应用状态改变", p, plan.ID); nil != err {
				logger.Entry().WithError(err).WithField("request", request).Error("保存修改门店模板应用状态操作历史")
				// return fmt.Errorf("保存操作历史:%s", err.Error())
			}
		}

		return nil
	})

	if nil != err {
		api.ServerError(c, err.Error())
		return
	}

	api.NoContent(c)
}

// DeleteBranchTemplate 删除门店模板
func DeleteBranchTemplate(c *gin.Context) {
	var request struct {
		IDs []int `json:"ids"`
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error(`删除门店模板`)
		api.BadRequest(c, `参数错误`)
		return
	}

	if err := model.SongDB.Where(`id in (?)`, request.IDs).Delete(&image.Template{}).Error; nil != err {
		logger.Entry().WithError(err).Error("删除门店模板")
		api.ServerError(c, err.Error())
		return
	}

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleImageTemplate).
		SetStaff(middleware.StaffFromContext(c)).SetAction(meta.LogActionDelete).SetRemark(`删除门店模板`).SetData(request)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error(`保存删除门店模板操作历史`)
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.NoContent(c)
}
