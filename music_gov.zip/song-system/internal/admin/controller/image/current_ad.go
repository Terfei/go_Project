package image

import (
	"fmt"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/image"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

type currentAdRequest struct {
	api.PageRequest
	BranchBizType int    `json:"branch_biz_type" form:"branch_biz_type"`
	BranchID      string `json:"branch_id" form:"branch_id"`
	CategoryID    int    `json:"category_id" form:"category_id"`
}

// GetCurrentAd 获取实时广告列表
func GetCurrentAd(c *gin.Context) {
	var request currentAdRequest
	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("实时广告列表")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	query, err := getCurrentAdQuery(c, request)
	if nil != err {
		api.Unprocessable(c, err.Error())
		return
	}

	page := request.PageRequest.OffsetLimit()
	var count int
	var items []image.Overview
	query.Count(&count)
	query.Order("created_at desc").Offset(page.Offset).Limit(page.Limit).Find(&items)

	api.MakePage(c, items, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// ExportCurrentAd 导出实时广告
func ExportCurrentAd(c *gin.Context) {
	var request currentAdRequest
	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("实时广告列表")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	query, err := getCurrentAdQuery(c, request)
	if nil != err {
		api.Unprocessable(c, err.Error())
		return
	}

	var result []image.Overview
	query.Find(&result)

	xlsx, sheet := util.InitializeXlsx()
	xlsx.SetSheetRow(sheet, `A1`, &[]string{
		`门店`, `类型`, `总部指定广告`, `应用时间`, `门店自选广告`, `应用时间`,
	})
	for idx, v := range result {
		row := []string{
			v.BranchName, v.Category.Title,
		}

		row = append(row, normalizePlanData(v.CenterPlan)...)
		row = append(row, normalizePlanData(v.BranchPlan)...)

		lint := strconv.Itoa(idx + 2)
		xlsx.SetSheetRow(sheet, `A`+lint, &row)
	}

	util.ExportXlsx(xlsx, `实时广告.xlsx`, c)
}

func normalizePlanData(plan *image.OverviewPlan) (result []string) {
	if plan == nil {
		result = []string{``, ``}
		return
	}

	timeFormat := `2006-01-02 15:04:06`
	result = []string{
		strings.Join(plan.Template.Images, `，`),
		fmt.Sprintf(
			`%s-%s`,
			plan.BeginTime.Time.Format(timeFormat),
			plan.EndTime.Time.Format(timeFormat),
		),
	}

	return
}

func getCurrentAdQuery(c *gin.Context, request currentAdRequest) (query *gorm.DB, err error) {
	branchID, err := normalizeGetBranchID(c)
	if nil != err {
		return
	}

	query = model.SongDB.Model(&image.Overview{}).Preload(`Category`)
	if !uuid.Equal(branchID, uuid.Nil) {
		query = query.Scopes(songdb.ColumnEqualScope(`branch_id`, branchID))
	}
	if request.CategoryID > 0 {
		query = query.Scopes(songdb.ColumnEqualScope(`category_id`, request.CategoryID))
	}
	if request.BranchBizType > 0 {
		query = query.Scopes(songdb.ColumnEqualScope(`biz_type`, request.BranchBizType))
	}

	return
}
