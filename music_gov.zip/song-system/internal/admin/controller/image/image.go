package image

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/image"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetImage 图片列表
func GetImage(c *gin.Context) {
	var request struct {
		api.PageRequest
		CategoryID int    `json:"category_id" form:"category_id"`
		Filename   string `json:"filename" form:"filename"`
	}
	if err := c.ShouldBindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("图片列表参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	page := request.OffsetLimit()

	query := model.SongDB.Model(&image.Image{}).Scopes(songdb.ColumnLikeScope("filename", request.Filename))
	if request.CategoryID > 0 {
		query = query.Where("category_id = ?", request.CategoryID)
	}

	var items []image.Image
	var count int
	query.Count(&count)
	query.Order("updated_at desc").Limit(page.Limit).Offset(page.Offset).Find(&items)

	api.MakePage(c, items, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// PostImage 新增图片
func PostImage(c *gin.Context) {
	var request struct {
		CategoryID int    `json:"category_id" form:"category_id" binging:"required,gte=0"`
		Filename   string `json:"filename" binging:"required"`
	}

	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error("新增图片")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	item := image.Image{
		Filename:   request.Filename,
		CategoryID: request.CategoryID,
	}

	if err := model.SongDB.Create(&item).Error; nil != err {
		logger.Entry().WithError(err).WithField("request", request).Error("新增图片错误")
		api.ServerError(c, fmt.Sprintf("保存数据错误:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageImages, meta.LogActionInsert, "新增图片", request, item.ID); nil != err {
		logger.Entry().WithError(err).WithField("image", request).Error("保存图片新增操作历史")
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.Created(c)
}

// SearchImageCount 查询图片
func SearchImageCount(c *gin.Context) {
	var request struct {
		Filename string `json:"filename" form:"filename"`
	}

	if err := c.ShouldBindQuery(&request); nil != err {
		logger.Entry().WithError(err).WithField("search", request).Error("查询图片错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var count int
	model.SongDB.Model(&image.Image{}).Scopes(songdb.ColumnEqualScope("filename", request.Filename)).Count(&count)

	api.Make(c, map[string]int{
		"count": count,
	})
}

// DeleteImage 删除
func DeleteImage(c *gin.Context) {
	var item image.Image
	if err := model.SongDB.Model(&image.Image{}).Where("id = ?", c.Param("id")).First(&item).Error; nil != err {
		logger.Entry().WithError(err).Error("删除图片记录错误")
		api.NotFound(c)
		return
	}

	conf := config.Setting.Aliyun.Oss

	if err := util.NewAliyunOss(conf).DeleteObject(fmt.Sprintf("%s/%s", conf.Ad, item.Filename)); nil != err {
		logger.Entry().WithError(err).WithField("image", item).Error("删除阿里云数据失败")
		api.ServerError(c, fmt.Sprintf("删除阿里云数据失败:%s", err.Error()))
		return
	}

	if err := model.SongDB.Model(&item).Where("id = ?", item.ID).Delete(&item).Error; nil != err {
		logger.Entry().WithError(err).WithField("image", item).Error("删除数据失败")
		api.ServerError(c, fmt.Sprintf("删除数据失败:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageImages, meta.LogActionDelete, "删除图片", item, item.ID); nil != err {
		logger.Entry().WithError(err).WithField("image", item).Error("保存图片删除操作历史")
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.NoContent(c)
}
