package image

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/image"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetImageCategory 图片类型
func GetImageCategory(c *gin.Context) {
	var request struct {
		Title string `json:"title" form:"title"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("图片类型列表")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var items []image.Category
	model.SongDB.Scopes(songdb.ColumnLikeScope("title", request.Title)).Order("created_at").Find(&items)

	api.Make(c, items)
}

// PostImageCategory 新增图片类型
func PostImageCategory(c *gin.Context) {
	var request struct {
		Title  string `json:"title" binding:"required"`
		Width  int    `json:"width" binding:"required,gte=0"`
		Height int    `json:"height" binding:"required,gte=0"`
		Disk   string `json:"disk" binding:"required"`
	}

	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error("图片类型新增")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	category := image.Category{
		Title:  request.Title,
		Height: request.Height,
		Width:  request.Width,
		Disk:   request.Disk,
	}

	if err := model.SongDB.Create(&category).Error; nil != err {
		logger.Entry().WithError(err).WithField("category", category).Error("保存图片类型")
		api.ServerError(c, fmt.Sprintf("保存数据错误:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageCategory, meta.LogActionInsert, "新增图片类型", category, category.ID); nil != err {
		logger.Entry().WithError(err).WithField("category", category).Error("保存图片类型新增操作历史")
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.Created(c)
}

// PatchImageCategory 修改图片历史
func PatchImageCategory(c *gin.Context) {
	var request struct {
		Title  string `json:"title" binding:"required"`
		Width  int    `json:"width" binding:"required,gte=0"`
		Height int    `json:"height" binding:"required,gte=0"`
		Disk   string `json:"disk" binding:"required"`
	}

	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error("修改图片类型")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var category image.Category
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&category).Error; nil != err {
		logger.Entry().WithError(err).Error("修改图片类型，数据无效")
		api.NotFound(c)
		return
	}

	update := util.MakeParams(request)

	if err := model.SongDB.Model(&category).Where("id = ?", category.ID).Update(update).Error; nil != err {
		logger.Entry().WithError(err).Error("更新图片类型")
		api.ServerError(c, fmt.Sprintf("保存数据失败:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageCategory, meta.LogActionUpdate, "修改图片类型", update, category.ID); nil != err {
		logger.Entry().WithError(err).WithField("request", request).Error("修改图片历史操作历史")
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.NoContent(c)
}

// DeleteImageCategory 删除图片类型
func DeleteImageCategory(c *gin.Context) {
	var category image.Category
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&category).Error; nil != err {
		logger.Entry().WithError(err).Error("删除图片类型，数据无效")
		api.NotFound(c)
		return
	}

	if err := model.SongDB.Where("id = ?", category.ID).Delete(&category).Error; nil != err {
		logger.Entry().WithError(err).Error("删除图片类型")
		api.ServerError(c, fmt.Sprintf("保存数据失败:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleImageCategory, meta.LogActionDelete, "删除图片类型", category, category.ID); nil != err {
		logger.Entry().WithError(err).WithField("category", category).Error("删除图片历史操作历史")
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.NoContent(c)
}
