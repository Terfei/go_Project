package report

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/report"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
)

// GetAccompanyTop 置顶列表
func GetAccompanyTop(c *gin.Context) {
	var request api.PageRequest

	if err := c.BindQuery(&request); err != nil {
		logger.Entry().WithError(err).Error("歌曲置顶参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var items []report.AccompanyTopping
	var count int
	page := request.OffsetLimit()

	model.SongDB.Table(report.TableAccompanyTopping).Count(&count)
	model.SongDB.Table(report.TableAccompanyTopping).Order("weight desc").Offset(page.Offset).Limit(page.Limit).Find(&items)

	api.MakePage(c, items, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// PostAccompanyTop 新增置顶
func PostAccompanyTop(c *gin.Context) {
	var request struct {
		AccompanyID int `json:"accompany_id" form:"accompany_id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("新增歌曲置顶参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var accompany song.Accompany
	if err := model.SongDB.Model(&song.Accompany{}).Where("id = ?", request.AccompanyID).First(&accompany).Error; nil != err {
		logger.Entry().WithError(err).WithField("request", request).Error("歌曲置顶，信息错误")
		api.NotFound(c)
		return
	}

	var count int
	model.SongDB.Table(report.TableAccompanyTopping).Where("songno = ?", accompany.Songno).Count(&count)
	if count > 0 {
		api.ServerError(c, "存在置顶数据")
		return
	}

	var category song.AccompanyCategory
	model.SongDB.Model(&song.AccompanyCategory{}).Where("id = ?", accompany.CategoryID).First(&category)

	var language song.AccompanyLanguage
	model.SongDB.Model(&song.AccompanyLanguage{}).Where("id = ?", accompany.LanguageID).First(&language)

	top := report.AccompanyTopping{
		ID:                  0,
		Songno:              accompany.Songno,
		AccompanyID:         accompany.ID,
		AccompanyName:       accompany.Name,
		AccompanyCategoryID: accompany.CategoryID,
		AccompanyCategory:   category.Name,
		AccompanyLanguageID: accompany.LanguageID,
		AccompanyLanguage:   language.Name,
		SingerID:            accompany.Singers.SingerOne.ID,
		SingerName:          accompany.Singers.SingerOne.Name,
	}

	var total int
	model.SongDB.Table(report.TableAccompanyTopping).Count(&total)
	top.Weight = total + 1

	if err := model.SongDB.Create(&top).Error; nil != err {
		logger.Entry().WithError(err).WithField("request", request).Error("歌曲置顶失败")
		api.ServerError(c, fmt.Sprintf("保存数据错误:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyTop, meta.LogActionInsert, "新增歌曲置顶", request, top.ID); nil != err {
		logger.Entry().WithError(err).Error("添加新增歌曲置顶操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.Created(c)
}

// PatchAccompanyTop 修改置顶排序
func PatchAccompanyTop(c *gin.Context) {
	var request struct {
		Params []struct {
			ID     int `json:"id" binging:"required,gte=0"`
			Weight int `json:"weight" binging:"required,gte=0"`
		} `json:"params"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("修改歌曲置顶参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		for _, params := range request.Params {
			if err := tx.Model(&report.AccompanyTopping{}).Where("id = ?", params.ID).Update(map[string]interface{}{
				"weight": params.Weight,
			}).Error; nil != err {
				return err
			}
		}
		return nil
	})

	if err != nil {
		logger.Entry().WithError(err).WithField("request", request).Error("修改歌曲置顶错误")
		api.ServerError(c, fmt.Sprintf("保存数据失败:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyTop, meta.LogActionUpdate, "修改歌曲置顶", request, 0); nil != err {
		logger.Entry().WithError(err).Error("修改歌曲置顶操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}

// DeleteAccompanyTop 删除置顶
func DeleteAccompanyTop(c *gin.Context) {
	var top report.AccompanyTopping
	if err := model.SongDB.Model(&report.AccompanyTopping{}).Where("id = ?", c.Param("id")).First(&top).Error; nil != err {
		logger.Entry().WithError(err).Error("删除歌曲置顶，数据无效")
		api.NotFound(c)
		return
	}

	if err := model.SongDB.Where("id = ?", top.ID).Delete(&top).Error; nil != err {
		logger.Entry().WithError(err).WithField("top", top).Error("删除歌曲置顶")
		api.ServerError(c, fmt.Sprintf("保存数据错误:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyTop, meta.LogActionDelete, "删除歌曲置顶", top, top.ID); nil != err {
		logger.Entry().WithError(err).Error("删除歌曲置顶操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}
