package report

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/report"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
)

// GetSingerTop 歌手排名
func GetSingerTop(c *gin.Context) {
	var request api.PageRequest

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("歌手置顶列表参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var items []report.SingerTopping
	var count int
	page := request.OffsetLimit()

	model.SongDB.Table(report.TableSingerTopping).Count(&count)
	model.SongDB.Table(report.TableSingerTopping).Order("weight desc").Offset(page.Offset).Limit(page.Limit).Find(&items)

	api.MakePage(c, items, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// PostSingerTop 新增歌手置顶
func PostSingerTop(c *gin.Context) {
	var request struct {
		SingerID int `json:"singer_id" form:"singer_id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("新增歌手置顶参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var singer song.Singer
	if err := model.SongDB.Model(&song.Singer{}).Where("id = ?", request.SingerID).First(&singer).Error; nil != err {
		logger.Entry().WithError(err).WithField("request", request).Error("歌手置顶信息错误")
		api.NotFound(c)
		return
	}

	var count int
	model.SongDB.Table(report.TableSingerTopping).Where("singer_id = ?", request.SingerID).Count(&count)
	if count > 0 {
		api.ServerError(c, "存在置顶数据")
		return
	}

	var area song.SingerArea
	model.SongDB.Model(&song.SingerArea{}).Where("id = ?", singer.AreaID).First(&area)

	top := report.SingerTopping{
		SingerID:   singer.ID,
		SingerName: singer.Name,
		SingerCode: singer.Code,
		AreaID:     singer.AreaID,
		AreaName:   area.Name,
	}

	var total int
	model.SongDB.Table(report.TableSingerTopping).Count(&total)
	top.Weight = total + 1

	if err := model.SongDB.Create(&top).Error; nil != err {
		logger.Entry().WithError(err).WithField("request", request).Error("歌手置顶失败")
		api.ServerError(c, fmt.Sprintf("保存数据错误:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleSingerTop, meta.LogActionInsert, "新增歌手置顶", request, top.ID); nil != err {
		logger.Entry().WithError(err).Error("添加新增歌手置顶操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.Created(c)
}

// PatchSingerTop 修改置顶排序
func PatchSingerTop(c *gin.Context) {
	var request struct {
		Params []struct {
			ID     int `json:"id" binging:"required,gte=0"`
			Weight int `json:"weight" binging:"required,gte=0"`
		} `json:"params"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("修改歌手置顶参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		for _, params := range request.Params {
			if err := tx.Model(&report.SingerTopping{}).Where("id = ?", params.ID).Update(map[string]interface{}{
				"weight": params.Weight,
			}).Error; nil != err {
				return err
			}
		}
		return nil
	})

	if err != nil {
		logger.Entry().WithError(err).WithField("request", request).Error("修改歌手置顶错误")
		api.ServerError(c, fmt.Sprintf("保存数据失败:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleSingerTop, meta.LogActionUpdate, "修改歌手置顶", request, 0); nil != err {
		logger.Entry().WithError(err).Error("修改歌手置顶操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}

// DeleteSingerTop 删除置顶
func DeleteSingerTop(c *gin.Context) {
	var top report.SingerTopping
	if err := model.SongDB.Model(&report.SingerTopping{}).Where("id = ?", c.Param("id")).First(&top).Error; nil != err {
		logger.Entry().WithError(err).Error("删除歌手置顶，数据无效")
		api.NotFound(c)
		return
	}

	if err := model.SongDB.Where("id = ?", top.ID).Delete(&top).Error; nil != err {
		logger.Entry().WithError(err).WithField("top", top).Error("删除歌手置顶")
		api.ServerError(c, fmt.Sprintf("保存数据错误:%s", err.Error()))
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleSingerTop, meta.LogActionDelete, "删除歌手置顶", top, top.ID); nil != err {
		logger.Entry().WithError(err).Error("删除歌手置顶操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}
