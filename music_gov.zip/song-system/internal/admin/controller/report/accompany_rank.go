package report

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/report"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"strconv"
	"time"
)

// AccompanyAccompanyRankStat 歌曲排名
type AccompanyAccompanyRankStat struct {
	AccompanyID int `json:"accompany_id"`
	SumTimes    int `json:"sum_times"`
}

// GetAccompanyRank 查询歌曲排名
func GetAccompanyRank(c *gin.Context) {
	var request struct {
		api.PageRequest
		AccompanyName     string    `json:"accompany_name" form:"accompany_name"`
		BranchBizType     int       `json:"branch_biz_type" form:"branch_biz_type"`
		BranchID          string    `json:"branch_id" form:"branch_id"`
		BeginDate         time.Time `json:"begin_date" form:"begin_date" time_format:"2006-01-02"`
		EndData           time.Time `json:"end_data" form:"end_date" time_format:"2006-01-02"`
		AccompanyCategory int       `json:"accompany_category" form:"accompany_category"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("歌曲排行，参数错误")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	query := getRankQuery(c)

	var count []AccompanyAccompanyRankStat
	query.Select("accompany_id,sum(times) as sum_times").Group("accompany_id").Scan(&count)
	var stats []AccompanyAccompanyRankStat
	page := request.PageRequest.OffsetLimit()
	query.Select("accompany_id,sum(times) as sum_times").Group("accompany_id").Order("sum_times desc").Offset(page.Offset).Limit(page.Limit).Scan(&stats)

	api.MakePage(c, formatRank(stats), api.PageResponse{
		Total:    len(count),
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// ExportAccompanyRank 导出
func ExportAccompanyRank(c *gin.Context) {
	var request struct {
		AccompanyName     string    `json:"accompany_name" form:"accompany_name"`
		BranchBizType     int       `json:"branch_biz_type" form:"branch_biz_type"`
		BranchID          string    `json:"branch_id" form:"branch_id"`
		BeginDate         time.Time `json:"begin_date" form:"begin_date" time_format:"2006-01-02"`
		EndData           time.Time `json:"end_data" form:"end_date" time_format:"2006-01-02"`
		AccompanyCategory int       `json:"accompany_category" form:"accompany_category"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("歌曲排行导出，参数错误")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	query := getRankQuery(c)
	var stats []AccompanyAccompanyRankStat
	query.Select("accompany_id,sum(times) as sum_times").Group("accompany_id").Order("sum_times desc").Scan(&stats)
	items := formatRank(stats)

	excel, sheet := util.InitializeXlsx()
	excel.SetSheetRow(sheet, `A1`, &[]string{"排行", "歌曲编号", "歌曲名", "歌星名", "语种", "歌曲类型", "点击数", "是否置顶"})
	topMap := map[bool]string{
		true:  "已置顶",
		false: "",
	}
	for idx, item := range items {
		line := fmt.Sprintf("A%d", idx+2)
		top, _ := topMap[item.IsTop]
		excel.SetSheetRow(sheet, line, &[]string{
			strconv.Itoa(idx + 1),
			item.Songno,
			item.AccompanyName,
			item.SingerName,
			item.AccompanyLanguage,
			item.AccompanyCategory,
			strconv.Itoa(item.Times),
			top,
		})
	}

	util.ExportXlsx(excel, "歌曲排名.xlsx", c)
}

func getRankQuery(c *gin.Context) *gorm.DB {
	query := model.SongDB.Table(report.TableReportAccompanyClicks).Where("accompany_id > 0")

	if name, ok := c.GetQuery("accompany_name"); ok && name != "" {
		query = query.Scopes(songdb.ColumnLikeScope("accompany_name", name))
	}

	if biz, ok := c.GetQuery("biz_type"); ok {
		query = query.Where("branch_biz_type = ?", biz)
	}

	if branch, ok := c.GetQuery("branch_id"); ok {
		query = query.Where("branch_id = ?", branch)
	}

	if begin, ok := c.GetQuery("begin_date"); ok {
		query = query.Where("created_at > ?", begin)
	}

	if end, ok := c.GetQuery("end_date"); ok {
		query = query.Where("created_at < ?", end)
	}

	if category, ok := c.GetQuery("accompany_category"); ok {
		query = query.Where("accompany_category_id = ?", category)
	}

	return query
}

// AccompanyRankResponse 排名返回
type AccompanyRankResponse struct {
	AccompanyID       int    `json:"accompany_id"`
	AccompanyName     string `json:"accompany_name"`
	Songno            string `json:"songno"`
	SingerID          int    `json:"singer_id"`
	SingerName        string `json:"singer_name"`
	Times             int    `json:"times"`
	AccompanyCategory string `json:"accompany_category"`
	AccompanyLanguage string `json:"accompany_language"`
	IsTop             bool   `json:"is_top"`
}

func formatRank(items []AccompanyAccompanyRankStat) []AccompanyRankResponse {
	var songID []int
	for _, item := range items {
		songID = append(songID, item.AccompanyID)
	}

	accompanyMap := getAccompanyMap(songID)
	categoryMap := getAccompanyCategoryMap()
	languageMap := getAccompanyLanguageMap()
	topMap := getAccompanyTopMap(songID)
	var response []AccompanyRankResponse
	for _, item := range items {
		if accompany, ok := accompanyMap[item.AccompanyID]; ok {
			rank := AccompanyRankResponse{
				AccompanyID:   accompany.ID,
				AccompanyName: accompany.Name,
				Songno:        accompany.Songno,
				SingerID:      accompany.Singers.SingerOne.ID,
				SingerName:    accompany.Singers.SingerOne.Name,
				Times:         item.SumTimes,
				IsTop:         false,
			}

			if category, ok := categoryMap[accompany.CategoryID]; ok {
				rank.AccompanyCategory = category.Name
			}

			if language, ok := languageMap[accompany.LanguageID]; ok {
				rank.AccompanyLanguage = language.Name
			}

			if _, ok := topMap[accompany.ID]; ok {
				rank.IsTop = true
			}

			response = append(response, rank)
		}
	}

	return response
}

func getAccompanyMap(ids []int) map[int]song.Accompany {
	var items []song.Accompany
	model.SongDB.Model(&song.Accompany{}).Where("id in (?)", ids).Find(&items)

	response := make(map[int]song.Accompany)
	for _, item := range items {
		response[item.ID] = item
	}

	return response
}

func getAccompanyCategoryMap() map[int]song.AccompanyCategory {
	var items []song.AccompanyCategory
	model.SongDB.Model(&song.AccompanyCategory{}).Find(&items)

	response := make(map[int]song.AccompanyCategory)

	for _, item := range items {
		response[item.ID] = item
	}

	return response
}

func getAccompanyLanguageMap() map[int]song.AccompanyLanguage {
	var items []song.AccompanyLanguage
	model.SongDB.Model(&song.AccompanyLanguage{}).Find(&items)

	response := make(map[int]song.AccompanyLanguage)

	for _, item := range items {
		response[item.ID] = item
	}

	return response
}

func getAccompanyTopMap(ids []int) map[int]report.AccompanyTopping {
	var items []report.AccompanyTopping
	model.SongDB.Model(&report.AccompanyTopping{}).Where("accompany_id in (?)", ids).Find(&items)

	response := make(map[int]report.AccompanyTopping)
	for _, item := range items {
		response[item.AccompanyID] = item
	}

	return response
}
