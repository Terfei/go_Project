package report

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/report"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"strconv"
	"time"
)

// SingerRankStat 歌手排名
type SingerRankStat struct {
	SingerID int `json:"singer_id"`
	SumTimes int `json:"sum_times"`
}

// GetSingerRank 歌手排行
func GetSingerRank(c *gin.Context) {
	var request struct {
		api.PageRequest
		SingerName    string    `json:"singer_name" form:"singer_name"`
		BranchBizType int       `json:"branch_biz_type" form:"branch_biz_type"`
		BranchID      string    `json:"branch_id" form:"branch_id"`
		BeginDate     time.Time `json:"begin_date" form:"begin_date" time_format:"2006-01-02"`
		EndData       time.Time `json:"end_data" form:"end_date" time_format:"2006-01-02"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("歌手排行，参数错误")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	query := getSingerRankQuery(c)

	var count []SingerRankStat
	query.Select("singer_id,sum(times) as sum_times").Group("singer_id").Scan(&count)
	var stats []SingerRankStat
	page := request.PageRequest.OffsetLimit()
	query.Select("singer_id,sum(times) as sum_times").Group("singer_id").Order("sum_times desc").Offset(page.Offset).Limit(page.Limit).Scan(&stats)

	api.MakePage(c, formatSingerRank(stats), api.PageResponse{
		Total:    len(count),
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// ExportSingerRank 导出
func ExportSingerRank(c *gin.Context) {
	var request struct {
		SingerName    string    `json:"singer_name" form:"singer_name"`
		BranchBizType int       `json:"branch_biz_type" form:"branch_biz_type"`
		BranchID      string    `json:"branch_id" form:"branch_id"`
		BeginDate     time.Time `json:"begin_date" form:"begin_date" time_format:"2006-01-02"`
		EndData       time.Time `json:"end_data" form:"end_date" time_format:"2006-01-02"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("歌手排行导出，参数错误")
		api.ServerError(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	query := getSingerRankQuery(c)
	var stats []SingerRankStat
	query.Select("singer_id,sum(times) as sum_times").Group("singer_id").Order("sum_times desc").Scan(&stats)
	items := formatSingerRank(stats)

	excel, sheet := util.InitializeXlsx()
	excel.SetSheetRow(sheet, `A1`, &[]string{"排行", "歌星编号", "歌星名", "区域", "点击数", "是否置顶"})

	topMap := map[bool]string{
		true:  "已置顶",
		false: "",
	}
	for idx, item := range items {
		line := fmt.Sprintf("A%d", idx+2)
		top, _ := topMap[item.IsTop]
		excel.SetSheetRow(sheet, line, &[]string{
			strconv.Itoa(idx + 1),
			item.SingerCode,
			item.SingerName,
			item.AreaName,
			strconv.Itoa(item.Times),
			top,
		})
	}

	util.ExportXlsx(excel, "歌手排名.xlsx", c)
}

func getSingerRankQuery(c *gin.Context) *gorm.DB {
	query := model.SongDB.Table(report.TableReportAccompanyClicks).Where("singer_id > 0")

	if name, ok := c.GetQuery("singer_name"); ok && name != "" {
		query = query.Scopes(songdb.ColumnLikeScope("singer_name", name))
	}

	if biz, ok := c.GetQuery("biz_type"); ok {
		query = query.Where("branch_biz_type = ?", biz)
	}

	if branch, ok := c.GetQuery("branch_id"); ok {
		query = query.Where("branch_id = ?", branch)
	}

	if begin, ok := c.GetQuery("begin_date"); ok {
		query = query.Where("created_at > ?", begin)
	}

	if end, ok := c.GetQuery("end_date"); ok {
		query = query.Where("created_at < ?", end)
	}

	return query
}

// SingerRankResponse 歌手排行
type SingerRankResponse struct {
	SingerID   int    `json:"singer_id"`
	SingerName string `json:"singer_name"`
	SingerCode string `json:"singer_code"`
	AreaID     int    `json:"area_id"`
	AreaName   string `json:"area_name"`
	Times      int    `json:"times"`
	IsTop      bool   `json:"is_top"`
}

func formatSingerRank(items []SingerRankStat) []SingerRankResponse {
	var singerID []int
	for _, item := range items {
		singerID = append(singerID, item.SingerID)
	}

	singerMap := getSingerMap(singerID)
	areaMap := getAreaMap()
	topMap := getSingerTopMap(singerID)

	var response []SingerRankResponse

	for _, item := range items {
		if singer, ok := singerMap[item.SingerID]; ok {
			rank := SingerRankResponse{
				SingerID:   singer.ID,
				SingerName: singer.Name,
				SingerCode: singer.Code,
				AreaID:     singer.AreaID,
				Times:      item.SumTimes,
				IsTop:      false,
			}

			if area, ok := areaMap[singer.AreaID]; ok {
				rank.AreaName = area.Name
			}

			if _, ok := topMap[singer.ID]; ok {
				rank.IsTop = true
			}

			response = append(response, rank)
		}
	}

	return response
}

func getSingerMap(ids []int) map[int]song.Singer {
	var singers []song.Singer
	model.SongDB.Model(&song.Singer{}).Where("id in (?)", ids).Find(&singers)

	response := make(map[int]song.Singer)

	for _, item := range singers {
		response[item.ID] = item
	}

	return response
}

func getAreaMap() map[int]song.SingerArea {
	var items []song.SingerArea
	model.SongDB.Model(&song.SingerArea{}).Find(&items)

	response := make(map[int]song.SingerArea)

	for _, item := range items {
		response[item.ID] = item
	}

	return response
}

func getSingerTopMap(ids []int) map[int]report.SingerTopping {
	var items []report.SingerTopping
	model.SongDB.Table(report.TableSingerTopping).Where("singer_id in (?)", ids).Find(&items)

	response := make(map[int]report.SingerTopping)

	for _, item := range items {
		response[item.SingerID] = item
	}

	return response
}
