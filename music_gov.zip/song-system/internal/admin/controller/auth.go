package controller

import (
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// Login 登陆系统
func Login(c *gin.Context) {
	var request struct {
		UserName string `json:"username" binding:"required"`
		Password string `json:"password" binding:"required"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		api.Unprocessable(c, "参数错误")
		return
	}

	staff, token, err := middleware.Login(request.UserName, request.Password)
	if errors.Is(err, gorm.ErrRecordNotFound) {
		api.Unprocessable(c, "登陆账户不存在")
		return
	} else if errors.Is(err, util.ErrPassword) {
		api.Unprocessable(c, "密码错误")
		return
	} else if nil != err {
		api.ServerError(c, err.Error())
		return
	}

	api.Make(c, map[string]interface{}{
		"staff": staff,
		"token": token,
	})
}
