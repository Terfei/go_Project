package meta

import (
	"fmt"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
)

// GetSystemLog 获取操作日志列表
func GetSystemLog(c *gin.Context) {
	var request struct {
		api.PageRequest
		StaffName string               `json:"staff_name" form:"staff_name"`
		LogDate   time.Time            `json:"log_date" form:"log_date" time_format:"2006-01-02"`
		Module    meta.SystemLogModule `json:"module" form:"module"`
	}
	if err := c.ShouldBind(&request); nil != err {
		logger.Entry().WithError(err).Error("参数错误")
		api.BadRequest(c, "参数错误")
		return
	}

	query := model.SongDB.Model(&meta.SystemLog{}).Scopes(
		songdb.ColumnLikeScope(`staff_name`, request.StaffName),
		songdb.ColumnBetweenDateScope(`created_at`, request.LogDate, request.LogDate.Add(time.Hour*24)),
	)

	if _, ok := c.GetQuery(`module`); ok {
		query = query.Scopes(songdb.ColumnEqualScope(`module`, request.Module))
	}

	count := 0
	query.Count(&count)

	var logs []meta.SystemLog
	page := request.PageRequest.OffsetLimit()
	if err := query.Order(`created_at desc`).Offset(page.Offset).Limit(page.Limit).Find(&logs).Error; nil != err {
		logger.Entry().WithError(err).Error("获取操作日志列表失败")
		api.ServerError(c, "获取操作日志列表失败")
		return
	}

	api.MakePage(c, logs, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// ExportSystemLog 导出
func ExportSystemLog(c *gin.Context) {
	var request struct {
		StaffName string               `json:"staff_name" form:"staff_name"`
		LogDate   time.Time            `json:"log_date" form:"log_date" time_format:"2006-01-02"`
		Module    meta.SystemLogModule `json:"module" form:"module"`
	}
	if err := c.ShouldBind(&request); nil != err {
		logger.Entry().WithError(err).Error("参数错误")
		api.BadRequest(c, "参数错误")
		return
	}

	query := model.SongDB.Model(&meta.SystemLog{}).Scopes(
		songdb.ColumnLikeScope(`staff_name`, request.StaffName),
		songdb.ColumnBetweenDateScope(`created_at`, request.LogDate, request.LogDate.Add(time.Hour*24)),
	)

	if _, ok := c.GetQuery(`module`); ok {
		query = query.Scopes(songdb.ColumnEqualScope(`module`, request.Module))
	}
	var logs []meta.SystemLog
	query.Order("created_at desc").Find(&logs)
	excel, sheet := util.InitializeXlsx()
	excel.SetSheetRow(sheet, `A1`, &[]string{"序号", "操作人", "操作时间", "操作模块", "操作类型", "备注"})

	for idx, log := range logs {
		line := fmt.Sprintf("A%d", idx+2)
		mod, _ := meta.ModuleName[log.Module]
		action, _ := meta.ActionName[log.Action]
		excel.SetSheetRow(sheet, line, &[]string{
			strconv.Itoa(idx + 1),
			log.StaffName,
			log.CreatedAt.String(),
			mod,
			action,
			log.Remark,
		})
	}

	util.ExportXlsx(excel, "操作日志.xlsx", c)
}
