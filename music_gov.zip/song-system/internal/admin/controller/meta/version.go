package meta

import (
	"context"
	"fmt"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	bridgeBranch "gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetVersionOverview 批次号总览
func GetVersionOverview(c *gin.Context) {
	var request struct {
		api.PageRequest
		Code string `json:"code" form:"code"`
	}
	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("批次总览列表")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}
	var items []meta.VersionOverview
	var count int

	query := model.SongDB.Table(meta.TableVersionOverview).Unscoped().Scopes(songdb.ColumnLikeScope("version_code", request.Code))
	query.Count(&count)
	query.Order("created_at desc").Offset(request.OffsetLimit().Offset).Limit(request.OffsetLimit().Limit).Find(&items)

	api.MakePage(c, items, api.PageResponse{
		Total:    count,
		Page:     request.OffsetLimit().Page,
		PageSize: request.OffsetLimit().Limit,
	})
}

// CreateBranchSync 同步到门店
func CreateBranchSync(c *gin.Context) {
	var request struct {
		Branches []string `json:"branches" form:"branches"`
	}

	if err := c.BindJSON(&request); nil != err {
		logger.Entry().Error(err)
		api.Unprocessable(c, "参数错误")
		return
	}

	if err := model.RedisConnection(config.Setting.Database.Redis); nil != err {
		logger.Entry().WithError(err).Error("redis")
		api.ServerError(c, "redis error")
		return
	}

	ctx := context.Background()
	code := time.Now().Format("2006-01-02 15:04:05")
	redis := model.Rds
	hkey := "branch_sync"

	// 判断redis同步状态
	for _, item := range request.Branches {
		// 可以直接判断hexists
		if redis.HExists(ctx, hkey, item).Val() {
			continue
		}

		redis.HSet(ctx, hkey, item, code)
	}

	redis.Expire(ctx, hkey, time.Hour)

	params := util.Params{}
	params.Set("branches", request.Branches)
	saveVersionSystemLog(c, meta.LogActionInsert, "同步到门店", params)
	api.Created(c)
}

// DeleteVersionOverview 删除批次
func DeleteVersionOverview(c *gin.Context) {
	id := c.Param("id")
	var version meta.VersionOverview
	if err := model.SongDB.Table(meta.TableVersionOverview).First(&version, id).Error; nil != err {
		logger.Entry().WithError(err).Error("查询批次信息")
		api.ServerError(c, "查询批次信息错误")
		return
	}

	if version.IsDefault > 0 {
		api.ServerError(c, "默认批次不能删除")
		return
	}

	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		if err := tx.Where("id = ?", version.ID).Delete(&version).Error; nil != err {
			return err
		}

		if err := tx.Where("version_id = ?", version.ID).Delete(&branch.Version{}).Error; nil != err {
			return err
		}
		return nil
	})

	if err != nil {
		logger.Entry().WithError(err).Error("删除批次信息")
		api.ServerError(c, err.Error())
		return
	}

	params := util.Params{}
	params.Set("id", id)
	saveVersionSystemLog(c, meta.LogActionDelete, "删除", params)
	api.NoContent(c)
}

// CreateVersionOverview 生成批次号
func CreateVersionOverview(c *gin.Context) {
	if !canMakeVersion() {
		api.Unprocessable(c, "已经是最新批次")
		return
	}

	branchAuthorizes := selectBranchAuthorizes()
	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		// 生成批次总览
		version, err := createVersion(tx)
		if err != nil {
			return fmt.Errorf("创建批次总览,err:%s", err.Error())
		}

		// 处理每种类型批次信息
		for _, category := range branch.AllVersionCategoryType() {
			update := map[string]interface{}{
				"overview_id": version.ID,
				"updated_at":  time.Now(),
			}
			if err := model.SongDB.Table(category.String()).Where("overview_id = 0").Update(update).Error; nil != err {
				return fmt.Errorf("设置素材批次, category:%s, err:%s", category, err.Error())
			}
		}

		// 门店批次信息
		for _, item := range bridgeBranch.AllBranchMap() {
			var data branch.Version
			data.BranchID = item.BranchID
			data.VersionID = version.ID
			data.VersionCode = version.VersionCode
			if authorizes, ok := branchAuthorizes[item.BranchID]; ok {
				v := version.VersionCode.String()[:6]
				if _, ok := authorizes[v]; ok {
					data.CanDownload = 1
				}
			}

			if err := tx.Create(&data).Error; nil != err {
				return fmt.Errorf("保存门店批次信息, err:%s", err.Error())
			}
		}

		return nil
	})

	if err != nil {
		logger.Entry().WithError(err).Info("生成批次号")
		api.ServerError(c, err.Error())
		return
	}

	saveVersionSystemLog(c, meta.LogActionInsert, "新增", util.Params{})
	api.Created(c)
}

func canMakeVersion() bool {
	var can bool
Loop:
	for _, category := range branch.AllVersionCategoryType() {
		var count int
		model.SongDB.Table(category.String()).Where("overview_id = 0").Count(&count)
		if count > 0 {
			can = true
			break Loop
		}
	}
	return can
}

func createVersion(tx *gorm.DB) (meta.VersionOverview, error) {
	code := meta.MakeVersionCode()
	version := meta.VersionOverview{
		VersionCode: code,
	}
	err := tx.Create(&version).Error

	return version, err
}

func selectBranchAuthorizes() map[uuid.UUID]map[string]string {
	var authorizes []branch.Authorize
	model.SongDB.Find(&authorizes)

	items := make(map[uuid.UUID]map[string]string)

	for _, authorize := range authorizes {
		if _, ok := items[authorize.BranchID]; !ok {
			items[authorize.BranchID] = map[string]string{}
		}
		for _, m := range authorize.Months {
			key := fmt.Sprintf("%d%02d", authorize.Year, m)
			items[authorize.BranchID][key] = key
		}
	}

	return items
}

func saveVersionSystemLog(c *gin.Context, action meta.SystemLogAction, remark string, data interface{}) {
	staff := middleware.StaffFromContext(c)

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleMetaVersionOverview).SetStaff(staff).SetAction(action).SetRemark(remark).SetData(data)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error("批次总览操作历史")
	}
}
