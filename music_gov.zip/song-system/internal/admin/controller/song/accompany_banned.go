package song

import (
	"fmt"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetBanned 获取禁歌列表
func GetBanned(c *gin.Context) {
	var request struct {
		api.PageRequest
		SongName   string    `json:"song_name" form:"song_name"`
		SingerName string    `json:"singer_name" form:"singer_name"`
		Begin      time.Time `json:"begin" form:"begin" time_format:"2006-01-02"`
		End        time.Time `json:"end" form:"end" time_format:"2006-01-02"`
	}

	if err := c.ShouldBindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error(`禁歌列表`)
		api.Unprocessable(c, `参数错误`)
		return
	}

	query := model.SongDB.Table(song.TableAccompanyBanned).Scopes(
		songdb.ColumnNullScope(`deleted_at`),
		songdb.ColumnLikeScope(`song_name`, request.SongName),
		songdb.ColumnLikeScope(`singer_name`, request.SingerName),
		songdb.ColumnBetweenDateScope(`ban_date`, request.Begin, request.End),
	)

	count := 0
	query.Count(&count)

	var result []song.AccompanyBanned
	page := request.PageRequest.OffsetLimit()
	query.Order(`ban_date`).Offset(page.Offset).Limit(page.Limit).Find(&result)

	api.MakePage(c, result, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// PostBanned 添加禁歌
func PostBanned(c *gin.Context) {
	var request struct {
		SongName   string `json:"song_name"`
		SingerName string `json:"singer_name"`
		Remark     string `json:"remark"`
		BanDate    string `json:"ban_date" `
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error(`添加禁歌`)
		api.Unprocessable(c, `参数错误`)
		return
	}

	banned := song.AccompanyBanned{
		SongName:   request.SongName,
		SingerName: request.SingerName,
		Remark:     request.Remark,
		BanDate:    request.BanDate,
	}
	if err := model.SongDB.Create(&banned).Error; nil != err {
		logger.Entry().WithError(err).Error(`添加禁歌`)
		api.ServerError(c, err.Error())
		return
	}

	saveBannedSystemLog(c, meta.LogActionInsert, `新增禁歌`, request)
	api.Created(c)
}

// PatchBanned 修改禁歌
func PatchBanned(c *gin.Context) {
	var request struct {
		SongName   string        `json:"song_name"`
		SingerName string        `json:"singer_name"`
		Remark     string        `json:"remark"`
		BanDate    util.DateTime `json:"ban_date" `
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error(`修改禁歌`)
		api.BadRequest(c, `参数错误`)
		return
	}

	id := c.Param(`id`)
	if err := model.SongDB.Where(id).First(&song.AccompanyBanned{}).Error; nil != err {
		logger.Entry().WithField(`id`, id).WithError(err).Error(`修改时查找对应禁歌`)
		api.BadRequest(c, `未找到相关禁歌`)
		return
	}

	attrs := map[string]interface{}{
		`song_name`:   request.SongName,
		`singer_name`: request.SingerName,
		`remark`:      request.Remark,
		`ban_date`:    request.BanDate,
	}
	if err := model.SongDB.Model(&song.AccompanyBanned{}).Where(id).Update(attrs).Error; nil != err {
		logger.Entry().WithFields(attrs).WithField(`id`, id).WithError(err).Error(`修改禁歌`)
		api.ServerError(c, err.Error())
		return
	}

	saveBannedSystemLog(c, meta.LogActionUpdate, `修改禁歌`, request)
	api.Created(c)
}

// BatchDeleteBanned 批量删除禁歌
func BatchDeleteBanned(c *gin.Context) {
	var request struct {
		IDs []int `json:"ids"`
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error(`删除禁歌`)
		api.BadRequest(c, `参数错误`)
		return
	}

	if err := model.SongDB.Where(`id in (?)`, request.IDs).Delete(&song.AccompanyBanned{}).Error; nil != err {
		logger.Entry().WithError(err).Error("批量删除错误")
		api.ServerError(c, err.Error())
		return
	}

	saveBannedSystemLog(c, meta.LogActionDelete, "禁歌批量删除", request)
	api.NoContent(c)
}

// ImportBanned 导入禁歌
func ImportBanned(c *gin.Context) {
	contents, err := util.HTTPExcelContents(c)
	if nil != err {
		logger.Entry().WithError(err).Error("禁歌导入excel失败")
		api.Unprocessable(c, `禁歌导入excel失败`)
		return
	}

	code := time.Now().Format("20060102150405")
	timeCols := map[string]string{}
	excel := util.NormalizeExcelData(contents, timeCols, `SongName`)
	response := excel.Response

	for _, item := range excel.Params {
		if fail := saveBannedHistory(item, code, meta.ExcelHistoryInsert); nil != fail {
			response.Fail = fmt.Sprintf("保存历史信息错误,%s", fail.Error())
			api.Make(c, response)
			return
		}

		banned := song.AccompanyBanned{
			SongName:   item.GetString(`SongName`),
			SingerName: item.GetString(`SongerName`),
			Remark:     item.GetString(`Remark`),
			BanDate:    item.GetString(`CreateDate`),
		}

		if err := model.SongDB.Create(&banned).Error; nil != err {
			response.Fail = fmt.Sprintf("新增禁歌错误, SongName:%s, err:%s", banned.SongName, err.Error())
			api.Make(c, response)
			return
		}
	}

	saveBannedSystemLog(c, meta.LogActionInsert, `导入禁歌`, util.Params{})
	api.Make(c, response)
}

// ExportBanned 导出禁歌
func ExportBanned(c *gin.Context) {
	var request struct {
		SongName   string    `json:"song_name" form:"song_name"`
		SingerName string    `json:"singer_name" form:"singer_name"`
		Begin      time.Time `json:"begin" form:"begin" time_format:"2006-01-02"`
		End        time.Time `json:"end" form:"end" time_format:"2006-01-02"`
	}

	if err := c.ShouldBindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error(`禁歌列表`)
		api.Unprocessable(c, `参数错误`)
		return
	}

	var result []song.AccompanyBanned
	model.SongDB.Table(song.TableAccompanyBanned).Scopes(
		songdb.ColumnLikeScope(`song_name`, request.SongName),
		songdb.ColumnLikeScope(`singer_name`, request.SingerName),
		songdb.ColumnBetweenDateScope(`ban_date`, request.Begin, request.End),
	).Order(`ban_date`).Find(&result)

	xlsx, sheet := util.InitializeXlsx()
	xlsx.SetSheetRow(sheet, `A1`, &[]string{`SongName`, `SongerName`, `Remark`, `CreateDate`})
	for idx, v := range result {
		lint := strconv.Itoa(idx + 2)
		xlsx.SetSheetRow(sheet, `A`+lint, &[]string{
			v.SongName, v.SingerName, v.Remark, v.BanDate,
		})
	}

	util.ExportXlsx(xlsx, `禁歌列表.xlsx`, c)
}

func saveBannedSystemLog(c *gin.Context, action meta.SystemLogAction, remark string, data interface{}) {
	staff := middleware.StaffFromContext(c)

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleAccompanyBanned).
		SetStaff(staff).SetAction(action).SetRemark(remark).SetData(data)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error(`禁歌操作历史记录`)
	}
}

func saveBannedHistory(params util.Params, code string, action meta.ExcelHistoryAction) error {
	history := meta.ExcelHistory{
		Category:   meta.ExcelHistoryAccompanyBanned,
		Content:    params,
		Action:     action,
		RelationID: params.GetString("SongName"),
		ImportCode: code,
	}

	if err := model.SongDB.Create(&history).Error; nil != err {
		return err
	}

	return nil
}
