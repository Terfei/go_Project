package song

import (
	"fmt"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetAcc 公播列表
func GetAcc(c *gin.Context) {
	var request struct {
		api.PageRequest
		AccType song.AccType `json:"acc_type" form:"acc_type"`
		Keyword string       `json:"keyword" form:"keyword"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("公播列表")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var acc []song.Acc
	count := 0
	page := request.PageRequest.OffsetLimit()

	query := model.SongDB.Model(song.Acc{}).Scopes(song.AccTypeScope(request.AccType), song.AccNoOrNameLikeScope(request.Keyword))

	query.Count(&count)
	query.Order("seq").Order("created_at").Offset(page.Offset).Limit(page.Limit).Find(&acc)

	api.MakePage(c, acc, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// PostAcc 导入公播
func PostAcc(c *gin.Context) {
	contents, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("新增公播excel错误")
		api.Unprocessable(c, "公播新增excel失败")
		return
	}

	code := time.Now().Format("20060102150405")
	excel := util.NormalizeExcelData(contents, map[string]string{}, "songno")

	for _, item := range excel.Params {
		if err := saveAccHistory(item, code, meta.ExcelHistoryInsert); nil != err {
			excel.Response.Fail = fmt.Sprintf("保存公播新增历史记录错误:%s", err.Error())
			api.Make(c, excel.Response)
			return
		}

		if err := saveAcc(item); nil != err {
			excel.Response.Fail = fmt.Sprintf("处理公播信息错误:%s, err:%s", item.GetString("songno"), err.Error())
			api.Make(c, excel.Response)
			return
		}
	}

	saveAccSystemLog(c, meta.LogActionInsert, code, util.Params{})
	api.Make(c, excel.Response)
}

// UpdateAcc 修改公播
func UpdateAcc(c *gin.Context) {
	contents, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("修改公播excel错误")
		api.Unprocessable(c, "公播修改excel失败")
		return
	}

	code := time.Now().Format("20060102150405")
	excel := util.NormalizeExcelData(contents, map[string]string{}, "songno")

	for _, item := range excel.Params {
		if err := saveAccHistory(item, code, meta.ExcelHistoryUpdate); nil != err {
			excel.Response.Fail = fmt.Sprintf("保存公播修改历史记录错误:%s", err.Error())
			api.Make(c, excel.Response)
			return
		}

		if err := saveAcc(item); nil != err {
			excel.Response.Fail = fmt.Sprintf("处理公播信息错误:%s, err:%s", item.GetString("songno"), err.Error())
			api.Make(c, excel.Response)
			return
		}
	}

	saveAccSystemLog(c, meta.LogActionUpdate, code, util.Params{})
	api.Make(c, excel.Response)
}

// BatchDeleteAcc 批量删除
func BatchDeleteAcc(c *gin.Context) {
	var request struct {
		IDs []int `json:"ids" form:"ids"`
	}
	if err := c.BindJSON(&request); nil != err {
		logger.Entry().Error(err)
		api.Unprocessable(c, "参数错误")
		return
	}

	if err := model.SongDB.Where("id in (?)", request.IDs).Delete(&song.Acc{}).Error; nil != err {
		logger.Entry().WithError(err).Error("批量删除错误")
		api.ServerError(c, err.Error())
		return
	}

	saveAccSystemLog(c, meta.LogActionDelete, "批量删除", request)
	api.NoContent(c)
}

func saveAcc(params util.Params) error {
	acc, err := paramsToAcc(params)
	if err != nil {
		return err
	}

	var count int
	if err := model.SongDB.Model(&song.Acc{}).Where("acc_id = ?", acc.AccID).Where("acc_type = ?", acc.AccType).Count(&count).Error; nil != err {
		return err
	}

	if count > 0 {
		return model.SongDB.Model(&song.Acc{}).Where("acc_id = ?", acc.AccID).Where("acc_type = ?", acc.AccType).Update(acc).Error
	}

	return model.SongDB.Create(&acc).Error
}

func paramsToAcc(params util.Params) (*song.Acc, error) {
	acc := song.Acc{
		AccName:         params.GetString("songname"),
		HostIP:          params.GetString("serverpath"),
		ListID:          params.GetInt("list_id"),
		Seq:             params.GetInt("moncnt"),
		Channel:         params.GetString("channel"),
		LampID:          params.GetInt("lamp_id"),
		ReverberationID: params.GetInt("mic_id"),
		EffectID:        params.GetInt("effect_id"),
		Volume:          params.GetInt("volume"),
		Audio:           params.GetInt("audio"),
		StrLevel:        params.GetInt("str_level"),
	}

	acc.AccID = params.GetInt("songno")

	file1, err := splitFilename(params.GetString("diskname1"))
	if nil != err {
		return nil, err
	}
	acc.Filename = file1.File
	acc.Codec = file1.Ext

	file2, err2 := splitFilename(params.GetString("diskname2"))
	if nil != err2 {
		return nil, err2
	}
	acc.Filename2 = file2.File
	acc.StartTime, acc.EndTime = flagToLocalTime(params.GetString("flag"))

	acc.AccType = song.IntToAccType(params.GetInt("type"))

	return &acc, nil
}

// flagToLocalTime excel flag to localtime
func flagToLocalTime(s string) (util.LocalTime, util.LocalTime) {
	split := strings.Split(s, "-")

	return util.StringToLocalTime(split[0]), util.StringToLocalTime(split[1])
}

type accFilename struct {
	File string
	Ext  string
}

// splitFilename 文件名
func splitFilename(s string) (*accFilename, error) {
	split := strings.Split(s, ".")
	l := len(split)

	if l < 1 {
		return nil, fmt.Errorf("filename error:%s", s)
	}

	return &accFilename{
		File: split[0],
		Ext:  split[l-1],
	}, nil
}

// saveAccHistory 保存excel历史
func saveAccHistory(params util.Params, code string, action meta.ExcelHistoryAction) error {
	history := meta.ExcelHistory{
		Category:   meta.ExcelHistoryAcc,
		Content:    params,
		Action:     action,
		RelationID: params.GetString("songno"),
		ImportCode: code,
	}

	return model.SongDB.Create(&history).Error
}

// saveAccSystemLog 保存操作历史
func saveAccSystemLog(c *gin.Context, action meta.SystemLogAction, remark string, data interface{}) {
	staff := middleware.StaffFromContext(c)

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleAcc).SetStaff(staff).SetAction(action).SetRemark(remark).SetData(data)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error("公播操作历史")
	}
}
