package song

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"time"
)

// GetNewSongs 新歌列表
func GetNewSongs(c *gin.Context) {
	var request struct {
		api.PageRequest
		Name string `json:"name" form:"name"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().Error(err)
		api.Unprocessable(c, "参数错误")
		return
	}

	duration, _ := time.ParseDuration(fmt.Sprintf("-%dh", 90*24))
	t := time.Now().Add(duration).Format("2006-01-02")
	query := model.SongDB.Model(&song.Accompany{}).Scopes(songdb.ColumnLikeScope("name", request.Name)).Where("release_time > ?", t)

	count := 0
	query.Count(&count)

	var songs []song.Accompany
	page := request.PageRequest.OffsetLimit()
	query.Preload(`Language`).Order("release_time desc").Offset(page.Offset).Limit(page.Limit).Find(&songs)

	api.MakePage(c, formatSongs(songs), api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

type newSongResponse struct {
	AccompanyID   int    `json:"accompany_id"`
	AccompanyName string `json:"accompany_name"`
	SingerName    string `json:"singer_name"`
	Language      string `json:"language"`
}

func formatSongs(songs []song.Accompany) []newSongResponse {
	var response []newSongResponse
	for _, s := range songs {
		response = append(response, newSongResponse{
			AccompanyID:   s.ID,
			AccompanyName: s.Name,
			SingerName:    s.SingerNameAll,
			Language:      s.Language.Name,
		})
	}
	return response
}
