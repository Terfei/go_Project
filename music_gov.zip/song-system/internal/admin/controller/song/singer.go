package song

import (
	"fmt"
	"net/http"
	"time"

	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"

	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetSinger 歌手列表
func GetSinger(c *gin.Context) {
	var request struct {
		api.PageRequest
		Code string `json:"code" form:"code"`
		Name string `json:"name" form:"name"`
	}
	if err := c.ShouldBind(&request); nil != err {
		logger.Entry().Error(err)
		api.Unprocessable(c, "参数错误")
		return
	}

	query := model.SongDB.Model(song.Singer{}).Preload(`Area`).Scopes(
		song.SingerNameLikeScope(request.Name),
		song.SingerCodeLikeScope(request.Code),
	)

	count := 0
	query.Count(&count)

	var singers []song.Singer
	page := request.PageRequest.OffsetLimit()
	query.Offset(page.Offset).Limit(page.Limit).Find(&singers)

	api.MakePage(c, singers, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// PostSinger 导入新增歌手
func PostSinger(c *gin.Context) {
	act := meta.ExcelHistoryInsert

	response, code, err := importSinger(c, act)
	if nil != err {
		if len(response.Params) == 0 {
			api.Unprocessable(c, "新增歌手导入excel失败")
			return
		}

		api.Make(c, response.Response)
		return
	}

	saveSingerSystemLog(c, meta.LogActionInsert, code, util.Params{})
	api.Make(c, response.Response)
}

// PatchSinger 导入修改歌手
func PatchSinger(c *gin.Context) {
	act := meta.ExcelHistoryUpdate

	response, code, err := importSinger(c, act)
	if nil != err {
		if len(response.Params) == 0 {
			api.Unprocessable(c, "更新歌手导入excel失败")
			return
		}

		api.Make(c, response.Response)
		return
	}

	saveSingerSystemLog(c, meta.LogActionUpdate, code, util.Params{})
	api.Make(c, response.Response)
}

// DeleteSinger 导入删除歌手
func DeleteSinger(c *gin.Context) {
	xlsx, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("删除歌手导入excel失败")
		api.Unprocessable(c, "删除歌手导入excel失败")
		return
	}

	relationTag := `SINGERNO`
	excel := util.NormalizeExcelData(xlsx, map[string]string{}, relationTag)
	response := excel.Response

	code := time.Now().Format("20060102150405")
	for _, item := range excel.Params {
		flag := item.GetString(relationTag)
		history := meta.ExcelHistory{
			Category:   meta.ExcelHistorySinger,
			Content:    item,
			Action:     meta.ExcelHistoryDelete,
			RelationID: flag,
			ImportCode: code,
		}

		if err := model.SongDB.Create(&history).Error; nil != err {
			logger.Entry().WithError(err).Error("新增导入历史数据失败")
			response.Fail = fmt.Sprintf(`保存导入历史错误, singer:%s, err:%s`, flag, err.Error())

			api.CodeWithData(c, http.StatusTeapot, response)
			return
		}

		var singer song.Singer
		query := model.SongDB.Where(`code = ?`, flag)
		if err := query.First(&singer).Error; nil != err {
			response.Fail = fmt.Sprintf("删除歌手错误%s,%s", flag, err.Error())
			api.CodeWithData(c, http.StatusTeapot, response)
			return
		}

		if err := query.Delete(singer).Error; nil != err {
			response.Fail = fmt.Sprintf("删除歌手错误%s,%s", flag, err.Error())
			api.CodeWithData(c, http.StatusTeapot, response)
			return
		}
	}

	saveSingerSystemLog(c, meta.LogActionDelete, code, util.Params{})
	api.Make(c, response)
}

// BatchDeleteSinger 批量删除歌手
func BatchDeleteSinger(c *gin.Context) {
	var request struct {
		IDs []int `json:"ids" form:"ids"`
	}
	if err := c.BindJSON(&request); nil != err {
		logger.Entry().Error(err)
		api.Unprocessable(c, "参数错误")
		return
	}

	if err := model.SongDB.Where("id in (?)", request.IDs).Delete(&song.Singer{}).Error; nil != err {
		logger.Entry().WithError(err).Error("批量删除错误")
		api.ServerError(c, err.Error())
		return
	}

	saveSingerSystemLog(c, meta.LogActionDelete, "批量删除", request)
	api.NoContent(c)
}

// SaveSingerImage 保存歌手图片
func SaveSingerImage(c *gin.Context) {
	var request struct {
		Image string `json:"image"`
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().Error(err)
		api.Unprocessable(c, "参数错误")
		return
	}

	attrs := map[string]interface{}{
		`image`: request.Image,
	}

	id := c.Param(`id`)
	if err := model.SongDB.Model(&song.Singer{}).Where(id).Update(attrs).Error; nil != err {
		logger.Entry().WithError(err).Error("修改歌手图片错误")
		api.ServerError(c, err.Error())
		return
	}

	saveSingerSystemLog(c, meta.LogActionUpdate, "修改歌手图片", request)
	api.NoContent(c)
}

// importSinger 导入歌手
func importSinger(c *gin.Context, act meta.ExcelHistoryAction) (util.ExcelData, string, error) {
	xlsx, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("歌手导入excel失败")
		return util.ExcelData{}, ``, err
	}

	relationTag := `singerno`
	response := util.NormalizeExcelData(xlsx, map[string]string{}, relationTag)

	code := time.Now().Format("20060102150405")
	for _, item := range response.Params {
		flag := item.GetString(relationTag)
		history := meta.ExcelHistory{
			Category:   meta.ExcelHistorySinger,
			Content:    item,
			Action:     act,
			RelationID: flag,
			ImportCode: code,
		}

		if err := model.SongDB.Create(&history).Error; nil != err {
			logger.Entry().WithError(err).Error("新增导入历史数据失败")

			response.Response.Fail = fmt.Sprintf(`保存导入历史错误, singer:%s, err:%s`, flag, err.Error())

			return response, code, err
		}

		msg, err := saveSinger(item, flag)
		if nil != err {
			response.Response.Fail = fmt.Sprintf(`%s错误, singer:%s, err:%s`, msg, flag, err.Error())

			return response, code, err
		}

	}

	return response, code, nil
}

func saveSinger(p util.Params, flag string) (string, error) {
	singer := song.Singer{
		Code:         p.GetString(`singerno`),
		Name:         p.GetString(`SONGERNAME`),
		NameSpell:    p.GetString(`SPELL`),
		CharCount:    p.GetInt(`SINGERNUM`),
		Gender:       song.GanderFromString(p.GetString(`SEX`)),
		LanguageType: p.GetString(`LANGUAGE_TYPE`),
		AreaID:       p.GetInt(`area`),
		Bh:           p.GetString(`BH`),
		Rank:         p.GetInt(`MONCNT`),
		Image:        fmt.Sprintf("%s.jpg", p.GetString("SONGERNAME")),
	}

	if _, err := song.FindSingerByCode(flag); nil != err {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return `新增歌手`, model.SongDB.Create(&singer).Error
		}

		return `查询歌手是否存在`, err
	}

	return `修改歌手`, model.SongDB.Model(&song.Singer{}).Where(`code = ?`, flag).Update(&singer).Error
}

func saveSingerSystemLog(c *gin.Context, action meta.SystemLogAction, remark string, data interface{}) {
	staff := middleware.StaffFromContext(c)

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleSinger).
		SetStaff(staff).SetAction(action).SetRemark(remark).SetData(data)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error("歌手操作历史")
	}
}
