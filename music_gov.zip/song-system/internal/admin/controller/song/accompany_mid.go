package song

import (
	"fmt"
	"time"

	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetMids 伴奏Mid列表
func GetMids(c *gin.Context) {
	var request struct {
		api.PageRequest
		Songno string `json:"songno" form:"songno"`
	}
	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("伴奏列表")
		api.Unprocessable(c, "参数错误")
		return
	}

	var songs []song.Accompany
	count := 0
	page := request.PageRequest.OffsetLimit()

	query := model.SongDB.Model(&song.Accompany{}).Scopes(
		songdb.ColumnLikeScope("songno", request.Songno),
		songdb.ColumnNotNullScope(`mid_filepath`),
	)

	query.Count(&count)
	query.Set("gorm:auto_preload", true).Order("songno").Offset(page.Offset).Limit(page.Limit).Find(&songs)

	api.MakePage(c, songs, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// PostMid 新增伴奏Mid
func PostMid(c *gin.Context) {
	contents, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("新增歌曲MID导入excel失败")
		api.Unprocessable(c, "新增歌曲MID导入excel失败")
		return
	}

	code := time.Now().Format("20060102150405")
	excel := util.NormalizeExcelData(contents, accompanyTimeColumns(), "SONGNO")
	response := excel.Response

	for _, item := range excel.Params {
		if fail := saveAccompanyHistory(item, code, meta.ExcelHistoryUpdate); nil != fail {
			response.Fail = fmt.Sprintf("保存历史信息错误,%s", fail.Error())
			api.Make(c, response)
			return
		}

		var accompany song.Accompany
		query := model.SongDB.Scopes(songdb.ColumnEqualScope(`songno`, item.Get(`SONGNO`)))
		if err := query.First(&accompany).Error; err != nil {
			response.Fail = err.Error()
			api.Make(c, response)
			return
		}

		accompany.MidFilepath = item.GetString(`mid_filepath`)
		if err := model.SongDB.Model(song.Accompany{}).Where(accompany.ID).Update(&accompany).Error; nil != err {
			response.Fail = fmt.Sprintf("修改歌曲错误, songno:%s, err:%s", accompany.Songno, err.Error())
			api.Make(c, response)
			return
		}
	}

	saveAccompanySystemLog(c, meta.LogActionUpdate, code, util.Params{})
	api.Make(c, response)
}

// PatchMid mid修改
func PatchMid(c *gin.Context) {
	var request struct {
		MidFilepath string `json:"mid_filepath"`
	}
	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().Error(err)
		api.Unprocessable(c, `参数错误`)
		return
	}

	id := c.Param(`id`)
	var accompany song.Accompany
	if err := model.SongDB.Where(id).First(&accompany).Error; nil != err {
		logger.Entry().WithError(err).Error(`无此记录`)
		api.BadRequest(c, `未找到相关歌曲`)
		return
	}

	attrs := map[string]interface{}{
		`mid_filepath`: request.MidFilepath,
	}
	if err := model.SongDB.Model(&song.Accompany{}).Where(id).Update(attrs).Error; nil != err {
		logger.Entry().WithError(err).Error("设置伴奏MID错误")
		api.ServerError(c, err.Error())
		return
	}

	saveAccompanySystemLog(c, meta.LogActionUpdate, `MID修改`, request)
	api.NoContent(c)
}

// BatchDeleteMids 批量删除
func BatchDeleteMids(c *gin.Context) {
	var request struct {
		IDs []int `json:"ids" form:"ids"`
	}
	if err := c.BindJSON(&request); nil != err {
		logger.Entry().Error(err)
		api.Unprocessable(c, "参数错误")
		return
	}

	attrs := map[string]interface{}{
		`mid_filepath`: nil,
	}
	if err := model.SongDB.Model(&song.Accompany{}).Where("id in (?)", request.IDs).Update(attrs).Error; nil != err {
		logger.Entry().WithError(err).Error("批量删除MID错误")
		api.ServerError(c, err.Error())
		return
	}

	saveAccompanySystemLog(c, meta.LogActionUpdate, "MID批量删除", request)
	api.NoContent(c)
}
