package song

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
	"time"
)

// GetPartyDance 派对舞曲列表
func GetPartyDance(c *gin.Context) {
	var request struct {
		api.PageRequest
		Keyword string `json:"keyword" form:"keyword"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("派对舞曲列表")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var accompanys []song.PartyDance

	count := 0
	page := request.PageRequest.OffsetLimit()

	query := model.SongDB.Table(song.TablePartyDance).Scopes(song.PartyDanceNoOrNameLikeScope(request.Keyword))

	query.Count(&count)
	query.Order("songno").Offset(page.Offset).Limit(page.Limit).Find(&accompanys)

	api.MakePage(c, accompanys, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// PostPartyDance 新增派对舞曲
func PostPartyDance(c *gin.Context) {
	contents, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("新增派对舞曲excel错误")
		api.Unprocessable(c, "派对舞曲新增excel失败")
		return
	}

	code := time.Now().Format("20060102150405")
	excel := util.NormalizeExcelData(contents, map[string]string{}, "songno")

	for _, item := range excel.Params {
		if err := savePartyDanceHistory(item, code, meta.ExcelHistoryInsert); nil != err {
			excel.Response.Fail = fmt.Sprintf("保存派对舞曲历史记录错误:%s", err.Error())
			api.Make(c, excel.Response)
			return
		}

		if err := savePartyDance(item); nil != err {
			excel.Response.Fail = fmt.Sprintf("处理派对舞曲信息错误:%s, err:%s", item.GetString("songno"), err.Error())
			api.Make(c, excel.Response)
			return
		}
	}

	savePartyDaceSystemLog(c, meta.LogActionInsert, code, util.Params{})
	api.Make(c, excel.Response)
}

// UpdatePartyDance 修改派对舞曲
func UpdatePartyDance(c *gin.Context) {
	contents, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("修改派对舞曲excel错误")
		api.Unprocessable(c, "派对舞曲修改excel失败")
		return
	}

	code := time.Now().Format("20060102150405")
	excel := util.NormalizeExcelData(contents, map[string]string{}, "songno")

	for _, item := range excel.Params {
		if err := savePartyDanceHistory(item, code, meta.ExcelHistoryUpdate); nil != err {
			excel.Response.Fail = fmt.Sprintf("保存派对舞曲历史记录错误:%s", err.Error())
			api.Make(c, excel.Response)
			return
		}

		if err := savePartyDance(item); nil != err {
			excel.Response.Fail = fmt.Sprintf("处理派对误区信息错误:%s, err:%s", item.GetString("songno"), err.Error())
			api.Make(c, excel.Response)
			return
		}
	}

	savePartyDaceSystemLog(c, meta.LogActionUpdate, code, util.Params{})
	api.Make(c, excel.Response)
}

// BatchDeletePartyDance 批量删除
func BatchDeletePartyDance(c *gin.Context) {
	var request struct {
		IDs []int `json:"ids" form:"ids"`
	}
	if err := c.BindJSON(&request); nil != err {
		logger.Entry().Error(err)
		api.Unprocessable(c, "参数错误")
		return
	}

	if err := model.SongDB.Where("id in (?)", request.IDs).Delete(&song.PartyDance{}).Error; nil != err {
		logger.Entry().WithError(err).Error("批量删除错误")
		api.ServerError(c, err.Error())
		return
	}

	savePartyDaceSystemLog(c, meta.LogActionDelete, "批量删除", request)
	api.NoContent(c)
}

func savePartyDanceHistory(params util.Params, code string, action meta.ExcelHistoryAction) error {
	history := meta.ExcelHistory{
		Category:   meta.ExcelHistoryPartyDance,
		Content:    params,
		Action:     action,
		RelationID: params.GetString("songno"),
		ImportCode: code,
	}

	return model.SongDB.Create(&history).Error
}

func savePartyDance(params util.Params) error {
	party, err := paramsToPartyDance(params)
	if err != nil {
		return err
	}

	var count int
	if err := model.SongDB.Model(&song.PartyDance{}).Where("songno = ?", party.Songno).Count(&count).Error; nil != err {
		return err
	}

	if count > 0 {
		return model.SongDB.Model(&song.PartyDance{}).Where("songno = ?", party.Songno).Update(party).Error
	}

	return model.SongDB.Create(party).Error
}

func paramsToPartyDance(params util.Params) (*song.PartyDance, error) {
	party := song.PartyDance{
		Songno:                 params.GetString("songno"),
		AccompanyID:            params.GetInt("songno"),
		AccompanyName:          params.GetString("accompany_name"),
		AccompanyNameSpell:     params.GetString("accompany_name_spell"),
		AccompanyFilename:      params.GetString("accompany_filename"),
		Audio:                  params.GetInt("audio"),
		HostIP:                 params.GetString("host_ip"),
		Image:                  params.GetString("image"),
		CategoryID:             params.GetInt("category_id"),
		CategoryName:           params.GetString("category_name"),
		CharCount:              params.GetInt("char_count"),
		Rank:                   params.GetInt("rank"),
		LampID:                 params.GetInt("lamp_id"),
		EffectID:               params.GetInt("effect_id"),
		ReverberationID:        params.GetInt("reverberation_id"),
		Codec:                  params.GetString("codec"),
		Volume:                 params.GetInt("volume"),
		StrLevel:               params.GetInt("str_level"),
		AccompanyTitleFilename: params.GetString("accompany_title_filename"),
	}

	return &party, nil
}

//
//
//// splitFilename 文件名
//func splitFilename(s string) (*accFilename, error) {
//	split := strings.Split(s, ".")
//	l := len(split)
//
//	if l < 1 {
//		return nil, fmt.Errorf("filename error:%s", s)
//	}
//
//	return &accFilename{
//		File: split[0],
//		Ext:  split[l-1],
//	}, nil
//}

func savePartyDaceSystemLog(c *gin.Context, action meta.SystemLogAction, remark string, data interface{}) {
	staff := middleware.StaffFromContext(c)

	log := meta.SystemLog{}
	log.SetModule(meta.LogModulePartyDance).SetStaff(staff).SetAction(action).SetRemark(remark).SetData(data)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error("派对舞曲操作历史")
	}
}
