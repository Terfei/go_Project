package song

import (
	"fmt"
	"time"

	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetActVideo 跳舞视频列表
func GetActVideo(c *gin.Context) {
	var request struct {
		api.PageRequest
		Keyword string `json:"keyword" form:"keyword"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("跳舞视频列表")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var videos []song.ActVideo

	count := 0
	page := request.PageRequest.OffsetLimit()

	query := model.SongDB.Model(song.ActVideo{}).Scopes(song.ActVideoNoOrNameLikeScope(request.Keyword))

	query.Count(&count)
	query.Order("songno").Offset(page.Offset).Limit(page.Limit).Find(&videos)

	api.MakePage(c, videos, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// PostActVideo 新增跳舞视频
func PostActVideo(c *gin.Context) {
	contents, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("新增跳舞视频excel错误")
		api.Unprocessable(c, "跳舞视频新增excel失败")
		return
	}

	code := time.Now().Format("20060102150405")
	excel := util.NormalizeExcelData(contents, map[string]string{}, "songno")

	for _, item := range excel.Params {
		if err := saveActVideoExcelHistory(item, code, meta.ExcelHistoryInsert); nil != err {
			excel.Response.Fail = fmt.Sprintf("保存跳舞视频新增历史记录错误:%s", err.Error())
			api.Make(c, excel.Response)
			return
		}

		if err := saveActVideo(item); nil != err {
			excel.Response.Fail = fmt.Sprintf("处理跳舞视频信息错误:%s, err:%s", item.GetString("songno"), err.Error())
			api.Make(c, excel.Response)
			return
		}
	}

	saveActVideoSystemLog(c, meta.LogActionInsert, code, util.Params{})
	api.Make(c, excel.Response)
}

// UpdateActVideo 修改跳舞视频
func UpdateActVideo(c *gin.Context) {
	contents, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("修改跳舞视频excel错误")
		api.Unprocessable(c, "跳舞视频修改excel失败")
		return
	}

	code := time.Now().Format("20060102150405")
	excel := util.NormalizeExcelData(contents, map[string]string{}, "songno")

	for _, item := range excel.Params {
		if err := saveActVideoExcelHistory(item, code, meta.ExcelHistoryUpdate); nil != err {
			excel.Response.Fail = fmt.Sprintf("保存跳舞视频新增历史记录错误:%s", err.Error())
			api.Make(c, excel.Response)
			return
		}

		if err := saveActVideo(item); nil != err {
			excel.Response.Fail = fmt.Sprintf("处理跳舞视频信息错误:%s, err:%s", item.GetString("songno"), err.Error())
			api.Make(c, excel.Response)
			return
		}
	}

	saveActVideoSystemLog(c, meta.LogActionUpdate, code, util.Params{})
	api.Make(c, excel.Response)
}

// BatchDeleteActVideo 批量删除跳舞视频
func BatchDeleteActVideo(c *gin.Context) {
	var request struct {
		IDs []int `json:"ids" form:"ids"`
	}
	if err := c.BindJSON(&request); nil != err {
		logger.Entry().Error(err)
		api.Unprocessable(c, "参数错误")
		return
	}

	if err := model.SongDB.Where("id in (?)", request.IDs).Delete(&song.ActVideo{}).Error; nil != err {
		logger.Entry().WithError(err).Error("批量删除错误")
		api.ServerError(c, err.Error())
		return
	}

	saveActVideoSystemLog(c, meta.LogActionDelete, "批量删除", request)
	api.NoContent(c)
}

func saveActVideo(params util.Params) error {
	video := paramsToActVideo(params)

	var count int
	if err := model.SongDB.Model(&song.ActVideo{}).Where("accompany_id = ?", video.AccompanyID).Count(&count).Error; nil != err {
		return err
	}

	if count > 0 {
		return model.SongDB.Model(&song.ActVideo{}).Where("accompany_id = ?", video.AccompanyID).Update(video).Error
	}

	return model.SongDB.Create(&video).Error
}

func paramsToActVideo(params util.Params) song.ActVideo {
	return song.ActVideo{
		AccompanyID:        params.GetInt("songno"), //用songno当作accompany_id
		Songno:             params.GetString("songno"),
		AccompanyName:      params.GetString("accompany_name"),
		AccompanyNameSpell: params.GetString("accompany_name_spell"),
		AccompanyFilename:  params.GetString("accompany_filename"),
		Audio:              params.GetInt("audio"),
		HostIP:             params.GetString("host_ip"),
		Image:              params.GetString("image"),
		CategoryID:         params.GetInt("category_id"),
		ActVideoType:       params.GetInt("type"),
		CharCount:          params.GetInt("char_count"),
		Rank:               params.GetInt("rank"),
		LampID:             params.GetInt("lamp_id"),
		EffectID:           params.GetInt("effect_id"),
		ReverberationID:    params.GetInt("reverberation_id"),
	}
}

func saveActVideoExcelHistory(params util.Params, code string, action meta.ExcelHistoryAction) error {
	history := meta.ExcelHistory{
		Category:   meta.ExcelHistoryActVideo,
		Content:    params,
		Action:     action,
		RelationID: params.GetString("songno"),
		ImportCode: code,
	}

	return model.SongDB.Create(&history).Error
}

func saveActVideoSystemLog(c *gin.Context, action meta.SystemLogAction, remark string, data interface{}) {
	staff := middleware.StaffFromContext(c)

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleActVideo).SetStaff(staff).SetAction(action).SetRemark(remark).SetData(data)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error("跳舞视频操作历史")

	}
}
