package song

import (
	"fmt"
	"time"

	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetWallpaper 动态壁纸列表
func GetWallpaper(c *gin.Context) {
	var request struct {
		api.PageRequest
		No       string `json:"no" form:"no"`
		Name     string `json:"name" form:"name"`
		Filename string `json:"filename" form:"filename"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("动态壁纸列表")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var wallpapers []song.Wallpaper
	count := 0
	page := request.PageRequest.OffsetLimit()

	query := model.SongDB.Model(song.Wallpaper{}).Scopes(
		song.WallpaperLikeScope("wallpaper_no", request.No),
		song.WallpaperLikeScope("wallpaper_name", request.Name),
		song.WallpaperLikeScope("wallpaper_filename", request.Filename))

	query.Count(&count)
	query.Order("wallpaper_no").Offset(page.Offset).Limit(page.Limit).Find(&wallpapers)

	api.MakePage(c, appendWallpaperEmoTag(wallpapers), api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// WallpaperWithEmo 动态壁纸返回
type WallpaperWithEmo struct {
	song.Wallpaper

	Emos []string `json:"emos"`
}

func appendWallpaperEmoTag(wallpapers []song.Wallpaper) []WallpaperWithEmo {
	emoMap := song.EmoTagMap()

	var response []WallpaperWithEmo
	for _, wallpaper := range wallpapers {
		item := WallpaperWithEmo{
			Wallpaper: wallpaper,
		}

		var emos []string
		for _, i := range *wallpaper.EmoTagIds {
			if _, ok := emoMap[int(i)]; ok {
				emos = append(emos, emoMap[int(i)])
			}
		}

		item.Emos = emos

		response = append(response, item)
	}

	return response
}

// PostWallpaper 新增动态壁纸导入
func PostWallpaper(c *gin.Context) {
	contents, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("新增动态壁纸excel错误")
		api.Unprocessable(c, "动态壁纸新增excel失败")
		return
	}

	code := time.Now().Format("20060102150405")
	excel := util.NormalizeExcelData(contents, map[string]string{}, "wallpaper_no")

	for _, item := range excel.Params {
		if err := saveWallpaperHistory(item, code, meta.ExcelHistoryInsert); nil != err {
			excel.Response.Fail = fmt.Sprintf("保存动态壁纸新增历史记录错误:%s", err.Error())
			api.Make(c, excel.Response)
			return
		}

		if err := saveWallpaper(item); nil != err {
			excel.Response.Fail = fmt.Sprintf("处理动态壁纸信息错误:%s, err:%s", item.GetString("wallpaper_no"), err.Error())
			api.Make(c, excel.Response)
			return
		}
	}

	saveWallpaperSystemLog(c, meta.LogActionInsert, code, util.Params{})
	api.Make(c, excel.Response)
}

// UpdateWallpaper 修改动态壁纸
func UpdateWallpaper(c *gin.Context) {
	contents, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("修改动态壁纸excel错误")
		api.Unprocessable(c, "动态壁纸修改excel失败")
		return
	}

	code := time.Now().Format("20060102150405")
	excel := util.NormalizeExcelData(contents, map[string]string{}, "wallpaper_no")

	for _, item := range excel.Params {
		if err := saveWallpaperHistory(item, code, meta.ExcelHistoryUpdate); nil != err {
			excel.Response.Fail = fmt.Sprintf("保存动态壁纸修改历史记录错误:%s", err.Error())
			api.Make(c, excel.Response)
			return
		}

		if err := saveWallpaper(item); nil != err {
			excel.Response.Fail = fmt.Sprintf("处理动态壁纸信息错误:%s, err:%s", item.GetString("wallpaper_no"), err.Error())
			api.Make(c, excel.Response)
			return
		}
	}

	saveWallpaperSystemLog(c, meta.LogActionUpdate, code, util.Params{})
	api.Make(c, excel.Response)
}

// BatchDeleteWallpaper 批量删除
func BatchDeleteWallpaper(c *gin.Context) {
	var request struct {
		IDs []int `json:"ids" form:"ids"`
	}
	if err := c.BindJSON(&request); nil != err {
		logger.Entry().Error(err)
		api.Unprocessable(c, "参数错误")
		return
	}

	if err := model.SongDB.Where("id in (?)", request.IDs).Delete(&song.Wallpaper{}).Error; nil != err {
		logger.Entry().WithError(err).Error("批量删除错误")
		api.ServerError(c, err.Error())
		return
	}

	saveWallpaperSystemLog(c, meta.LogActionDelete, "批量删除", request)
	api.NoContent(c)
}

// saveWallpaper 保存信息
func saveWallpaper(param util.Params) error {
	wallpaper, err := paramToWallpaper(param)
	if err != nil {
		return err
	}

	var count int
	if err := model.SongDB.Model(&song.Wallpaper{}).Where("wallpaper_no = ?", wallpaper.WallpaperNo).Count(&count).Error; nil != err {
		return err
	}

	if count > 0 {
		return model.SongDB.Model(&song.Wallpaper{}).Where("wallpaper_no = ?", wallpaper.WallpaperNo).Update(wallpaper).Error
	}

	return model.SongDB.Create(wallpaper).Error
}

// paramToWallpaper 格式化动态壁纸导入信息
func paramToWallpaper(param util.Params) (*song.Wallpaper, error) {
	wallpaper := song.Wallpaper{
		WallpaperNo:       param.GetString("wallpaper_no"),
		WallpaperName:     param.GetString("wallpaper_name"),
		WallpaperFilename: param.GetString("wallpaper_filename"),
		Codec:             param.GetString("codec"),
		Width:             param.GetInt("width"),
		Height:            param.GetInt("height"),
		HostIP:            param.GetString("host_ip"),
		Location:          param.GetString("location"),
		PipX:              param.GetInt("pip_x"),
		PipY:              param.GetInt("pip_y"),
		PngX:              param.GetInt("png_x"),
		PngY:              param.GetInt("png_y"),
		Pip2X:             param.GetInt("pip2_x"),
		Pip2Y:             param.GetInt("pip2_y"),
		Png2X:             param.GetInt("png2_x"),
		Png2Y:             param.GetInt("png2_y"),
		PipWidth:          param.GetInt("pip_width"),
		PipHeight:         param.GetInt("pip_height"),
		PngHostIP:         param.GetString("png_host_ip"),
		PngCount:          param.GetInt("png_count"),
	}

	emos := param.GetString("emo_tag_id")
	if ids, err := util.IntStringToPqInt64Arr(emos); nil == err {
		wallpaper.EmoTagIds = ids
	} else {
		return nil, fmt.Errorf("emo_tag解析错误:%s", emos)
	}

	return &wallpaper, nil
}

// saveWallpaperHistory 保存excel导入历史
func saveWallpaperHistory(param util.Params, code string, action meta.ExcelHistoryAction) error {
	history := meta.ExcelHistory{
		Category:   meta.ExcelHistoryWallpaper,
		Content:    param,
		Action:     action,
		RelationID: param.GetString("wallpaper_no"),
		ImportCode: code,
	}

	return model.SongDB.Create(&history).Error
}

func saveWallpaperSystemLog(c *gin.Context, action meta.SystemLogAction, remark string, data interface{}) {
	staff := middleware.StaffFromContext(c)

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleWallpaper).SetStaff(staff).SetAction(action).SetRemark(remark).SetData(data)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error("动态壁纸操作历史")
	}
}
