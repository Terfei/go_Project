package song

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetAccompany 伴奏列表
func GetAccompany(c *gin.Context) {
	var request struct {
		api.PageRequest
		Songno   string   `json:"songno" form:"songno"`
		Name     string   `json:"name" form:"name"`
		Singer   string   `json:"singer" form:"singer"`
		Language string   `json:"language" form:"language"`
		Songnos  []string `json:"songnos" form:"songnos[]"`
	}
	if err := c.ShouldBindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("伴奏列表")
		api.Unprocessable(c, "参数错误")
		return
	}

	var songs []song.Accompany
	count := 0
	page := request.PageRequest.OffsetLimit()

	query := model.SongDB.Model(&song.Accompany{}).Scopes(
		song.AccompanyLanguageNameLikeScope(request.Language),
		songdb.ColumnLikeScope("songno", request.Songno),
		songdb.ColumnLikeScope("name", request.Name),
		songdb.ColumnLikeScope("singer_name_all", request.Singer),
		songdb.ColumnStringInScope(`songno`, request.Songnos),
	)

	query.Count(&count)
	query.Set("gorm:auto_preload", true).Order("songno").Offset(page.Offset).Limit(page.Limit).Find(&songs)

	api.MakePage(c, songs, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// AccompanyImportResponse 歌曲导入下行
type AccompanyImportResponse struct {
	Total  int      `json:"total"`
	Fail   string   `json:"fail"`
	Banned []string `json:"banned"`
}

// PostAccompany 新增伴奏
func PostAccompany(c *gin.Context) {
	contents, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("新增歌曲导入excel失败")
		api.Unprocessable(c, "新增歌曲导入excel失败")
		return
	}

	code := time.Now().Format("20060102150405")
	languages := languageMap()
	excel := util.NormalizeExcelData(contents, accompanyTimeColumns(), "SONGNO")
	response := AccompanyImportResponse{
		Total: excel.Response.Total,
		Fail:  excel.Response.Fail,
	}

	for _, item := range excel.Params {
		if fail := saveAccompanyHistory(item, code, meta.ExcelHistoryInsert); nil != fail {
			response.Fail = fmt.Sprintf("保存历史信息错误,%s", fail.Error())
			api.Make(c, response)
			return
		}

		accompany, err := dealPostAccompanyExcelParams(item, languages)
		if err != nil {
			response.Fail = err.Error()
			api.Make(c, response)
			return
		}

		if fail := saveAccompany(accompany); "" != fail {
			response.Fail = fail
			api.Make(c, response)
			return
		}

		if count := song.CountBannedBySongName(accompany.Name); count > 0 {
			response.Banned = append(response.Banned, accompany.Songno)
		}
	}

	saveAccompanySystemLog(c, meta.LogActionInsert, code, util.Params{})
	api.Make(c, response)
}

// UpdateAccompany 修改歌曲信息导入
func UpdateAccompany(c *gin.Context) {
	contents, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("修改歌曲导入excel失败")
		api.Unprocessable(c, "修改歌曲导入excel失败")
		return
	}

	code := time.Now().Format("20060102150405")
	languages := languageMap()

	excel := util.NormalizeExcelData(contents, accompanyTimeColumns(), "SONGNO")
	response := AccompanyImportResponse{
		Total: excel.Response.Total,
		Fail:  excel.Response.Fail,
	}

	for _, item := range excel.Params {
		if fail := saveAccompanyHistory(item, code, meta.ExcelHistoryUpdate); nil != fail {
			response.Fail = fmt.Sprintf("保存历史信息错误,%s", fail.Error())
			api.Make(c, response)
			return
		}

		accompany, err := dealPostAccompanyExcelParams(item, languages)
		if err != nil {
			response.Fail = err.Error()
			api.Make(c, response)
			return
		}

		if fail := saveAccompany(accompany); "" != fail {
			response.Fail = fail
			api.Make(c, response)
			return
		}

		if count := song.CountBannedBySongName(accompany.Name); count > 0 {
			response.Banned = append(response.Banned, accompany.Songno)
		}
	}

	saveAccompanySystemLog(c, meta.LogActionUpdate, code, util.Params{})
	api.Make(c, response)
}

// ExcelDeleteAccompany excel删除
func ExcelDeleteAccompany(c *gin.Context) {
	contents, err := util.HTTPExcelContents(c)
	if err != nil {
		logger.Entry().WithError(err).Error("删除歌曲导入excel失败")
		api.Unprocessable(c, "删除歌曲导入excel失败")
		return
	}

	code := time.Now().Format("20060102150405")
	excel := util.NormalizeExcelData(contents, map[string]string{}, "SONGNO")
	response := excel.Response

	for _, item := range excel.Params {
		if fail := saveAccompanyHistory(item, code, meta.ExcelHistoryDelete); nil != fail {
			response.Fail = fmt.Sprintf("保存历史信息错误,%s", fail.Error())
			api.Make(c, response)
			return
		}

		songno := item.GetString("SONGNO")
		query := model.SongDB.Table(song.TableAccompany).Where("songno = ?", songno)

		var accompany song.Accompany
		if err := query.First(&accompany).Error; nil != err {
			response.Fail = fmt.Sprintf("删除歌曲错误%s,%s", songno, err.Error())
			api.Make(c, response)
			return
		}

		if err := query.Delete(&accompany).Error; nil != err {
			response.Fail = fmt.Sprintf("删除歌曲错误%s,%s", songno, err.Error())
			api.Make(c, response)
			return
		}
	}

	saveAccompanySystemLog(c, meta.LogActionDelete, code, util.Params{})
	api.Make(c, response)
}

// BatchDeleteAccompany 批量删除
func BatchDeleteAccompany(c *gin.Context) {
	var request struct {
		IDs []int `json:"ids" form:"ids"`
	}
	if err := c.BindJSON(&request); nil != err {
		logger.Entry().Error(err)
		api.Unprocessable(c, "参数错误")
		return
	}

	if err := model.SongDB.Where("id in (?)", request.IDs).Delete(&song.Accompany{}).Error; nil != err {
		logger.Entry().WithError(err).Error("批量删除错误")
		api.ServerError(c, err.Error())
		return
	}

	saveAccompanySystemLog(c, meta.LogActionDelete, "批量删除", request)
	api.NoContent(c)
}

func saveAccompany(accompany *song.Accompany) string {
	var count int
	if err := model.SongDB.Model(&song.Accompany{}).Where("songno = ?", accompany.Songno).Count(&count).Error; nil != err {
		return fmt.Sprintf("查询歌曲是否存在错误, songno:%s, err:%s", accompany.Songno, err.Error())
	}

	if count > 0 {
		if err := model.SongDB.Model(&song.Accompany{}).Where("songno = ?", accompany.Songno).Update(accompany).Error; nil != err {
			return fmt.Sprintf("修改歌曲错误, songno:%s, err:%s", accompany.Songno, err.Error())
		}
	} else {
		if err := model.SongDB.Create(accompany).Error; nil != err {
			return fmt.Sprintf("新增歌曲错误, songno:%s, err:%s", accompany.Songno, err.Error())
		}
	}

	return ""
}

func dealPostAccompanyExcelParams(params util.Params, languages map[string]int) (*song.Accompany, error) {
	var s song.Accompany
	s.Audio, _ = strconv.Atoi(params.GetString("AUDIO"))
	s.Songno = params.GetString("SONGNO")
	s.Filename = params.GetString("DISKNAME")
	s.ReleaseTime = util.StringToDateTime(params.GetString("NEWSONG"))
	s.Name = params.GetString("SONGNAME")
	if len(s.Name) == 0 {
		return nil, fmt.Errorf("歌曲名信息错误:%s", s.Songno)
	}
	s.SingerNameAll = params.GetString("SONGER_ALL")
	language := params.GetString("LANGUAGE_TYPE")
	if l, ok := languages[language]; ok {
		s.LanguageID = l
	} else {
		item := song.AccompanyLanguage{
			Name:   language,
			IsShow: 1,
		}
		if err := model.SongDB.Create(&item).Error; nil != err {
			return nil, fmt.Errorf("保存语种信息错误:%s", language)
		}
		s.LanguageID = item.ID
	}
	s.Channel = params.GetString("LR")
	s.VersionID, _ = strconv.Atoi(params.GetString("LTD"))
	s.CategoryID, _ = strconv.Atoi(params.GetString("TYPE"))
	s.Ext = strings.Trim(params.GetString("File_Ext"), ".")
	s.Singers = getSinger(params)
	s.NameSpell = params.GetString("SPELL")
	s.MidFilepath = params.GetString("mid_filepath")
	s.CharCount, _ = strconv.Atoi(params.GetString("SONGNUM"))
	s.EffectID, _ = strconv.Atoi(params.GetString("EFFECT"))
	s.LampID, _ = strconv.Atoi(params.GetString("LAMP"))
	s.ServerPath = params.GetString("SERVERPATH")
	s.Rank, _ = strconv.Atoi(params.GetString("MONCNT"))
	s.ReverberationGroup = params.GetString("reverberation_group")
	s.VideoqltyID, _ = strconv.Atoi(params.GetString("videoqlty_id"))
	s.AudioqltyID, _ = strconv.Atoi(params.GetString("audioqlty_id"))
	s.TagID, _ = strconv.Atoi(params.GetString("Tag_id"))

	emos := params.GetString("emo_tag_id")
	if ids, err := util.IntStringToPqInt64Arr(emos); nil == err {
		s.EmoTagIds = ids
	} else {
		return nil, fmt.Errorf("emo_tag解析错误:%s", emos)
	}

	return &s, nil
}

func languageMap() map[string]int {
	var items []song.AccompanyLanguage
	model.SongDB.Find(&items)
	res := make(map[string]int)

	for _, item := range items {
		res[item.Name] = item.ID
	}

	return res
}

func getSinger(params util.Params) song.AccompanySingers {
	singer := song.AccompanySingers{}
	singerOne := params.GetString("SONGER")
	if singerOne != "" {
		if s, err := song.FindSingerByName(singerOne); nil == err {
			singer.SingerOne = song.AccompanySinger{
				Name: s.Name,
				ID:   s.ID,
			}
		}
	}
	singerTwo := params.GetString("SONGER2")
	if singerTwo != "" {
		if s, err := song.FindSingerByName(singerTwo); nil == err {
			singer.SingerTwo = song.AccompanySinger{
				Name: s.Name,
				ID:   s.ID,
			}
		}
	}
	singerThree := params.GetString("SONGER3")
	if singerThree != "" {
		if s, err := song.FindSingerByName(singerThree); nil == err {
			singer.SingerThree = song.AccompanySinger{
				Name: s.Name,
				ID:   s.ID,
			}
		}
	}
	singerFour := params.GetString("SONGER4")
	if singerFour != "" {
		if s, err := song.FindSingerByName(singerFour); nil == err {
			singer.SingerFour = song.AccompanySinger{
				Name: s.Name,
				ID:   s.ID,
			}
		}
	}

	return singer
}

func accompanyTimeColumns() map[string]string {
	return map[string]string{
		"DISCK_DATE":  "DISCK_DATE",
		"NEWSONG":     "NEWSONG",
		"Set_Time_ED": "Set_Time_ED",
		"Set_Time_ST": "Set_Time_ST",
		"check_date":  "check_date",
	}
}

func saveAccompanyHistory(params util.Params, code string, action meta.ExcelHistoryAction) error {
	history := meta.ExcelHistory{
		Category:   meta.ExcelHistoryAccompany,
		Content:    params,
		Action:     action,
		RelationID: params.GetString("SONGNO"),
		ImportCode: code,
	}

	if err := model.SongDB.Create(&history).Error; nil != err {
		return err
	}

	return nil
}

func saveAccompanySystemLog(c *gin.Context, action meta.SystemLogAction, remark string, data interface{}) {
	staff := middleware.StaffFromContext(c)

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleAccompany).
		SetStaff(staff).SetAction(action).SetRemark(remark).SetData(data)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error("伴奏操作历史")
	}
}
