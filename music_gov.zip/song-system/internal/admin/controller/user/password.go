package user

import (
	"bytes"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

const modifyURI = `/api/users/staff/password`

// UpdatePassword 保存密码
func UpdatePassword(c *gin.Context) {
	var request struct {
		Password    string `json:"password"`
		NewPassword string `json:"new_password"`
	}

	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().Error(err)
		api.ServerError(c, err.Error())
		return
	}

	staff := middleware.StaffFromContext(c)
	if !staff.IsPasswordRight(request.Password) {
		api.BadRequest(c, `原密码输入错误`)
		return
	}

	attrs := map[string]string{
		`_method`:  `PUT`,
		`password`: request.NewPassword,
		`staff_id`: staff.StaffID.String(),
	}

	if err := postCentre(attrs); nil != err {
		api.BadRequest(c, err.Error())
		return
	}

	var params util.Params
	params.Set("staff_id", staff.StaffID)
	params.Set("stadd_name", staff.StaffName)

	if err := meta.SaveSystemLog(staff, meta.LogModuleUserStaff, meta.LogActionUpdate, "修改密码", params, 0); err != nil {
		logger.Entry().WithError(err).WithField("params", params).Error("修改密码操作历史")
		api.ServerError(c, fmt.Sprintf("保存操作历史:%s", err.Error()))
		return
	}

	api.NoContent(c)
}

// ResetPassword 重置密码
func ResetPassword(c *gin.Context) {
	id := c.Param(`id`)
	attrs := map[string]string{
		`_method`:  `PUT`,
		`reset`:    `1`,
		`staff_id`: id,
	}

	if err := postCentre(attrs); nil != err {
		api.BadRequest(c, err.Error())
		return
	}
	api.NoContent(c)
}

func postCentre(attrs map[string]string) error {
	client := &http.Client{
		Timeout: time.Second * 3,
	}

	j, _ := json.Marshal(attrs)
	URL := fmt.Sprintf(`http://%s%s`, config.Setting.Centre.Domain, modifyURI)
	request, err := http.NewRequest(`POST`, URL, bytes.NewReader(j))
	if nil != err {
		logger.Entry().WithError(err).Error(`建立请求出错`)
		return err
	}

	request.Header.Set(`Content-Type`, `application/json`)
	request.Header.Set(`x-request-from`, `ck-microservice`)
	request.Header.Set(`Authorization`, generateSign(attrs))

	response, err := client.Do(request)
	if err != nil {
		logger.Entry().WithError(err).Error(`向中央服务器发送修改密码请求出错`)
		return err
	}

	defer response.Body.Close()
	if http.StatusOK != response.StatusCode {
		return errors.New(`修改密码失败`)
	}

	return nil
}

func generateSign(attrs map[string]string) string {
	attrs[`salt`] = config.Setting.Centre.Salt

	var s string
	util.EachMap(attrs, func(k, v string) {
		s = s + k + `=` + v + `&`
	})

	ss := s[0 : len(s)-1]
	ret := md5.Sum([]byte(ss))
	return hex.EncodeToString(ret[:])
}
