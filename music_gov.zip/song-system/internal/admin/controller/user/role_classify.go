package user

import (
	"github.com/gin-gonic/gin"
	"github.com/sirupsen/logrus"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/user"
)

// GetRoleClassify 角色分类列表
func GetRoleClassify(c *gin.Context) {
	var request struct {
		api.PageRequest
		Name string `form:"name"`
	}

	if err := c.ShouldBindQuery(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}

	page := request.PageRequest.OffsetLimit()
	query := model.SongDB.Where(`name like ?`, `%`+request.Name+`%`)

	count := 0
	query.Model(&user.RoleClassify{}).Count(&count)

	var rcs []user.RoleClassify
	if err := query.Offset(page.Offset).Limit(page.Limit).Find(&rcs).Error; nil != err {
		logger.Entry().WithError(err).Error("获取角色类别列表失败")
		api.ServerError(c, "获取角色类别列表失败")
		return
	}

	api.MakePage(c, rcs, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// ShowRoleClassify 角色类别
func ShowRoleClassify(c *gin.Context) {
	var rc user.RoleClassify

	id := c.Param(`id`)
	if err := model.SongDB.Where(`id = ?`, id).First(&rc).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}

	api.Make(c, map[string]interface{}{
		`list`: rc,
	})
}

// PostRoleClassify 添加角色类别
func PostRoleClassify(c *gin.Context) {
	var request struct {
		Name string `json:"name"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}

	attrs := map[string]interface{}{
		"name": request.Name,
	}
	roleClassify := user.RoleClassify{
		Name: request.Name,
	}

	if err := model.SongDB.Create(&roleClassify).Error; nil != err {
		logrus.WithFields(attrs).Error("添加角色类别失败" + err.Error())
		api.ServerError(c, "添加角色类别失败")
		return
	}

	saveRoleSystemLog(c, meta.LogActionInsert, `添加角色类别`, roleClassify)

	api.Created(c)
}

// PatchRoleClassify 编辑角色类别
func PatchRoleClassify(c *gin.Context) {
	var request struct {
		Name string `json:"name"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}

	id := c.Param(`id`)
	var roleClassify user.RoleClassify
	if err := model.SongDB.Where(`id = ?`, id).First(&roleClassify).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}

	roleClassify.Name = request.Name
	if err := model.SongDB.Model(&user.RoleClassify{}).Where(`id = ?`, id).Update(&roleClassify).Error; nil != err {
		attrs := map[string]interface{}{
			"name": request.Name,
		}

		logrus.WithFields(attrs).Error("修改角色类别失败" + err.Error())
		api.ServerError(c, "修改角色类别失败")
		return
	}

	saveRoleSystemLog(c, meta.LogActionUpdate, `修改角色类别`, roleClassify)

	api.NoContent(c)
}

// DeleteRoleClassify 删除角色类别
func DeleteRoleClassify(c *gin.Context) {
	var roleClassify user.RoleClassify
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&roleClassify).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}

	if err := model.SongDB.Delete(roleClassify).Error; nil != err {
		logger.Entry().WithError(err).Error("删除角色类别失败")
		api.ServerError(c, "修改角色类别失败")
		return
	}

	saveRoleSystemLog(c, meta.LogActionDelete, `删除角色类别`, roleClassify)

	api.NoContent(c)
}

func saveRoleClassifySystemLog(c *gin.Context, action meta.SystemLogAction, remark string, data interface{}) {
	staff := middleware.StaffFromContext(c)

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleUserRoleClassify).
		SetStaff(staff).SetAction(action).SetRemark(remark).SetData(data)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error("角色类别操作历史")
	}
}
