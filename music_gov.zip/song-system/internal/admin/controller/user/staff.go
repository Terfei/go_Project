package user

import (
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/pkg/errors"
	uuid "github.com/satori/go.uuid"
	"github.com/sirupsen/logrus"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	bridgeUsers "gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/users"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/user"
)

type staffListResp struct {
	bridgeUsers.Staff
	ViewCode string      `json:"view_code"`
	Roles    []user.Role `json:"roles"`
	IsCenter bool        `json:"is_center"`
}

// GetStaffs 获取员工列表
func GetStaffs(c *gin.Context) {
	var request struct {
		api.PageRequest
		Name     string `form:"name"`
		BranchID string `json:"branch_id" form:"branch_id"`
	}

	if err := c.ShouldBindQuery(&request); nil != err {
		logrus.Error(err)
		api.Unprocessable(c, `参数错误`)
		return
	}

	query := model.BridgeDB.Model(&bridgeUsers.Staff{}).Scopes(
		bridgeUsers.StaffNameLikeScope(request.Name),
	).Where(`delete_time is null`)

	if _, ok := c.GetQuery(`branch_id`); ok {
		bid, err := uuid.FromString(request.BranchID)
		if nil != err {
			logrus.Error(err)
			api.Unprocessable(c, `参数门店id错误`)
			return
		}
		query = query.Scopes(bridgeUsers.BranchIDInScope(bid))
	}

	count := 0
	query.Count(&count)

	var staffs []bridgeUsers.Staff
	page := request.PageRequest.OffsetLimit()
	query.Order(`erp_code`).Order(`create_time desc`).Offset(page.Offset).Limit(page.Limit).Find(&staffs)

	staffExtra, err := staffExtraData(staffs)
	if err != nil {
		logrus.Error(err)
	}

	var lists []staffListResp
	for _, v := range staffs {
		extraInfo := staffExtra[v.StaffID]
		lists = append(lists, staffListResp{
			v,
			extraInfo.ViewCode,
			extraInfo.Roles,
			extraInfo.IsCenter(),
		})
	}

	api.MakePage(c, lists, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// ShowStaff 账号
func ShowStaff(c *gin.Context) {
	var staff user.Staff

	id := c.Param(`id`)
	if err := model.SongDB.Preload(`Roles`).Where(`id = ?`, id).First(&staff).Error; nil != err {
		api.NoContent(c)
		return
	}

	api.Make(c, map[string]interface{}{
		`list`: staff,
	})
}

// PatchStaff 编辑员工
func PatchStaff(c *gin.Context) {
	var request struct {
		RoleIDs  []int `json:"role_ids"`
		IsCenter bool  `json:"is_center"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}

	id := c.Param(`id`)
	attrs := map[string]interface{}{
		"id":       id,
		"role_ids": request.RoleIDs,
		"extra":    user.StaffExtra{Center: request.IsCenter},
	}

	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		rs, err := user.FindByRoleIDs(request.RoleIDs)
		if nil != err {
			logrus.WithFields(attrs).Error("查询角色失败" + err.Error())
			return err
		}

		var staff user.Staff
		if err := model.SongDB.Where(`id = ?`, id).First(&staff).Error; nil != err {
			staffID, err := uuid.FromString(id)
			if nil != err {
				logrus.WithFields(attrs).Error("id错误" + err.Error())
				return err
			}

			staff := user.Staff{
				ID:    staffID,
				Roles: rs,
				Extra: &user.StaffExtra{
					Center: request.IsCenter,
				},
			}

			if err := tx.Omit(`ViewCode`).Create(&staff).Error; nil != err {
				logrus.WithFields(attrs).Error("修改员工失败" + err.Error())
				return err
			}

			return nil
		}

		tx.Model(staff).Where("id = ?", staff.ID).Update(map[string]interface{}{
			"extra": &user.StaffExtra{Center: request.IsCenter},
		})

		if err := tx.Model(staff).Association(`roles`).Clear().Append(rs).Error; nil != err {
			logrus.WithFields(attrs).Error("修改员工角色关联失败" + err.Error())
			return err
		}

		saveStaffSystemLog(c, meta.LogActionUpdate, `修改员工授权`, staff)

		return nil
	})

	if nil != err {
		api.ServerError(c, "修改角色失败")
		return
	}

	api.NoContent(c)
}

func staffExtraData(staffs []bridgeUsers.Staff) (map[uuid.UUID]user.Staff, error) {
	result := make(map[uuid.UUID]user.Staff, len(staffs))
	staffIDs := staffIDs(staffs)
	if len(staffIDs) == 0 {
		return result, nil
	}

	var localStaffs []user.Staff
	if err := model.SongDB.Where(`id in (?)`, staffIDs).Preload(`Roles`).Find(&localStaffs).Error; err != nil {
		return result, errors.Wrap(err, `查询本地店员账号表出错`)
	}

	for _, v := range localStaffs {
		result[v.ID] = v
	}

	return result, nil
}

func staffIDs(staffs []bridgeUsers.Staff) []uuid.UUID {
	result := make([]uuid.UUID, 0, len(staffs))
	for _, v := range staffs {
		result = append(result, v.StaffID)
	}

	return result
}

func saveStaffSystemLog(c *gin.Context, action meta.SystemLogAction, remark string, data interface{}) {
	staff := middleware.StaffFromContext(c)

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleUserStaff).
		SetStaff(staff).SetAction(action).SetRemark(remark).SetData(data)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error("角色类别操作历史")
	}
}
