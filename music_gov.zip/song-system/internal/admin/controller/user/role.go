package user

import (
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/sirupsen/logrus"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/user"
)

// GetRoles 角色列表
func GetRoles(c *gin.Context) {
	var request struct {
		api.PageRequest
		Name string `form:"name"`
	}

	if err := c.ShouldBindQuery(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}

	page := request.PageRequest.OffsetLimit()
	query := model.SongDB.Where(`name like ?`, `%`+request.Name+`%`)

	count := 0
	query.Model(&user.Role{}).Count(&count)

	var rs []user.Role
	preQuery := query.Preload(`Classify`).Preload(`Permissions`)
	if err := preQuery.Offset(page.Offset).Limit(page.Limit).Order("code").Find(&rs).Error; nil != err {
		logger.Entry().WithError(err).Error("获取角色列表失败")
		api.ServerError(c, "获取角色列表失败")
		return
	}

	api.MakePage(c, rs, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// ShowRole 角色
func ShowRole(c *gin.Context) {
	var role user.Role

	id := c.Param(`id`)
	query := model.SongDB.Preload(`Classify`).Preload(`Permissions`)
	if err := query.Where(`id = ?`, id).First(&role).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}

	api.Make(c, map[string]interface{}{
		`list`: role,
	})
}

// PostRole 添加角色
func PostRole(c *gin.Context) {
	var request struct {
		Name          string `json:"name"`
		Status        string `json:"status"`
		Remarks       string `json:"remarks"`
		ClassifyID    int    `json:"classify_id"`
		PermissionIDs []int  `json:"permission_ids"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}

	attrs := map[string]interface{}{
		"name":           request.Name,
		"status":         request.Status,
		"remarks":        request.Remarks,
		"classify_id":    request.ClassifyID,
		"permission_ids": request.PermissionIDs,
	}

	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		ps, err := user.FindByPermissionIDs(request.PermissionIDs)
		if nil != err {
			logrus.WithFields(attrs).Error("查询权限点失败" + err.Error())
			return err
		}

		role := user.Role{
			Name:        request.Name,
			Status:      request.Status,
			Remarks:     request.Remarks,
			ClassifyID:  request.ClassifyID,
			Permissions: ps,
		}

		if err := tx.Omit(`ViewCode`).Create(&role).Error; nil != err {
			logrus.WithFields(attrs).Error("添加角色失败" + err.Error())
			return err
		}

		saveRoleSystemLog(c, meta.LogActionInsert, `添加角色`, role)
		return nil
	})

	if nil != err {
		api.ServerError(c, "添加角色失败")
		return
	}

	api.Created(c)
}

// PatchRole 编辑角色
func PatchRole(c *gin.Context) {
	var request struct {
		Name          string `json:"name"`
		Status        string `json:"status"`
		Remarks       string `json:"remarks"`
		ClassifyID    int    `json:"classify_id"`
		PermissionIDs []int  `json:"permission_ids"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}

	id := c.Param(`id`)
	var role user.Role
	if err := model.SongDB.Where(`id = ?`, id).First(&role).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}

	attrs := map[string]interface{}{
		"name":           request.Name,
		"status":         request.Status,
		"remarks":        request.Remarks,
		"classify_id":    request.ClassifyID,
		"permission_ids": request.PermissionIDs,
	}

	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		ps, err := user.FindByPermissionIDs(request.PermissionIDs)
		if nil != err {
			logrus.WithFields(attrs).Error("查询权限点失败" + err.Error())
			return err
		}

		if err := tx.Model(role).Association(`permissions`).Clear().Append(ps).Error; nil != err {
			logrus.WithFields(attrs).Error("修改角色权限点关联失败" + err.Error())
			return err
		}

		role.Name = request.Name
		role.Status = request.Status
		role.Remarks = request.Remarks
		role.ClassifyID = request.ClassifyID

		if err := tx.Omit(`ViewCode`).Model(&user.Role{}).Where(`id = ?`, id).Update(&role).Error; nil != err {
			logrus.WithFields(attrs).Error("修改角色失败" + err.Error())
			return err
		}

		saveRoleSystemLog(c, meta.LogActionUpdate, `修改角色`, role)
		return nil
	})

	if nil != err {
		api.ServerError(c, "修改角色失败")
		return
	}

	api.NoContent(c)
}

// DeleteRole 删除角色
func DeleteRole(c *gin.Context) {
	var role user.Role
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&role).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}

	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(role).Association(`permissions`).Clear().Error; nil != err {
			logrus.Error("删除角色权限点关联失败" + err.Error())
			return err
		}

		if err := tx.Delete(role).Error; nil != err {
			logger.Entry().WithError(err).Error("删除角色失败")
			return err
		}

		saveRoleSystemLog(c, meta.LogActionDelete, `删除角色`, role)
		return nil
	})

	if nil != err {
		api.ServerError(c, "删除角色失败")
		return
	}

	api.NoContent(c)
}

func saveRoleSystemLog(c *gin.Context, action meta.SystemLogAction, remark string, data interface{}) {
	staff := middleware.StaffFromContext(c)

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleUserRole).
		SetStaff(staff).SetAction(action).SetRemark(remark).SetData(data)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error("角色操作历史")
	}
}
