package tag

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
)

// PostEmoTag 添加情绪标签
func PostEmoTag(c *gin.Context) {
	var request struct {
		Name    string `json:"name"`
		NameKey string `json:"name_key"`
		Image   string `json:"image"`
		Seq     int8   `json:"seq"`
		IsShow  int8   `json:"is_show"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	emo := song.EmoTag{
		Name:    request.Name,
		NameKey: request.NameKey,
		Image:   request.Image,
		Seq:     request.Seq,
		IsShow:  request.IsShow,
	}
	if err := model.SongDB.Create(&emo).Error; nil != err {
		logger.Entry().WithError(err).Error("添加情绪标签失败")
		api.ServerError(c, "添加情绪标签失败")
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleEmoTag, meta.LogActionInsert, "新增情绪标签", request, emo.ID); nil != err {
		logger.Entry().WithError(err).Error("添加情绪标签操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.Created(c)
}

// GetEmoTag 情绪标签列表
func GetEmoTag(c *gin.Context) {
	var EmoTags []song.EmoTag
	if err := model.SongDB.Order(`seq`).Find(&EmoTags).Error; nil != err {
		logger.Entry().WithError(err).Error("获取情绪标签列表失败")
		api.ServerError(c, "获取情绪标签列表失败")
		return
	}

	api.Make(c, EmoTags)
}

// PatchEmoTag 编辑情绪标签
func PatchEmoTag(c *gin.Context) {
	var emo song.EmoTag
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&emo).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	var request struct {
		Name       string `json:"name"`
		NameKey    string `json:"name_key"`
		OverviewID int8   `json:"overview_id"`
		Image      string `json:"image"`
		Seq        int8   `json:"seq"`
		IsShow     int8   `json:"is_show"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	requestPatch := song.EmoTag{
		Name:    request.Name,
		NameKey: request.NameKey,
		Image:   request.Image,
		Seq:     request.Seq,
		IsShow:  request.IsShow,
	}
	if err := model.SongDB.Model(&song.EmoTag{}).Where("id = ?", emo.ID).Update(&requestPatch).Error; nil != err {
		logger.Entry().WithError(err).Error("编辑情绪标签失败")
		api.ServerError(c, "编辑情绪标签质量失败")
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleEmoTag, meta.LogActionUpdate, "修改情绪标签", request, emo.ID); nil != err {
		logger.Entry().WithError(err).Error("添加情绪标签操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}

// DeleteEmoTag 删除情绪标签
func DeleteEmoTag(c *gin.Context) {
	var emo song.EmoTag
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&emo).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	if err := model.SongDB.Where("id = ?", c.Param("id")).Delete(song.EmoTag{}).Error; nil != err {
		logger.Entry().WithError(err).Error("删除情绪标签失败")
		api.ServerError(c, "删除情绪标签失败")
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleEmoTag, meta.LogActionDelete, "删除情绪标签", emo, emo.ID); nil != err {
		logger.Entry().WithError(err).Error("添加情绪标签操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}
