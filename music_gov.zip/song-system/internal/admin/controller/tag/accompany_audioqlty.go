package tag

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
)

// PostAccompanyAudioqlty 添加伴奏音频质量
func PostAccompanyAudioqlty(c *gin.Context) {
	var request struct {
		Code   string `json:"code" binding:"required"`
		Image  string `json:"image"`
		Seq    int8   `json:"seq"`
		IsShow int8   `json:"is_show"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	audio := song.AccompanyAudioqlty{
		Code:   request.Code,
		Image:  request.Image,
		Seq:    request.Seq,
		IsShow: request.IsShow,
	}
	if err := model.SongDB.Create(&audio).Error; nil != err {
		logger.Entry().WithError(err).Error("添加伴奏音频质量失败")
		api.ServerError(c, "添加伴奏音频质量失败")
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyAudioqlty, meta.LogActionInsert, "新增音频质量", request, audio.ID); nil != err {
		logger.Entry().WithError(err).Error("添加音频质量操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.Created(c)
}

// GetAccompanyAudioqlty 伴奏音频质量列表
func GetAccompanyAudioqlty(c *gin.Context) {
	var accompantAudioqlties []song.AccompanyAudioqlty
	if err := model.SongDB.Order(`seq`).Find(&accompantAudioqlties).Error; nil != err {
		logger.Entry().WithError(err).Error("获取伴奏音频质量列表失败")
		api.ServerError(c, "获取伴奏音频质量列表失败")
		return
	}

	api.Make(c, accompantAudioqlties)
}

// PatchAccompanyAudioqlty 编辑伴奏音频质量
func PatchAccompanyAudioqlty(c *gin.Context) {
	var audio song.AccompanyAudioqlty
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&audio).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	var request struct {
		Code   string `json:"code" binding:"required"`
		Image  string `json:"image"`
		Seq    int8   `json:"seq"`
		IsShow int8   `json:"is_show"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	requestPatch := song.AccompanyAudioqlty{
		Code:   request.Code,
		Image:  request.Image,
		Seq:    request.Seq,
		IsShow: request.IsShow,
	}
	if err := model.SongDB.Model(&song.AccompanyAudioqlty{}).Where("id = ?", audio.ID).Update(&requestPatch).Error; nil != err {
		logger.Entry().WithError(err).Error("编辑伴奏音频质量失败")
		api.ServerError(c, "编辑伴奏音频质量失败")
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyAudioqlty, meta.LogActionUpdate, "修改音频质量", request, audio.ID); nil != err {
		logger.Entry().WithError(err).Error("添加音频质量操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}

// DeleteAccompanyAudioqlty 删除伴奏音频质量
func DeleteAccompanyAudioqlty(c *gin.Context) {
	var audio song.AccompanyAudioqlty
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&audio).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	if err := model.SongDB.Where("id = ?", audio.ID).Delete(song.AccompanyAudioqlty{}).Error; nil != err {
		logger.Entry().WithError(err).Error("删除伴奏音频质量失败")
		api.ServerError(c, "删除伴奏音频质量失败")
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyAudioqlty, meta.LogActionDelete, "删除音频质量", audio, audio.ID); nil != err {
		logger.Entry().WithError(err).Error("添加音频质量操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}
	api.NoContent(c)
}
