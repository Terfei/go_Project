package tag

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
)

// PostAccompanyVersion 添加伴奏版本
func PostAccompanyVersion(c *gin.Context) {
	var request struct {
		Seq  int8   `json:"seq"`
		Name string `json:"name"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	version := song.AccompanyVersion{
		Seq:  request.Seq,
		Name: request.Name,
	}
	if err := model.SongDB.Create(&version).Error; nil != err {
		logger.Entry().WithError(err).Error("添加伴奏版本失败")
		api.ServerError(c, "添加伴奏版本失败")
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyVersion, meta.LogActionInsert, "新增歌曲版本", request, version.ID); nil != err {
		logger.Entry().WithError(err).Error("添加歌曲版本操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.Created(c)
}

// GetAccompanyVersion 伴奏版本列表
func GetAccompanyVersion(c *gin.Context) {
	var AccompanyVersions []song.AccompanyVersion
	if err := model.SongDB.Order(`seq`).Find(&AccompanyVersions).Error; nil != err {
		logger.Entry().WithError(err).Error("获取伴奏版本列表失败")
		api.ServerError(c, "获取伴奏版本列表失败")
		return
	}

	api.Make(c, AccompanyVersions)
}

// PatchAccompanyVersion 编辑伴奏版本
func PatchAccompanyVersion(c *gin.Context) {
	var version song.AccompanyVersion
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&version).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	var request struct {
		Seq  int8   `json:"seq"`
		Name string `json:"name"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	requestPatch := song.AccompanyVersion{
		Seq:  request.Seq,
		Name: request.Name,
	}
	if err := model.SongDB.Model(&song.AccompanyVersion{}).Where("id = ?", version.ID).Update(&requestPatch).Error; nil != err {
		logger.Entry().WithError(err).Error("编辑伴奏版本失败")
		api.ServerError(c, "编辑伴奏版本失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyVersion, meta.LogActionUpdate, "修改歌曲版本", request, version.ID); nil != err {
		logger.Entry().WithError(err).Error("添加歌曲版本操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}

// DeleteAccompanyVersion 删除伴奏版本
func DeleteAccompanyVersion(c *gin.Context) {
	var version song.AccompanyVersion
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&version).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	if err := model.SongDB.Where("id = ?", version.ID).Delete(song.AccompanyVersion{}).Error; nil != err {
		logger.Entry().WithError(err).Error("删除伴奏版本失败")
		api.ServerError(c, "删除伴奏版本失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyVersion, meta.LogActionDelete, "删除歌曲版本", version, version.ID); nil != err {
		logger.Entry().WithError(err).Error("添加歌曲版本操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}
