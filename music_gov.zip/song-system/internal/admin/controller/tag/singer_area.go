package tag

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
)

// PostSingerArea 添加歌手区域
func PostSingerArea(c *gin.Context) {
	var request struct {
		Name  string `json:"name"`
		Image string `json:"image"`
		Seq   int8   `json:"seq"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	singerArea := song.SingerArea{
		Name:  request.Name,
		Image: request.Image,
		Seq:   request.Seq,
	}
	if err := model.SongDB.Create(&singerArea).Error; nil != err {
		logger.Entry().WithError(err).Error("添加歌手区域失败")
		api.ServerError(c, "添加歌手区域失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleSingerArea, meta.LogActionInsert, "新增歌手区域", request, singerArea.ID); nil != err {
		logger.Entry().WithError(err).Error("添加歌手区域历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.Created(c)
}

// GetSingerArea 歌手区域列表
func GetSingerArea(c *gin.Context) {
	var SingerAreas []song.SingerArea
	if err := model.SongDB.Order(`seq`).Find(&SingerAreas).Error; nil != err {
		logger.Entry().WithError(err).Error("获取歌手区域列表失败")
		api.ServerError(c, "获取歌手区域列表失败")
		return
	}

	api.Make(c, SingerAreas)
}

// PatchSingerArea 编辑歌手区域
func PatchSingerArea(c *gin.Context) {
	var area song.SingerArea
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&area).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}

	var request struct {
		Name  string `json:"name"`
		Image string `json:"image"`
		Seq   int8   `json:"seq"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}

	attrs := map[string]interface{}{
		`name`:  request.Name,
		`image`: request.Image,
		`seq`:   request.Seq,
	}
	if err := model.SongDB.Model(&song.SingerArea{}).Where("id = ?", c.Param("id")).Update(attrs).Error; nil != err {
		logger.Entry().WithError(err).Error("编辑歌手区域失败")
		api.ServerError(c, "编辑歌手区域失败")
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleSingerArea, meta.LogActionUpdate, "修改歌手区域", request, area.ID); nil != err {
		logger.Entry().WithError(err).Error("添加歌手区域历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}

// DeleteSingerArea 删除歌手区域
func DeleteSingerArea(c *gin.Context) {
	var area song.SingerArea
	if err := model.SongDB.Where(c.Param("id")).First(&area).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	if err := model.SongDB.Where(c.Param("id")).Delete(song.SingerArea{}).Error; nil != err {
		logger.Entry().WithError(err).Error("删除歌手区域失败")
		api.ServerError(c, "删除歌手区域失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleSingerArea, meta.LogActionDelete, "删除歌手区域", area, area.ID); nil != err {
		logger.Entry().WithError(err).Error("添加歌手区域历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}
