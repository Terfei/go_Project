package tag

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
)

// PostAccompanyLanguage 添加伴奏语种
func PostAccompanyLanguage(c *gin.Context) {
	var request struct {
		Name    string `json:"name"`
		NameKey string `json:"name_key"`
		Image   string `json:"image"`
		Seq     int8   `json:"seq"`
		IsShow  int8   `json:"is_show"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	language := song.AccompanyLanguage{
		Name:    request.Name,
		NameKey: request.NameKey,
		Image:   request.Image,
		Seq:     request.Seq,
		IsShow:  request.IsShow,
	}
	if err := model.SongDB.Create(&language).Error; nil != err {
		logger.Entry().WithError(err).Error("添加伴奏语种失败")
		api.ServerError(c, "添加伴奏语种失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyLanguage, meta.LogActionInsert, "新增歌曲语种", request, language.ID); nil != err {
		logger.Entry().WithError(err).Error("添加歌曲语种操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.Created(c)
}

// GetAccompanyLanguage 伴奏语种列表
func GetAccompanyLanguage(c *gin.Context) {
	var AccompanyLanguages []song.AccompanyLanguage
	if err := model.SongDB.Order(`seq`).Find(&AccompanyLanguages).Error; nil != err {
		logger.Entry().WithError(err).Error("获取伴奏语种列表失败")
		api.ServerError(c, "获取伴奏语种列表失败")
		return
	}

	api.Make(c, AccompanyLanguages)
}

// PatchAccompanyLanguage 编辑伴奏语种
func PatchAccompanyLanguage(c *gin.Context) {
	var language song.AccompanyLanguage
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&language).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	var request struct {
		Name    string `json:"name"`
		NameKey string `json:"name_key"`
		Image   string `json:"image"`
		Seq     int8   `json:"seq"`
		IsShow  int8   `json:"is_show"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	requestPatch := song.AccompanyLanguage{
		Name:    request.Name,
		NameKey: request.NameKey,
		Image:   request.Image,
		Seq:     request.Seq,
		IsShow:  request.IsShow,
	}
	if err := model.SongDB.Model(&song.AccompanyLanguage{}).Where("id = ?", language.ID).Update(&requestPatch).Error; nil != err {
		logger.Entry().WithError(err).Error("编辑伴奏语种失败")
		api.ServerError(c, "编辑伴奏语种失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyLanguage, meta.LogActionUpdate, "修改歌曲语种", request, language.ID); nil != err {
		logger.Entry().WithError(err).Error("添加歌曲语种操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}

// DeleteAccompanyLanguage 删除伴奏语种
func DeleteAccompanyLanguage(c *gin.Context) {
	var language song.AccompanyLanguage
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&language).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	if err := model.SongDB.Where("id = ?", language.ID).Delete(song.AccompanyLanguage{}).Error; nil != err {
		logger.Entry().WithError(err).Error("删除伴奏语种失败")
		api.ServerError(c, "删除伴奏语种失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyLanguage, meta.LogActionDelete, "删除歌曲语种", language, language.ID); nil != err {
		logger.Entry().WithError(err).Error("添加歌曲语种操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}
