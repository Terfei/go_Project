package tag

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
)

// PostAccompanyTag 添加伴奏标签质量
func PostAccompanyTag(c *gin.Context) {
	var request struct {
		Name   string `json:"name"`
		Seq    int8   `json:"seq"`
		IsShow int8   `json:"is_show"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	tag := song.AccompanyTag{
		Name:   request.Name,
		Seq:    request.Seq,
		IsShow: request.IsShow,
	}
	if err := model.SongDB.Create(&tag).Error; nil != err {
		logger.Entry().WithError(err).Error("添加伴奏标签失败")
		api.ServerError(c, "添加伴奏标签失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyTag, meta.LogActionInsert, "新增歌曲标签", request, tag.ID); nil != err {
		logger.Entry().WithError(err).Error("添加歌曲标签操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.Created(c)
}

// GetAccompanyTag 伴奏伴奏标签列表
func GetAccompanyTag(c *gin.Context) {
	var accompanyTags []song.AccompanyTag
	if err := model.SongDB.Order(`seq`).Find(&accompanyTags).Error; nil != err {
		logger.Entry().WithError(err).Error("获取伴奏标签列表失败")
		api.ServerError(c, "获取伴奏标签列表失败")
		return
	}

	api.Make(c, accompanyTags)
}

// PatchAccompanyTag 编辑伴奏标签
func PatchAccompanyTag(c *gin.Context) {
	var tag song.AccompanyTag
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&tag).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	var request struct {
		Name   string `json:"name"`
		Seq    int8   `json:"seq"`
		IsShow int8   `json:"is_show"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	requestPatch := song.AccompanyTag{
		Name:   request.Name,
		Seq:    request.Seq,
		IsShow: request.IsShow,
	}
	if err := model.SongDB.Model(&song.AccompanyTag{}).Where("id = ?", tag.ID).Update(&requestPatch).Error; nil != err {
		logger.Entry().WithError(err).Error("编辑伴奏标签失败")
		api.ServerError(c, "编辑伴奏标签失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyTag, meta.LogActionUpdate, "修改歌曲标签", request, tag.ID); nil != err {
		logger.Entry().WithError(err).Error("添加歌曲标签操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}

// DeleteAccompanyTag 删除伴奏标签
func DeleteAccompanyTag(c *gin.Context) {
	var tag song.AccompanyTag
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&tag).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	if err := model.SongDB.Where("id = ?", tag.ID).Delete(song.AccompanyTag{}).Error; nil != err {
		logger.Entry().WithError(err).Error("删除伴奏标签失败")
		api.ServerError(c, "删除伴奏标签失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyTag, meta.LogActionDelete, "删除歌曲标签", tag, tag.ID); nil != err {
		logger.Entry().WithError(err).Error("添加歌曲标签操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}
