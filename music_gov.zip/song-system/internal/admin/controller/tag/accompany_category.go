package tag

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
)

// PostAccompanyCategory 添加伴奏分类
func PostAccompanyCategory(c *gin.Context) {
	var request struct {
		Name    string `json:"name"`
		NameKey string `json:"name_key"`
		Image   string `json:"image"`
		Seq     int8   `json:"seq"`
		IsShow  int8   `json:"is_show"`
		Type    int8   `json:"type"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	requestPost := song.AccompanyCategory{
		Name:    request.Name,
		NameKey: request.NameKey,
		Image:   request.Image,
		Seq:     request.Seq,
		IsShow:  request.IsShow,
		Type:    request.Type,
	}
	if err := model.SongDB.Create(&requestPost).Error; nil != err {
		logger.Entry().WithError(err).Error("添加伴奏分类失败")
		api.ServerError(c, "添加伴奏分类失败")
		return
	}

	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyCategory, meta.LogActionInsert, "新增歌曲分类", request, requestPost.ID); nil != err {
		logger.Entry().WithError(err).Error("添加伴奏分类操作历史失败")
		api.ServerError(c, "伴奏操作历史添加失败")
		return
	}

	api.Created(c)
}

// GetAccompanyCategory 伴奏分类列表
func GetAccompanyCategory(c *gin.Context) {
	var AccompanyCategories []song.AccompanyCategory
	if err := model.SongDB.Order(`seq`).Find(&AccompanyCategories).Error; nil != err {
		logger.Entry().WithError(err).Error("获取伴奏分类列表失败")
		api.ServerError(c, "获取伴奏分类列表失败")
		return
	}

	api.Make(c, AccompanyCategories)
}

// PatchAccompanyCategory 编辑伴奏分类
func PatchAccompanyCategory(c *gin.Context) {
	var category song.AccompanyCategory
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&category).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	var request struct {
		Name    string `json:"name"`
		NameKey string `json:"name_key"`
		Image   string `json:"image"`
		Seq     int8   `json:"seq"`
		IsShow  int8   `json:"is_show"`
		Type    int8   `json:"type"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	requestPatch := song.AccompanyCategory{
		Name:    request.Name,
		NameKey: request.NameKey,
		Image:   request.Image,
		Seq:     request.Seq,
		IsShow:  request.IsShow,
		Type:    request.Type,
	}
	if err := model.SongDB.Model(&song.AccompanyCategory{}).Where("id = ?", category.ID).Update(&requestPatch).Error; nil != err {
		logger.Entry().WithError(err).Error("编辑伴奏分类失败")
		api.ServerError(c, "编辑伴奏分类失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyCategory, meta.LogActionUpdate, "修改歌曲分类", request, category.ID); nil != err {
		logger.Entry().WithError(err).Error("添加伴奏分类操作历史失败")
		api.ServerError(c, "伴奏操作历史添加失败")
		return
	}

	api.NoContent(c)
}

// DeleteAccompanyCategory 删除伴奏分类
func DeleteAccompanyCategory(c *gin.Context) {
	var category song.AccompanyCategory
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&category).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	if err := model.SongDB.Where("id = ?", category.ID).Delete(song.AccompanyCategory{}).Error; nil != err {
		logger.Entry().WithError(err).Error("删除伴奏分类失败")
		api.ServerError(c, "删除伴奏分类失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyCategory, meta.LogActionDelete, "删除歌曲分类", category, category.ID); nil != err {
		logger.Entry().WithError(err).Error("添加伴奏分类操作历史失败")
		api.ServerError(c, "伴奏操作历史添加失败")
		return
	}

	api.NoContent(c)
}
