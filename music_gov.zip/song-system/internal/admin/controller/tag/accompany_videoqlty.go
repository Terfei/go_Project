package tag

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
)

// PostAccompanyVideoqlty 添加视频质量
func PostAccompanyVideoqlty(c *gin.Context) {
	var request struct {
		Code   string `json:"code" binding:"required"`
		Image  string `json:"image"`
		Seq    int8   `json:"seq"`
		IsShow int8   `json:"is_show"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	video := song.AccompanyVideoqlty{
		Code:   request.Code,
		Image:  request.Image,
		Seq:    request.Seq,
		IsShow: request.IsShow,
	}
	if err := model.SongDB.Create(&video).Error; nil != err {
		logger.Entry().WithError(err).Error("添加伴奏视频质量失败")
		api.ServerError(c, "添加伴奏视频质量失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyVideoqlty, meta.LogActionInsert, "新增视频质量", request, video.ID); nil != err {
		logger.Entry().WithError(err).Error("添加视频操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.Created(c)
}

// GetAccompanyVideoqlty 伴奏视频质量列表
func GetAccompanyVideoqlty(c *gin.Context) {
	var AccompantAudioqlties []song.AccompanyVideoqlty
	if err := model.SongDB.Order(`seq`).Find(&AccompantAudioqlties).Error; nil != err {
		logger.Entry().WithError(err).Error("获取伴奏视频质量列表失败")
		api.ServerError(c, "获取伴奏视频质量列表失败")
		return
	}

	api.Make(c, AccompantAudioqlties)
}

// PatchAccompanyVideoqlty 编辑伴奏视频质量
func PatchAccompanyVideoqlty(c *gin.Context) {
	var video song.AccompanyVideoqlty
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&video).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	var request struct {
		Code   string `json:"code" binding:"required"`
		Image  string `json:"image"`
		Seq    int8   `json:"seq"`
		IsShow int8   `json:"is_show"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	requestPatch := song.AccompanyAudioqlty{
		Code:   request.Code,
		Image:  request.Image,
		Seq:    request.Seq,
		IsShow: request.IsShow,
	}
	if err := model.SongDB.Model(&song.AccompanyVideoqlty{}).Where("id = ?", video.ID).Update(&requestPatch).Error; nil != err {
		logger.Entry().WithError(err).Error("编辑伴奏视频质量失败")
		api.ServerError(c, "编辑伴奏视频质量失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyVideoqlty, meta.LogActionUpdate, "修改视频质量", request, video.ID); nil != err {
		logger.Entry().WithError(err).Error("添加视频操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}

// DeleteAccompanyVideoqlty 删除伴奏视频质量
func DeleteAccompanyVideoqlty(c *gin.Context) {
	var video song.AccompanyVideoqlty
	if err := model.SongDB.Where("id = ?", c.Param("id")).First(&video).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}
	if err := model.SongDB.Where("id = ?", video.ID).Delete(song.AccompanyVideoqlty{}).Error; nil != err {
		logger.Entry().WithError(err).Error("删除伴奏视频质量失败")
		api.ServerError(c, "删除伴奏视频质量失败")
		return
	}
	if err := meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleAccompanyVideoqlty, meta.LogActionDelete, "删除视频质量", video, video.ID); nil != err {
		logger.Entry().WithError(err).Error("添加视频操作历史失败")
		api.ServerError(c, "添加操作历史失败")
		return
	}

	api.NoContent(c)
}
