package controller

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
)

// GetSetting 设置信息
func GetSetting(c *gin.Context) {
	api.Make(c, map[string]interface{}{
		"oss_domain": config.Setting.Aliyun.Oss.Domain,
		"oss_path":   config.Setting.Aliyun.Oss.Image,
		"oss_ad":     config.Setting.Aliyun.Oss.Ad,
	})

}
