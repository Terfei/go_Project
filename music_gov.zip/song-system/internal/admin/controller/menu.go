package controller

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/sirupsen/logrus"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/user"
)

type (
	// Menu 菜单
	Menu struct {
		Link       string         `json:"link"`
		Title      string         `json:"title"`
		Icon       string         `json:"icon"`
		Permission string         `json:"permission"`
		Children   []MenuChildren `json:"children"`
	}

	// MenuChildren 页面
	MenuChildren struct {
		Title      string `json:"title"`
		Link       string `json:"link"`
		Permission string `json:"permission"`
		Group      string `json:"group"`
	}
)

// GetMenu 菜单
func GetMenu(c *gin.Context) {

	file := getMenuFilePath()
	data, err := ioutil.ReadFile(file)
	if nil != err {
		api.ServerError(c, "读取权限配置文件错误："+file)
		return
	}

	var menus []Menu
	if err := json.Unmarshal(data, &menus); nil != err {
		api.ServerError(c, "解析权限配置文件错误："+file)
		return
	}

	staff := middleware.StaffFromContext(c)

	localStaff, err := user.LocalStaffByID(staff.StaffID)
	if nil != err {
		logrus.Error("系统内未找到当前用户，请联系管理员")
		c.AbortWithStatus(http.StatusUnauthorized)
	}

	if staff.IsAdmin() {
		api.Make(c, map[string]interface{}{
			"menus": menus,
		})

		return
	}

	permissions := localStaff.Permissions()

	api.Make(c, map[string]interface{}{
		"menus": filterMenus(menus, permissions),
	})

}

// filterMenus 过滤菜单
func filterMenus(ms []Menu, ps map[string]struct{}) []Menu {
	var menus []Menu
	for _, m := range ms {
		if _, ok := ps[m.Permission]; !ok {
			continue
		}

		var childrens []MenuChildren
		for _, mc := range m.Children {
			if _, ok := ps[mc.Permission]; !ok {
				continue
			}
			childrens = append(childrens, mc)
		}

		menus = append(menus, Menu{
			Link:       m.Link,
			Icon:       m.Icon,
			Title:      m.Title,
			Permission: m.Permission,
			Children:   childrens,
		})
	}

	return menus
}

//getMenuFilePath 获取菜单json绝对路径
func getMenuFilePath() string {
	return fmt.Sprintf("%s/configs/admin/menus.json", config.Setting.App.Root)
}
