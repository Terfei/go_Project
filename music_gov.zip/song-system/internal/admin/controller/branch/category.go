package branch

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	branchBridge "gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
)

// GetVersionStat 门店批次下载统计
func GetVersionStat(c *gin.Context) {
	var request struct {
		api.PageRequest
		VersionCode string `json:"version_code" form:"version_code"`
		BranchID    string `json:"branch_id" form:"branch_id"`
		Type        string `json:"type" form:"type"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("门店批次下载记录参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	staff := middleware.StaffFromContext(c)
	fmt.Println(staff.BranchIDs)

	var items []branch.VersionCategory
	var count int
	query := model.SongDB.Model(&branch.VersionCategory{}).Scopes(
		songdb.BranchIDScope(request.BranchID),
		branch.CategoryColumnEqualScope("version_code", request.VersionCode),
		branch.CategoryColumnEqualScope("relation_type", request.Type)).Where("file_count > 0").Where("branch_id in (?)", staff.BranchIDs.Slice())
	query.Count(&count)
	query.Offset(request.OffsetLimit().Offset).Limit(request.OffsetLimit().Limit).Find(&items)

	api.MakePage(c, appendVersionStatBranch(items), api.PageResponse{
		Total:    count,
		Page:     request.OffsetLimit().Page,
		PageSize: request.OffsetLimit().Limit,
	})
}

// VersionStatBranch 批次门店
type VersionStatBranch struct {
	Stat   branch.VersionCategory  `json:"stat"`
	Branch branchBridge.MetaBranch `json:"branch"`
}

func appendVersionStatBranch(versions []branch.VersionCategory) []VersionStatBranch {
	branchMap := branchBridge.AllBranchMap()

	var response []VersionStatBranch

	for _, version := range versions {
		item := VersionStatBranch{
			Stat: version,
		}

		if b, ok := branchMap[version.BranchID]; ok {
			item.Branch = b
		}

		response = append(response, item)
	}

	return response
}

// GetVersionFailFile 门店批次下载失败文件
func GetVersionFailFile(c *gin.Context) {
	var request struct {
		api.PageRequest
		CategoryID int `json:"category_id" form:"category_id" binding:"required"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("门店批次未下载参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var items []branch.VersionDetail
	var count int
	query := model.SongDB.Model(&branch.VersionDetail{}).Where("version_category_id = ?", request.CategoryID).Where("is_download = 0")
	query.Count(&count)
	query.Offset(request.OffsetLimit().Offset).Limit(request.OffsetLimit().Limit).Find(&items)

	api.MakePage(c, items, api.PageResponse{
		Total:    count,
		Page:     request.OffsetLimit().Page,
		PageSize: request.OffsetLimit().Limit,
	})
}
