package branch

import (
	"errors"
	"fmt"
	"github.com/sirupsen/logrus"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	bridgeBranch "gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/users"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetAuthorize 门店授权列表
func GetAuthorize(c *gin.Context) {
	var request listRequest
	if err := c.ShouldBindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("门店授权列表")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	res, page, count, err := authorizes(c, request, 0)
	if nil != err {
		api.Unprocessable(c, err.Error())
		return
	}

	api.MakePage(c, res, api.PageResponse{
		Total:    count,
		Page:     page.Page,
		PageSize: page.Limit,
	})
}

// ExportAuthorize 导出门店授权列表
func ExportAuthorize(c *gin.Context) {
	var request listRequest
	if err := c.ShouldBindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("门店授权列表")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	res, _, _, err := authorizes(c, request, 1)
	if nil != err {
		api.Unprocessable(c, err.Error())
		return
	}

	year := year(c, request)
	minusSet := util.NewSet([]int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12}...)

	xlsx, sheet := util.InitializeXlsx()
	xlsx.SetSheetRow(sheet, `A1`, &[]string{
		`序号`, `门店编号`, `门店名称`, `类别`,
		fmt.Sprintf(`%d有权限月`, year), fmt.Sprintf(`%d无权限月`, year), `备注`,
	})
	for idx, v := range res {
		lint := strconv.Itoa(idx + 2)
		xlsx.SetSheetRow(sheet, `A`+lint, &[]string{
			strconv.Itoa(idx + 1), v.BranchCode, v.BranchName, branch.AuthorizeCategoryMap[v.Category],
			util.NewSetInt64(v.Months...).Join(`,`), minusSet.Minus(util.NewSetInt64(v.Months...)).Join(`,`),
			v.Remark,
		})
	}
	styleID, err := util.GetHeaderStyle(xlsx)
	if nil != err {
		api.Unprocessable(c, err.Error())
		return
	}
	xlsx.SetCellStyle(sheet, `A1`, `G1`, styleID)

	util.ExportXlsx(xlsx, fmt.Sprintf(`%d年门店授权列表导出.xlsx`, year), c)
}

type postRequest struct {
	BranchID    string                   `json:"branch_id" binding:"required"`
	Category    branch.AuthorizeCategory `json:"category"`
	BeginMonth  util.Month               `json:"begin_month"`
	EndMonth    util.Month               `json:"end_month"`
	CanDownload int                      `json:"can_download"`
	Remark      string                   `json:"remark"`
}

// PostAuthorize 添加门店授权
func PostAuthorize(c *gin.Context) {
	var request postRequest
	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}

	var b bridgeBranch.MetaBranch
	if err := model.BridgeDB.Table(bridgeBranch.TableMetaBranch).Where("branch_id = ?", request.BranchID).First(&b).Error; nil != err {
		api.ServerError(c, fmt.Sprintf("查询门店信息错误:%s", err.Error()))
		return
	}

	yearMonths := yearMonthsFromRange(request.BeginMonth, request.EndMonth)
	err := model.SongDB.DB.Transaction(func(tx *gorm.DB) (err error) {
		for year, months := range yearMonths {
			query := tx.Model(branch.Authorize{}).
				Where("branch_id = ?", request.BranchID).
				Where("category = ?", request.Category).
				Where("year = ?", year)

			var count int
			if err = query.Count(&count).Error; nil != err {
				err = fmt.Errorf("查询已存在授权信息错误:%s", err.Error())
				return
			}

			var authorize branch.Authorize
			authorize = branch.Authorize{
				BranchID:   b.BranchID,
				BranchCode: b.Code,
				Year:       year,
				Category:   request.Category,
				Remark:     request.Remark,
			}
			if count > 0 {
				query.First(&authorize)
			}

			normMonths := mergeMonths(authorize, months, request.CanDownload)
			newAuth, err := saveAuthorize(authorize, normMonths, request.CanDownload, request.Remark, tx)
			if nil != err {
				return err
			}

			staff := middleware.StaffFromContext(c)
			enable, _ := fetchMonths(make([]int64, 0), normMonths)
			for _, r := range enable {
				begin := util.FromStringWithNil(fmt.Sprintf(`%d-%02d`, year, r.Begin))
				end := util.FromStringWithNil(fmt.Sprintf(`%d-%02d`, year, r.End))
				saveAuthorizeLog(begin, end, request.Category, request.CanDownload, request.Remark, b, *staff, newAuth.ID, tx)
			}

			saveAuthorizeSystemLog(c, meta.LogActionInsert, newAuth.ID, "新增门店授权", newAuth)

			dealAuthorizeVersion(c, newAuth)
		}

		return
	})

	if nil != err {
		api.ServerError(c, err.Error())
		return
	}

	api.Created(c)
}

// PatchAuthorize 编辑门店授权
func PatchAuthorize(c *gin.Context) {
	var request struct {
		Months []int64 `json:"months"`
		Remark string  `json:"remark"`
	}

	id, _ := strconv.Atoi(c.Param("id"))
	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}
	var authorize branch.Authorize
	if err := model.SongDB.First(&authorize, id).Error; nil != err {
		logger.Entry().WithError(err).Error("无此记录")
		api.NotFound(c)
		return
	}

	var b bridgeBranch.MetaBranch
	if err := model.BridgeDB.Table(bridgeBranch.TableMetaBranch).Where("branch_id = ?", authorize.BranchID).First(&b).Error; nil != err {
		api.ServerError(c, fmt.Sprintf("查询门店信息错误:%s", err.Error()))
		return
	}

	params := map[string]interface{}{
		"months": request.Months,
		"remark": request.Remark,
	}
	logger.Entry().Info(params)

	if err := model.SongDB.Model(&branch.Authorize{}).Where("id = ?", id).Update(params).Error; nil != err {
		logger.Entry().WithError(err).Error("编辑门店授权失败")
		api.ServerError(c, "编辑门店授权失败")
		return
	}

	staff := middleware.StaffFromContext(c)
	enable, disable := fetchMonths(authorize.Months, request.Months)
	if len(enable) != 0 {
		for _, r := range enable {
			begin := util.FromStringWithNil(fmt.Sprintf(`%d-%02d`, authorize.Year, r.Begin))
			end := util.FromStringWithNil(fmt.Sprintf(`%d-%02d`, authorize.Year, r.End))
			saveAuthorizeLog(begin, end, authorize.Category, 1, request.Remark, b, *staff, id, model.SongDB.DB)
		}
	}
	if len(disable) != 0 {
		for _, r := range disable {
			begin := util.FromStringWithNil(fmt.Sprintf(`%d-%02d`, authorize.Year, r.Begin))
			end := util.FromStringWithNil(fmt.Sprintf(`%d-%02d`, authorize.Year, r.End))
			saveAuthorizeLog(begin, end, authorize.Category, 0, request.Remark, b, *staff, id, model.SongDB.DB)
		}
	}

	// 修改日志
	authorize.Remark = request.Remark
	authorize.Months = request.Months
	saveAuthorizeSystemLog(c, meta.LogActionUpdate, id, request.Remark, authorize)

	dealAuthorizeVersion(c, authorize)

	api.NoContent(c)
}

// CopyBranchAuthorize 复制门店权限
func CopyBranchAuthorize(c *gin.Context) {
	var request struct {
		FormBranch string `json:"form_branch" form:"form_branch" binding:"required"`
		ToBranch   string `json:"to_branch" form:"to_branch" binding:"required"`
		Remark     string `json:"remark" form:"remark"`
	}

	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithError(err).Error("复制门店权限，参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var count int
	model.SongDB.Model(&branch.Authorize{}).Where("branch_id = ?", request.ToBranch).Count(&count)
	if count > 0 {
		api.ServerError(c, "存在目标门店授权信息")
		return
	}

	var toBranch bridgeBranch.MetaBranch
	if err := model.BridgeDB.Where("branch_id = ?", request.ToBranch).First(&toBranch).Error; nil != err {
		logger.Entry().WithError(err).WithField("request", request).Error("复制门店授权，门店信息错误")
		api.ServerError(c, "门店信息错误")
		return
	}

	staff := middleware.StaffFromContext(c)

	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		var authorizes []branch.Authorize
		tx.Where("branch_id = ?", request.FormBranch).Find(&authorizes)
		//需要记录日志 不使用insert xx select xx
		for _, authorize := range authorizes {
			data := branch.Authorize{
				BranchID:   toBranch.BranchID,
				BranchCode: toBranch.Code,
				Category:   authorize.Category,
				Year:       authorize.Year,
				Months:     authorize.Months,
				Remark:     request.Remark,
			}

			if err := tx.Create(&data).Error; nil != err {
				logger.Entry().WithError(err).WithField("request", request).Error("复制门店授权，保存信息错误")
				return err
			}

			enable, _ := fetchMonths(make([]int64, 0), data.Months)
			for _, r := range enable {
				begin := util.FromStringWithNil(fmt.Sprintf(`%d-%02d`, data.Year, r.Begin))
				end := util.FromStringWithNil(fmt.Sprintf(`%d-%02d`, data.Year, r.End))
				fmt.Println(begin, end)
				if err := saveAuthorizeLog(begin, end, authorize.Category, 1, request.Remark, toBranch, *staff, data.ID, tx); nil != err {
					logger.Entry().WithError(err).WithFields(logrus.Fields{
						"request": request,
						"enable":  enable,
					}).Error("复制门店授权，保存操作历史错误")
					return err
				}
			}
		}

		var versions []branch.Version
		tx.Where("branch_id = ?", request.FormBranch).Find(&versions)
		sql := `insert into branch.versions(branch_id, version_id, version_code, remarks, can_download,created_at,updated_at) select '%s', version_id ,version_code, '%s',can_download,now(),now() from branch.versions where branch_id ='%s'`

		tx.Exec(fmt.Sprintf(sql, request.ToBranch, request.Remark, request.FormBranch))

		if err := meta.SaveSystemLog(staff, meta.LogModuleBranchAuthorize, meta.LogActionInsert, request.Remark, request, 0); nil != err {
			logger.Entry().WithError(err).WithField("request", request).Error("保存操作历史失败")
			return err
		}

		return nil
	})

	if err != nil {
		logger.Entry().WithField("request", request).WithError(err).Error("复制门店授权")
		api.ServerError(c, err.Error())
		return
	}

	api.NoContent(c)
}

// GetAuthorizeHistory 门店授权历史
func GetAuthorizeHistory(c *gin.Context) {
	var request struct {
		api.PageRequest
		BranchBizType int                      `json:"branch_biz_type" form:"branch_biz_type"`
		BranchID      string                   `json:"branch_id" form:"branch_id"`
		Category      branch.AuthorizeCategory `json:"category" form:"category"`
		StaffName     string                   `json:"staff_name" form:"staff_name"`
		Begin         time.Time                `json:"begin" form:"begin" time_format:"2006-01-02"`
		End           time.Time                `json:"end" form:"end" time_format:"2006-01-02"`
		AuthorizeID   int                      `json:"authorize_id" form:"authorize_id"`
	}
	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("门店授权历史列表")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	staff := middleware.StaffFromContext(c)
	query := model.SongDB.Model(branch.AuthorizeLog{}).Where("branch_id in (?)", staff.BranchIDs.Slice())
	if request.StaffName != "" {
		query = query.Where("staff_name like ?", fmt.Sprintf("%%%s%%", request.StaffName))
	}

	branchIDs, err := historyBranchIDs(c, request.BranchBizType, request.BranchID)
	if nil == err {
		if len(branchIDs) > 0 {
			query = query.Where(`branch_id in (?)`, branchIDs)
		} else {
			query = query.Where(`branch_id is null`)
		}
	}

	if _, ok := c.GetQuery("category"); ok {
		query = query.Scopes(songdb.ColumnEqualScope(`category`, request.Category))
	}

	if !request.Begin.IsZero() {
		query = query.Where("updated_at > ?", request.Begin.Format("2006-01-02")+` 00:00:00`)
	}
	if !request.End.IsZero() {
		query = query.Where("updated_at <= ?", request.End.Format("2006-01-02")+` 23:59:59`)
	}

	if request.AuthorizeID > 0 {
		query = query.Where("authorize_id = ?", request.AuthorizeID)
	}

	var count int
	var items []branch.AuthorizeLog
	query.Count(&count)
	query.Order("created_at desc").Offset(request.OffsetLimit().Offset).Limit(request.OffsetLimit().Limit).Find(&items)

	api.MakePage(c, items, api.PageResponse{
		Total:    count,
		Page:     request.OffsetLimit().Page,
		PageSize: request.OffsetLimit().Limit,
	})
}

func listBranches(c *gin.Context, branchBizType int, branchID uuid.UUID) (map[uuid.UUID]bridgeBranch.MetaBranch, []uuid.UUID, error) {
	IDs := make([]uuid.UUID, 0)
	result := make(map[uuid.UUID]bridgeBranch.MetaBranch, 0)

	q := model.BridgeDB.Model(bridgeBranch.MetaBranch{})
	if _, ok := c.GetQuery("branch_biz_type"); ok {
		q = q.Where("biz_type = ?", branchBizType)
	}
	if !uuid.Equal(branchID, uuid.Nil) {
		q = q.Scopes(songdb.ColumnEqualScope(`branch_id`, branchID))
	}

	var branches []bridgeBranch.MetaBranch
	if err := q.Find(&branches).Error; nil != err {
		return result, IDs, err
	}

	for _, b := range branches {
		result[b.BranchID] = b
		IDs = append(IDs, b.BranchID)
	}

	return result, IDs, nil
}

func historyBranchIDs(c *gin.Context, branchBizType int, branchID string) (IDs []uuid.UUID, err error) {
	err = errors.New(`没有门店相关查询条件`)
	bQuery := model.BridgeDB.Model(&bridgeBranch.MetaBranch{})
	if _, ok := c.GetQuery("branch_biz_type"); ok {
		err = nil
		bQuery = bQuery.Where("biz_type = ?", branchBizType)
	}
	if branchID != "" {
		err = nil
		bQuery = bQuery.Scopes(songdb.ColumnEqualScope(`branch_id`, branchID))
	}

	if nil == err {
		bQuery.Pluck("branch_id", &IDs)
	}

	return
}

func saveAuthorizeLog(beginMonth, endMonth util.Month, category branch.AuthorizeCategory, canDownload int, remark string, b bridgeBranch.MetaBranch, staff users.Staff, authorizeID int, db *gorm.DB) (err error) {
	logger.Entry().Info(staff)
	log := branch.AuthorizeLog{
		StaffID:     staff.StaffID,
		StaffName:   staff.StaffName,
		BranchID:    b.BranchID,
		BranchCode:  b.Code,
		BranchName:  b.BranchName,
		Category:    category,
		BeginMonth:  beginMonth,
		EndMonth:    endMonth,
		CanDownload: canDownload,
		Remark:      remark,
		AuthorizeID: authorizeID,
	}

	if err := db.Create(&log).Error; nil != err {
		logger.Entry().WithError(err).Error("保存操作历史报错")
	}

	return
}

func saveAuthorizeSystemLog(c *gin.Context, action meta.SystemLogAction, relationID int, remark string, data interface{}) {
	staff := middleware.StaffFromContext(c)

	log := meta.SystemLog{
		Module:     meta.LogModuleBranchAuthorize,
		Action:     action,
		Remark:     remark,
		Extra:      nil,
		RelationID: relationID,
	}
	log.SetData(data).SetStaff(staff)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error("门店授权操作历史")
	}
}

func year(c *gin.Context, req listRequest) int {
	if _, ok := c.GetQuery("year"); !ok {
		return time.Now().Year()
	}

	return req.Year
}

func normalizeGetBranchID(c *gin.Context, req listRequest) (ID uuid.UUID, err error) {
	ID = uuid.Nil
	if _, ok := c.GetQuery(`branch_id`); ok {
		ID, err = uuid.FromString(req.BranchID)

		return
	}

	return
}

func mergeMonths(authorize branch.Authorize, months []int, canDownload int) (result []int64) {
	if canDownload == 1 {
		result = util.NewSet(authorize.IntMonths()...).Union(util.NewSet(months...)).Int64SortList()
		return
	}

	intersect := util.NewSet(authorize.IntMonths()...).Intersect(util.NewSet(months...))
	result = util.NewSet(authorize.IntMonths()...).Minus(intersect).Int64SortList()

	return
}

func saveAuthorize(authorize branch.Authorize, months []int64, canDownload int, remark string, db *gorm.DB) (newAuth branch.Authorize, returnErr error) {
	if authorize.ID != 0 {
		newAuth = authorize
		params := map[string]interface{}{
			"months": months,
			"remark": remark,
		}
		if err := db.Model(&authorize).Where("id = ?", authorize.ID).Update(params).Error; nil != err {
			logger.Entry().WithError(err).Error("编辑门店授权失败")
			returnErr = errors.New(`编辑门店授权失败`)
			return
		}
		return
	}

	if canDownload == 1 {
		authorize.Months = months
	}
	if err := db.Create(&authorize).Error; nil != err {
		returnErr = fmt.Errorf("保存信息错误:%s", err.Error())
		return
	}
	return
}

type listRequest struct {
	api.PageRequest
	BranchBizType int                      `json:"branch_biz_type" form:"branch_biz_type"`
	BranchID      string                   `json:"branch_id" form:"branch_id"`
	Category      branch.AuthorizeCategory `json:"category" form:"category"`
	Year          int                      `json:"year" form:"year"`
}

type responseListItem struct {
	BranchName string `json:"branch_name"`
	branch.Authorize
}

func authorizes(c *gin.Context, request listRequest, isExport int) (res []responseListItem, page api.PageOffsetLimit, count int, runtimeErr error) {
	year := year(c, request)
	branchID, err := normalizeGetBranchID(c, request)
	if nil != err {
		runtimeErr = errors.New(`参数门店id错误`)
		return
	}

	branches, branchIDs, err := listBranches(c, request.BranchBizType, branchID)
	if nil != err {
		runtimeErr = err
		return
	}

	staff := middleware.StaffFromContext(c)
	query := model.SongDB.Table(branch.TableAuthorize).Where("year = ?", year).Where("branch_id in (?)", staff.BranchIDs.Slice())
	if len(branchIDs) > 0 {
		query = query.Where("branch_id in (?)", branchIDs)
	} else {
		query = query.Where(`branch_id is null`)
	}

	page = request.PageRequest.OffsetLimit()

	var authorizes []branch.Authorize
	query.Count(&count)
	if isExport != 0 {
		query.Order("branch_code").Find(&authorizes)
	} else {
		query.Order("branch_code").Offset(page.Offset).Limit(page.Limit).Find(&authorizes)
	}

	for _, item := range authorizes {
		branch := branches[item.BranchID]
		res = append(res, responseListItem{
			branch.BranchName,
			item,
		})
	}

	return
}

// ms := []int{1, 2, 3, 4, 5, 8, 9, 10, 12}
// newMs := []int{3, 11}
// // 后者没有的
// s := util.NewSet(ms...).Minus(util.NewSet(newMs...)).Ranges()
// logger.Entry().Info(`-------------`, s)
// // 前者没有的
// ss := util.NewSet(ms...).Complement(util.NewSet(newMs...)).Ranges()
// logger.Entry().Info(`==============`, ss)
func fetchMonths(orig, new []int64) (enable, disable []util.SetRange) {
	if len(orig) == 0 {
		enable = util.NewSetInt64(new...).Ranges()
		return
	}

	s1 := util.NewSetInt64(orig...)
	s2 := util.NewSetInt64(new...)

	enable = s1.Complement(s2).Ranges()
	disable = s1.Minus(s2).Ranges()

	return
}

func yearMonthsFromRange(bm, em util.Month) map[int][]int {
	result := make(map[int][]int, 0)

	begin := bm.FirstDayOfMonth().AddDate(0, -1, 0)
	end := em.FirstDayOfMonth()
	for {
		begin = begin.AddDate(0, 1, 0)

		year := begin.Year()
		if _, ok := result[year]; !ok {
			result[year] = []int{}
		}
		result[year] = append(result[year], int(begin.Month()))

		if begin.Equal(end) {
			break
		}
	}
	return result
}

func dealAuthorizeVersion(c *gin.Context, authorize branch.Authorize) error {
	var versions []meta.VersionOverview
	model.SongDB.Unscoped().Where("to_char(created_at, 'YYYY') = ?", authorize.Year).Find(&versions)

	versionMap := make(map[string][]int)

	for _, version := range versions {
		key := version.VersionCode.String()[:6]
		monthVersion, ok := versionMap[key]
		if !ok {
			monthVersion = []int{}
		}

		monthVersion = append(monthVersion, version.ID)

		versionMap[key] = monthVersion
	}

	yearMonth := authorize.YearMonthMap()
	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		for month, versions := range versionMap {
			if _, ok := yearMonth[month]; ok {
				err := tx.Model(&branch.Version{}).Where("version_id in (?)", versions).
					Where("branch_id = ?", authorize.BranchID).Update(map[string]interface{}{
					"can_download": 1,
				}).Error

				if err != nil {
					return err
				}
			} else {
				err := tx.Model(&branch.Version{}).Where("version_id in (?)", versions).
					Where("branch_id = ?", authorize.BranchID).Update(map[string]interface{}{
					"can_download": 0,
				}).Error

				if err != nil {
					return err
				}
			}
		}

		return nil
	})

	if err != nil {
		logger.Entry().WithError(err).WithField("authorize", authorize).Error("门店授权，批量修改门店批次下载信息错误")

		return err
	}

	meta.SaveSystemLog(middleware.StaffFromContext(c), meta.LogModuleBranchVersion, meta.LogActionUpdate, "修改门店授权，批量修改门店批次", authorize, 0)

	return nil
}
