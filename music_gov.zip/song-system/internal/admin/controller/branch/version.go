package branch

import (
	"fmt"
	"github.com/gin-gonic/gin"
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	branchBridge "gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
)

// GetBranchVersion 门店批次列表
func GetBranchVersion(c *gin.Context) {
	var request struct {
		api.PageRequest
		VersionCode int    `json:"version_code" form:"version_code" binding:"required"`
		BranchID    string `json:"branch_id" form:"branch_id"`
	}

	if err := c.BindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("门店批次详情参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	staff := middleware.StaffFromContext(c)
	var versions []branch.Version
	var count int
	query := model.SongDB.Model(&branch.Version{}).
		Scopes(songdb.ColumnEqualScope("version_code", request.VersionCode), songdb.BranchIDScope(request.BranchID)).
		Where("branch_id in (?)", staff.BranchIDs.Slice())
	query.Count(&count)
	query.Offset(request.OffsetLimit().Offset).Limit(request.OffsetLimit().Limit).Find(&versions)

	api.MakePage(c, appendVersionBranch(versions), api.PageResponse{
		Total:    count,
		Page:     request.OffsetLimit().Page,
		PageSize: request.OffsetLimit().Limit,
	})

}

// VersionBranch 批次门店
type VersionBranch struct {
	Version branch.Version          `json:"version"`
	Branch  branchBridge.MetaBranch `json:"branch"`
}

func appendVersionBranch(versions []branch.Version) []VersionBranch {
	branchMap := branchBridge.AllBranchMap()

	var response []VersionBranch

	for _, version := range versions {
		item := VersionBranch{
			Version: version,
		}

		if b, ok := branchMap[version.BranchID]; ok {
			item.Branch = b
		}

		response = append(response, item)
	}

	return response
}

// CreateBranchVersion 新增门店下载批次
func CreateBranchVersion(c *gin.Context) {
	var request struct {
		VersionCode string `json:"version_code" binding:"required"`
		BranchID    string `json:"branch_id" binding:"required"`
		CanDownload int8   `json:"can_download" binding:"required"`
		Remarks     string `json:"remarks"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}

	var version meta.VersionOverview
	if err := model.SongDB.Model(&meta.VersionOverview{}).Where("version_code = ?", request.VersionCode).First(&version).Error; nil != err {
		logger.Entry().WithField("request", request).WithError(err).Error("批次信息查询错误")
		api.ServerError(c, "批次信息不存在")
		return
	}

	var count int
	model.SongDB.Model(&branch.Version{}).Where("branch_id = ?", request.BranchID).Where("version_id = ?", version.ID).Count(&count)
	if count > 0 {
		logger.Entry().WithField("request", request).Error("存在对应门店批次信息")
		api.ServerError(c, "存在对应门店信息")
		return
	}

	branchID, err := uuid.FromString(request.BranchID)
	if err != nil {
		logger.Entry().WithField("request", request).WithError(err).Error("门店UUID错误")
		api.ServerError(c, "门店UUID错误")
		return
	}

	item := branch.Version{
		VersionBase: branch.VersionBase{
			BranchID:    branchID,
			VersionID:   version.ID,
			VersionCode: version.VersionCode,
		},
		Remarks:     request.Remarks,
		CanDownload: request.CanDownload,
	}

	if err := model.SongDB.Create(&item).Error; nil != err {
		logger.Entry().WithField("request", request).WithError(err).Error("保存信息错误")
		api.ServerError(c, "保存信息错误")
		return
	}

	saveBranchVersionHistory(c, meta.LogActionInsert, item)

	api.Created(c)
}

// UpdateBranchVersion 修改门店批次
func UpdateBranchVersion(c *gin.Context) {
	var request struct {
		CanDownload int8   `json:"can_download"`
		Remarks     string `json:"remarks"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}

	id := c.Param("id")
	var version branch.Version
	if err := model.SongDB.Where("id = ?", id).First(&version).Error; nil != err {
		logger.Entry().WithError(err).WithField("id", id).Error("查询门店版本信息错误")
		api.NotFound(c)
		return
	}

	attr := map[string]interface{}{
		"can_download": request.CanDownload,
		"remarks":      request.Remarks,
	}

	if err := model.SongDB.Model(&branch.Version{}).Where("id = ?", id).Update(attr).Error; nil != err {
		logger.Entry().WithField("attr", attr).WithField("id", id).WithError(err).Error("修改门店版本错误")
		api.ServerError(c, "修改错误")
		return
	}

	version.CanDownload = request.CanDownload
	version.Remarks = request.Remarks

	saveBranchVersionHistory(c, meta.LogActionUpdate, version)

	api.NoContent(c)
}

func saveBranchVersionHistory(c *gin.Context, action meta.SystemLogAction, version branch.Version) {
	staff := middleware.StaffFromContext(c)

	log := meta.SystemLog{}
	log.SetModule(meta.LogModuleBranchVersion).SetStaff(staff).SetAction(action).SetRemark(version.Remarks).SetRelationID(version.ID).SetData(version)

	if err := log.Save(); nil != err {
		logger.Entry().WithError(err).Error("伴奏操作历史")
	}
}
