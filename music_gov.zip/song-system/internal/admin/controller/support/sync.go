package support

import (
	"github.com/gin-gonic/gin"
	"github.com/sirupsen/logrus"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/localdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
)

// PostBranchSync 处理门店回调
func PostBranchSync(c *gin.Context) {
	var request struct {
		Items    []localdb.BranchVersionDetail `json:"items" form:"items"`
		BranchID string                        `json:"branch_id" form:"branch_id"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.Unprocessable(c, "参数错误")
		return
	}

	logger.Entry().WithField("request", request).Info("收到门店同步回传数据")

	saveSyncResult(request.Items)

	api.NoContent(c)
}

func saveSyncResult(items []localdb.BranchVersionDetail) {
	categoryMap := make(map[int]branch.VersionCategory)

	for _, item := range items {
		if _, ok := categoryMap[item.VersionCategoryID]; !ok {
			category, err := getBranchCategory(item.VersionCategoryID)
			if err != nil {
				continue
			}

			categoryMap[item.VersionCategoryID] = category
		}

		update := map[string]interface{}{
			"disk_file":   item.DiskFile,
			"is_download": item.IsDownload,
		}

		if err := model.SongDB.Model(&branch.VersionDetail{}).Where("id = ?", item.ID).Update(update).Error; nil != err {
			logger.Entry().WithFields(logrus.Fields{
				"id":     item.ID,
				"update": update,
			}).WithError(err).Error("门店回调修改detail错误")
		}
	}

	for _, category := range categoryMap {
		dealCategory(category)
	}
}

func dealCategory(item branch.VersionCategory) {
	var count int
	var success int
	var fail int
	query := model.SongDB.Table(branch.TableVersionDetail).Where("version_category_id = ?", item.ID)

	query.Count(&count)
	query.Where("is_download = 1").Count(&success)
	query.Where("is_download = 0").Count(&fail)

	update := map[string]interface{}{
		"file_count":   count,
		"done_count":   success,
		"undone_count": fail,
	}

	if count == success {
		update["deal_status"] = branch.VersionCategoryStatusSuccess
	} else {
		update["deal_status"] = branch.VersionCategoryStatusFail
	}

	if err := model.SongDB.Table(branch.TableVersionCategory).Where("id = ?", item.ID).Update(update).Error; nil != err {
		logger.Entry().WithFields(logrus.Fields{
			"id":     item.ID,
			"update": update,
		}).WithError(err).Error("门店回调 修改category失败")
	}
}

func getBranchCategory(id int) (category branch.VersionCategory, err error) {
	if err = model.SongDB.Table(branch.TableVersionCategory).Where("id = ?", id).First(&category).Error; nil != err {
		logger.Entry().WithField("category id", id).Error("查询批次分类错误")
		return
	}

	return
}
