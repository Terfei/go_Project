package support

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/report"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// ImportBranchAccompanyClick 导入门店歌曲点播记录
func ImportBranchAccompanyClick(c *gin.Context) {
	var request struct {
		Stats []struct {
			SongNo string `json:"SongNo"`
			Total  int    `json:"Total"`
			Songer string `json:"Songer"`
		} `json:"stats"`
		BranchID string `json:"branch_id"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("导入门店歌曲点播数据错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	var metaBranch branch.MetaBranch
	if err := model.BridgeDB.Model(&branch.MetaBranch{}).Where("branch_id = ?", request.BranchID).First(&metaBranch).Error; nil != err {
		logger.Entry().WithError(err).WithField("branch_id", request.BranchID).Error("导入门店歌曲点播数据,门店信息错误")
		api.ServerError(c, "门店信息错误")
		return
	}

	logger.Entry().WithField("request", request).Info("导入门店歌曲点播记录")

	songMap := make(util.StringStringMap)
	singerMap := make(util.StringStringMap)
	for _, item := range request.Stats {
		songMap[item.SongNo] = item.SongNo
		singerMap[item.Songer] = item.Songer
	}

	songs := getSongs(songMap)
	singers := getSinger(singerMap)

	for _, item := range request.Stats {
		data := report.AccompanyClick{
			Times:         item.Total,
			BranchID:      metaBranch.BranchID,
			BranchBizType: metaBranch.BizType,
		}

		accompany, ok := songs[item.SongNo]

		if !ok {
			logger.Entry().WithField("stat", item).Error("导入门店点播信息,歌曲信息查询错误")
		}

		data.AccompanyID = accompany.ID
		data.Songno = item.SongNo
		data.AccompanyName = accompany.Name
		data.AccompanyCategoryID = accompany.CategoryID

		if singer, ok := singers[item.Songer]; !ok {
			logger.Entry().WithField("stat", item).Error("导入门店点播信息,歌手信息错误")
		} else {
			data.SingerID = singer.ID
			data.SingerName = item.Songer
		}

		if err := model.SongDB.Create(&data).Error; nil != err {
			logger.Entry().WithError(err).Error("导入门店点播信息,保存数据错误")
			api.ServerError(c, fmt.Sprintf("保存数据:%s", err.Error()))
			return
		}
	}

	api.NoContent(c)
}

func getSongs(songMap util.StringStringMap) map[string]song.Accompany {
	var songs []song.Accompany

	model.SongDB.Unscoped().Where("songno in (?)", songMap.GetKeys()).Find(&songs)

	response := make(map[string]song.Accompany)

	for _, item := range songs {
		response[item.Songno] = item
	}

	return response
}

func getSinger(singerMap util.StringStringMap) map[string]song.Singer {
	var singers []song.Singer

	model.SongDB.Unscoped().Where("name in (?)", singerMap.GetKeys()).Find(&singers)

	response := make(map[string]song.Singer)

	for _, singer := range singers {
		response[singer.Name] = singer
	}

	return response
}

// PostVodAccompanyClick vod点播
func PostVodAccompanyClick(c *gin.Context) {
	var request struct {
		BranchID string `json:"branch_id"`
		SongNo   string `json:"songno"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("vod点播歌曲数据错误")
		api.Unprocessable(c, "参数错误")
	}
	var metaBranch branch.MetaBranch
	if err := model.BridgeDB.Model(&branch.MetaBranch{}).Where("branch_id = ?", request.BranchID).First(&metaBranch).Error; nil != err {
		logger.Entry().WithError(err).WithField("branch_id", request.BranchID).Error("vod点播歌曲,门店信息错误")
		api.ServerError(c, "门店信息错误")
		return
	}

	logger.Entry().WithField("request", request).Info("vod点播歌曲")

	var accompany song.Accompany
	if err := model.SongDB.Where("songno = ?", request.SongNo).First(&accompany).Error; nil != err {
		logger.Entry().WithError(err).Error("vod点播歌曲,信息错误")
		api.NotFound(c)
		return
	}

	data := report.AccompanyClick{
		ID:                  0,
		Songno:              accompany.Songno,
		AccompanyID:         accompany.ID,
		AccompanyName:       accompany.Name,
		AccompanyCategoryID: accompany.CategoryID,
		SingerID:            accompany.Singers.SingerOne.ID,
		SingerName:          accompany.Singers.SingerOne.Name,
		Times:               1,
		BranchID:            metaBranch.BranchID,
		BranchBizType:       metaBranch.BizType,
	}

	if err := model.SongDB.Create(&data).Error; nil != err {
		logger.Entry().WithError(err).Error("vod点播歌曲,保存数据错误")
		api.ServerError(c, fmt.Sprintf("保存数据:%s", err.Error()))
		return
	}

	api.Created(c)
}
