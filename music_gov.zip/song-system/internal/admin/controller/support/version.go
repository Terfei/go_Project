package support

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
)

// GetVersionType 获取批次类型
func GetVersionType(c *gin.Context) {
	api.Make(c, map[branch.VersionCategoryType]string{
		branch.VersionCategoryTypeSong:      "歌曲",
		branch.VersionCategoryTypeSinger:    "歌手",
		branch.VersionCategoryTypeAcc:       "公播",
		branch.VersionCategoryTypeWallpaper: "动态壁纸",
		branch.VersionCategoryTypeDance:     "派对舞曲",
		branch.VersionCategoryTypeVj:        "VJ视频",
		branch.VersionCategoryTypeActVideo:  "跳舞视频",
	})
}
