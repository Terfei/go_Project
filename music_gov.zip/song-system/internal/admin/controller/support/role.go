package support

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/user"
)

// GetRoles 角色列表
func GetRoles(c *gin.Context) {
	var rs []user.Role
	if err := model.SongDB.Find(&rs).Error; nil != err {
		logger.Entry().WithError(err).Error("获取角色列表失败")
		api.ServerError(c, "获取角色列表失败")
		return
	}

	api.Make(c, map[string]interface{}{
		`list`: rs,
	})
}
