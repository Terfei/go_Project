package support

import (
	"fmt"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	bridgeBranch "gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/image"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetBranchImageOverview 获取门店广告图
func GetBranchImageOverview(c *gin.Context) {
	params := util.Params{
		"ip":  c.ClientIP(),
		"url": c.Request.URL.String(),
	}
	logger.Entry().WithField("params", params).Info("门店广告，收到请求")
	var request struct {
		BranchID string `json:"branch_id" form:"branch_id" binding:"required"`
	}
	if err := c.ShouldBindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("获取门店壁纸信息，参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	params.Set("branch_id", request.BranchID)
	var branch bridgeBranch.MetaBranch
	if err := model.BridgeDB.Where("branch_id = ?", request.BranchID).First(&branch).Error; nil != err {
		logger.Entry().WithError(err).WithField("params", params).Error("门店信息错误")
		api.ServerError(c, "门店信息错误")
		return
	}

	categoryPlans := getCategoryPlan(branch)

	response := getOverview(branch, categoryPlans)

	api.Make(c, response)
}

type imagePlan struct {
	Category   image.Category
	CenterPlan image.TemplatePlan
	BranchPlan image.TemplatePlan
}

func getCategoryPlan(branch bridgeBranch.MetaBranch) []imagePlan {
	var categoryItems []image.Category
	model.SongDB.Find(&categoryItems)
	var response []imagePlan
	now := time.Now()
	for _, category := range categoryItems {
		var plan imagePlan
		plan.Category = category
		// todo 状态移除
		query := model.SongDB.Model(&image.TemplatePlan{}).
			Preload(`Template.Category`).Preload(`Category`).
			Where("branch_id = ?", branch.BranchID).
			Where("begin_time < ?", now).
			Where("category_id = ?", category.ID).
			Where("end_time > ?", now).
			Where("status in (?)", []image.PlanStatus{
				image.PlanStatusInit,
				image.PlanStatusAudit,
				image.PlanStatusReject,
				image.PlanStatusUpdated,
				image.PlanStatusFailed,
			}).
			Order("begin_time")

		query.Where("module = ?", image.TemplateModuleBranch).First(&plan.BranchPlan)
		query.Where("module = ?", image.TemplateModuleCentre).First(&plan.CenterPlan)

		response = append(response, plan)
	}

	return response
}

type imageOverview struct {
	CategoryID    int      `json:"category_id"`
	CategoryTitle string   `json:"category_title"`
	CategoryDisk  string   `json:"category_disk"`
	CenterPlanID  int      `json:"center_plan_id"`
	BranchPlanID  int      `json:"branch_plan_id"`
	CenterImages  []string `json:"center_images"`
	BranchImages  []string `json:"branch_images"`
}

func getOverview(branch bridgeBranch.MetaBranch, items []imagePlan) []imageOverview {
	var response []imageOverview

	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		// 清理上一次数据
		tx.Table(image.TableOverview).Where("branch_id = ?", branch.BranchID).Delete(&image.Overview{})
		for _, item := range items {
			params := util.Params{
				"branch_id": branch.BranchID,
				"category":  item.Category,
			}
			if item.CenterPlan.ID == 0 && item.BranchPlan.ID == 0 {
				logger.Entry().WithField("params", params).Info("模板应用信息为空，跳过处理")
				continue
			}
			// 返回数据
			overview := imageOverview{
				CategoryID:    item.Category.ID,
				CategoryTitle: item.Category.Title,
				CategoryDisk:  item.Category.Disk,
			}
			// 保存数据
			data := image.Overview{
				CategoryID: item.Category.ID,
				BranchID:   branch.BranchID,
				BranchName: branch.BranchName,
				BizType:    branch.BizType,
			}

			if item.CenterPlan.ID > 0 {
				overview.CenterPlanID = item.CenterPlan.ID
				template := getPlanTemplate(item.CenterPlan)
				overview.CenterImages = template.Images

				data.CenterPlanID = item.CenterPlan.ID
				p := image.NewOverviewPlan(item.CenterPlan)
				data.CenterPlan = &p
				data.CenterTemplateID = template.ID
				t := image.NewOverviewTemplate(template)
				data.CenterTemplate = &t
			} else {
				logger.Entry().WithField("params", params).Info("总部模板应用信息为空")
			}

			if item.BranchPlan.ID > 0 {
				overview.BranchPlanID = item.BranchPlan.ID
				template := getPlanTemplate(item.BranchPlan)
				overview.BranchImages = template.Images

				p := image.NewOverviewPlan(item.BranchPlan)
				data.BranchPlan = &p
				data.BranchPlanID = item.BranchPlan.ID
				data.BranchTemplateID = template.ID
				t := image.NewOverviewTemplate(template)
				data.BranchTemplate = &t
			} else {
				logger.Entry().WithField("params", params).Info("门店模板应用信息为空")
			}

			params.Set("overview", overview)
			response = append(response, overview)
			logger.Entry().WithField("params", params).Info("获取门店广告应用信息")
			if err := tx.Create(&data).Error; nil != err {
				return err
			}
		}
		return nil
	})

	if err != nil {
		logger.Entry().WithError(err).WithField("branch_id", branch.BranchID).WithField("response", response).Error("获取门店广告信息错误")
	}

	return response
}

func getPlanTemplate(plan image.TemplatePlan) image.Template {
	var template image.Template
	model.SongDB.Where("id = ?", plan.TemplateID).First(&template)

	return template
}

// CallBackBranchImageOverview 更新状态
func CallBackBranchImageOverview(c *gin.Context) {
	params := util.Params{
		"ip":  c.ClientIP(),
		"url": c.Request.URL.String(),
	}
	logger.Entry().WithField("params", params).Info("门店广告状态回传")
	var request struct {
		BranchID string `json:"branch_id" form:"branch_id"`
		Params   []struct {
			Params struct {
				CategoryID    int      `json:"category_id"`
				CategoryTitle string   `json:"category_title"`
				CategoryDisk  string   `json:"category_disk"`
				CenterPlanID  int      `json:"center_plan_id"`
				BranchPlanID  int      `json:"branch_plan_id"`
				CenterImages  []string `json:"center_images"`
				BranchImages  []string `json:"branch_images"`
			} `json:"params"`
			CenterSuccess bool `json:"center_success"`
			BranchSuccess bool `json:"branch_success"`
		} `json:"params"`
	}

	if err := c.ShouldBindJSON(&request); nil != err {
		logger.Entry().WithField("params", params).WithError(err).Error("参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	params.Set("request", request)
	logger.Entry().WithField("params", params).Info("门店广告回传参数")

	err := model.SongDB.Transaction(func(tx *gorm.DB) error {
		for _, item := range request.Params {
			if item.Params.BranchPlanID > 0 {
				if err := tx.Model(&image.TemplatePlan{}).Where("id = ?", item.Params.BranchPlanID).Update("status", getParamsStatus(item.BranchSuccess)).Error; nil != err {
					return err
				}
			}

			if item.Params.CenterPlanID > 0 {
				if err := tx.Model(&image.TemplatePlan{}).Where("id = ?", item.Params.CenterPlanID).Update("status", getParamsStatus(item.CenterSuccess)).Error; nil != err {
					return err
				}
			}

		}
		return nil
	})

	if err != nil {
		logger.Entry().WithError(err).WithField("params", params).Error("更新状态错误")
		api.ServerError(c, fmt.Sprintf("更新错误:%s", err.Error()))
		return
	}

	api.NoContent(c)
}

func getParamsStatus(success bool) image.PlanStatus {
	if success {
		return image.PlanStatusUpdated
	}

	return image.PlanStatusFailed
}
