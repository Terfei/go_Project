package support

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
)

// GetDisk 获取盘符信息
func GetDisk(c *gin.Context) {
	var items []meta.Disk
	model.SongDB.Find(&items)

	response := make(map[string]map[string]string)
	for _, item := range items {
		response[item.Category] = map[string]string{
			"local": item.LocalDisk,
			"share": item.ShareDisk,
		}
	}

	api.Make(c, response)
}
