package support

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
)

// GetAccType 公播类型
func GetAccType(c *gin.Context) {
	response := make(map[song.AccType]string)

	response[song.AccTypeUnknow] = "全部"
	response[song.AccTypeCK] = "CK"
	response[song.AccTypeKP] = "KP"
	response[song.AccTypeGala] = "Gala"

	api.Make(c, response)
}
