package support

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/song"
)

// GetAccompanyCategory 歌曲类别
func GetAccompanyCategory(c *gin.Context) {
	var items []song.AccompanyCategory

	model.SongDB.Model(&song.AccompanyCategory{}).Find(&items)

	api.Make(c, items)
}
