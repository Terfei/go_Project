package support

import (
	"fmt"

	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/image"
)

// GetBranchTemplates 门店模板列表
func GetBranchTemplates(c *gin.Context) {
	var request struct {
		CategoryID int `json:"category_id" form:"category_id"`
	}
	if err := c.ShouldBindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("门店模板助手接口参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	query := model.SongDB.Model(&image.Image{}).Scopes(
		songdb.ColumnEqualScope(`module`, image.TemplateModuleBranch),
	)
	if request.CategoryID > 0 {
		query = query.Where("category_id = ?", request.CategoryID)
	}

	var items []image.Template
	query.Find(&items)

	api.Make(c, items)
}

// GetCentreTemplates 总部模板列表
func GetCentreTemplates(c *gin.Context) {
	var request struct {
		CategoryID int `json:"category_id" form:"category_id"`
	}
	if err := c.ShouldBindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("门店模板助手接口参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	query := model.SongDB.Model(&image.Image{}).Scopes(
		songdb.ColumnEqualScope(`module`, image.TemplateModuleCentre),
	)
	if request.CategoryID > 0 {
		query = query.Where("category_id = ?", request.CategoryID)
	}

	var items []image.Template
	query.Find(&items)

	api.Make(c, items)
}
