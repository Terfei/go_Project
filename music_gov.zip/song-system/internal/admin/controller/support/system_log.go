package support

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/meta"
)

// GetSystemLogModule 获取模板列表
func GetSystemLogModule(c *gin.Context) {
	api.Make(c, meta.ModuleName)
}
