package support

import (
	"fmt"

	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/image"
)

// GetImages 图片分类
func GetImages(c *gin.Context) {
	var request struct {
		Title      string `json:"title" form:"title"`
		CategoryID int    `json:"category_id" form:"category_id"`
	}
	if err := c.ShouldBindQuery(&request); nil != err {
		logger.Entry().WithError(err).Error("图库助手接口参数错误")
		api.Unprocessable(c, fmt.Sprintf("参数错误:%s", err.Error()))
		return
	}

	query := model.SongDB.Model(&image.Image{}).Scopes(
		songdb.ColumnLikeScope(`filename`, request.Title),
	)
	if request.CategoryID > 0 {
		query = query.Where("category_id = ?", request.CategoryID)
	}

	var items []image.Image
	query.Find(&items)

	api.Make(c, items)
}
