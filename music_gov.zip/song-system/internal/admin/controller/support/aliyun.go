package support

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/util"
)

// GetAliyunStsToken 安全签名
func GetAliyunStsToken(c *gin.Context) {
	conf := config.Setting.Aliyun.Oss
	resp, err := util.NewAliyunOss(conf).StsToken()
	if nil != err {
		logger.NewEntry().WithError(err).Error("请求阿里云Sts Token")
		api.ServerError(c, err.Error())
		return
	}

	api.Make(c, map[string]interface{}{
		`access_key_id`:     resp.Credentials.AccessKeyId,
		`access_key_secret`: resp.Credentials.AccessKeySecret,
		`sts_token`:         resp.Credentials.SecurityToken,
		`expire`:            resp.Credentials.Expiration.Local().Format(`2006-01-02 15:04:05`),
		`region`:            conf.Region,
		`bucket`:            conf.Bucket,
		`domain`:            conf.Domain,
	})
}
