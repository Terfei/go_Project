package support

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/user"
)

// GetRoleClassify 角色类别列表
func GetRoleClassify(c *gin.Context) {
	var rcs []user.RoleClassify
	if err := model.SongDB.Find(&rcs).Error; nil != err {
		logger.Entry().WithError(err).Error("获取角色类别列表失败")
		api.ServerError(c, "获取角色类别列表失败")
		return
	}

	api.Make(c, map[string]interface{}{
		`list`: rcs,
	})
}
