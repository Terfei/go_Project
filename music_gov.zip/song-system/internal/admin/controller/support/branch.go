package support

import (
	"github.com/gin-gonic/gin"
	uuid "github.com/satori/go.uuid"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/bridge/users"
)

// GetBranches 门店列表
func GetBranches(c *gin.Context) {
	var items []branch.MetaBranch
	if err := model.BridgeDB.Model(&branch.MetaBranch{}).Where(`delete_time is null`).Find(&items).Error; nil != err {
		logger.Entry().WithError(err).Error("获取门店列表失败")
		api.ServerError(c, "获取门店列表失败")
		return
	}

	staff := middleware.StaffFromContext(c)
	api.Make(c, filterStaffBranches(staff, items))
}

type branchResponse struct {
	branch.MetaBranch
	DistrictID uuid.UUID `json:"district_id"`
}

func filterStaffBranches(staff *users.Staff, branches []branch.MetaBranch) []branchResponse {
	cityMap := branch.AllCity()
	var response []branchResponse
	branchMap := make(map[uuid.UUID]branchResponse)
	for _, item := range branches {
		city, _ := cityMap[item.CityID]
		tmp := branchResponse{
			MetaBranch: item,
			DistrictID: city.DistrictID,
		}

		branchMap[item.BranchID] = tmp

		response = append(response, tmp)
	}

	if staff.IsAdmin() {
		return response
	}

	var items []branchResponse

	for _, i := range staff.BranchIDs {
		if item, ok := branchMap[i]; ok {
			items = append(items, item)
		}
	}

	return items
}

// GetBizType 直营 | 加盟
func GetBizType(c *gin.Context) {
	api.Make(c, map[int]string{
		0: "直营",
		1: "加盟",
	})
}

// GetMetaDistrict 区域列表
func GetMetaDistrict(c *gin.Context) {
	query := model.BridgeDB.Model(&branch.MetaDistrict{})
	var MetaDistricts []branch.MetaDistrict
	if err := query.Where(`delete_time is null`).Find(&MetaDistricts).Error; nil != err {
		logger.Entry().WithError(err).Error("获取区域列表失败")
		api.ServerError(c, "获取区域列表失败")
		return
	}
	api.Make(c, MetaDistricts)
}
