package support

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/user"
)

// GetPermissions 权限列表
func GetPermissions(c *gin.Context) {
	var ps []user.Permission
	if err := model.SongDB.Find(&ps).Error; nil != err {
		logger.Entry().WithError(err).Error("获取权限列表失败")
		api.ServerError(c, "获取权限列表失败")
		return
	}

	api.Make(c, map[string]interface{}{
		`list`: ps,
	})
}
