package support

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/image"
)

// GetImageCategory 图片分类
func GetImageCategory(c *gin.Context) {
	var items []image.Category

	model.SongDB.Model(&image.Category{}).Find(&items)

	api.Make(c, items)
}
