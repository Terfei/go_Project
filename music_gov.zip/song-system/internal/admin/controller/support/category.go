package support

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/vod/song-system/internal/model/songdb/branch"
)

// GetAuthorizeCategory 授权类别
func GetAuthorizeCategory(c *gin.Context) {

	api.Make(c, map[branch.AuthorizeCategory]string{
		branch.AuthorizeCategorySong: "曲库",
	})
}
