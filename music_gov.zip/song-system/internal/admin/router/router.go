package router

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/controller"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/controller/branch"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/controller/image"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/controller/meta"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/controller/report"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/controller/song"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/controller/support"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/controller/tag"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/controller/user"
	"gitlab.omytech.com.cn/vod/song-system/internal/admin/middleware"
)

// Router 全局 router
var Router *gin.Engine

// Init 初始化执行
func Init() {
	Router = gin.Default()
	Router.POST(`/api/login`, controller.Login) // api/login

	Router.GET(`/api/support/disk`, support.GetDisk) //盘符信息

	Router.POST(`/api/support/sync/callback`, support.PostBranchSync)                       //回传同步信息
	Router.POST(`/api/support/import/branch/accompany`, support.ImportBranchAccompanyClick) //导入门店歌曲点播数据
	Router.POST(`/api/support/accompany/click`, support.PostVodAccompanyClick)              //vod点播
	Router.GET(`/api/support/branch/ad`, support.GetBranchImageOverview)                    //门店广告
	Router.POST(`/api/support/branch/ad`, support.CallBackBranchImageOverview)              //门店广告（回传）

	// Simple group: v1
	api := Router.Group(`/api`, middleware.Auth())
	{
		api.GET(`/menus`, controller.GetMenu) //菜单

		api.PATCH(`/modify-password`, user.UpdatePassword)
		api.GET(`/setting`, controller.GetSetting)

		// 基础api
		supportAPI := api.Group(`/support`)
		{
			supportAPI.GET(`/roles`, support.GetRoles)
			supportAPI.GET(`/role-classify`, support.GetRoleClassify)
			supportAPI.GET(`/permissions`, support.GetPermissions)
			supportAPI.GET(`/authorize/category`, support.GetAuthorizeCategory) //授权获取类别
			supportAPI.GET(`/biz-type`, support.GetBizType)                     //直营 | 加盟
			supportAPI.GET(`/meta-district`, support.GetMetaDistrict)           // 区域列表
			supportAPI.GET(`/branches`, support.GetBranches)                    //门店列表
			supportAPI.GET(`/acc-type`, support.GetAccType)                     //公播类型
			supportAPI.GET(`/system-log-modules`, support.GetSystemLogModule)   //获取操作日志模块列表
			supportAPI.GET(`/aliyun/sts-token`, support.GetAliyunStsToken)      // 阿里云oss sts token
			supportAPI.GET(`/version-type`, support.GetVersionType)             // 获取批次类别
			supportAPI.GET(`/image/category`, support.GetImageCategory)         //图片类型分类
			supportAPI.GET(`/accompany/category`, support.GetAccompanyCategory) //歌曲类别
			supportAPI.GET(`/images`, support.GetImages)                        //图库

			supportAPI.GET(`/branch-templates`, support.GetBranchTemplates) //门店模板列表
			supportAPI.GET(`/centre-templates`, support.GetCentreTemplates) //总部模板列表
		}

		userAPI := api.Group(`/user`)
		{
			userAPI.GET(`/staffs`, middleware.Permission(`用户管理>账号管理`), user.GetStaffs)
			userAPI.GET(`/staff/:id`, middleware.Permission(`用户管理>账号管理>查询`), user.ShowStaff)
			userAPI.PATCH(`/staff/:id`, middleware.Permission(`用户管理>账号管理>修改`), user.PatchStaff)
			userAPI.PATCH(`/staff/:id/reset-password`, middleware.Permission(`用户管理>账号管理>重置密码`), user.ResetPassword)

			userAPI.GET(`/role-classify`, middleware.Permission(`用户管理>角色类别管理`), user.GetRoleClassify)
			userAPI.GET(`/role-classify/:id`, middleware.Permission(`用户管理>角色类别管理>查询`), user.ShowRoleClassify)
			userAPI.POST(`/role-classify`, middleware.Permission(`用户管理>角色类别管理>新增`), user.PostRoleClassify)
			userAPI.PATCH(`/role-classify/:id`, middleware.Permission(`用户管理>角色类别管理>修改`), user.PatchRoleClassify)
			userAPI.DELETE(`/role-classify/:id`, middleware.Permission(`用户管理>角色类别管理>删除`), user.DeleteRoleClassify)

			userAPI.GET(`/roles`, middleware.Permission(`用户管理>角色管理`), user.GetRoles)
			userAPI.GET(`/role/:id`, middleware.Permission(`用户管理>角色管理>查询`), user.ShowRole)
			userAPI.POST(`/role`, middleware.Permission(`用户管理>角色管理>新增`), user.PostRole)
			userAPI.PATCH(`/role/:id`, middleware.Permission(`用户管理>角色管理>修改`), user.PatchRole)
			userAPI.DELETE(`/role/:id`, middleware.Permission(`用户管理>角色管理>删除`), user.DeleteRole)
		}

		songAPI := api.Group(`/song`)
		{
			songAPI.GET(`/singer`, middleware.Permission(`曲库管理>歌星管理`), song.GetSinger)                               // 歌手列表
			songAPI.POST(`/singer`, middleware.Permission(`曲库管理>歌星管理>新增`), song.PostSinger)                          // 新增导入歌手
			songAPI.PATCH(`/singer`, middleware.Permission(`曲库管理>歌星管理>修改`), song.PatchSinger)                        // 更新导入歌手
			songAPI.DELETE(`/singer`, middleware.Permission(`曲库管理>歌星管理>导入删除`), song.DeleteSinger)                    //excel删除歌手
			songAPI.DELETE(`/batch/singer`, middleware.Permission(`曲库管理>歌星管理>批量删除`), song.BatchDeleteSinger)         //批量删除
			songAPI.PATCH(`/save-singer-image/:id`, middleware.Permission(`曲库管理>歌星管理>修改歌星图片`), song.SaveSingerImage) // 修改歌手图片

			songAPI.GET(`/accompany`, middleware.Permission(`曲库管理>歌曲管理`), song.GetAccompany)                       //歌曲列表
			songAPI.POST(`/accompany`, middleware.Permission(`曲库管理>歌曲管理>新增`), song.PostAccompany)                  //新增歌曲
			songAPI.PATCH(`/accompany`, middleware.Permission(`曲库管理>歌曲管理>修改`), song.UpdateAccompany)               //修改歌曲
			songAPI.DELETE(`/accompany`, middleware.Permission(`曲库管理>歌曲管理>导入删除`), song.ExcelDeleteAccompany)       //excel删除歌曲
			songAPI.DELETE(`/batch/accompany`, middleware.Permission(`曲库管理>歌曲管理>批量删除`), song.BatchDeleteAccompany) //批量删除

			songAPI.GET(`/mids`, middleware.Permission(`曲库管理>MID资料管理`), song.GetMids)                       // mid列表
			songAPI.POST(`/mids`, middleware.Permission(`曲库管理>MID资料管理>新增`), song.PostMid)                   // 导入mid
			songAPI.PATCH(`/mids/:id`, middleware.Permission(`曲库管理>MID资料管理>修改`), song.PatchMid)             // mid修改
			songAPI.DELETE(`/batch/mids`, middleware.Permission(`曲库管理>MID资料管理>批量删除`), song.BatchDeleteMids) //批量删除

			songAPI.GET(`/new-songs`, middleware.Permission(`曲库管理>新歌管理`), song.GetNewSongs)

			songAPI.GET(`/wallpaper`, middleware.Permission(`曲库管理>动态壁纸管理`), song.GetWallpaper)                       //excel动态壁纸
			songAPI.POST(`/wallpaper`, middleware.Permission(`曲库管理>动态壁纸管理>新增`), song.PostWallpaper)                  //excel导入新增动态壁纸
			songAPI.PATCH(`/wallpaper`, middleware.Permission(`曲库管理>动态壁纸管理>修改`), song.UpdateWallpaper)               //excel修改动态壁纸
			songAPI.DELETE(`/batch/wallpaper`, middleware.Permission(`曲库管理>动态壁纸管理>批量删除`), song.BatchDeleteWallpaper) //批量删除动态壁纸

			songAPI.GET(`/party/dance`, middleware.Permission(`曲库管理>派对舞曲管理`), song.GetPartyDance)                       //排队舞曲
			songAPI.POST(`/party/dance`, middleware.Permission(`曲库管理>派对舞曲管理>新增`), song.PostPartyDance)                  //excel派对舞曲新增
			songAPI.PATCH(`/party/dance`, middleware.Permission(`曲库管理>派对舞曲管理>修改`), song.UpdatePartyDance)               //excel派对舞曲修改
			songAPI.DELETE(`/batch/party/dance`, middleware.Permission(`曲库管理>派对舞曲管理>批量删除`), song.BatchDeletePartyDance) //派对舞曲删除

			songAPI.GET(`/acc`, middleware.Permission(`曲库管理>公播管理`), song.GetAcc)                       //公播列表
			songAPI.POST(`/acc`, middleware.Permission(`曲库管理>公播管理>新增`), song.PostAcc)                  //新增公播
			songAPI.PATCH(`/acc`, middleware.Permission(`曲库管理>公播管理>修改`), song.UpdateAcc)               //修改公播
			songAPI.DELETE(`/batch/acc`, middleware.Permission(`曲库管理>公播管理>批量删除`), song.BatchDeleteAcc) //删除公播

			songAPI.GET(`/act/video`, middleware.Permission(`曲库管理>跳舞视频管理`), song.GetActVideo)                       //跳舞视频列表
			songAPI.POST(`/act/video`, middleware.Permission(`曲库管理>跳舞视频管理>新增`), song.PostActVideo)                  //新增跳舞视频
			songAPI.PATCH(`/act/video`, middleware.Permission(`曲库管理>跳舞视频管理>修改`), song.UpdateActVideo)               //修改跳舞视频
			songAPI.DELETE(`/batch/act/video`, middleware.Permission(`曲库管理>跳舞视频管理>批量删除`), song.BatchDeleteActVideo) //删除跳舞视频

			songAPI.GET(`/banned`, middleware.Permission(`曲库管理>禁歌管理`), song.GetBanned)                       // 禁歌列表
			songAPI.POST(`/banned`, middleware.Permission(`曲库管理>禁歌管理>新增`), song.PostBanned)                  // 新增禁歌
			songAPI.PATCH(`/banned/:id`, middleware.Permission(`曲库管理>禁歌管理>修改`), song.PatchBanned)            // 修改禁歌
			songAPI.DELETE(`/batch/banned`, middleware.Permission(`曲库管理>禁歌管理>批量删除`), song.BatchDeleteBanned) //批量删除
			songAPI.POST(`/import-banned`, middleware.Permission(`曲库管理>禁歌管理>导入`), song.ImportBanned)         // 导入禁歌
			songAPI.GET(`/export-banned`, middleware.Permission(`曲库管理>禁歌管理>导出`), song.ExportBanned)          // 导出禁歌

		}

		tagAPI := api.Group(`/tag`)
		{
			tagAPI.GET(`/singer-area`, middleware.Permission(`曲库管理>类型管理`), tag.GetSingerArea)              // 歌手区域列表
			tagAPI.POST(`/singer-area`, middleware.Permission(`曲库管理>类型管理>新增`), tag.PostSingerArea)         // 添加歌手区域
			tagAPI.PATCH(`/singer-area/:id`, middleware.Permission(`曲库管理>类型管理>修改`), tag.PatchSingerArea)   // 编辑歌手区域
			tagAPI.DELETE(`/singer-area/:id`, middleware.Permission(`曲库管理>类型管理>删除`), tag.DeleteSingerArea) // 删除歌手区域

			tagAPI.GET(`/accompany-audioqlty`, middleware.Permission(`曲库管理>类型管理`), tag.GetAccompanyAudioqlty)              //伴奏音频质量
			tagAPI.POST(`/accompany-audioqlty`, middleware.Permission(`曲库管理>类型管理>新增`), tag.PostAccompanyAudioqlty)         //添加伴奏音频质量
			tagAPI.PATCH(`/accompany-audioqlty/:id`, middleware.Permission(`曲库管理>类型管理>修改`), tag.PatchAccompanyAudioqlty)   //编辑音频质量
			tagAPI.DELETE(`/accompany-audioqlty/:id`, middleware.Permission(`曲库管理>类型管理>删除`), tag.DeleteAccompanyAudioqlty) //删除音频质量

			tagAPI.GET(`/accompany-videoqlty`, middleware.Permission(`曲库管理>类型管理`), tag.GetAccompanyVideoqlty)              //伴奏视频质量
			tagAPI.POST(`/accompany-videoqlty`, middleware.Permission(`曲库管理>类型管理>新增`), tag.PostAccompanyVideoqlty)         //添加伴奏视频质量
			tagAPI.PATCH(`/accompany-videoqlty/:id`, middleware.Permission(`曲库管理>类型管理>修改`), tag.PatchAccompanyVideoqlty)   //编辑视频质量
			tagAPI.DELETE(`/accompany-videoqlty/:id`, middleware.Permission(`曲库管理>类型管理>删除`), tag.DeleteAccompanyVideoqlty) //删除视频质量

			tagAPI.GET(`/accompany-tag`, middleware.Permission(`曲库管理>类型管理`), tag.GetAccompanyTag)              //伴奏伴奏标签
			tagAPI.POST(`/accompany-tag`, middleware.Permission(`曲库管理>类型管理>新增`), tag.PostAccompanyTag)         //添加伴奏标签
			tagAPI.PATCH(`/accompany-tag/:id`, middleware.Permission(`曲库管理>类型管理>修改`), tag.PatchAccompanyTag)   //编辑伴奏标签
			tagAPI.DELETE(`/accompany-tag/:id`, middleware.Permission(`曲库管理>类型管理>删除`), tag.DeleteAccompanyTag) //删除伴奏语种

			tagAPI.GET(`/accompany-language`, middleware.Permission(`曲库管理>类型管理`), tag.GetAccompanyLanguage)              //伴奏语种
			tagAPI.POST(`/accompany-language`, middleware.Permission(`曲库管理>类型管理>新增`), tag.PostAccompanyLanguage)         //添加伴奏语种
			tagAPI.PATCH(`/accompany-language/:id`, middleware.Permission(`曲库管理>类型管理>修改`), tag.PatchAccompanyLanguage)   //编辑伴奏语种
			tagAPI.DELETE(`/accompany-language/:id`, middleware.Permission(`曲库管理>类型管理>删除`), tag.DeleteAccompanyLanguage) //删除伴奏语种

			tagAPI.GET(`/accompany-version`, middleware.Permission(`曲库管理>类型管理`), tag.GetAccompanyVersion)              //伴奏版本
			tagAPI.POST(`/accompany-version`, middleware.Permission(`曲库管理>类型管理>新增`), tag.PostAccompanyVersion)         //添加伴奏版本
			tagAPI.PATCH(`/accompany-version/:id`, middleware.Permission(`曲库管理>类型管理>修改`), tag.PatchAccompanyVersion)   //编辑伴奏版本
			tagAPI.DELETE(`/accompany-version/:id`, middleware.Permission(`曲库管理>类型管理>删除`), tag.DeleteAccompanyVersion) //删除伴奏版本

			tagAPI.GET(`/emo`, middleware.Permission(`曲库管理>类型管理`), tag.GetEmoTag)              //情绪标签
			tagAPI.POST(`/emo`, middleware.Permission(`曲库管理>类型管理>新增`), tag.PostEmoTag)         //添加情绪标签
			tagAPI.PATCH(`/emo/:id`, middleware.Permission(`曲库管理>类型管理>修改`), tag.PatchEmoTag)   //编辑情绪标签
			tagAPI.DELETE(`/emo/:id`, middleware.Permission(`曲库管理>类型管理>删除`), tag.DeleteEmoTag) //删除情绪标签

			tagAPI.GET(`/accompany-category`, middleware.Permission(`曲库管理>类型管理`), tag.GetAccompanyCategory)              //伴奏分类
			tagAPI.POST(`/accompany-category`, middleware.Permission(`曲库管理>类型管理>新增`), tag.PostAccompanyCategory)         //添加伴奏分类
			tagAPI.PATCH(`/accompany-category/:id`, middleware.Permission(`曲库管理>类型管理>修改`), tag.PatchAccompanyCategory)   //编辑伴奏分类
			tagAPI.DELETE(`/accompany-category/:id`, middleware.Permission(`曲库管理>类型管理>删除`), tag.DeleteAccompanyCategory) //删除伴奏分类
		}

		metaAPI := api.Group(`/meta`)
		{
			metaAPI.GET(`/system-log`, middleware.Permission(`操作日志>操作日志`), meta.GetSystemLog)           //获取操作日志列表
			metaAPI.GET(`/export/system-log`, middleware.Permission(`操作日志>操作日志`), meta.ExportSystemLog) //导出

			metaAPI.GET(`/version/overview`, middleware.Permission(`下载管理>批次管理`), meta.GetVersionOverview)              //批次
			metaAPI.POST(`/version/overview`, middleware.Permission(`下载管理>批次管理>生成批次`), meta.CreateVersionOverview)     //生成批次
			metaAPI.DELETE(`/version/overview/:id`, middleware.Permission(`下载管理>批次管理>删除`), meta.DeleteVersionOverview) //删除批次
			metaAPI.POST(`/branch/version/sync`, middleware.Permission(`下载管理>批次管理>门店同步`), meta.CreateBranchSync)       //门店同步
		}

		branchAPI := api.Group(`/branch`)
		{
			branchAPI.GET(`/authorize`, middleware.Permission(`门店管理>门店授权管理`), branch.GetAuthorize)            //获取门店授权列表
			branchAPI.POST(`/authorize`, middleware.Permission(`门店管理>门店授权管理>新增`), branch.PostAuthorize)       //添加门店授权列表
			branchAPI.PATCH(`/authorize/:id`, middleware.Permission(`门店管理>门店授权管理>修改`), branch.PatchAuthorize) //编辑门店授权列表

			branchAPI.GET(`/authorize/export`, middleware.Permission(`门店管理>门店授权管理>导出`), branch.ExportAuthorize) //获取门店授权列表
			branchAPI.POST(`/authorize/copy`, branch.CopyBranchAuthorize)                                       //复制门店授权

			branchAPI.GET(`/authorize-history`, middleware.Permission(`门店管理>门店授权记录`), branch.GetAuthorizeHistory) //门店授权历史

			branchAPI.GET(`/versions`, middleware.Permission(`下载管理>批次管理`), branch.GetBranchVersion)          //门店批次详情
			branchAPI.POST(`/versions`, middleware.Permission(`下载管理>批次管理`), branch.CreateBranchVersion)      //新增门店批次
			branchAPI.PATCH(`/versions/:id`, middleware.Permission(`下载管理>批次管理`), branch.UpdateBranchVersion) //修改门店批次

			branchAPI.GET(`/versions/stats`, middleware.Permission(`下载管理>批次下载记录`), branch.GetVersionStat)         //门店批次下载记录
			branchAPI.GET(`/version/fail-files`, middleware.Permission(`下载管理>批次下载记录`), branch.GetVersionFailFile) //门店批次下载失败文件
		}

		imageAPI := api.Group(`/image`)
		{
			templateAPI := imageAPI.Group(`/template`)
			{
				templateAPI.GET(`/branch`, middleware.Permission(`广告管理>门店模板`), image.GetBranchTemplate)            //门店模板列表
				templateAPI.GET(`/branch/:id`, middleware.Permission(`广告管理>门店模板>查询`), image.ShowBranchTemplate)    //查看门店模板
				templateAPI.POST(`/branch`, middleware.Permission(`广告管理>门店模板>新增`), image.PostBranchTemplate)       //新增门店模板
				templateAPI.PATCH(`/branch/:id`, middleware.Permission(`广告管理>门店模板>编辑`), image.PatchBranchTemplate) //修改门店模板
				templateAPI.DELETE(`/branch`, middleware.Permission(`广告管理>门店模板>删除`), image.DeleteBranchTemplate)   //删除门店模板

				templateAPI.GET(`/centre`, middleware.Permission(`广告管理>总部模板`), image.GetCentreTemplate)            //总部模板列表
				templateAPI.GET(`/centre/:id`, middleware.Permission(`广告管理>总部模板>查询`), image.ShowCentreTemplate)    //查看总部模板
				templateAPI.POST(`/centre`, middleware.Permission(`广告管理>总部模板>新增`), image.PostCentreTemplate)       //新增总部模板
				templateAPI.PATCH(`/centre/:id`, middleware.Permission(`广告管理>总部模板>编辑`), image.PatchCentreTemplate) //修改总部模板
				templateAPI.DELETE(`/centre`, middleware.Permission(`广告管理>总部模板>删除`), image.DeleteCentreTemplate)   //删除总部模板

				templateAPI.GET(`/branch-plan`, middleware.Permission(`广告管理>门店模板应用`), image.GetBranchTemplatePlan)                      //门店模板列表
				templateAPI.GET(`/branch-plan/:id`, middleware.Permission(`广告管理>门店模板应用>查询`), image.ShowBranchTemplatePlan)              //查看门店模板
				templateAPI.POST(`/branch-plan`, middleware.Permission(`广告管理>门店模板应用>新增`), image.PostBranchTemplatePlan)                 //新增门店模板
				templateAPI.PATCH(`/branch-plan/:id`, middleware.Permission(`广告管理>门店模板应用>编辑`), image.PatchBranchTemplatePlan)           //修改门店模板
				templateAPI.DELETE(`/branch-plan`, middleware.Permission(`广告管理>门店模板应用>删除`), image.DeleteBranchTemplatePlan)             //删除门店模板
				templateAPI.PATCH(`/branch-plan-audit`, middleware.Permission(`广告管理>门店模板应用>审核通过`), image.AuditBranchTemplatePlan)       //审核门店模板
				templateAPI.PATCH(`/branch-plan/:id/reject`, middleware.Permission(`广告管理>门店模板应用>审核驳回`), image.RejectBranchTemplatePlan) //驳回门店模板

				templateAPI.GET(`/centre-plan`, middleware.Permission(`广告管理>总部模板应用`), image.GetCentreTemplatePlan)            //总部模板列表
				templateAPI.GET(`/centre-plan/:id`, middleware.Permission(`广告管理>总部模板应用>查询`), image.ShowCentreTemplatePlan)    //查看总部模板
				templateAPI.POST(`/centre-plan`, middleware.Permission(`广告管理>总部模板应用>新增`), image.PostCentreTemplatePlan)       //新增总部模板
				templateAPI.PATCH(`/centre-plan/:id`, middleware.Permission(`广告管理>总部模板应用>修改`), image.PatchCentreTemplatePlan) //修改总部模板
				templateAPI.DELETE(`/centre-plan`, middleware.Permission(`广告管理>总部模板应用>删除`), image.DeleteCentreTemplatePlan)   //删除总部模板
			}

			imageAPI.GET(`/current-ads`, middleware.Permission(`广告管理>实时广告>查询`), image.GetCurrentAd)           //实时广告
			imageAPI.GET(`/current-ads/export`, middleware.Permission(`广告管理>实时广告>导出`), image.ExportCurrentAd) //实时广告

			imageAPI.GET(`/category`, middleware.Permission(`广告管理>图库类型管理>查询`), image.GetImageCategory)           //图片类型列表
			imageAPI.POST(`/category`, middleware.Permission(`广告管理>图库类型管理>新增`), image.PostImageCategory)         //新增图片类型
			imageAPI.PATCH(`/category/:id`, middleware.Permission(`广告管理>图库类型管理>修改`), image.PatchImageCategory)   //修改图片类型
			imageAPI.DELETE(`/category/:id`, middleware.Permission(`广告管理>图库类型管理>删除`), image.DeleteImageCategory) //删除图片类型

			imageAPI.GET(`/images`, middleware.Permission(`广告管理>图库管理`), image.GetImage)                  //图片列表
			imageAPI.POST(`/images`, middleware.Permission(`广告管理>图库管理>上传`), image.PostImage)             //新增图片
			imageAPI.GET(`/search-count`, middleware.Permission(`广告管理>图库管理>查询`), image.SearchImageCount) //查询图片数量
			imageAPI.DELETE(`images/:id`, middleware.Permission(`广告管理>图库管理>删除`), image.DeleteImage)      //删除图片
		}

		reportAPI := api.Group(`/report`)
		{
			reportAPI.GET(`/accompany/rank`, middleware.Permission(`排行管理>歌曲排行>查询`), report.GetAccompanyRank) //歌曲排行
			reportAPI.POST(`/accompany-top`, middleware.Permission(`排行管理>歌曲排行>置顶`), report.PostAccompanyTop) //歌曲置顶
			reportAPI.GET(`/singer/rank`, middleware.Permission(`排行管理>歌星排行>查询`), report.GetSingerRank)       //歌手排行
			reportAPI.POST(`/singer-top`, middleware.Permission(`排行管理>歌星排行>置顶`), report.PostSingerTop)       //歌手置顶
			reportAPI.GET(`/export/accompany/rank`, middleware.Permission(`排行管理>歌曲排行>导出`), report.ExportAccompanyRank)
			reportAPI.GET(`/export/singer/rank`, middleware.Permission(`排行管理>歌星排行>导出`), report.ExportSingerRank)

			reportAPI.GET(`/accompany/top`, middleware.Permission(`排行管理>歌曲置顶列表`), report.GetAccompanyTop)                //歌曲置顶
			reportAPI.POST(`/accompany/top`, middleware.Permission(`排行管理>歌曲置顶列表`), report.PostAccompanyTop)              //歌曲置顶
			reportAPI.PATCH(`/accompany/top`, middleware.Permission(`排行管理>歌曲置顶列表>上移下移`), report.PatchAccompanyTop)       //歌曲置顶
			reportAPI.DELETE(`/accompany/top/:id`, middleware.Permission(`排行管理>歌曲置顶列表>取消置顶`), report.DeleteAccompanyTop) //歌曲置顶

			reportAPI.GET(`/singer/top`, middleware.Permission(`排行管理>歌星置顶列表`), report.GetSingerTop)                //歌手置顶
			reportAPI.POST(`/singer/top`, middleware.Permission(`排行管理>歌星置顶列表`), report.PostSingerTop)              //歌手置顶
			reportAPI.PATCH(`/singer/top`, middleware.Permission(`排行管理>歌星置顶列表>上移下移`), report.PatchSingerTop)       //歌手置顶
			reportAPI.DELETE(`/singer/top/:id`, middleware.Permission(`排行管理>歌星置顶列表>取消置顶`), report.DeleteSingerTop) //歌手置顶
		}
	}

}
