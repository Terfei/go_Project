package config

import "time"

// Setting 配置对象
var Setting setting

// setting 配置
type setting struct {
	App struct {
		Root  string
		Port  int
		Debug bool
	}

	Database struct {
		Bridge    DBConfig
		Song      DBConfig
		Sqlite    DBConfig
		SQLServer DBConfig
		Redis     RedisConfig
	}

	Jwt struct {
		Secret  string
		Timeout time.Duration
	}
	Storage struct {
		Path string
		DB   string
	}
	Aliyun struct {
		Oss OssConfig
	}

	Centre struct {
		Domain string
		Salt   string
	}
}

// OssConfig 阿里云oss配置
type OssConfig struct {
	Bucket    string
	Region    string
	Endpoint  string
	AccessID  string `toml:"access_id"`
	AccessKey string `toml:"access_key"`
	AcsRAM    string `toml:"acs_ram"`
	Domain    string
	Image     string
	Song      string
	Ad        string
	Db        string
}

// DBConfig 数据库配置
type DBConfig struct {
	Dialect  string
	Server   string
	Port     int
	User     string
	Database string
	Password string
	Log      bool
}

// RedisConfig redis config
type RedisConfig struct {
	Server   string
	Port     int
	Database int
	Password string
}
