package router

import (
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/vod/song-system/internal/branch/controller"
)

// Router 门店服务路由
var Router *gin.Engine

// Init 初始化执行
func Init() {
	Router = gin.Default()

	Router.GET(`/api/sync`, controller.DealSync) //执行同步

	Router.POST(`/api/sync`, controller.DealSync) //执行同步
}
