package controller

import (
	"context"
	"github.com/gin-gonic/gin"
	"gitlab.omytech.com.cn/gopkg/api"
	"gitlab.omytech.com.cn/gopkg/logger"
	"gitlab.omytech.com.cn/vod/song-system/internal/config"
	"gitlab.omytech.com.cn/vod/song-system/internal/model"
)

// DealSync 执行门店同步
func DealSync(c *gin.Context) {
	var request struct {
		Version  string `json:"version" form:"version"`
		BranchID string `json:"branch_id" form:"branch_id"`
		File     string `json:"file" form:"file"`
	}
	if err := c.BindJSON(&request); err != nil {
		logger.Entry().WithError(err).Error("参数错误")
		api.ServerError(c, err.Error())
		return
	}

	logger.Entry().WithField("request", request).Info("branch request")

	if err := model.RedisConnection(config.Setting.Database.Redis); nil != err {
		logger.Entry().WithError(err).Error("redis")
		api.ServerError(c, "redis error")
		return
	}

	model.Rds.HSet(context.Background(), "branch_download", request.Version, request.File)

	api.NoContent(c)
}
